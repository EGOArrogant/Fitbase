"""Retos, niveles (tiers) y feedback.

Retos: el progreso se calcula solo con los datos que la persona ya registra en la app (sesiones, diario de comidas, pasos,
proteína, series, tonelaje, peso). Los retos "manuales" los valida el organizador.
Tiers: se suben con puntos de retos completados y de constancia. Cada tier da beneficios para la persona.
Retos con cuota: en esta versión el pago se registra a mano (transferencia o efectivo) y el organizador lo marca como pagado.
Para cobrar en línea al publicar la app se conecta una pasarela (Mercado Pago, Stripe, Conekta).
"""
import datetime as dt

TIPOS_META = {
    "sesiones": ("Entrenamientos completados", "sesiones"),
    "dias_comida": ("Días registrando tus comidas", "días"),
    "dias_proteina": ("Días alcanzando tu proteína mínima", "días"),
    "dias_pasos": ("Días con 8,000 pasos o más", "días"),
    "pasos": ("Pasos totales", "pasos"),
    "series": ("Series efectivas registradas", "series"),
    "tonelaje": ("Kilos levantados en total (tonelaje)", "kg"),
    "perdida_pct": ("% de peso perdido (promedio de 7 días)", "%"),
    "manual": ("Meta personalizada (la valida el organizador)", "puntos"),
}
TIERS = [
    ("Bronce", 0, "#B07A4A", ["Insignias de reto en tu perfil", "Acceso a todos los retos gratis"]),
    ("Plata", 300, "#9AA3AF", ["5 % de descuento en retos con cuota", "Marco plateado en tu perfil"]),
    ("Oro", 800, "#D4A72C", ["10 % de descuento en retos con cuota", "Acceso anticipado a retos nuevos", "+20 mensajes al mes con el Coach IA (versión en línea)"]),
    ("Platino", 1500, "#6FB6C9", ["15 % de descuento en retos con cuota", "Retos exclusivos de nivel Platino", "Revisión mensual de tu progreso con tu entrenador"]),
    ("Diamante", 3000, "#8E75F0", ["20 % de descuento en retos con cuota", "Puedes proponer retos a la comunidad", "Insignia Diamante animada"]),
    ("Leyenda", 6000, "#E5484D", ["25 % de descuento en retos con cuota", "Tu nombre en el muro de Leyendas", "Invitación a retos con premios especiales"]),
]
FEEDBACK_TIPOS = [("idea", "Idea o mejora"), ("problema", "Algo no funciona"), ("contenido", "Contenido (ejercicios, recetas, artículos)"),
                  ("felicitacion", "Me encanta"), ("otro", "Otro")]
FEEDBACK_AREAS = ["Entrenamiento", "Nutrición", "Registro de comidas", "Mediciones", "Coach IA", "Retos", "Diseño / celular", "Entrenador", "Otra"]
FEEDBACK_ESTADOS = [("nuevo", "Nuevo"), ("revision", "En revisión"), ("planeado", "Planeado"), ("hecho", "¡Hecho!"), ("descartado", "No por ahora")]


def tier_de(puntos):
    actual = TIERS[0]
    for t in TIERS:
        if puntos >= t[1]:
            actual = t
    i = TIERS.index(actual)
    sig = TIERS[i + 1] if i + 1 < len(TIERS) else None
    pct = 100 if not sig else round((puntos - actual[1]) / (sig[1] - actual[1]) * 100)
    return {"nombre": actual[0], "min": actual[1], "color": actual[2], "beneficios": actual[3], "indice": i,
            "siguiente": sig[0] if sig else None, "faltan": (sig[1] - puntos) if sig else 0, "pct": pct,
            "descuento": [0, 5, 10, 15, 20, 25][i]}


def progreso(con, reto, uid, prot_min=None):
    """Valor actual del reto para la persona entre las fechas del reto (o desde que se inscribió)."""
    ini, fin = reto["inicio"], min(reto["fin"], str(dt.date.today()))
    t = reto["tipo"]
    q = lambda sql, *a: con.execute(sql, (uid, ini, fin) + a).fetchone()[0]
    if t == "sesiones":
        return q("SELECT COUNT(*) FROM registros WHERE usuario_id=? AND fecha BETWEEN ? AND ? AND entreno='Sí'") or 0
    if t == "dias_comida":
        return q("SELECT COUNT(DISTINCT fecha) FROM diario_comidas WHERE usuario_id=? AND fecha BETWEEN ? AND ?") or 0
    if t == "dias_proteina":
        return q("SELECT COUNT(*) FROM registros WHERE usuario_id=? AND fecha BETWEEN ? AND ? AND proteina >= ?", prot_min or 0) or 0
    if t == "dias_pasos":
        return q("SELECT COUNT(*) FROM registros WHERE usuario_id=? AND fecha BETWEEN ? AND ? AND pasos >= 8000") or 0
    if t == "pasos":
        return q("SELECT COALESCE(SUM(pasos),0) FROM registros WHERE usuario_id=? AND fecha BETWEEN ? AND ?") or 0
    if t == "series":
        return q("SELECT COUNT(*) FROM series WHERE usuario_id=? AND fecha BETWEEN ? AND ?") or 0
    if t == "tonelaje":
        return round(q("SELECT COALESCE(SUM(peso*reps),0) FROM series WHERE usuario_id=? AND fecha BETWEEN ? AND ?") or 0)
    if t == "perdida_pct":
        pesos = [r[0] for r in con.execute("SELECT peso FROM registros WHERE usuario_id=? AND fecha BETWEEN ? AND ? AND peso IS NOT NULL ORDER BY fecha",
                                           (uid, ini, fin)).fetchall()]
        if len(pesos) < 4:
            return 0
        a, b = sum(pesos[:7]) / len(pesos[:7]), sum(pesos[-7:]) / len(pesos[-7:])
        semanas = max(1, (dt.date.fromisoformat(fin) - dt.date.fromisoformat(ini)).days / 7)
        return round(min(max(0, (a - b) / a * 100), semanas * 1.0), 1)   # cuenta máximo 1 % por semana (pérdida saludable)
    if t == "manual":
        r = con.execute("SELECT progreso_manual FROM retos_inscritos WHERE reto_id=? AND usuario_id=?", (reto["id"], uid)).fetchone()
        return (r[0] or 0) if r else 0
    return 0


def estado_reto(reto):
    hoy = str(dt.date.today())
    return "proximo" if reto["inicio"] > hoy else "terminado" if reto["fin"] < hoy else "activo"


RETOS_BASE = [
    dict(titulo="21 días registrando tus comidas", descripcion="Registra al menos una comida al día durante 21 días. El hábito que más predice resultados en nutrición es medir lo que comes.",
         tipo="dias_comida", meta=21, dias=30, puntos=150, nivel="Todos", cuota=0, premios="Insignia «Diario de hierro» y 150 puntos."),
    dict(titulo="12 entrenamientos en 4 semanas", descripcion="Completa 12 sesiones en 28 días (3 por semana). Ideal para crear constancia.",
         tipo="sesiones", meta=12, dias=28, puntos=200, nivel="Todos", cuota=0, premios="Insignia «Constancia» y 200 puntos."),
    dict(titulo="Proteína 20 de 30", descripcion="Alcanza tu proteína mínima diaria 20 de los próximos 30 días.",
         tipo="dias_proteina", meta=20, dias=30, puntos=150, nivel="Todos", cuota=0, premios="Insignia «Proteína al día» y 150 puntos."),
    dict(titulo="Semana de 70,000 pasos", descripcion="Suma 70,000 pasos en 7 días (10,000 al día en promedio).",
         tipo="pasos", meta=70000, dias=7, puntos=100, nivel="Todos", cuota=0, premios="Insignia «Caminante» y 100 puntos."),
    dict(titulo="Club de las 100 toneladas", descripcion="Levanta 100,000 kg de tonelaje total en 6 semanas. Para intermedios y avanzados.",
         tipo="tonelaje", meta=100000, dias=42, puntos=400, nivel="Intermedio+", cuota=0, premios="Insignia «100 toneladas» y 400 puntos."),
    dict(titulo="Transformación 8 semanas", descripcion="Reto con premios: pierde el mayor porcentaje de peso de forma saludable (máximo 1 % por semana cuenta). "
         "Pesajes semanales validados por el organizador y fotos de inicio y final.", tipo="perdida_pct", meta=6, dias=56, puntos=600, nivel="Todos",
         cuota=299, premios="1.º lugar: 3 meses de asesoría + suplementos · 2.º: 2 meses de asesoría · 3.º: 1 mes de asesoría. Todos los que lleguen a la meta: playera del reto.",
         cupo=50, validar=1),
]
