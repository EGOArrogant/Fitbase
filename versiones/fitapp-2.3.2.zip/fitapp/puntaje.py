"""Puntaje nutricional del día (0-100) y "qué te falta".

Componentes y referencias:
- Proteína: mínimo de 1.6 g/kg para quien entrena fuerza (Morton et al. 2018, Br J Sports Med; ISSN 2017).
- Energía: cerca de la meta diaria (±10 %).
- Fibra: 14 g por cada 1000 kcal (Dietary Guidelines for Americans 2020-2025; IOM 2005).
- Frutas y verduras: al menos 400 g al día (OMS, Healthy diet, 2020).
- Azúcares libres y ultraprocesados: menos de 10 % de la energía (OMS 2015, Guideline: sugars intake);
  los ultraprocesados se asocian a mayor ingesta calórica (Hall et al. 2019, Cell Metabolism).
- Variedad: 12 o más alimentos distintos al día como indicador práctico de diversidad de la dieta.
"""
import re

import alimentos as alim
from data.recetas import RECETAS

POR_NOMBRE = {a["nombre"]: a for a in alim.ALIMENTOS}
REC_NOMBRE = {r["nombre"]: r for r in RECETAS}
FRUTA_VERDURA = {"Frutas", "Verduras"}
ULTRA = ("refresco", "jugo envasado", "nectar", "dona", "concha", "galleta", "hojuelas azucaradas", "gomitas", "chocolate con leche",
         "papas a la francesa", "papas fritas", "nuggets", "salchicha", "hot dog", "pizza", "hamburguesa", "palomitas de microondas",
         "totopos", "bebida energetica", "bebida isotonica", "yogur bebible endulzado", "cajeta", "mermelada", "azucar", "miel",
         "piloncillo", "cacahuate japones", "barra de proteina", "agua de horchata", "agua de jamaica con azucar", "agua de limon con azucar",
         "tocino", "chorizo", "cuernito", "hot cake", "granola comercial", "catsup", "salsa bbq", "aderezo")
CAMBIOS = {"Pan blanco de caja": "pan integral de caja", "Arroz blanco cocido": "arroz integral o mitad arroz y mitad verduras",
           "Refresco de cola": "agua mineral con limón o refresco sin azúcar", "Jugo envasado (néctar)": "la fruta entera",
           "Tortilla de harina de trigo": "tortilla de maíz", "Cereal de hojuelas azucaradas": "avena en hojuelas con fruta",
           "Yogur bebible endulzado": "yogur griego natural con fruta", "Bolillo": "pan integral o tortilla de maíz",
           "Papas a la francesa (fritas)": "papa cocida o al horno", "Totopos de maíz fritos": "tostadas horneadas",
           "Galletas marías": "fruta con un puño de nueces", "Concha (pan dulce)": "pan integral con crema de cacahuate",
           "Agua de horchata": "agua natural o de fruta sin azúcar", "Chocolate con leche": "chocolate oscuro 70 %"}


def _n(s):
    import unicodedata
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()


def _alimento(fila):
    if fila.get("alimento_id") is not None:
        a = alim.POR_ID.get(fila["alimento_id"])
        if a:
            return a
    return POR_NOMBRE.get(fila["alimento"])


def _componentes(fila):
    """Devuelve lista de (nombre, gramos, alimento|None) de una fila del diario; abre las recetas en ingredientes."""
    nom = fila["alimento"] or ""
    if nom.startswith("Receta: "):
        r = REC_NOMBRE.get(nom[8:])
        if r:
            m = re.search(r"([\d.]+)", fila.get("porcion") or "")
            f = float(m.group(1)) if m else 1
            return [(n, gr * f, POR_NOMBRE.get(n)) for n, gr in r["ing"]]
    return [(nom, fila.get("gramos") or 0, _alimento(fila))]


def analizar(filas, mac, mins, peso):
    tot = {k: sum((f.get(k) or 0) for f in filas) for k in ("kcal", "prot", "carb", "grasa")}
    fibra, fv, ultra_kcal, distintos = 0.0, 0.0, 0.0, set()
    for f in filas:
        partes = _componentes(f)
        for nombre, gramos, a in partes:
            distintos.add(nombre)
            if a:
                if a["por100g"].get("fibra") is not None and (f.get("fibra") is None or len(partes) > 1):
                    fibra += a["por100g"]["fibra"] * gramos / 100
                if a.get("categoria") in FRUTA_VERDURA and "jugo" not in _n(a["nombre"]):
                    fv += gramos
                if any(u in _n(a["nombre"]) for u in ULTRA):
                    ultra_kcal += (a["por100g"].get("kcal") or 0) * gramos / 100
            elif any(u in _n(nombre) for u in ULTRA) and len(partes) == 1:
                ultra_kcal += f.get("kcal") or 0
        if f.get("fibra") is not None and len(partes) == 1:
            fibra += f["fibra"]
    meta_fibra = mins.get("fibra") or round(14 * mac["kcal"] / 1000)
    pct_ultra = ultra_kcal / tot["kcal"] * 100 if tot["kcal"] else 0
    desv = abs(tot["kcal"] - mac["kcal"]) / mac["kcal"] if mac["kcal"] else 0
    lin = lambda x, a, b: max(0.0, min(1.0, (x - a) / (b - a)))   # 0 en a, 1 en b
    comp = [
        ("Proteína", 20, lin(tot["prot"], 0, mins["prot_min"]), f"{tot['prot']:.0f} g", f"mínimo {mins['prot_min']} g ({mins['prot_min'] / peso:.1f} g/kg)"),
        ("Energía", 15, 1 - lin(desv, .10, .45), f"{tot['kcal']:.0f} kcal", f"meta {mac['kcal']:.0f} kcal ±10 %"),
        ("Fibra", 20, lin(fibra, 0, meta_fibra), f"{fibra:.0f} g", f"meta {meta_fibra} g (14 g por 1000 kcal)"),
        ("Frutas y verduras", 20, lin(fv, 0, 400), f"{fv:.0f} g", "al menos 400 g (≈5 porciones)"),
        ("Azúcares y ultraprocesados", 15, 1 - lin(pct_ultra, 10, 30), f"{pct_ultra:.0f} % de tus kcal", "menos de 10 %"),
        ("Variedad", 10, lin(len(distintos), 0, 12), f"{len(distintos)} alimentos", "12 o más distintos"),
    ]
    total = round(sum(p * v for _, p, v, _, _ in comp))
    etiqueta = "Excelente" if total >= 85 else "Bueno" if total >= 70 else "Regular" if total >= 50 else "Mejorable"
    nivel = lambda v: "Muy bajo" if v < .4 else "Bajo" if v < .75 else "Bien" if v < .95 else "Excelente"
    componentes = [{"nombre": n, "max": p, "puntos": round(p * v, 1), "ratio": v, "valor": val, "meta": meta, "nivel": nivel(v)}
                   for n, p, v, val, meta in comp]
    return {"total": total, "etiqueta": etiqueta, "componentes": componentes, "tot": tot, "fibra": fibra, "meta_fibra": meta_fibra,
            "fv": fv, "pct_ultra": pct_ultra, "distintos": len(distintos), "n": len(filas),
            "sugerencias": sugerencias(filas, tot, mac, mins, fibra, meta_fibra, fv, pct_ultra, len(distintos))}


def _top(categorias, campo, n=3):
    xs = []
    for a in alim.ALIMENTOS:
        if a.get("categoria") in categorias and a["por100g"].get(campo) and a["porciones"]:
            p = a["porciones"][0]
            if p["desc"].startswith(("100 g", "1 equivalente")):
                continue
            xs.append((a["por100g"][campo] * p["g"] / 100, a["nombre"], p["desc"]))
    xs.sort(reverse=True)
    vistos, out = set(), []
    for v, nom, desc in xs:
        k = nom.split(" ")[0]
        if k not in vistos:
            vistos.add(k); out.append(f"{nom} ({desc}): {v:.0f} g")
        if len(out) == n:
            break
    return out


def _ideas(nombres, campo):
    out = []
    for n in nombres:
        a = POR_NOMBRE.get(n)
        if a and a["porciones"]:
            p = a["porciones"][0]
            out.append(f"{n} ({p['desc']}): {a['por100g'][campo] * p['g'] / 100:.0f} g")
    return out


FIBRA_TOP = None
PROT_TOP = None


def sugerencias(filas, tot, mac, mins, fibra, meta_fibra, fv, pct_ultra, distintos):
    global FIBRA_TOP, PROT_TOP
    FIBRA_TOP = FIBRA_TOP or _top({"Leguminosas", "Frutas", "Verduras", "Grasas y semillas"}, "fibra")
    PROT_TOP = PROT_TOP or _ideas(["Pechuga de pollo cocida (sin piel)", "Atún en agua (escurrido)", "Yogur griego natural sin grasa",
                                   "Huevo entero (crudo o cocido)", "Proteína whey concentrada", "Lenteja cocida"], "prot")
    s = []
    nombres = [f["alimento"] for f in filas]
    if tot["prot"] < mins["prot_min"] * .9:
        s.append({"titulo": "Proteína", "nivel": "Muy bajo" if tot["prot"] < mins["prot_min"] * .4 else "Bajo",
                  "texto": f"Te faltan {mins['prot_min'] - tot['prot']:.0f} g para tu mínimo de {mins['prot_min']} g. Repártela en 3-5 tomas de 25-40 g.",
                  "ideas": PROT_TOP})
    if fibra < meta_fibra * .9:
        cambio = next((f"Prueba cambiar {n.lower()} por {CAMBIOS[n]} en tu próxima comida." for n in nombres if n in CAMBIOS), "")
        s.append({"titulo": "Fibra", "nivel": "Muy bajo" if fibra < meta_fibra * .4 else "Bajo",
                  "texto": f"Te faltan {meta_fibra - fibra:.0f} g para tu meta de {meta_fibra} g. {cambio}".strip(), "ideas": FIBRA_TOP})
    if fv < 400:
        s.append({"titulo": "Frutas y verduras", "nivel": "Muy bajo" if fv < 160 else "Bajo",
                  "texto": f"Llevas {fv:.0f} g de 400 g. Agrega media taza de verduras a la comida y a la cena y una fruta entera como colación.",
                  "ideas": ["1 taza de brócoli, calabacita o ejotes cocidos ≈ 150 g", "1 manzana, pera o naranja mediana ≈ 150-180 g", "Ensalada de lechuga, jitomate y pepino ≈ 120 g"]})
    if pct_ultra > 10:
        cambios = [f"{n} → {CAMBIOS[n]}" for n in dict.fromkeys(nombres) if n in CAMBIOS][:3]
        s.append({"titulo": "Azúcares y ultraprocesados", "nivel": "Alto" if pct_ultra < 25 else "Muy alto",
                  "texto": f"El {pct_ultra:.0f} % de tus calorías vino de bebidas azucaradas, dulces o comida muy procesada (meta: menos de 10 %).",
                  "ideas": cambios or ["Agua natural o mineral en lugar de refresco o jugo", "Fruta con yogur natural en lugar de pan dulce"]})
    if mac["kcal"] and tot["kcal"] > mac["kcal"] * 1.1:
        s.append({"titulo": "Energía", "nivel": "Alto", "texto": f"Vas {tot['kcal'] - mac['kcal']:.0f} kcal arriba de tu meta. Un día no cambia el resultado: mira el promedio de la semana.", "ideas": []})
    elif mac["kcal"] and filas and tot["kcal"] < mac["kcal"] * .75:
        s.append({"titulo": "Energía", "nivel": "Bajo", "texto": f"Llevas {tot['kcal']:.0f} de {mac['kcal']:.0f} kcal. Si el día ya terminó, revisa que hayas registrado todo (bebidas, aceite, aderezos).", "ideas": []})
    if filas and distintos < 8:
        s.append({"titulo": "Variedad", "nivel": "Bajo", "texto": f"Comiste {distintos} alimentos distintos. Variar colores y grupos mejora vitaminas y minerales.", "ideas": []})
    return s
