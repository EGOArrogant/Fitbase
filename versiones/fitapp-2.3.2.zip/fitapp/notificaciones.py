"""Notificaciones para usuarios y actividad de clientes en tiempo (casi) real para su entrenador."""
import datetime as dt
import json

AGRUPAR_MIN = 15   # acciones repetidas del mismo tipo en este lapso se agrupan en una sola línea

# tipo -> (icono, color css)
TIPOS = {
    "entreno": ("🏋️", "s1"), "comida": ("🍽️", "s3"), "dia": ("📅", "s2"), "medicion": ("📏", "s4"), "foto": ("📸", "s5"),
    "reto": ("🏆", "s6"), "feedback": ("💬", "s2"), "perfil": ("🧭", "s4"), "cliente": ("👋", "s1"), "comentario": ("💬", "s1"),
    "plan": ("⭐", "s6"), "pago": ("💳", "s3"), "sistema": ("🔔", "s2"), "guia": ("🧭", "s1"), "ajuste": ("🛠️", "s4"),
}
FILTROS = [("", "Todo"), ("entreno", "Entrenamiento"), ("comida", "Comidas"), ("dia", "Registro diario"), ("medicion", "Mediciones"),
           ("foto", "Fotos"), ("reto", "Retos"), ("perfil", "Perfil")]


def ahora():
    return dt.datetime.now().isoformat(timespec="seconds")


def avisar(con, usuario_id, tipo, titulo, texto="", url=None, actor_id=None):
    if not usuario_id:
        return
    con.execute("INSERT INTO notificaciones (usuario_id, tipo, titulo, texto, url, actor_id, creado) VALUES (?,?,?,?,?,?,?)",
                (usuario_id, tipo, titulo[:160], (texto or "")[:400], url, actor_id, ahora()))


def registrar_actividad(con, actor, tipo, texto, url=None, detalle=None):
    """Guarda lo que hizo un cliente para que su entrenador lo vea en vivo. Agrupa repeticiones seguidas."""
    if not actor or not actor.get("coach_id"):
        return
    limite = (dt.datetime.now() - dt.timedelta(minutes=AGRUPAR_MIN)).isoformat(timespec="seconds")
    ult = con.execute("SELECT * FROM actividad WHERE actor_id=? ORDER BY id DESC LIMIT 1", (actor["id"],)).fetchone()
    if ult and ult["tipo"] == tipo and ult["creado"] >= limite and ult["texto"].split(" · ")[0] == texto.split(" · ")[0]:
        det = json.loads(ult["detalle"] or "[]")
        if detalle:
            det = (det + [detalle])[-12:]
        con.execute("UPDATE actividad SET n=n+1, creado=?, detalle=?, texto=? WHERE id=?", (ahora(), json.dumps(det, ensure_ascii=False), texto, ult["id"]))
    else:
        con.execute("INSERT INTO actividad (actor_id, coach_id, tipo, texto, url, detalle, creado) VALUES (?,?,?,?,?,?,?)",
                    (actor["id"], actor["coach_id"], tipo, texto[:300], url, json.dumps([detalle] if detalle else [], ensure_ascii=False), ahora()))


def hace(iso):
    """'hace 3 min', 'ayer 18:20'…"""
    try:
        t = dt.datetime.fromisoformat(iso.replace(" ", "T")[:19])
    except (ValueError, AttributeError):
        return ""
    s = (dt.datetime.now() - t).total_seconds()
    if s < 45:
        return "ahora"
    if s < 3600:
        return f"hace {int(s // 60) or 1} min"
    if s < 86400 and t.date() == dt.date.today():
        return f"hace {int(s // 3600)} h"
    if t.date() == dt.date.today() - dt.timedelta(days=1):
        return "ayer " + t.strftime("%H:%M")
    return t.strftime("%d/%m %H:%M")


def a_dict(r):
    d = dict(r)
    ic, color = TIPOS.get(d.get("tipo"), ("🔔", "s2"))
    d.update(icono=ic, color=color, cuando=hace(d.get("creado")))
    if "detalle" in d:
        d["detalle"] = json.loads(d["detalle"] or "[]")
    return d


def no_leidas(con, uid):
    return con.execute("SELECT COUNT(*) FROM notificaciones WHERE usuario_id=? AND leida=0", (uid,)).fetchone()[0]


def ultimas(con, uid, limite=8, desde=0):
    return [a_dict(r) for r in con.execute("SELECT * FROM notificaciones WHERE usuario_id=? AND id>? ORDER BY id DESC LIMIT ?",
                                           (uid, desde, limite)).fetchall()]


def feed_coach(con, coach_id, desde=None, cliente=None, tipo=None, limite=60):
    """desde = marca de tiempo ISO: devuelve lo nuevo y lo que se agrupó/actualizó desde entonces (el navegador reemplaza por id)."""
    q = "SELECT a.*, u.nombre AS cliente FROM actividad a JOIN usuarios u ON u.id=a.actor_id WHERE a.coach_id=? AND u.coach_id=?"
    args = [coach_id, coach_id]
    if desde:
        q += " AND a.creado>=?"
        args.append(desde)
    if cliente:
        q += " AND a.actor_id=?"
        args.append(cliente)
    if tipo:
        q += " AND a.tipo=?"
        args.append(tipo)
    q += " ORDER BY a.creado DESC, a.id DESC LIMIT ?"
    args.append(limite)
    return [a_dict(r) for r in con.execute(q, args).fetchall()]
