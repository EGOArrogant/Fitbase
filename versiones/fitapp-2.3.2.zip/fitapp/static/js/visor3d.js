// Visor 3D de ejercicios: maniquí articulado + poses clave por patrón de movimiento (Three.js, MIT).
// Convenciones: el personaje mira hacia +Z; Y es arriba. Ángulos en grados.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/OrbitControls.js';

const D = Math.PI / 180;

/* ---------------- poses por patrón ----------------
   Cada pose: root {y, z, rx} (altura de cadera, desplazamiento y giro del cuerpo completo), sp (inclinación del tronco),
   L/R: sh [flexión, abducción, rotación externa opcional], el (codo), hip [flexión, abducción], kn (rodilla), an (tobillo). R se refleja de L si falta.
   plant: 'pies' mantiene los pies en el suelo; 'nada' usa root tal cual. */
const P = {
  sentadilla: { t: [1.4, .3, 1.0, .5], plant: 'pies', kf: [
    { sp: 8, L: { sh: [-66, 4, 112], el: 125, hip: [0, 10], kn: 0, an: 0 } },
    { sp: 38, L: { sh: [-66, 4, 112], el: 125, hip: [105, 18], kn: 115, an: 22 } }] },
  sentadilla_frontal: { t: [1.4, .3, 1.0, .5], plant: 'pies', kf: [
    { sp: 4, L: { sh: [90, 10], el: 135, hip: [0, 10], kn: 0, an: 0 } },
    { sp: 22, L: { sh: [90, 10], el: 135, hip: [100, 18], kn: 118, an: 25 } }] },
  bisagra: { t: [1.5, .3, 1.1, .5], plant: 'pies', kf: [
    { sp: 2, L: { sh: [0, 6], el: 0, hip: [0, 8], kn: 0, an: 0 } },
    { sp: 68, L: { sh: [68, 6], el: 0, hip: [10, 8], kn: 22, an: 6 } }] },
  peso_muerto: { t: [1.5, .4, 1.1, .5], plant: 'pies', kf: [
    { sp: 2, L: { sh: [0, 6], el: 0, hip: [0, 8], kn: 0, an: 0 } },
    { sp: 55, L: { sh: [55, 6], el: 0, hip: [30, 8], kn: 55, an: 18 } }] },
  swing: { t: [.5, .05, .5, .05], plant: 'pies', kf: [
    { sp: 60, L: { sh: [25, 3], el: 0, hip: [5, 12], kn: 25, an: 8 } },
    { sp: 0, L: { sh: [95, 3], el: 0, hip: [0, 12], kn: 0, an: 0 } }] },
  press_banca: { t: [1.3, .2, .9, .4], plant: 'nada', escena: 'banco', kf: [
    { root: { y: .6, z: 0, rx: -90 }, sp: 0, L: { sh: [88, 12], el: 0, hip: [-35, 14], kn: 95, an: 0 } },
    { root: { y: .6, z: 0, rx: -90 }, sp: 0, L: { sh: [15, 55], el: 95, hip: [-35, 14], kn: 95, an: 0 } }] },
  aperturas: { t: [1.4, .2, 1.0, .4], plant: 'nada', escena: 'banco', kf: [
    { root: { y: .6, z: 0, rx: -90 }, sp: 0, L: { sh: [90, 4], el: 15, hip: [-35, 14], kn: 95, an: 0 } },
    { root: { y: .6, z: 0, rx: -90 }, sp: 0, L: { sh: [70, 75], el: 20, hip: [-35, 14], kn: 95, an: 0 } }] },
  lagartija: { t: [1.2, .2, .9, .4], plant: 'nada', kf: [
    { root: { y: .43, z: 0, rx: 65 }, sp: 0, L: { sh: [96, 6], el: 0, hip: [0, 4], kn: 0, an: -35 } },
    { root: { y: .22, z: .12, rx: 80 }, sp: 0, L: { sh: [30, 40], el: 95, hip: [0, 4], kn: 0, an: -35 } }] },
  press_vertical: { t: [1.0, .2, 1.2, .4], plant: 'pies', kf: [
    { sp: 0, L: { sh: [40, 70], el: 120, hip: [0, 8], kn: 0, an: 0 } },
    { sp: -3, L: { sh: [168, 12], el: 5, hip: [0, 8], kn: 0, an: 0 } }] },
  remo: { t: [.9, .2, 1.2, .4], plant: 'pies', kf: [
    { sp: 50, L: { sh: [55, 8], el: 0, hip: [45, 8], kn: 25, an: 10 } },
    { sp: 50, L: { sh: [-25, 22], el: 100, hip: [45, 8], kn: 25, an: 10 } }] },
  jalon: { t: [1.0, .2, 1.3, .4], plant: 'nada', escena: 'polea_alta', kf: [
    { root: { y: .55, z: 0, rx: 0 }, sp: -10, L: { sh: [165, 25], el: 5, hip: [90, 8], kn: 90, an: 0 } },
    { root: { y: .55, z: 0, rx: 0 }, sp: -18, L: { sh: [30, 60], el: 120, hip: [90, 8], kn: 90, an: 0 } }] },
  dominada: { t: [1.0, .3, 1.3, .4], plant: 'nada', escena: 'barra_alta', cam: [1.5, 1.2], kf: [
    { root: { y: .95, z: 0, rx: 0 }, sp: -4, L: { sh: [170, 22], el: 0, hip: [10, 4], kn: 35, an: 0 } },
    { root: { y: 1.45, z: 0, rx: 0 }, sp: -10, L: { sh: [45, 55], el: 125, hip: [15, 4], kn: 35, an: 0 } }] },
  curl: { t: [.9, .2, 1.3, .3], plant: 'pies', kf: [
    { sp: 0, L: { sh: [0, 6], el: 5, hip: [0, 8], kn: 0, an: 0 } },
    { sp: 0, L: { sh: [12, 6], el: 140, hip: [0, 8], kn: 0, an: 0 } }] },
  extension_triceps: { t: [.9, .2, 1.2, .3], plant: 'pies', escena: 'polea_alta', kf: [
    { sp: 12, L: { sh: [8, 10], el: 115, hip: [0, 8], kn: 8, an: 0 } },
    { sp: 12, L: { sh: [0, 8], el: 0, hip: [0, 8], kn: 8, an: 0 } }] },
  elevacion_lateral: { t: [1.0, .2, 1.2, .3], plant: 'pies', kf: [
    { sp: 4, L: { sh: [8, 8], el: 15, hip: [0, 8], kn: 5, an: 0 } },
    { sp: 4, L: { sh: [8, 88], el: 15, hip: [0, 8], kn: 5, an: 0 } }] },
  elevacion_frontal: { t: [1.0, .2, 1.2, .3], plant: 'pies', kf: [
    { sp: 0, L: { sh: [0, 6], el: 5, hip: [0, 8], kn: 0, an: 0 } },
    { sp: 0, L: { sh: [90, 6], el: 5, hip: [0, 8], kn: 0, an: 0 } }] },
  zancada: { t: [1.2, .2, 1.0, .5], plant: 'pies', asim: true, kf: [
    { sp: 2, L: { sh: [0, 8], el: 0, hip: [20, 6], kn: 5, an: 5 }, R: { sh: [0, 8], el: 0, hip: [-20, 6], kn: 5, an: -15 } },
    { sp: 6, L: { sh: [0, 8], el: 0, hip: [85, 6], kn: 90, an: 10 }, R: { sh: [0, 8], el: 0, hip: [-12, 6], kn: 95, an: -10 } }] },
  hip_thrust: { t: [1.0, .4, .9, .4], plant: 'pies', escena: 'banco_bajo', kf: [
    { root: { y: .3, z: 0, rx: -50 }, sp: 0, L: { sh: [10, 30], el: 30, hip: [55, 14], kn: 120, an: -10 } },
    { root: { y: .5, z: 0, rx: -88 }, sp: 0, L: { sh: [10, 30], el: 30, hip: [0, 14], kn: 92, an: 0 } }] },
  talones: { t: [.7, .4, .9, .3], plant: 'nada', kf: [
    { root: { y: .98, z: 0, rx: 0 }, sp: 0, L: { sh: [0, 8], el: 0, hip: [0, 8], kn: 0, an: 10 } },
    { root: { y: 1.08, z: 0, rx: 0 }, sp: 0, L: { sh: [0, 8], el: 0, hip: [0, 8], kn: 0, an: -35 } }] },
  plancha: { t: [1.5, 1.5, 1.5, 1.5], plant: 'nada', kf: [
    { root: { y: .42, z: 0, rx: 82 }, sp: 0, L: { sh: [80, 10], el: 90, hip: [0, 4], kn: 0, an: -30 } },
    { root: { y: .44, z: 0, rx: 81 }, sp: 0, L: { sh: [80, 10], el: 90, hip: [0, 4], kn: 0, an: -30 } }] },
  caminar: { t: [.5, 0, .5, 0], plant: 'nada', ciclo: true, escena: 'caminadora', kf: [
    { root: { y: .97, z: 0, rx: 0 }, sp: 3, L: { sh: [-22, 6], el: 25, hip: [25, 4], kn: 8, an: 5 }, R: { sh: [22, 6], el: 30, hip: [-15, 4], kn: 20, an: -10 } },
    { root: { y: .97, z: 0, rx: 0 }, sp: 3, L: { sh: [22, 6], el: 30, hip: [-15, 4], kn: 20, an: -10 }, R: { sh: [-22, 6], el: 25, hip: [25, 4], kn: 8, an: 5 } }] },
  bicicleta: { t: [.45, 0, .45, 0], plant: 'nada', ciclo: true, escena: 'bici', kf: [
    { root: { y: .95, z: 0, rx: 0 }, sp: 30, L: { sh: [65, 8], el: 30, hip: [80, 6], kn: 110, an: 5 }, R: { sh: [65, 8], el: 30, hip: [35, 6], kn: 30, an: -10 } },
    { root: { y: .95, z: 0, rx: 0 }, sp: 30, L: { sh: [65, 8], el: 30, hip: [35, 6], kn: 30, an: -10 }, R: { sh: [65, 8], el: 30, hip: [80, 6], kn: 110, an: 5 } }] },
};

// músculo -> segmentos del maniquí
const SEG = { pectoral: ['pecho'], deltoide_ant: ['hombro'], deltoide_lat: ['hombro'], deltoide_post: ['hombro'], trapecio: ['pecho', 'cuello'],
  dorsal: ['pecho'], romboides: ['pecho'], erectores: ['abdomen'], biceps: ['brazo'], triceps: ['brazo'], antebrazo: ['antebrazo'],
  abdomen: ['abdomen'], oblicuos: ['abdomen'], gluteo: ['pelvis'], cuadriceps: ['muslo'], isquios: ['muslo'], aductores: ['muslo'],
  pantorrilla: ['pierna'], tibial: ['pierna'] };

function css(v, f) { const s = getComputedStyle(document.documentElement).getPropertyValue(v).trim(); return s || f; }

async function cargarCuerpo(nombre) {
  const r = await fetch(new URL(`../cuerpo3d/${nombre}.bin`, import.meta.url)); if (!r.ok) throw new Error('sin malla');
  const buf = await r.arrayBuffer(), dv = new DataView(buf), ml = dv.getUint32(0, true);
  const meta = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 4, ml)));
  let o = 4 + ml;
  const tomar = (T, n) => { const a = new T(buf, o, n); o += a.byteLength; o = (o + 3) & ~3; return a; };
  const nv = meta.nv, nf = meta.nf;
  return { meta, pos: tomar(Float32Array, nv * 3), idx: tomar(nv < 65536 ? Uint16Array : Uint32Array, nf * 3), si: tomar(Uint8Array, nv * 4),
    sw: tomar(Uint8Array, nv * 4), tid: tomar(Uint8Array, nv), mg: tomar(Int16Array, nv * 3), mm: tomar(Int16Array, nv * 3) };
}

export async function montar(el) {
  const patron = el.dataset.patron, prop = el.dataset.prop || '', targets = JSON.parse(el.dataset.targets || '[]');
  const def = P[patron]; if (!def) return;
  const malla = await cargarCuerpo(JSON.parse(el.dataset.cuerpo || '{}').sexo === 'Mujer' ? 'mujer' : 'hombre').catch(() => null);
  const W = () => el.clientWidth, H = () => el.clientHeight;
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(2, window.devicePixelRatio)); renderer.setSize(W(), H());
  el.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, W() / H(), .1, 50);
  camera.position.set(2.55, 1.45, 2.8);
  { const v = new URLSearchParams(location.search).get('vista'); if (v === 'espalda') camera.position.set(-1.6, 1.4, -3.2); if (v === 'frente') camera.position.set(.6, 1.3, 3.4); }
  const ctl = new OrbitControls(camera, renderer.domElement);
  ctl.target.set(0, def.cam ? def.cam[0] : .8, 0); if (def.cam) camera.position.y += def.cam[1]; ctl.enableDamping = true; ctl.minDistance = 2; ctl.maxDistance = 8; ctl.enablePan = false; ctl.update();
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
  scene.add(new THREE.HemisphereLight(0xffffff, 0x8a8a95, 1.25));
  const luz = new THREE.DirectionalLight(0xffffff, 2.2); luz.position.set(2.5, 5, 3); luz.castShadow = true;
  luz.shadow.mapSize.set(1024, 1024); Object.assign(luz.shadow.camera, { left: -2, right: 2, top: 2.5, bottom: -1, near: .5, far: 12 }); luz.shadow.radius = 4; scene.add(luz);
  const contra = new THREE.DirectionalLight(0xcfd6ff, .8); contra.position.set(-3, 3, -3); scene.add(contra);
  const piso = new THREE.Mesh(new THREE.CircleGeometry(1.6, 48), new THREE.MeshStandardMaterial({ color: css('--surface-2', '#222'), roughness: 1 }));
  piso.rotation.x = -Math.PI / 2; piso.receiveShadow = true; scene.add(piso);
  const aro = new THREE.Mesh(new THREE.RingGeometry(1.58, 1.62, 64), new THREE.MeshBasicMaterial({ color: css('--accent', '#7B61FF') }));
  aro.rotation.x = -Math.PI / 2; aro.position.y = .002; scene.add(aro);

  // ---------- cuerpo esculpido (cada forma lleva su músculo) ----------
  const cuerpo = JSON.parse(el.dataset.cuerpo || '{}');
  const mujer = cuerpo.sexo === 'Mujer';
  const g = 1 + Math.max(-.1, Math.min(.35, ((cuerpo.grasa ?? (mujer ? 26 : 18)) - (mujer ? 26 : 18)) * .012));  // volumen por grasa
  const mu = 1 + Math.max(-.15, Math.min(.3, ((cuerpo.meso ?? 4.5) - 4.5) * .08));                                 // volumen muscular
  const anchoH = mujer ? .86 : 1, anchoC = mujer ? 1.1 : 1, rL = mujer ? .86 : 1;
  const tgt = new Set(targets), principalM = targets[0];
  const cBase = '#c4c4c9', cP = css('--muscle-sel', '#7B61FF');
  const cSec = new THREE.Color(cP).lerp(new THREE.Color(cBase), .5);
  const mats = {};
  const mat = m => mats[m] || (mats[m] = new THREE.MeshStandardMaterial({ color: m === principalM ? cP : (m && tgt.has(m)) ? cSec : cBase, roughness: .82, metalness: 0 }));
  const piel = mat(null);
  const metal = new THREE.MeshStandardMaterial({ color: 0x9aa0ab, metalness: .8, roughness: .3 });
  const negro = new THREE.MeshStandardMaterial({ color: 0x26262b, roughness: .7 });
  const piezas = [];
  const sombra = o => { o.castShadow = true; o.receiveShadow = true; piezas.push(o); return o; };
  const elip = (padre, m, rx, ry, rz, x, y, z, rot) => { const e = sombra(new THREE.Mesh(new THREE.SphereGeometry(1, 28, 20), mat(m)));
    e.scale.set(rx, ry, rz); e.position.set(x, y, z); if (rot) e.rotation.set(...rot); padre.add(e); return e; };
  const tubo = (padre, m, r1, r2, largo, y0 = 0) => { const t = sombra(new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, largo, 24, 1), mat(m)));
    t.position.y = y0 - largo / 2; padre.add(t); elip(padre, m, r2 * .98, r2 * .98, r2 * .98, 0, y0 - largo, 0); return t; };

  const root = new THREE.Group(); scene.add(root);
  // pelvis y cadera
  elip(root, null, .16 * anchoC * g, .11, .115 * g, 0, 0, 0);
  for (const s of [1, -1]) elip(root, 'gluteo', .085 * anchoC * g * mu, .1, .08 * g * mu, s * .075 * anchoC, -.03, -.075);
  const spine = new THREE.Group(); spine.position.y = .06; root.add(spine);
  elip(spine, null, .135 * g, .16, .105 * g, 0, .13, 0);
  elip(spine, 'abdomen', .095 * g, .14, .045 * g, 0, .13, .075 * g);
  for (const s of [1, -1]) elip(spine, 'oblicuos', .05 * g, .12, .08 * g, s * .115 * g, .12, .005);
  elip(spine, 'erectores', .1, .14, .05, 0, .13, -.075 * g);
  const chest = new THREE.Group(); chest.position.y = .26; spine.add(chest);
  elip(chest, null, .19 * anchoH * g, .2, .125 * g, 0, .14, 0);
  for (const s of [1, -1]) {
    elip(chest, 'pectoral', .095 * anchoH * mu, .07 * mu, .05 * mu, s * .08 * anchoH, .19, .095 * g, [0, 0, s * .2]);
    if (mujer) elip(chest, null, .07 * g, .068 * g, .065 * g, s * .085, .16, .12 * g);
    elip(chest, 'dorsal', .07 * mu, .17, .075 * mu, s * .14 * anchoH, .1, -.04, [0, 0, -s * .25]);
  }
  elip(chest, 'romboides', .11 * anchoH, .1, .045, 0, .21, -.105 * g);
  elip(chest, 'trapecio', .16 * anchoH * mu, .07, .085, 0, .31, -.03);
  const cuello = sombra(new THREE.Mesh(new THREE.CylinderGeometry(.05 * rL, .065 * rL, .12, 20), piel)); cuello.position.y = .36; chest.add(cuello);
  elip(chest, null, .09 * rL, .118, .102, 0, .49, .01);                       // cabeza
  elip(chest, null, .065 * rL, .05, .07, 0, .425, .03);                        // mandíbula
  if (mujer) { elip(chest, null, .095, .1, .1, 0, .515, -.02); elip(chest, null, .035, .09, .035, 0, .42, -.11, [.4, 0, 0]); }  // cabello y coleta
  else elip(chest, null, .093, .06, .1, 0, .56, -.005);                        // cabello corto
  const lado = {};
  for (const [s, k] of [[1, 'L'], [-1, 'R']]) {
    const sh = new THREE.Group(); sh.rotation.order = 'XZY'; sh.position.set(s * .225 * anchoH, .27, 0); chest.add(sh);
    elip(sh, 'deltoide_lat', .06 * mu, .075 * mu, .065 * mu, s * .025, -.02, 0);
    elip(sh, 'deltoide_ant', .05 * mu, .07 * mu, .045 * mu, s * .005, -.03, .04);
    elip(sh, 'deltoide_post', .05 * mu, .065 * mu, .045 * mu, s * .005, -.03, -.04);
    tubo(sh, null, .05 * rL * g, .042 * rL * g, .26, -.04);
    elip(sh, 'biceps', .04 * rL * mu, .095, .042 * rL * mu, 0, -.16, .025);
    elip(sh, 'triceps', .045 * rL * mu, .11, .045 * rL * mu, 0, -.14, -.025);
    const el_ = new THREE.Group(); el_.position.y = -.3; sh.add(el_);
    tubo(el_, 'antebrazo', .042 * rL * mu, .028 * rL, .25);
    const mano = new THREE.Group(); mano.position.y = -.27; el_.add(mano);
    elip(mano, null, .03, .05, .018, 0, -.02, 0);
    const hip = new THREE.Group(); hip.position.set(s * .095 * anchoC, -.05, 0); root.add(hip);
    tubo(hip, null, .082 * g * rL, .056 * rL, .42);
    elip(hip, 'cuadriceps', .07 * mu * rL, .18, .06 * mu, 0, -.2, .035);
    elip(hip, 'isquios', .062 * mu * rL, .16, .05 * mu, 0, -.21, -.035);
    elip(hip, 'aductores', .04 * rL, .13, .05, -s * .035, -.13, 0);
    const kn = new THREE.Group(); kn.position.y = -.44; hip.add(kn);
    tubo(kn, null, .052 * rL, .034 * rL, .41);
    elip(kn, 'pantorrilla', .05 * mu * rL, .11, .05 * mu, 0, -.13, -.03);
    elip(kn, 'tibial', .025, .13, .025, s * .012, -.18, .035);
    const an = new THREE.Group(); an.position.y = -.43; kn.add(an);
    const pie = sombra(new THREE.Mesh(new THREE.CapsuleGeometry(.04, .17, 6, 12), piel)); pie.rotation.x = Math.PI / 2; pie.scale.set(1.1, 1, .7); pie.position.set(0, -.035, .055); an.add(pie);
    lado[k] = { s, sh, el: el_, mano, hip, kn, an, pie };
  }

  // ---------- piel continua (malla esculpida con huesos) ----------
  if (malla) {
    const { meta, pos, idx, si, sw, tid, mg, mm } = malla;
    for (const k of ['L', 'R']) { lado[k].sh.rotation.set(0, 0, lado[k].s * meta.bind.hombro * D); lado[k].hip.rotation.set(0, 0, lado[k].s * meta.bind.cadera * D); }
    root.position.set(0, .97, 0); root.rotation.set(0, 0, 0); root.updateMatrixWorld(true);
    const L_ = lado.L, R_ = lado.R;
    const huesos = { root, spine, chest, shL: L_.sh, elL: L_.el, manoL: L_.mano, shR: R_.sh, elR: R_.el, manoR: R_.mano, hipL: L_.hip, knL: L_.kn, anL: L_.an, hipR: R_.hip, knR: R_.kn, anR: R_.an };
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.setAttribute('skinIndex', new THREE.BufferAttribute(si, 4));
    geo.setAttribute('skinWeight', new THREE.BufferAttribute(sw, 4, true));
    const esc = meta.morph_esc, f32 = a => { const r = new Float32Array(a.length); for (let i = 0; i < a.length; i++) r[i] = a[i] * esc; return r; };
    geo.morphAttributes.position = [new THREE.BufferAttribute(f32(mg), 3), new THREE.BufferAttribute(f32(mm), 3)];
    geo.morphTargetsRelative = true;
    const cB = new THREE.Color(cBase), cPr = new THREE.Color(cP), cPelo = new THREE.Color(mujer ? '#6f6a70' : '#8b8b92');
    const col = new Float32Array(meta.nv * 3);
    for (let i = 0; i < meta.nv; i++) {
      const t = tid[i] ? meta.tags[tid[i] - 1] : null;
      const c = t === 'pelo' ? cPelo : t && t === principalM ? cPr : t && tgt.has(t) ? cSec : cB;
      col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.computeVertexNormals();
    const piel3d = new THREE.SkinnedMesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .72, metalness: 0 }));
    piel3d.morphTargetInfluences[0] = (g - 1) / .3; piel3d.morphTargetInfluences[1] = (mu - 1) / .25;
    piel3d.castShadow = piel3d.receiveShadow = true; piel3d.frustumCulled = false;
    piel3d.bind(new THREE.Skeleton(meta.huesos.map(n => huesos[n])), new THREE.Matrix4());
    scene.add(piel3d);
    for (const p of piezas) p.visible = false;
  }

  // ---------- accesorios ----------
  const objetos = [];
  function barra(largo = 1.6) {
    const g = new THREE.Group();
    const b = new THREE.Mesh(new THREE.CylinderGeometry(.014, .014, largo, 12), metal); b.rotation.z = Math.PI / 2; g.add(b);
    for (const s of [1, -1]) { const d = new THREE.Mesh(new THREE.CylinderGeometry(.2, .2, .05, 28), negro); d.rotation.z = Math.PI / 2; d.position.x = s * (largo / 2 - .12); g.add(d); }
    return g;
  }
  function mancuerna() {
    const g = new THREE.Group();
    const b = new THREE.Mesh(new THREE.CylinderGeometry(.015, .015, .26, 10), metal); b.rotation.z = Math.PI / 2; g.add(b);
    for (const s of [1, -1]) { const d = new THREE.Mesh(new THREE.CylinderGeometry(.06, .06, .06, 16), negro); d.rotation.z = Math.PI / 2; d.position.x = s * .11; g.add(d); }
    return g;
  }
  function kettlebell() {
    const g = new THREE.Group();
    const c = new THREE.Mesh(new THREE.SphereGeometry(.1, 20, 14), negro); c.position.y = -.12; g.add(c);
    const a = new THREE.Mesh(new THREE.TorusGeometry(.06, .012, 8, 20, Math.PI), negro); a.position.y = -.04; g.add(a);
    return g;
  }
  let barraManos = null, kbManos = null, barraEspalda = null;
  if (prop === 'barra' && ['sentadilla'].includes(patron)) { const b = barra(); b.position.set(0, .31, -.13); chest.add(b); barraEspalda = b; }
  else if (prop === 'barra' && patron === 'sentadilla_frontal') { const b = barra(); b.position.set(0, .3, .17); chest.add(b); barraEspalda = b; }
  else if (prop === 'barra' || prop === 'smith') { barraManos = barra(prop === 'smith' ? 1.5 : 1.6); scene.add(barraManos); }
  else if (prop === 'mancuernas') { for (const k of ['L', 'R']) { const m = mancuerna(); m.position.y = -.03; m.rotation.y = Math.PI / 2; lado[k].mano.add(m); } }
  else if (prop === 'kettlebell' || prop === 'goblet') { kbManos = kettlebell(); scene.add(kbManos); }
  if (prop === 'smith') { for (const s of [1, -1]) { const r = new THREE.Mesh(new THREE.BoxGeometry(.06, 2.2, .06), metal); r.position.set(s * .85, 1.1, 0); scene.add(r); } }
  const esc = def.escena;
  if (esc === 'banco') { const b = new THREE.Mesh(new THREE.BoxGeometry(.32, .08, 1.2), negro); b.position.set(0, .45, -.25); scene.add(b);
    const p = new THREE.Mesh(new THREE.BoxGeometry(.1, .45, .1), metal); p.position.set(0, .22, -.25); scene.add(p); }
  if (esc === 'banco_bajo') { const b = new THREE.Mesh(new THREE.BoxGeometry(1.0, .42, .3), negro); b.position.set(0, .21, -.62); scene.add(b); }
  if (esc === 'barra_alta') { const b = new THREE.Mesh(new THREE.CylinderGeometry(.016, .016, 1.4, 12), metal); b.rotation.z = Math.PI / 2; b.position.set(0, 2.12, 0); scene.add(b); }
  if (esc === 'polea_alta') { const t = new THREE.Mesh(new THREE.BoxGeometry(.12, 2.3, .12), metal); t.position.set(0, 1.15, .55); scene.add(t);
    const asiento = patron === 'jalon' ? new THREE.Mesh(new THREE.BoxGeometry(.4, .08, .35), negro) : null; if (asiento) { asiento.position.set(0, .5, 0); scene.add(asiento); } }
  if (esc === 'caminadora') { const c = new THREE.Mesh(new THREE.BoxGeometry(.6, .08, 1.7), negro); c.position.set(0, .04, 0); scene.add(c); }
  if (esc === 'bici') { const s = new THREE.Mesh(new THREE.BoxGeometry(.18, .05, .25), negro); s.position.set(0, .86, -.05); scene.add(s);
    const f = new THREE.Mesh(new THREE.BoxGeometry(.06, .85, .06), metal); f.position.set(0, .43, -.05); scene.add(f);
    const v = new THREE.Mesh(new THREE.TorusGeometry(.2, .02, 8, 24), metal); v.rotation.y = Math.PI / 2; v.position.set(0, .35, .38); scene.add(v);
    const m = new THREE.Mesh(new THREE.BoxGeometry(.4, .04, .04), metal); m.position.set(0, 1.12, .55); scene.add(m); }
  let cable = null;
  if (esc === 'polea_alta') { cable = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0xaaaaaa })); scene.add(cable);
    barraManos = barraManos || (() => { const g = new THREE.Mesh(new THREE.CylinderGeometry(.012, .012, patron === 'jalon' ? 1.0 : .35, 8), metal); g.rotation.z = Math.PI / 2; const w = new THREE.Group(); w.add(g); scene.add(w); return w; })(); }

  // ---------- animación ----------
  const neutro = { root: { y: .97, z: 0, rx: 0 }, sp: 0, L: { sh: [0, 0], el: 0, hip: [0, 0], kn: 0, an: 0 } };
  const full = p => { const o = JSON.parse(JSON.stringify(p)); o.root = Object.assign({}, neutro.root, p.root || {}); o.R = o.R || JSON.parse(JSON.stringify(o.L)); return o; };
  const kf = def.kf.map(full);
  const lerp = (a, b, t) => typeof a === 'number' ? a + (b - a) * t : Array.isArray(a) ? a.map((x, i) => lerp(x, b[i], t)) : Object.fromEntries(Object.keys(a).map(k => [k, lerp(a[k], b[k], t)]));
  const BALANCE = { sentadilla: 1, sentadilla_frontal: 1, peso_muerto: 1, bisagra: 1, press_vertical: 1, remo: 1, curl: 0, swing: 0 };
  function cargaZ() {
    const v = new THREE.Vector3();
    if (barraEspalda) barraEspalda.getWorldPosition(v);
    else { const a = new THREE.Vector3(), b = new THREE.Vector3(); lado.L.mano.getWorldPosition(a); lado.R.mano.getWorldPosition(b); v.copy(a.add(b).multiplyScalar(.5)); }
    return v.z;
  }
  function medioPie() { const a = new THREE.Vector3(), b = new THREE.Vector3(); lado.L.pie.getWorldPosition(a); lado.R.pie.getWorldPosition(b); return (a.z + b.z) / 2; }
  function aplicar(p) {
    if (BALANCE[patron] && prop && !p._eq) {   // ajusta el tobillo para que la carga quede sobre el medio del pie
      let lo = -20, hi = 20;
      for (let i = 0; i < 14; i++) {
        const d = (lo + hi) / 2, q = JSON.parse(JSON.stringify(p)); q._eq = 1; q.L.an += d; q.R.an += d;
        aplicar(q); const err = cargaZ() - medioPie();
        if (err > 0) hi = d; else lo = d;
      }
      const q = JSON.parse(JSON.stringify(p)); q._eq = 1; q.L.an += (lo + hi) / 2; q.R.an += (lo + hi) / 2; return aplicar(q);
    }
    root.position.set(0, p.root.y, p.root.z); root.rotation.set(p.root.rx * D, 0, 0);
    spine.rotation.x = p.sp * D * .6; chest.rotation.x = p.sp * D * .4;
    for (const k of ['L', 'R']) {
      const q = p[k], o = lado[k], s = o.s;
      o.sh.rotation.set(-q.sh[0] * D, s * (q.sh[2] || 0) * D, s * q.sh[1] * D);
      o.el.rotation.x = -q.el * D;
      o.hip.rotation.set(-q.hip[0] * D, 0, s * q.hip[1] * D);
      o.kn.rotation.x = q.kn * D;
      o.an.rotation.x = -q.an * D;
    }
    if (def.plant === 'pies') {
      root.updateMatrixWorld(true);
      const v = new THREE.Vector3(), w = new THREE.Vector3();
      lado.L.an.getWorldPosition(v); lado.R.an.getWorldPosition(w);
      const y = Math.min(v.y, w.y), z = (v.z + w.z) / 2;
      root.position.y += .09 - y; root.position.z -= z - (def.asim ? 0 : 0);
    }
    root.updateMatrixWorld(true);
    const a = new THREE.Vector3(), b = new THREE.Vector3(); lado.L.mano.getWorldPosition(a); lado.R.mano.getWorldPosition(b);
    const mid = a.clone().add(b).multiplyScalar(.5);
    if (barraManos) barraManos.position.copy(mid);
    if (kbManos) kbManos.position.copy(mid);
    if (cable) { const pos = cable.geometry.attributes.position; pos.setXYZ(0, 0, 2.25, .55); pos.setXYZ(1, mid.x, mid.y, mid.z); pos.needsUpdate = true; }
  }
  const ease = t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  const [tBaja, tAbajo, tSube, tArriba] = def.t, ciclo = tBaja + tAbajo + tSube + tArriba;
  const reloj = new THREE.Clock();
  let pausa = false, vel = 1;
  el.parentElement.querySelectorAll('[data-v3d]').forEach(b => b.addEventListener('click', () => {
    if (b.dataset.v3d === 'pausa') { pausa = !pausa; b.textContent = pausa ? '▶ Reproducir' : '❚❚ Pausa'; }
    else { vel = +b.dataset.v3d; el.parentElement.querySelectorAll('[data-v3d]').forEach(x => x.classList.toggle('on', x === b)); }
  }));
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let t = 0;
  function cuadro() {
    const dt = reloj.getDelta();
    if (!pausa && !reduce) t = (t + dt * vel) % ciclo;
    let u;
    if (def.ciclo) u = .5 - .5 * Math.cos(t / ciclo * 2 * Math.PI);
    else if (t < tBaja) u = ease(t / tBaja); else if (t < tBaja + tAbajo) u = 1;
    else if (t < tBaja + tAbajo + tSube) u = 1 - ease((t - tBaja - tAbajo) / tSube); else u = 0;
    aplicar(lerp(kf[0], kf[1], u));
    ctl.update(); renderer.render(scene, camera);
    requestAnimationFrame(cuadro);
  }
  if (reduce) t = tBaja;
  const fijo = new URLSearchParams(location.search).get('pose');
  if (fijo !== null) { pausa = true; t = +fijo ? tBaja + tAbajo / 2 : 0; if (def.ciclo) t = +fijo ? ciclo / 2 : 0; }
  cuadro();
  new ResizeObserver(() => { renderer.setSize(W(), H()); camera.aspect = W() / H(); camera.updateProjectionMatrix(); }).observe(el);
}

document.querySelectorAll('[data-patron]').forEach(montar);
