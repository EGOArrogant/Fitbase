// Portada: animaciones al desplazarse (sin librerías). Respeta "reducir movimiento".
(function () {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const body = document.body, root = document.documentElement;
  if (!reduce) root.classList.add('js-anim');

  // 1. Aparición al entrar en pantalla
  const rv = document.querySelectorAll('[data-rv]');
  if (reduce || !('IntersectionObserver' in window)) rv.forEach(e => e.classList.add('in'));
  else {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }),
      { threshold: .14, rootMargin: '0px 0px -6% 0px' });
    rv.forEach(e => io.observe(e));
  }

  // 2. Contadores que suben
  const fmt = n => Math.round(n).toLocaleString('es-MX');
  const contar = el => {
    const fin = +el.dataset.count; if (reduce) { el.textContent = fmt(fin); return; }
    const t0 = performance.now(), dur = 1600;
    const paso = t => { const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(fin * e); if (k < 1) requestAnimationFrame(paso); };
    requestAnimationFrame(paso);
  };
  const cio = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { contar(e.target); cio.unobserve(e.target); } }), { threshold: .6 }) : null;
  document.querySelectorAll('[data-count]').forEach(el => { if (cio) { el.textContent = '0'; cio.observe(el); } });

  // 3. Palabras que rotan en el título
  const pal = document.querySelectorAll('.lp-palabras b');
  if (pal.length > 1 && !reduce) {
    let i = 0;
    setInterval(() => {
      const a = pal[i]; i = (i + 1) % pal.length; const b = pal[i];
      a.classList.remove('on'); a.classList.add('sale'); b.classList.remove('sale'); b.classList.add('on');
      setTimeout(() => a.classList.remove('sale'), 500);
    }, 2400);
  }

  // 4. Barra de lectura, encabezado sólido, paralaje y CTA en celular
  const barra = document.querySelector('.lp-progreso span');
  const par = [...document.querySelectorAll('[data-parallax]')];
  const hero = document.querySelector('.lp-hero');
  let pend = false;
  function scroll() {
    pend = false;
    const y = scrollY, h = root.scrollHeight - innerHeight;
    if (barra) barra.style.transform = `scaleX(${h > 0 ? y / h : 0})`;
    body.classList.toggle('nav-solida', y > 30);
    body.classList.toggle('cta-visible', hero && y > hero.offsetHeight * .8 && y < h - 400);
    if (!reduce) par.forEach(el => {
      const r = el.getBoundingClientRect(), c = r.top + r.height / 2 - innerHeight / 2;
      el.style.translate = `0 ${(-c * +el.dataset.parallax).toFixed(1)}px`;
    });
  }
  addEventListener('scroll', () => { if (!pend) { pend = true; requestAnimationFrame(scroll); } }, { passive: true });
  addEventListener('resize', scroll); scroll();

  // 5. Historia: el teléfono fijo cambia de pantalla según el paso
  const pasos = document.querySelectorAll('.lp-paso'), pantallas = document.querySelectorAll('[data-pantalla]'), puntos = document.querySelectorAll('.lp-puntos span');
  if (pasos.length && 'IntersectionObserver' in window) {
    const hio = new IntersectionObserver(es => es.forEach(e => {
      if (!e.isIntersecting) return;
      const n = +e.target.dataset.paso;
      pasos.forEach((p, k) => p.classList.toggle('on', k === n));
      pantallas.forEach((p, k) => p.classList.toggle('on', k === n));
      puntos.forEach((p, k) => p.classList.toggle('on', k === n));
    }), { rootMargin: '-45% 0px -45% 0px' });
    pasos.forEach(p => hio.observe(p));
    pasos[0].classList.add('on');
  }

  // 6. Interruptor "Entreno por mi cuenta / Soy entrenador"
  const sw = document.querySelector('.lp-switch');
  sw && sw.querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
    const c = b.dataset.camino;
    sw.classList.toggle('coach', c === 'coach');
    sw.querySelectorAll('button').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-selected', x === b); });
    document.querySelectorAll('.lp-camino').forEach(p => {
      const on = p.dataset.panel === c; p.hidden = !on; p.classList.toggle('entra', on && !reduce);
      if (on) p.querySelectorAll('[data-rv]').forEach(e => e.classList.add('in'));
    });
  }));

  // 7. Tarjetas con inclinación 3D al pasar el ratón (solo computadora)
  if (!reduce && matchMedia('(hover: hover) and (pointer: fine)').matches) {
    document.querySelectorAll('.lp-tile').forEach(t => {
      t.addEventListener('pointermove', e => {
        const r = t.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        t.style.transform = `perspective(900px) rotateX(${(.5 - y) * 6}deg) rotateY(${(x - .5) * 8}deg) translateY(-4px)`;
        t.style.setProperty('--mx', x * 100 + '%'); t.style.setProperty('--my', y * 100 + '%');
      });
      t.addEventListener('pointerleave', () => { t.style.transform = ''; });
    });
  }

  // 8. Laptop de entrenador: alterna pantallas
  const lap = document.querySelectorAll('.lp-lap-rota img');
  if (lap.length > 1 && !reduce) { let k = 0; setInterval(() => { lap[k].classList.remove('on'); k = (k + 1) % lap.length; lap[k].classList.add('on'); }, 4200); }
})();

// Dispositivos: elegir celular, tableta o computadora y probar la app en vivo a su tamaño real
(function () {
  const escena = document.querySelector('.lp-disp-escena');
  if (!escena) return;
  const tabs = document.querySelectorAll('.lp-disp-tabs button'), btn = document.querySelector('[data-vivo]');
  let vivo = false;
  function elegir(k) {
    escena.dataset.escena = k;
    tabs.forEach(t => { const on = t.dataset.disp === k; t.classList.toggle('on', on); t.setAttribute('aria-selected', on); });
    if (vivo) montar();
  }
  function ajustar(fig) {
    const ifr = fig.querySelector('iframe'); if (!ifr) return;
    const pant = fig.querySelector('.lp-d-pantalla');
    ifr.style.transform = 'scale(' + (pant.clientWidth / +fig.dataset.w) + ')';
  }
  function quitar() {
    escena.querySelectorAll('iframe').forEach(f => f.remove());
    escena.querySelectorAll('.lp-vivo-aviso').forEach(f => f.remove());
    escena.querySelectorAll('.lp-d').forEach(f => f.classList.remove('activo'));
  }
  function montar() {
    quitar();
    const fig = escena.querySelector('.lp-d[data-disp="' + escena.dataset.escena + '"]');
    const ifr = document.createElement('iframe');
    ifr.src = '/demo'; ifr.title = 'Demo en vivo'; ifr.width = fig.dataset.w; ifr.height = fig.dataset.h;
    ifr.style.width = fig.dataset.w + 'px'; ifr.style.height = fig.dataset.h + 'px';
    fig.querySelector('.lp-d-pantalla').appendChild(ifr);
    const av = document.createElement('span'); av.className = 'lp-vivo-aviso';  av.textContent = ((window.FB_T && window.FB_T['EN VIVO']) || 'EN VIVO') + ' · ' + fig.dataset.w + ' × ' + fig.dataset.h;
    fig.appendChild(av); fig.classList.add('activo');
    ajustar(fig);
  }
  tabs.forEach(t => t.addEventListener('click', () => elegir(t.dataset.disp)));
  escena.querySelectorAll('.lp-d').forEach(f => f.addEventListener('click', () => { if (!vivo) elegir(f.dataset.disp); }));
  addEventListener('resize', () => escena.querySelectorAll('.lp-d.activo').forEach(ajustar), { passive: true });
  btn && btn.addEventListener('click', () => {
    vivo = !vivo; escena.classList.toggle('en-vivo', vivo);
    const T = s => (window.FB_T && window.FB_T[s]) || s;
    btn.textContent = vivo ? T('✕ Salir de la vista en vivo') : T('▶ Pruébala aquí mismo');
    vivo ? montar() : quitar();
    if (vivo) escena.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  });
})();
