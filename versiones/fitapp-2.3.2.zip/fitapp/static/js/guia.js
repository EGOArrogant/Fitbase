// Guía de uso: recorrido paso a paso sobre la página real (computadora y celular)
(function () {
  const T = s => (window.FB_T && window.FB_T[s]) || s;
  const datos = document.getElementById('guia-datos');
  window.FBguia = iniciar;
  document.addEventListener('click', e => { const b = e.target.closest('[data-guia-iniciar]'); if (b && datos) { e.preventDefault(); iniciar(); } });
  if (!datos) return;
  let pasos = [];
  try { pasos = JSON.parse(datos.textContent); } catch (e) { return; }
  const movil = () => matchMedia('(max-width:900px)').matches;
  const reducido = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let i = 0, capa, foco, caja, previo;

  function abrirGrupo(el) { const d = el && el.closest('details'); if (d && !d.open) d.open = true; }
  function visible(el) { if (!el) return false; const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden'; }
  function objetivo(p) {
    if (movil()) {
      const t = p.tab && document.querySelector(p.tab);
      if (visible(t)) { window.FBmenu && window.FBmenu(false); return t; }
      const s = p.sel && document.querySelector(p.sel);
      if (s) { abrirGrupo(s); window.FBmenu && window.FBmenu(true); return s; }
      window.FBmenu && window.FBmenu(false);
      return null;
    }
    const s = p.sel && document.querySelector(p.sel);
    abrirGrupo(s);
    return visible(s) ? s : null;
  }
  function construir() {
    capa = document.createElement('div'); capa.className = 'guia-capa';
    foco = document.createElement('div'); foco.className = 'guia-foco';
    caja = document.createElement('div'); caja.className = 'guia-caja'; caja.setAttribute('role', 'dialog'); caja.setAttribute('aria-modal', 'true'); caja.setAttribute('aria-labelledby', 'guia-t');
    document.body.append(capa, foco, caja);
    capa.addEventListener('click', () => {});
    document.addEventListener('keydown', teclas);
    addEventListener('resize', colocar, { passive: true });
    document.addEventListener('scroll', recolocar, { passive: true, capture: true });
    document.body.classList.add('guia-activa');
  }
  function teclas(e) {
    if (!caja) return;
    if (e.key === 'Escape') terminar('omitida');
    else if (e.key === 'ArrowRight' || e.key === 'Enter' && e.target === document.body) mover(1);
    else if (e.key === 'ArrowLeft') mover(-1);
  }
  function mostrar() {
    const p = pasos[i];
    const el = objetivo(p);
    previo = el;
    const ultimo = i === pasos.length - 1;
    caja.innerHTML =
      '<div class="guia-prog" aria-hidden="true">' + pasos.map((_, k) => '<i class="' + (k === i ? 'on' : k < i ? 'ok' : '') + '"></i>').join('') + '</div>' +
      '<h2 id="guia-t">' + esc(p.titulo) + '</h2><p>' + esc(p.texto) + '</p>' +
      '<div class="guia-bot"><button type="button" class="guia-saltar">' + (ultimo ? '' : T('Saltar guía')) + '</button><span class="guia-num">' + (i + 1) + ' ' + T('de') + ' ' + pasos.length + '</span>' +
      (i ? '<button type="button" class="btn sm guia-ant">' + T('Atrás') + '</button>' : '') +
      '<button type="button" class="btn pri sm guia-sig">' + (ultimo ? T('¡Listo!') : i ? T('Siguiente') : T('Empezar')) + '</button></div>';
    caja.querySelector('.guia-sig').onclick = () => mover(1);
    const a = caja.querySelector('.guia-ant'); a && (a.onclick = () => mover(-1));
    const s = caja.querySelector('.guia-saltar'); s && (s.onclick = () => terminar('omitida'));
    if (el) { el.scrollIntoView({ block: 'center', behavior: reducido || el.closest('.side') ? 'auto' : 'smooth' }); }
    setTimeout(colocar, el ? (movil() && el.closest('.side') ? 280 : 60) : 0);
    caja.querySelector('.guia-sig').focus({ preventScroll: true });
  }
  function colocar() {
    if (!caja) return;
    const el = previo;
    caja.classList.remove('centro', 'arriba');
    if (!el || !visible(el)) {
      foco.style.opacity = 0; capa.classList.add('oscura');
      caja.classList.add('centro'); caja.style.left = caja.style.top = '';
      return;
    }
    capa.classList.remove('oscura');
    const r = el.getBoundingClientRect(), m = 6;
    Object.assign(foco.style, { opacity: 1, left: (r.left - m) + 'px', top: (r.top - m) + 'px', width: (r.width + 2 * m) + 'px', height: (r.height + 2 * m) + 'px' });
    const cw = caja.offsetWidth, ch = caja.offsetHeight, W = innerWidth, H = innerHeight;
    let x, y;
    if (!movil() && r.right + 16 + cw < W) { x = r.right + 16; y = Math.min(Math.max(12, r.top + r.height / 2 - ch / 2), H - ch - 12); }
    else if (r.bottom + 14 + ch < H - 8) { y = r.bottom + 14; x = Math.min(Math.max(12, r.left + r.width / 2 - cw / 2), W - cw - 12); }
    else { y = Math.max(12, r.top - ch - 14); x = Math.min(Math.max(12, r.left + r.width / 2 - cw / 2), W - cw - 12); caja.classList.add('arriba'); }
    caja.style.left = x + 'px'; caja.style.top = y + 'px';
  }
  let raf = 0;
  function recolocar() { if (!caja || raf) return; raf = requestAnimationFrame(() => { raf = 0; colocar(); }); }
  function mover(d) {
    const n = i + d;
    if (n >= pasos.length) return terminar('completa');
    if (n < 0) return;
    i = n; caja.classList.add('cambia'); setTimeout(() => { caja && caja.classList.remove('cambia'); mostrar(); }, reducido ? 0 : 140);
  }
  function terminar(estado) {
    document.removeEventListener('keydown', teclas);
    document.removeEventListener('scroll', recolocar, true);
    [capa, foco, caja].forEach(x => x && x.remove()); capa = foco = caja = null;
    document.body.classList.remove('guia-activa');
    if (eraRiel) document.body.classList.add('menu-riel');
    window.FBmenu && window.FBmenu(false);
    const fd = new FormData(); fd.append('estado', estado);
    fetch('/guia/vista', { method: 'POST', body: fd, credentials: 'same-origin' }).catch(() => {});
    if (history.replaceState && /[?&]guia=/.test(location.search)) history.replaceState(null, '', location.pathname);
  }
  let eraRiel = false;
  function iniciar() { if (caja) return; eraRiel = document.body.classList.contains('menu-riel'); document.body.classList.remove('menu-riel'); i = 0; construir(); mostrar(); }
  function esc(t) { return String(t || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  if (window.top !== window) return;   // dentro de la vista previa de la página de inicio no se interrumpe
  if (document.readyState === 'complete') setTimeout(iniciar, 350); else addEventListener('load', () => setTimeout(iniciar, 350));
})();
