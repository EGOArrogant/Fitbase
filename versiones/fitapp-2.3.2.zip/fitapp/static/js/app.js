window.FBtr = s => (window.FB_T && window.FB_T[s]) || s;
// Tema claro/oscuro
(function () {
  const root = document.documentElement;
  const btns = document.querySelectorAll('[data-tema]');
  function etiqueta() {
    const dark = root.dataset.theme === 'dark' || (!root.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
    btns.forEach(b => {
      const t = dark ? FBtr('☀ Modo claro') : FBtr('☾ Modo oscuro'), i = t.indexOf(' ');
      b.innerHTML = '<span class="tema-ic" aria-hidden="true">' + t.slice(0, i) + '</span><span class="tema-tx">' + t.slice(i + 1) + '</span>';
      b.setAttribute('aria-label', t.slice(i + 1)); b.title = t.slice(i + 1); b.setAttribute('aria-pressed', dark);
    });
  }
  btns.forEach(b => b.addEventListener('click', () => {
    const dark = root.dataset.theme === 'dark' || (!root.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
    root.dataset.theme = dark ? 'light' : 'dark';
    try { localStorage.setItem('tema', root.dataset.theme); } catch (e) {}
    etiqueta();
  }));
  etiqueta();
})();

// Temporizador de descanso
(function () {
  const el = document.getElementById('timer');
  if (!el) return;
  let restante = 0, h = null;
  const pintar = () => { const m = Math.floor(restante / 60), s = restante % 60; el.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };
  const tick = () => {
    restante = Math.max(0, restante - 1); pintar();
    if (restante === 0) { clearInterval(h); h = null; try { navigator.vibrate && navigator.vibrate([200, 100, 200]); } catch (e) {} el.classList.add('ok-t'); }
  };
  document.querySelectorAll('[data-descanso]').forEach(b => b.addEventListener('click', () => {
    restante = parseInt(b.dataset.descanso, 10); el.classList.remove('ok-t'); pintar();
    clearInterval(h); h = setInterval(tick, 1000);
  }));
  document.querySelectorAll('[data-ajuste]').forEach(b => b.addEventListener('click', () => { restante = Math.max(0, restante + parseInt(b.dataset.ajuste, 10)); pintar(); }));
  pintar();
})();

// Rellenar el formulario de serie desde la sugerencia
document.querySelectorAll('[data-usar]').forEach(b => b.addEventListener('click', () => {
  const f = document.getElementById('form-serie'); if (!f) return;
  f.ejercicio.value = b.dataset.usar;
  if (b.dataset.peso) f.peso.value = b.dataset.peso;
  if (b.dataset.rir) f.rir.value = b.dataset.rir;
  f.reps.focus();
  f.scrollIntoView({ behavior: 'smooth', block: 'center' });
}));

// Menú lateral en celular (cajón deslizable)
(function () {
  const side = document.getElementById('menu-lateral'), velo = document.querySelector('.velo');
  if (!side) return;
  const abridores = document.querySelectorAll('[data-menu]');
  function abrir(si) {
    document.body.classList.toggle('menu-abierto', si);
    if (velo) velo.hidden = !si;
    abridores.forEach(b => b.setAttribute('aria-expanded', si));
    if (si) { const a = side.querySelector('a.nav.on') || side.querySelector('a'); a && a.focus({ preventScroll: true }); a && a.scrollIntoView({ block: 'center' }); }
  }
  window.FBmenu = abrir;
  abridores.forEach(b => b.addEventListener('click', () => abrir(!document.body.classList.contains('menu-abierto'))));
  document.querySelectorAll('[data-cerrar-menu]').forEach(b => b.addEventListener('click', () => abrir(false)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') abrir(false); });
  side.querySelectorAll('a').forEach(a => a.addEventListener('click', () => abrir(false)));
  // deslizar a la izquierda para cerrar
  let x0 = null;
  side.addEventListener('touchstart', e => { x0 = e.touches[0].clientX; }, { passive: true });
  side.addEventListener('touchend', e => { if (x0 !== null && x0 - e.changedTouches[0].clientX > 60) abrir(false); x0 = null; }, { passive: true });
})();

// Tablas anchas: indicar que se pueden desplazar
document.querySelectorAll('.tabla-wrap').forEach(w => {
  const marcar = () => w.classList.toggle('desliza', w.scrollWidth > w.clientWidth + 4);
  marcar(); window.addEventListener('resize', marcar);
});

// PDF: se abren en una pestaña nueva con el visor del navegador (desde ahí se guardan o comparten).
// Así funcionan también en celular y en la app instalada en la pantalla de inicio (donde las descargas directas fallan).
document.querySelectorAll('a[href*="pdf"]').forEach(a => {
  if (/\/pdf(\?|$)|\.pdf(\?|$)/.test(a.getAttribute('href'))) { a.target = '_blank'; a.rel = 'noopener'; }
});

// Navegación fluida: barra de carga, carga anticipada (para navegadores sin speculation rules) y posición del menú
(function () {
  const barra = document.querySelector('.carga-nav');
  const interno = a => a && a.href && a.origin === location.origin && !a.target && !a.hasAttribute('download') &&
    !/\/(salir|logout|demo)|pdf|\/api\/|\/fotos\/archivo\//.test(a.pathname) && !(a.pathname === location.pathname && a.hash);
  document.addEventListener('click', e => {
    const a = e.target.closest('a');
    if (!barra || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || !interno(a)) return;
    barra.classList.remove('on'); void barra.offsetWidth; barra.classList.add('on');
  });
  document.addEventListener('submit', e => { if (barra && !e.defaultPrevented && e.target.method !== 'dialog') { barra.classList.add('on'); } });
  addEventListener('pageshow', () => barra && barra.classList.remove('on'));
  // carga anticipada al pasar el ratón o tocar (Safari y Firefox no tienen speculation rules)
  const soporta = HTMLScriptElement.supports && HTMLScriptElement.supports('speculationrules');
  if (!soporta) {
    const hechos = new Set();
    const pre = e => {
      const a = e.target.closest && e.target.closest('a');
      if (!interno(a) || hechos.has(a.href) || /^\/(notificaciones|pago|pagar|guia|idioma|admin|salir|demo)/.test(a.pathname) || a.classList.contains('no-prefetch')) return;
      hechos.add(a.href);
      const l = document.createElement('link'); l.rel = 'prefetch'; l.href = a.href; document.head.appendChild(l);
    };
    document.addEventListener('pointerover', pre, { passive: true });
    document.addEventListener('touchstart', pre, { passive: true });
  }
  // el menú lateral conserva su desplazamiento entre páginas
  const side = document.getElementById('menu-lateral');
  if (side) {
    try { const y = sessionStorage.getItem('menuY'); if (y) side.scrollTop = +y; } catch (e) {}
    addEventListener('pagehide', () => { try { sessionStorage.setItem('menuY', side.scrollTop); } catch (e) {} });
  }
})();

// Notificaciones: contador en vivo, panel desplegable (computadora) y avisos emergentes
(function () {
  const botones = document.querySelectorAll('[data-notif]');
  if (!botones.length) return;
  const toasts = document.querySelector('.toasts');
  let ultimo = 0, panel = null;
  try { ultimo = parseInt(sessionStorage.getItem('notifUlt') || '0', 10) || 0; } catch (e) {}
  const esc = t => String(t || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function contador(n) {
    botones.forEach(b => { const s = b.querySelector('.notif-num'); if (!s) return; s.hidden = !n; s.textContent = n > 99 ? '99+' : n;
      b.setAttribute('aria-label', 'Notificaciones' + (n ? ', ' + n + ' sin leer' : '')); });
  }
  function toast(x) {
    if (!toasts) return;
    const a = document.createElement('a');
    a.className = 'toast'; a.href = '/notificaciones/' + x.id + '/abrir';
    a.innerHTML = '<span class="toast-ic">' + x.icono + '</span><span><b>' + esc(x.titulo) + '</b>' + (x.texto ? '<small>' + esc(x.texto) + '</small>' : '') + '</span>';
    toasts.appendChild(a);
    requestAnimationFrame(() => a.classList.add('on'));
    setTimeout(() => { a.classList.remove('on'); setTimeout(() => a.remove(), 400); }, 6500);
    try { if (document.hidden && 'Notification' in window && Notification.permission === 'granted') new Notification(x.titulo, { body: x.texto || '', icon: '/static/icon-180.png' }); } catch (e) {}
  }
  function revisar() {
    if (document.hidden && !('Notification' in window && Notification.permission === 'granted')) return;
    fetch('/notificaciones/estado.json?desde=' + ultimo, { credentials: 'same-origin', cache: 'no-store' }).then(r => r.ok ? r.json() : null).then(d => {
      if (!d || !d.ok) return;
      contador(d.no_leidas);
      const nuevas = (d.nuevas || []).slice().reverse();
      if (ultimo) nuevas.forEach(toast);
      const max = Math.max(ultimo, ...nuevas.map(x => x.id), 0);
      if (!ultimo || max > ultimo) { ultimo = max || ultimo; try { sessionStorage.setItem('notifUlt', ultimo); } catch (e) {} }
      if (!ultimo) fetch('/notificaciones/estado.json?lista=1', { credentials: 'same-origin' }).then(r => r.json()).then(x => {
        ultimo = (x.ultimas && x.ultimas[0] && x.ultimas[0].id) || 1; try { sessionStorage.setItem('notifUlt', ultimo); } catch (e) {} });
    }).catch(() => {});
  }
  function cerrar() { if (panel) { panel.remove(); panel = null; } }
  function abrirPanel(b) {
    cerrar();
    panel = document.createElement('div');
    panel.className = 'notif-panel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', FBtr('Notificaciones'));
    panel.innerHTML = '<div class="np-cab"><b>' + FBtr('Notificaciones') + '</b><button type="button" class="np-leer">' + FBtr('Marcar leídas') + '</button></div><div class="np-lista"><p class="sub">' + FBtr('Cargando…') + '</p></div>' +
      '<a class="np-todas" href="/notificaciones">' + FBtr('Ver todas') + '</a>' +
      ('Notification' in window && Notification.permission === 'default' ? '<button type="button" class="np-permiso">' + FBtr('🔔 Avisarme aunque tenga la pestaña cerrada') + '</button>' : '');
    document.body.appendChild(panel);
    const r = b.getBoundingClientRect();
    panel.style.top = (r.bottom + 8) + 'px'; panel.style.left = Math.max(12, Math.min(r.left, innerWidth - panel.offsetWidth - 12)) + 'px';
    fetch('/notificaciones/estado.json?lista=1', { credentials: 'same-origin', cache: 'no-store' }).then(r => r.json()).then(d => {
      const l = panel && panel.querySelector('.np-lista'); if (!l) return;
      l.innerHTML = (d.ultimas || []).length ? d.ultimas.map(x => '<a class="np-item ' + (x.leida ? '' : 'nueva') + '" href="/notificaciones/' + x.id + '/abrir"><span class="toast-ic">' + x.icono +
        '</span><span><b>' + esc(x.titulo) + '</b>' + (x.texto ? '<small>' + esc(x.texto) + '</small>' : '') + '<em>' + esc(x.cuando) + '</em></span></a>').join('') :
        '<p class="sub" style="padding:14px">' + FBtr('No tienes notificaciones todavía.') + '</p>';
    });
    panel.querySelector('.np-leer').addEventListener('click', () => fetch('/notificaciones/leer', { method: 'POST', credentials: 'same-origin' }).then(() => {
      contador(0); panel && panel.querySelectorAll('.np-item.nueva').forEach(x => x.classList.remove('nueva')); }));
    const pm = panel.querySelector('.np-permiso');
    pm && pm.addEventListener('click', () => Notification.requestPermission().then(() => pm.remove()));
    setTimeout(() => panel && panel.classList.add('on'));
  }
  botones.forEach(b => b.addEventListener('click', e => {
    if (matchMedia('(max-width:900px)').matches) return;      // en celular abre la página completa
    e.preventDefault(); panel ? cerrar() : abrirPanel(b);
  }));
  document.addEventListener('click', e => { if (panel && !panel.contains(e.target) && !e.target.closest('[data-notif]')) cerrar(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrar(); });
  revisar();
  setInterval(revisar, 20000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) revisar(); });
})();

// Ícono de la sección junto al título de cada página
(function () {
  const actual = document.querySelector('.side a.nav.on .ico');
  const h1 = document.querySelector('#contenido h1');
  if (!actual || !h1 || h1.querySelector('.cat-ins')) return;
  const b = document.createElement('span'); b.className = 'cat-ins'; b.setAttribute('aria-hidden', 'true');
  b.appendChild(actual.cloneNode(true)); h1.prepend(b);
})();

// Menú en riel (computadora): íconos con etiquetas, paneles por categoría y botón para expandir
(function () {
  const side = document.getElementById('menu-lateral');
  if (!side) return;
  const esRiel = () => document.body.classList.contains('menu-riel') && matchMedia('(min-width:901px)').matches;
  let fly = null, tip = null, cierre = null;
  function quitar() { if (fly) { fly.remove(); fly = null; } side.querySelectorAll('.fly-on').forEach(x => x.classList.remove('fly-on')); }
  function quitarTip() { if (tip) { tip.remove(); tip = null; } }
  function colocar(el, ref) {
    const r = ref.getBoundingClientRect();
    el.style.left = (r.right + 12) + 'px';
    el.style.top = Math.max(8, Math.min(r.top - 6, innerHeight - el.offsetHeight - 8)) + 'px';
  }
  function abrir(ref, titulo, icono, color, enlaces) {
    quitar(); quitarTip();
    fly = document.createElement('div');
    fly.className = 'riel-fly'; fly.setAttribute('role', 'menu');
    if (color) fly.dataset.c = color;
    fly.innerHTML = (titulo ? '<div class="riel-fly-cab">' + icono + '<span>' + titulo + '</span></div>' : '');
    enlaces.forEach(a => { const n = a.cloneNode(true); n.removeAttribute('data-guia-abrir'); n.setAttribute('role', 'menuitem'); fly.appendChild(n); });
    document.body.appendChild(fly); colocar(fly, ref);
    requestAnimationFrame(() => fly && fly.classList.add('on'));
    fly.addEventListener('mouseenter', () => clearTimeout(cierre));
    fly.addEventListener('mouseleave', () => { cierre = setTimeout(quitar, 220); });
  }
  side.querySelectorAll('details.ngrupo').forEach(d => {
    const s = d.querySelector('summary');
    const datos = () => [d.querySelector('.ngrupo-t').textContent, d.querySelector('.ngrupo-ic').innerHTML, d.dataset.c, [...d.querySelectorAll('.ngrupo-items a')]];
    s.addEventListener('click', e => {
      if (!esRiel()) return;
      e.preventDefault();
      if (d.classList.contains('fly-on') && fly) { quitar(); return; }
      abrir(s, ...datos()); d.classList.add('fly-on');
    });
    s.addEventListener('mouseenter', () => { if (!esRiel()) return; clearTimeout(cierre); cierre = setTimeout(() => { abrir(s, ...datos()); d.classList.add('fly-on'); }, 90); });
    s.addEventListener('mouseleave', () => { if (esRiel()) { clearTimeout(cierre); cierre = setTimeout(quitar, 260); } });
  });
  // botón «+»: acciones rápidas
  const cta = side.querySelector('[data-rapido]'), tpl = document.getElementById('rapido-tpl');
  if (cta && tpl) {
    cta.addEventListener('click', e => {
      if (!esRiel()) return;
      e.preventDefault();
      if (fly) { quitar(); return; }
      abrir(cta, FBtr('Registrar'), '', 'gen', [...tpl.content.querySelectorAll('a')]);
    });
  }
  // etiquetas al pasar sobre íconos sueltos
  side.addEventListener('mouseover', e => {
    if (!esRiel()) return;
    const a = e.target.closest('a.nav, .side-notif, .side-tema, .brand');
    if (!a || a.closest('details') || fly) return;
    const texto = a.querySelector('span:not(.notif-num):not(.brand-ic)') ? a.querySelector('span:not(.notif-num):not(.brand-ic)').textContent : (a.getAttribute('aria-label') || a.title || '');
    if (!texto.trim()) return;
    quitarTip();
    tip = document.createElement('div'); tip.className = 'riel-tip'; tip.textContent = texto.trim();
    document.body.appendChild(tip); colocar(tip, a); tip.style.top = (a.getBoundingClientRect().top + a.offsetHeight / 2 - tip.offsetHeight / 2) + 'px';
    requestAnimationFrame(() => tip && tip.classList.add('on'));
  });
  side.addEventListener('mouseout', e => { if (!e.relatedTarget || !side.contains(e.relatedTarget)) quitarTip(); else if (!e.relatedTarget.closest('a.nav, .side-notif, .side-tema, .brand')) quitarTip(); });
  document.addEventListener('click', e => { if (fly && !fly.contains(e.target) && !side.contains(e.target)) quitar(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { quitar(); quitarTip(); } });
  side.addEventListener('scroll', () => { quitar(); quitarTip(); }, { passive: true });
  // expandir / contraer
  document.querySelectorAll('[data-riel]').forEach(b => b.addEventListener('click', () => {
    const riel = !document.body.classList.contains('menu-riel');
    document.body.classList.add('riel-anim'); setTimeout(() => document.body.classList.remove('riel-anim'), 400);
    document.body.classList.toggle('menu-riel', riel); quitar(); quitarTip();
    try { localStorage.setItem('menuModo', riel ? 'riel' : 'expandido'); } catch (e) {}
  }));
})();
