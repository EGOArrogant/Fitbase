"""Proporcionalidad corporal, composición por zonas y afinidades deportivas.

- Estrategia Phantom de Ross & Wilson (1974): cada medida se ajusta a una estatura de 170.18 cm y se expresa como
  puntaje z frente a un humano de referencia unisex: z = (1/s)·[v·(170.18/talla)^d − P]  (d = 1 longitudes, 3 peso).
  z > +0.5: más largo/ancho de lo proporcional a tu estatura; z < −0.5: más corto/estrecho.
- Índice córmico (talla sentado / talla) e índice esquélico de Manouvrier ((talla − talla sentado) / talla sentado).
- Envergadura relativa (envergadura / talla).
- Índice acromio-ilíaco (biiliocrestal / biacromial).
- Área muscular del brazo corregida (Heymsfield et al. 1982) y perímetros corregidos por pliegue.
- Afinidades deportivas: rasgos frecuentes en deportistas de élite (Norton & Olds 2001, Sports Med 31:763-783;
  Ackland, Elliott & Bloomfield, Applied Anatomy and Biomechanics in Sport, 2009). Son ventajas biomecánicas posibles,
  no predicciones: el entrenamiento, la técnica y la fisiología pesan mucho más.
"""
import math

import calc

LONGITUDES = [("talla_sentado", "Talla sentado"), ("envergadura", "Envergadura (brazos abiertos, punta a punta)"),
              ("acromial_radial", "Brazo (acromial-radial)"), ("radial_estiloidea", "Antebrazo (radial-estiloidea)"),
              ("estiloidea_dactilar", "Mano (medio estiloidea-dactilar)"), ("ilioespinal", "Altura ilioespinal"),
              ("trocanterea", "Altura trocantérea"), ("troc_tibial", "Muslo (trocantérea-tibial lateral)"),
              ("tibial_lateral", "Altura tibial lateral (pierna)"), ("pie", "Longitud del pie")]
DIAMETROS_EXTRA = [("biacromial", "Biacromial (hombros)"), ("biiliocrestal", "Biiliocrestal (caderas)"),
                   ("torax_transverso", "Tórax transverso"), ("torax_ap", "Tórax anteroposterior")]
PERIMETROS_EXTRA = [("antebrazo", "Antebrazo máximo"), ("torax", "Tórax mesoesternal")]

# Phantom (Ross & Wilson 1974; Ross & Marfell-Jones 1991): media y desviación para 170.18 cm
PHANTOM = {
    "talla": (170.18, 6.29), "peso": (64.58, 8.60), "talla_sentado": (89.92, 4.50), "envergadura": (172.35, 7.41),
    "acromial_radial": (32.53, 1.77), "radial_estiloidea": (24.57, 1.37), "estiloidea_dactilar": (18.85, .85),
    "ilioespinal": (94.11, 4.71), "trocanterea": (86.40, 4.32), "troc_tibial": (41.37, 2.48), "tibial_lateral": (44.82, 2.56),
    "pie": (25.50, 1.16), "biacromial": (38.04, 1.92), "biiliocrestal": (28.84, 1.75), "torax_transverso": (27.92, 1.74),
    "torax_ap": (17.50, 1.38), "humero": (6.48, .35), "femur": (9.52, .48), "biestiloideo": (5.21, .28),
    "cuello": (34.91, 1.73), "brazo_relajado": (26.89, 2.33), "brazo_contraido": (29.41, 2.37), "antebrazo": (25.13, 1.41),
    "muneca": (16.35, .72), "torax": (87.86, 5.18), "cintura": (71.91, 4.45), "cadera": (94.67, 5.58), "muslo_medio": (53.20, 4.56),
    "pantorrilla_max": (35.25, 2.30),
    "triceps": (15.4, 4.47), "subescapular": (17.2, 5.07), "biceps": (8.0, 2.0), "cresta": (22.4, 6.80), "supraespinal": (15.4, 4.47),
    "abdominal": (25.4, 7.78), "muslo": (27.0, 8.33), "pantorrilla": (16.0, 4.67),
}
NOMBRES = {"talla_sentado": "Talla sentado", "envergadura": "Envergadura", "acromial_radial": "Brazo", "radial_estiloidea": "Antebrazo",
           "estiloidea_dactilar": "Mano", "ilioespinal": "Pierna (ilioespinal)", "trocanterea": "Altura trocantérea", "troc_tibial": "Muslo (longitud)",
           "tibial_lateral": "Pierna (tibial)", "pie": "Pie", "biacromial": "Hombros", "biiliocrestal": "Caderas", "torax_transverso": "Tórax ancho",
           "torax_ap": "Tórax profundo", "humero": "Codo (húmero)", "femur": "Rodilla (fémur)", "biestiloideo": "Muñeca (hueso)", "peso": "Peso",
           "brazo_relajado": "Brazo (perímetro)", "brazo_contraido": "Brazo contraído", "antebrazo": "Antebrazo (perímetro)", "torax": "Tórax (perímetro)",
           "cintura": "Cintura", "cadera": "Cadera (perímetro)", "muslo_medio": "Muslo (perímetro)", "pantorrilla_max": "Pantorrilla (perímetro)",
           "cuello": "Cuello", "muneca": "Muñeca (perímetro)",
           "triceps": "Pliegue tríceps", "subescapular": "Pliegue subescapular", "biceps": "Pliegue bíceps", "cresta": "Pliegue cresta ilíaca",
           "supraespinal": "Pliegue supraespinal", "abdominal": "Pliegue abdominal", "muslo": "Pliegue muslo", "pantorrilla": "Pliegue pantorrilla"}
GRUPOS_Z = [("Longitudes", ["talla_sentado", "envergadura", "acromial_radial", "radial_estiloidea", "estiloidea_dactilar", "ilioespinal", "troc_tibial", "tibial_lateral", "pie"]),
            ("Anchuras", ["biacromial", "biiliocrestal", "torax_transverso", "torax_ap", "humero", "femur", "biestiloideo"]),
            ("Perímetros", ["brazo_relajado", "brazo_contraido", "antebrazo", "torax", "cintura", "cadera", "muslo_medio", "pantorrilla_max"]),
            ("Grasa por zonas (pliegues)", ["triceps", "biceps", "subescapular", "cresta", "supraespinal", "abdominal", "muslo", "pantorrilla"])]


def _n(d, k):
    return calc.num(d.get(k))


def z_phantom(k, v, talla, peso=False):
    if v is None or not talla or k not in PHANTOM:
        return None
    m, s = PHANTOM[k]
    exp = 3 if peso else 1
    return ((v * (170.18 / talla) ** exp) - m) / s


def nivel(z, palabras=("corto", "medio", "largo")):
    if z is None:
        return None
    return palabras[0] if z < -.5 else palabras[2] if z > .5 else palabras[1]


def calcular(p, d, somatotipo=None):
    sexo = p.get("sexo", "Hombre")
    talla, peso = _n(d, "talla") or p.get("talla"), _n(d, "peso") or p.get("peso")
    if not talla:
        return None
    r = {"z": {}, "rasgos": [], "indices": [], "zonas": []}
    for k in PHANTOM:
        if k == "talla":
            continue
        v = _n(d, k)
        if v is not None:
            r["z"][k] = z_phantom(k, v, talla, k == "peso")
    z = r["z"]
    ts, env = _n(d, "talla_sentado"), _n(d, "envergadura")

    # --- tronco y piernas
    if ts:
        cor = ts / talla * 100
        clase = "tronco corto, piernas relativamente largas" if cor <= 51 else "tronco largo, piernas relativamente cortas" if cor >= 53.1 else "tronco y piernas proporcionados"
        r["indices"].append(("Índice córmico", f"{cor:.1f}", clase, "Talla sentado ÷ estatura. Braquicórmico ≤51 · metriocórmico 51.1-53 · macrocórmico ≥53.1"))
        esq = (talla - ts) / ts * 100
        r["indices"].append(("Índice esquélico", f"{esq:.1f}", "piernas cortas" if esq < 85 else "piernas largas" if esq >= 90 else "piernas medias",
                             "Longitud de piernas ÷ talla sentado (Manouvrier). Braquiesquélico <85 · mesoesquélico 85-89.9 · macroesquélico ≥90"))
        r["piernas"] = "cortas" if esq < 85 else "largas" if esq >= 90 else "medias"
        r["tronco"] = "largo" if cor >= 53.1 else "corto" if cor <= 51 else "medio"
    if z.get("ilioespinal") is not None and "piernas" not in r:
        r["piernas"] = {"corto": "cortas", "medio": "medias", "largo": "largas"}[nivel(z["ilioespinal"])]
    # --- brazos
    seg = [z[k] for k in ("acromial_radial", "radial_estiloidea", "estiloidea_dactilar") if z.get(k) is not None]
    if env:
        ape = env / talla
        r["indices"].append(("Envergadura relativa", f"{ape:.2f}", "brazos largos" if ape >= 1.04 else "brazos cortos" if ape <= .98 else "brazos medios",
                             "Envergadura ÷ estatura. Promedio ≈1.00-1.03"))
        r["brazos"] = "largos" if ape >= 1.04 else "cortos" if ape <= .98 else "medios"
    elif len(seg) >= 2:
        r["brazos"] = {"corto": "cortos", "medio": "medios", "largo": "largos"}[nivel(sum(seg) / len(seg))]
    # --- hombros y caderas
    bia, bic = _n(d, "biacromial"), _n(d, "biiliocrestal")
    if z.get("biacromial") is not None:
        r["hombros"] = {"corto": "estrechos", "medio": "medios", "largo": "anchos"}[nivel(z["biacromial"])]
    if z.get("biiliocrestal") is not None:
        r["caderas"] = {"corto": "estrechas", "medio": "medias", "largo": "anchas"}[nivel(z["biiliocrestal"])]
    if bia and bic:
        ai = bic / bia * 100
        r["indices"].append(("Índice acromio-ilíaco", f"{ai:.1f}", "tronco en V (hombros mucho más anchos que caderas)" if ai < 70 else
                             "caderas anchas respecto a los hombros" if ai > 75 else "hombros y caderas equilibrados",
                             "Biiliocrestal ÷ biacromial × 100. <70 en V · 70-75 intermedio · >75 trapezoidal"))
    # --- composición por zonas
    tri, bra = _n(d, "triceps"), _n(d, "brazo_relajado")
    if tri and bra:
        cmb = bra - math.pi * tri / 10
        ama = cmb ** 2 / (4 * math.pi) - (10 if sexo == "Hombre" else 6.5)
        r["zonas"].append(("Brazo", f"{cmb:.1f} cm", f"Área muscular {ama:.0f} cm² (Heymsfield 1982)"))
    for nom, per, pl in (("Muslo", "muslo_medio", "muslo"), ("Pantorrilla", "pantorrilla_max", "pantorrilla")):
        if _n(d, per) and _n(d, pl):
            r["zonas"].append((nom, f"{_n(d, per) - math.pi * _n(d, pl) / 10:.1f} cm", "Perímetro corregido por grasa (músculo + hueso)"))
    tronco = [_n(d, k) for k in ("subescapular", "cresta", "supraespinal", "abdominal")]
    extrem = [_n(d, k) for k in ("triceps", "biceps", "muslo", "pantorrilla")]
    if all(tronco) and all(extrem):
        ratio = sum(tronco) / sum(extrem)
        r["grasa_distribucion"] = (ratio, "central (más en el tronco)" if ratio > 1.2 else "periférica (más en brazos y piernas)" if ratio < .8 else "equilibrada")
    # --- rasgos y deportes
    for clave, txt in (("brazos", "Brazos"), ("piernas", "Piernas"), ("tronco", "Tronco"), ("hombros", "Hombros"), ("caderas", "Caderas")):
        if r.get(clave):
            r["rasgos"].append((txt, r[clave]))
    r["deportes"] = deportes(r, sexo, talla, somatotipo)
    return r if (r["z"] or r["indices"]) else None


DEPORTES = {
    "Natación": [("brazos", "largos", "brazos largos = brazada más larga"), ("tronco", "largo", "tronco largo favorece la flotación y el deslizamiento"),
                 ("hombros", "anchos", "hombros anchos para la tracción"), ("caderas", "estrechas", "caderas estrechas reducen el arrastre"), ("alto", True, "estatura alta")],
    "Remo": [("alto", True, "estatura alta = palanca larga"), ("brazos", "largos", "brazos largos alargan la palada"), ("piernas", "largas", "piernas largas en el empuje"),
             ("meso", True, "buena masa muscular")],
    "Baloncesto y voleibol": [("alto", True, "estatura alta"), ("brazos", "largos", "mayor alcance"), ("piernas", "largas", "piernas largas para el salto")],
    "Box, MMA y artes marciales": [("brazos", "largos", "mayor alcance de golpeo"), ("hombros", "anchos", "hombros anchos")],
    "Halterofilia y powerlifting": [("brazos", "cortos", "brazos cortos: menor recorrido en press"), ("piernas", "cortas", "piernas cortas: menor brazo de palanca en sentadilla"),
                                    ("tronco", "largo", "tronco largo y centro de masa bajo"), ("meso", True, "mesomorfia alta"), ("bajo", True, "estatura baja o media")],
    "Peso muerto y tirones": [("brazos", "largos", "brazos largos: la barra empieza más alta")],
    "Gimnasia y escalada": [("bajo", True, "estatura baja: rotaciones más rápidas"), ("brazos", "cortos", "palancas cortas"), ("meso", True, "fuerza relativa alta")],
    "Carreras de fondo": [("piernas", "largas", "piernas largas: zancada eficiente"), ("ecto", True, "linealidad (ectomorfia)"), ("caderas", "estrechas", "caderas estrechas")],
    "Velocidad y saltos": [("piernas", "largas", "piernas largas"), ("meso", True, "potencia muscular"), ("caderas", "estrechas", "caderas estrechas")],
    "Lucha y judo": [("piernas", "cortas", "centro de masa bajo"), ("tronco", "largo", "tronco largo y estable"), ("meso", True, "mesomorfia alta")],
    "Ciclismo": [("piernas", "largas", "piernas largas = mejor palanca en el pedal"), ("ecto", True, "linealidad para escalar")],
    "Fútbol": [("meso", True, "mesomorfia equilibrada"), ("medio", True, "proporciones medias: versatilidad")],
}


def deportes(r, sexo, talla, st):
    alto = talla >= (183 if sexo == "Hombre" else 170)
    bajo = talla <= (168 if sexo == "Hombre" else 156)
    meso = bool(st and st.get("meso", 0) >= 5)
    ecto = bool(st and st.get("ecto", 0) >= 3.5)
    medio = sum(1 for k in ("brazos", "piernas", "tronco") if r.get(k) in ("medios", "medias", "medio")) >= 2
    rasgos = {"alto": alto, "bajo": bajo, "meso": meso, "ecto": ecto, "medio": medio}
    out = []
    for dep, reglas in DEPORTES.items():
        si = []
        for clave, valor, motivo in reglas:
            if (rasgos.get(clave) is True and valor is True) or (clave in r and r.get(clave) == valor):
                si.append(motivo)
        if si:
            out.append((dep, len(si) / len(reglas), si))
    out.sort(key=lambda x: (-len(x[2]), -x[1]))
    return out[:5]


def grafica_z(z, alto_fila=22, ancho=560):
    """Barras horizontales de puntaje Phantom (−3 a +3). Devuelve SVG."""
    filas = [(g, k) for g, ks in GRUPOS_Z for k in ks if z.get(k) is not None]
    if not filas:
        return ""
    izq, der = 150, 20
    w = ancho - izq - der
    x0 = izq + w / 2
    esc = w / 6
    h, y = 0, 10
    partes, grupo = [], None
    for g, k in filas:
        if g != grupo:
            grupo = g
            partes.append(f'<text x="0" y="{y + 12}" font-size="11" font-weight="700" fill="var(--text-2)">{g.upper()}</text>')
            y += 20
        v = max(-3, min(3, z[k]))
        x = x0 + min(0, v) * esc
        col = "var(--accent)" if abs(v) <= .5 else ("#d18b0f" if g.startswith("Grasa") and v > .5 else "var(--accent-strong)")
        partes.append(f'<text x="{izq - 8}" y="{y + 14}" font-size="12" text-anchor="end" fill="var(--text)">{NOMBRES.get(k, k)}</text>'
                      f'<rect x="{x:.1f}" y="{y + 4}" width="{max(abs(v) * esc, 2):.1f}" height="{alto_fila - 8}" rx="3" fill="{col}"/>'
                      f'<text x="{(x0 + v * esc + (6 if v >= 0 else -6)):.1f}" y="{y + 14}" font-size="11" text-anchor="{"start" if v >= 0 else "end"}" fill="var(--text-2)">{(z[k] if abs(z[k]) >= .05 else 0):+.1f}</text>')
        y += alto_fila
    h = y + 24
    guias = "".join(f'<line x1="{x0 + t * esc:.1f}" x2="{x0 + t * esc:.1f}" y1="0" y2="{h - 20}" stroke="var(--border)" stroke-dasharray="{"" if t == 0 else "3 4"}"/>'
                    f'<text x="{x0 + t * esc:.1f}" y="{h - 6}" font-size="10" text-anchor="middle" fill="var(--text-2)">{t:+d}</text>' for t in range(-3, 4))
    banda = f'<rect x="{x0 - .5 * esc:.1f}" y="0" width="{esc:.1f}" height="{h - 20}" fill="var(--accent-soft)" opacity=".6"/>'
    return (f'<svg viewBox="0 0 {ancho} {h}" class="zphantom" role="img" aria-label="Puntajes z de proporcionalidad">{banda}{guias}{"".join(partes)}</svg>')
