"""Guías prácticas derivadas del contenido verificado de la app: por músculo, suplemento, mito, condición de salud,
equipo y técnica de cada ejercicio de fuerza."""
from data.contenido import MITOS, SUPLEMENTOS
from data.ejercicios import EJERCICIOS, sustitutos
from data.equipo import NOMBRES as EQUIPOS
from data.musculos import MUSCULOS

PM = "https://pubmed.ncbi.nlm.nih.gov/"
SCH_VOL = ("Schoenfeld BJ, Ogborn D, Krieger JW. J Sports Sci. 2017.", "10.1080/02640414.2016.1210197", False)
PELLAND = ("Pelland JC et al. Sports Med. 2025.", PM + "41343037/", False)
ACSM09 = ("Ratamess NA et al. ACSM position stand: progression models in resistance training. Med Sci Sports Exerc. 2009.", PM + "19204579/", False)
REFALO = ("Refalo MC et al. Sports Med. 2023.", "10.1007/s40279-022-01784-y", True)
IOC = ("Maughan RJ et al. IOC consensus statement on dietary supplements. Br J Sports Med. 2018.", PM + "29540367/", False)
KREIDER = ("Kreider RB et al. J Int Soc Sports Nutr. 2017.", "10.1186/s12970-017-0173-z", True)
GUEST = ("Guest NS et al. J Int Soc Sports Nutr. 2021.", "10.1186/s12970-020-00383-4", True)
MORTON = ("Morton RW et al. Br J Sports Med. 2018.", "10.1136/bjsports-2017-097608", True)
OMS = ("Bull FC et al. WHO 2020 guidelines. Br J Sports Med. 2020.", "10.1136/bjsports-2020-102955", True)


def _musculos():
    out = []
    for mid, m in MUSCULOS.items():
        nombre = m["nombre"].split(" (")[0]
        ejs = [e for e in EJERCICIOS.values() if e["targets"][0] == mid and e["tipo"] in ("Compuesto", "Aislamiento")]
        prin = [e["nombre"] for e in sorted(ejs, key=lambda e: (e["tipo"] != "Compuesto", e["nombre"]))][:6]
        out.append(dict(
            slug=f"guia-{mid.replace('_', '-')}", categoria="Guías por músculo", minutos=4,
            titulo=f"Cómo entrenar el {nombre.lower()}" if not nombre.lower().startswith(("abd", "obl", "isq", "aduc", "erec", "glút", "trap", "dors", "romb", "tib")) else f"Guía para entrenar: {nombre.lower()}",
            resumen=m["funcion"],
            claves=[m["funcion"].split(". ")[0] + ".", f"Volumen orientativo: {m['volumen']}", m["consejos"][0]],
            secciones=[("Anatomía básica", [m["anatomia"]]), ("Consejos de entrenamiento", m["consejos"]),
                       ("Movilidad", [m["movilidad"]]), ("Lesiones y prevención", [m["lesiones"]])],
            aplicar=([f"Ejercicios principales: {', '.join(prin)}."] if prin else []) +
                    ["Repártelo en al menos 2 sesiones por semana.", "Termina las series a 0–3 repeticiones del fallo.",
                     "Abre el mapa muscular de la app para ver todos los ejercicios de este músculo."],
            refs=[SCH_VOL, PELLAND]))
    return out


def _suplementos():
    nivel_txt = {"A": "evidencia fuerte", "B": "evidencia emergente", "C": "evidencia débil", "D": "sin evidencia útil",
                 "Salud": "solo para corregir deficiencias", "Riesgo": "riesgo para la salud"}
    refs_de = {"Creatina": [KREIDER, IOC], "Cafeína": [GUEST, IOC], "Proteína": [MORTON, IOC]}
    out = []
    for nombre, nivel, dosis, nota in SUPLEMENTOS:
        corto = nombre.split(" (")[0].split(",")[0]
        refs = next((v for k, v in refs_de.items() if nombre.startswith(k)), [IOC])
        out.append(dict(
            slug="suplemento-" + corto.lower().replace(" ", "-").replace("/", "-").replace("'", ""), categoria="Suplementos", minutos=2,
            titulo=f"{nombre}: ¿sirve?", resumen=f"Nivel de evidencia: {nivel_txt.get(nivel, nivel)}. {nota}",
            claves=[f"Clasificación: {nivel} ({nivel_txt.get(nivel, nivel)}).", f"Dosis habitual: {dosis}.", nota],
            secciones=[("Contexto", ["Los suplementos solo tienen un papel menor y siempre después de una alimentación adecuada (COI 2018). "
                                     "La clasificación usada en la app sigue el marco ABCD del Instituto Australiano del Deporte."])],
            aplicar=["Primero resuelve comida, sueño y entrenamiento.", "Elige productos con certificación de terceros (NSF Certified for Sport, Informed Sport).",
                     "Consulta a tu médico si tomas medicamentos, estás embarazada o tienes alguna enfermedad."],
            refs=refs))
    return out


def _mitos():
    out = []
    refs = {"agujetas": [("Roberts LA et al. J Physiol. 2015.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4594298", True)],
            "zona": [OMS], "rodillas": [ACSM09], "abdominales": [("Hall KD, Guo J. Gastroenterology. 2017.", "10.1053/j.gastro.2017.01.052", True)],
            "convierte": [ACSM09], "proteína": [("Trommelen J et al. Cell Rep Med. 2023.", "10.1016/j.xcrm.2023.101324", True)],
            "fallo": [REFALO], "Estirar": [("Behm DG et al. Appl Physiol Nutr Metab. 2016.", "10.1139/apnm-2015-0235", False)]}
    for i, (mito, verdad) in enumerate(MITOS):
        r = next((v for k, v in refs.items() if k.lower() in mito.lower()), [ACSM09])
        out.append(dict(slug=f"mito-{i + 1}", categoria="Mitos", minutos=2, titulo=f"Mito: «{mito}»",
                        resumen=verdad.split(". ")[0] + ".", claves=[verdad.split(". ")[0] + "."] + [x + "." for x in verdad.split(". ")[1:3] if x],
                        secciones=[("La explicación", [verdad])],
                        aplicar=["Desconfía de reglas absolutas en el gimnasio.", "Busca la fuente: si no hay estudio, es opinión.",
                                 "Consulta la sección Mitos vs evidencia de la app."], refs=r))
    return out


def _condiciones():
    import seleccion as sel
    casos = [
        ("obesidad", dict(peso=150, talla=172, edad=40), "Ejercicio con sobrepeso importante: empieza por el bajo impacto"),
        ("imc30", dict(peso=95, talla=172, edad=35), "Sobrepeso: cómo progresar del caminar al trotar"),
        ("rodilla", dict(sondeo={"dolor": ["rodilla"]}), "Dolor de rodilla: cómo entrenar sin empeorarlo"),
        ("espalda", dict(sondeo={"dolor": ["espalda"]}), "Dolor de espalda baja: el ejercicio es parte del tratamiento"),
        ("cadera", dict(sondeo={"dolor": ["cadera"]}), "Dolor de cadera: fuerza y bajo impacto"),
        ("hombro", dict(sondeo={"dolor": ["hombro"]}), "Dolor de hombro: qué evitar por ahora"),
        ("mayores", dict(edad=70), "Después de los 65: fuerza, equilibrio y potencia"),
        ("embarazo", dict(condiciones=["embarazo"]), "Ejercicio en el embarazo: reglas prácticas"),
        ("osteoporosis", dict(condiciones=["osteoporosis"]), "Osteoporosis: qué ejercicios elegir"),
        ("hipertension", dict(condiciones=["hipertension"]), "Hipertensión: cómo entrenar con seguridad"),
        ("diabetes", dict(condiciones=["diabetes"]), "Diabetes: combina fuerza y aeróbico"),
        ("principiante", dict(nivel="Principiante"), "Tus primeras 8 semanas en el gimnasio"),
        ("suelo", dict(sondeo={"suelo": "no"}), "Si te cuesta bajar al suelo: ejercicios de pie y en banco"),
        ("caminar", dict(sondeo={"camina10": "no"}), "Si te cansas rápido al caminar: empieza con bloques cortos"),
    ]
    out = []
    for clave, p, titulo in casos:
        base = dict(peso=70, talla=170, edad=30, nivel="Intermedio", condiciones=[], sondeo={})
        base.update(p)
        ev = sel.evaluar(base)
        reglas = [r for r in ev["reglas"] if r["tipo"] != "info" or clave in ("mayores", "diabetes", "principiante", "imc30", "suelo")]
        if not reglas:
            continue
        r0 = reglas[0]
        fuentes = []
        for r in reglas:
            if "doi:" in r["fuente"]:
                cita, doi = r["fuente"].rsplit("doi:", 1)
                fuentes.append((cita.strip().rstrip("."), doi.strip(), False))
        if not fuentes:
            fuentes = [ACSM09]
        cardio = f"Cardio sugerido: {', '.join(ev['cardio'][:4])}." if ev["cardio"] else ""
        out.append(dict(slug=f"condicion-{clave}", categoria="Salud y movimiento", minutos=3, titulo=titulo, resumen=r0["texto"].split(". ")[0] + ".",
                        claves=[r["titulo"] + "." for r in reglas][:3],
                        secciones=[(r["titulo"], [r["texto"]]) for r in reglas],
                        aplicar=[x for x in [cardio, "Responde el sondeo inicial: la app ajusta tus ejercicios automáticamente.",
                                             "Abre 'Mi plan inteligente' para ver qué ejercicios te recomienda y cuáles deja para después.",
                                             "Ante dolor de pecho, mareo o falta de aire desproporcionada, detente y consulta."] if x],
                        refs=fuentes[:3]))
    return out


EQUIPO_TXT = {
    "Barra": ("La herramienta para mover más peso en los básicos.", "Permite cargas altas y progresiones pequeñas con discos.", "Requiere técnica y, en press y sentadilla, seguros o asistente."),
    "Mancuernas": ("Versátiles, trabajan cada lado por separado.", "Mayor rango de movimiento y corrigen desequilibrios.", "Los saltos de peso entre mancuernas pueden ser grandes: usa más repeticiones para progresar."),
    "Máquina": ("Trayectoria guiada: ideal para aprender y para llegar cerca del fallo con seguridad.", "Buenas para principiantes, adultos mayores y rehabilitación.", "Ajusta asiento y apoyos a tu cuerpo antes de empezar."),
    "Polea": ("Tensión constante en todo el recorrido.", "Permite muchos ángulos y cambios de carga rápidos.", "Controla la fase de regreso: la polea tira de ti."),
    "Kettlebell": ("Pesa con asa descentrada: ideal para movimientos balísticos como el swing.", "Desarrolla potencia, agarre y acondicionamiento.", "Aprende la bisagra de cadera antes del swing."),
    "Peso corporal": ("Tu propio cuerpo como resistencia: sin equipo.", "Progresa cambiando la palanca, el rango o las repeticiones.", "Útil en casa y de viaje."),
    "Disco": ("Los discos sirven también como pesa libre.", "Prácticos para elevaciones, halos y sentadillas al frente.", "Sujétalos con firmeza; los discos lisos entrenan el agarre."),
    "Balón medicinal": ("Para lanzamientos y trabajo de potencia.", "Permite movimientos explosivos sin frenar la carga.", "Usa balones que no reboten para los lanzamientos al suelo."),
    "Banda elástica": ("Resistencia que aumenta al estirarse.", "Económica, portátil y amable con las articulaciones.", "Revisa que no tenga cortes; ánclala bien."),
    "TRX": ("Correas de suspensión: tu peso corporal con ángulo ajustable.", "Cambia la dificultad con la inclinación del cuerpo.", "Ancla en un punto sólido y revisa las correas."),
    "Bosu": ("Media esfera para equilibrio y estabilidad.", "Útil en equilibrio y propiocepción, no para cargas pesadas.", "No hagas sentadillas pesadas sobre superficies inestables."),
    "Máquina Smith": ("Barra guiada sobre rieles con seguros.", "Permite entrenar pesado con más seguridad si estás solo.", "La trayectoria es fija: ajusta tu posición a ella."),
    "Cardio": ("Caminadora, bicicleta, elíptica, remo, natación y más.", "Mejora la capacidad cardiorrespiratoria y la salud.", "Elige bajo impacto si tienes sobrepeso importante o dolor articular."),
    "Estiramientos": ("Mejoran el rango de movimiento de forma temporal y acumulativa.", "Útiles después de entrenar o en sesiones aparte.", "Sin dolor: tensión suave 30–60 s."),
    "Yoga": ("Combina movilidad, fuerza y respiración.", "Recomendado como ejercicio mente-cuerpo en artrosis de rodilla (OARSI 2019).", "Adapta posturas con bloques o silla."),
    "Pilates": ("Control del tronco y la cadera con movimientos precisos.", "Buen complemento para la espalda y el core.", "Calidad antes que cantidad de repeticiones."),
    "Recuperación": ("Rodillo, pelota de masaje, respiración y caminata suave.", "Mejoran la sensación de rigidez y ayudan a bajar pulsaciones.", "No sustituyen el sueño ni la buena alimentación."),
}


def _equipo():
    out = []
    for nombre in EQUIPOS:
        a, b, c = EQUIPO_TXT.get(nombre, ("", "", ""))
        ejs = [e["nombre"] for e in EJERCICIOS.values() if e["equipo"] == nombre][:8]
        out.append(dict(slug="equipo-" + nombre.lower().replace(" ", "-").replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u").replace("/", "-"),
                        categoria="Equipo y lugar", minutos=2, titulo=f"Entrenar con {nombre.lower()}", resumen=a,
                        claves=[a, b, c], secciones=[("Ejercicios de la biblioteca", [", ".join(ejs) + "."])],
                        aplicar=["Marca tu equipo disponible en el sondeo o en Entrenar hoy.", "Filtra la biblioteca de ejercicios por este equipo.",
                                 "Progresa poco a poco y prioriza la técnica."],
                        refs=[OMS] if nombre in ("Cardio",) else [("Bannuru RR et al. OARSI guidelines. Osteoarthritis Cartilage. 2019.", "10.1016/j.joca.2019.06.011", False)] if nombre == "Yoga" else [ACSM09]))
    return out


ERRORES = [  # (palabras clave en el nombre, errores comunes)
    (("Sentadilla", "Prensa", "Zancada", "Subida"), ["Rodillas que se van hacia dentro al subir.", "Talones que se despegan del suelo.", "Bajar poco por usar demasiado peso."]),
    (("Peso muerto", "Hip thrust", "Puente", "Swing", "Hiperextensiones", "Buenos"), ["Redondear la espalda baja.", "Hacer el movimiento con la espalda en lugar de la cadera.", "Hiperextender la espalda al final."]),
    (("Press de banca", "Press inclinado", "Press de pecho", "Lagartija", "Fondos", "Press cerrado", "Pase de pecho"), ["Codos muy abiertos (90°) que cargan el hombro.", "Rebotar la carga en el pecho.", "Despegar glúteos o cabeza del banco."]),
    (("Press militar", "Press de hombro", "Elevación", "Elevaciones"), ["Arquear la espalda baja para subir el peso.", "Encoger los hombros hacia las orejas.", "Balancear el cuerpo para ayudarte."]),
    (("Remo", "Jalón", "Dominadas", "Pull-over", "Face pull", "Y-T-W", "Pájaros", "posterior"), ["Tirar con los brazos sin mover las escápulas.", "Balancear el torso para mover más peso.", "No completar el estiramiento al regresar."]),
    (("Curl",), ["Mover los codos hacia adelante.", "Balancear la espalda.", "Bajar demasiado rápido sin controlar."]),
    (("Extensión", "Press francés"), ["Abrir los codos.", "Mover el hombro en lugar del codo.", "Rango corto por exceso de carga."]),
    (("Plancha", "Rueda", "Dead bug", "Bird dog", "Pallof", "Elevación de piernas", "Crunch", "Giro", "cien"), ["Hundir o elevar demasiado la cadera.", "Aguantar la respiración.", "Sacrificar la posición por hacer más repeticiones."]),
]
GENERICOS = ["Usar más carga de la que permite una técnica limpia.", "Moverse muy rápido en la fase de bajada.", "No calentar con series ligeras."]


def _ejercicios():
    out = []
    for e in EJERCICIOS.values():
        if e["tipo"] not in ("Compuesto", "Aislamiento"):
            continue
        errores = next((err for claves, err in ERRORES if any(k.lower() in e["nombre"].lower() for k in claves)), GENERICOS)
        musc = [MUSCULOS[t]["nombre"].split(" (")[0] for t in e["targets"] if t in MUSCULOS]
        alts = [s["nombre"] for s in sustitutos(e["nombre"])[:4]]
        reps = "6–10" if e["tipo"] == "Compuesto" else "10–15"
        out.append(dict(slug="tecnica-" + e["slug"], categoria="Técnica de ejercicios", minutos=2, titulo=f"Técnica: {e['nombre']}",
                        resumen=e["claves"], claves=[f"Trabaja: {', '.join(musc)}.", f"Equipo: {e['equipo']}. Tipo: {e['tipo'].lower()}.", e["claves"]],
                        secciones=[("Errores comunes", errores), ("Alternativas", [", ".join(alts) + "." if alts else "Consulta la biblioteca de ejercicios."])],
                        aplicar=[f"Rango sugerido: {reps} repeticiones con 1–3 en reserva.", "Calienta con 2–3 series ligeras.",
                                 "Progresa con doble progresión: primero repeticiones, luego carga.", "Abre la ficha del ejercicio para ver los músculos y el video."],
                        refs=[ACSM09, REFALO]))
    return out


GUIAS = _musculos() + _suplementos() + _mitos() + _condiciones() + _equipo() + _ejercicios()
