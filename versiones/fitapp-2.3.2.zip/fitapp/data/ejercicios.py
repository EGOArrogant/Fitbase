"""Biblioteca de ejercicios.

Cada ejercicio: (nombre, [músculos objetivo: primero el principal], tipo, equipo, incremento, claves técnicas)
Los IDs de músculo corresponden al mapa corporal (data/musculos.py).
Conteo de volumen: el grupo del músculo principal suma 1 serie; los demás grupos implicados suman 0.5
(conteo fraccionado, Pelland et al. 2025).
"""

C, A = "Compuesto", "Aislamiento"

_LIB = [
    # ---------------- PECHO ----------------
    ("Press de banca", ["pectoral", "triceps", "deltoide_ant"], C, "Barra", 0.025,
     "Escápulas retraídas y pies firmes. Baja la barra al pecho medio con antebrazos verticales."),
    ("Press de banca con mancuernas", ["pectoral", "triceps", "deltoide_ant"], C, "Mancuernas", 0.025,
     "Baja hasta sentir estiramiento en el pecho; codos a ~45° del torso."),
    ("Press inclinado con barra", ["pectoral", "deltoide_ant", "triceps"], C, "Barra", 0.025,
     "Banco a 30°. Toca la parte alta del pecho sin rebotar."),
    ("Press inclinado con mancuernas", ["pectoral", "deltoide_ant", "triceps"], C, "Mancuernas", 0.025,
     "Banco a 30°; controla la bajada 2–3 s."),
    ("Press de pecho en máquina", ["pectoral", "triceps", "deltoide_ant"], C, "Máquina", 0.025,
     "Ajusta el asiento para que las asas queden a la altura del pecho medio."),
    ("Fondos en paralelas", ["pectoral", "triceps", "deltoide_ant"], C, "Peso corporal", 0.025,
     "Inclina el torso adelante; baja hasta ~90° de codo si el hombro lo tolera."),
    ("Lagartijas", ["pectoral", "triceps", "deltoide_ant"], C, "Peso corporal", 0.025,
     "Cuerpo en línea recta; pecho cerca del suelo en cada repetición."),
    ("Aperturas con mancuernas", ["pectoral"], A, "Mancuernas", 0.025,
     "Codos ligeramente flexionados y fijos; abre hasta sentir estiramiento."),
    ("Aperturas en polea (cruce de poleas)", ["pectoral"], A, "Polea", 0.025,
     "Lleva las manos al frente en arco; aprieta al final sin encoger hombros."),
    ("Aperturas en máquina (pec deck)", ["pectoral"], A, "Máquina", 0.025,
     "Movimiento controlado; no dejes que el peso golpee al regresar."),
    # ---------------- ESPALDA ----------------
    ("Dominadas", ["dorsal", "biceps", "romboides"], C, "Peso corporal", 0.025,
     "Inicia bajando las escápulas; sube hasta que la barbilla pase la barra."),
    ("Dominadas asistidas", ["dorsal", "biceps", "romboides"], C, "Máquina", 0.025,
     "Usa la asistencia mínima que te permita 6–12 repeticiones limpias."),
    ("Jalón al pecho", ["dorsal", "biceps", "romboides"], C, "Polea", 0.025,
     "Pecho alto; lleva la barra a la clavícula sin balancear el torso."),
    ("Jalón con agarre estrecho", ["dorsal", "biceps"], C, "Polea", 0.025,
     "Codos pegados al cuerpo; estira por completo arriba."),
    ("Remo con barra", ["dorsal", "romboides", "biceps", "deltoide_post"], C, "Barra", 0.025,
     "Torso ~45°, espalda neutra; lleva la barra al ombligo sin impulso."),
    ("Remo con mancuerna a una mano", ["dorsal", "romboides", "biceps"], C, "Mancuernas", 0.025,
     "Apoya rodilla y mano; tira con el codo hacia la cadera."),
    ("Remo en polea baja", ["romboides", "dorsal", "biceps"], C, "Polea", 0.025,
     "Pecho alto; junta escápulas al final y estira al regresar."),
    ("Remo Gironda (polea baja, agarre cerrado)", ["romboides", "dorsal", "biceps"], C, "Polea", 0.025,
     "Variante de remo en polea con agarre estrecho; torso estable."),
    ("Remo en máquina con apoyo de pecho", ["romboides", "dorsal", "deltoide_post"], C, "Máquina", 0.025,
     "El apoyo de pecho elimina el impulso: ideal para llegar cerca del fallo."),
    ("Pull-over en polea", ["dorsal"], A, "Polea", 0.025,
     "Brazos casi rectos; lleva la barra a los muslos en arco."),
    ("Encogimientos con mancuernas", ["trapecio"], A, "Mancuernas", 0.025,
     "Sube los hombros hacia las orejas, pausa 1 s; sin rotar."),
    ("Hiperextensiones", ["erectores", "gluteo", "isquios"], C, "Peso corporal", 0.025,
     "Movimiento desde la cadera con espalda neutra; no hiperextiendas al final."),
    # ---------------- HOMBRO ----------------
    ("Press militar con barra", ["deltoide_ant", "triceps", "deltoide_lat"], C, "Barra", 0.025,
     "Glúteos y abdomen firmes; la barra sube cerca de la cara."),
    ("Press militar con mancuernas", ["deltoide_ant", "triceps", "deltoide_lat"], C, "Mancuernas", 0.025,
     "Sentado o de pie; baja hasta que las mancuernas lleguen a la altura de las orejas."),
    ("Press de hombro en máquina", ["deltoide_ant", "triceps"], C, "Máquina", 0.025,
     "Espalda apoyada; recorrido completo."),
    ("Elevaciones laterales con mancuernas", ["deltoide_lat"], A, "Mancuernas", 0.025,
     "Sube hasta la altura del hombro con el codo ligeramente flexionado; sin balanceo."),
    ("Elevaciones laterales en polea", ["deltoide_lat"], A, "Polea", 0.025,
     "La polea mantiene tensión en la parte baja del recorrido."),
    ("Elevaciones laterales en máquina", ["deltoide_lat"], A, "Máquina", 0.025,
     "Alinea el eje de la máquina con el hombro."),
    ("Elevaciones frontales con mancuernas", ["deltoide_ant"], A, "Mancuernas", 0.025,
     "Suelen ser innecesarias si ya haces press: el deltoide anterior recibe mucho trabajo indirecto."),
    ("Pájaros (deltoide posterior) con mancuernas", ["deltoide_post", "romboides"], A, "Mancuernas", 0.025,
     "Torso inclinado; abre los brazos llevando los codos hacia atrás."),
    ("Deltoide posterior en máquina", ["deltoide_post", "romboides"], A, "Máquina", 0.025,
     "Agarre neutro; no encojas los hombros."),
    ("Face pulls", ["deltoide_post", "romboides", "trapecio"], A, "Polea", 0.025,
     "Cuerda a la altura de la cara; separa las manos al final con rotación externa."),
    # ---------------- BRAZOS ----------------
    ("Curl con barra", ["biceps", "antebrazo"], A, "Barra", 0.025, "Codos quietos junto al torso; sin balancear la espalda."),
    ("Curl con barra EZ", ["biceps", "antebrazo"], A, "Barra", 0.025, "El agarre angulado reduce la tensión en las muñecas."),
    ("Curl con mancuernas", ["biceps", "antebrazo"], A, "Mancuernas", 0.025, "Supina la muñeca al subir."),
    ("Curl martillo", ["biceps", "antebrazo"], A, "Mancuernas", 0.025, "Agarre neutro: trabaja braquial y braquiorradial."),
    ("Curl inclinado con mancuernas", ["biceps"], A, "Mancuernas", 0.025, "El banco inclinado estira el bíceps (posición alargada)."),
    ("Curl predicador (Scott)", ["biceps"], A, "Barra", 0.025, "Baja hasta casi extender el codo sin perder el control."),
    ("Curl en polea baja", ["biceps"], A, "Polea", 0.025, "Tensión constante durante todo el recorrido."),
    ("Press francés con barra", ["triceps"], A, "Barra", 0.025, "Codos apuntando al techo; baja la barra hacia la frente o detrás de la cabeza."),
    ("Extensión de tríceps en polea", ["triceps"], A, "Polea", 0.025, "Codos pegados; extiende por completo."),
    ("Extensión con cuerda sobre la cabeza", ["triceps"], A, "Polea", 0.025, "Trabaja la cabeza larga del tríceps en posición estirada."),
    ("Extensión de tríceps con mancuerna", ["triceps"], A, "Mancuernas", 0.025, "Sobre la cabeza, con ambas manos."),
    ("Press cerrado en banca", ["triceps", "pectoral", "deltoide_ant"], C, "Barra", 0.025, "Manos al ancho de hombros; codos cerca del torso."),
    ("Curl de muñeca", ["antebrazo"], A, "Mancuernas", 0.025, "Antebrazo apoyado; recorrido completo de la muñeca."),
    # ---------------- PIERNA ----------------
    ("Sentadilla con barra", ["cuadriceps", "gluteo", "aductores", "erectores"], C, "Barra", 0.05,
     "Pies al ancho de hombros; rodillas siguen la dirección de los pies (pueden pasar la punta). Profundidad: al menos muslo paralelo."),
    ("Sentadilla frontal", ["cuadriceps", "gluteo", "erectores"], C, "Barra", 0.05, "Codos altos; torso más vertical que la sentadilla trasera."),
    ("Sentadilla hack", ["cuadriceps", "gluteo"], C, "Máquina", 0.05, "Baja profundo con la espalda apoyada."),
    ("Sentadilla en máquina Smith", ["cuadriceps", "gluteo"], C, "Máquina Smith", 0.05, "Coloca los pies ligeramente adelante de la barra."),
    ("Prensa de piernas", ["cuadriceps", "gluteo", "aductores"], C, "Máquina", 0.05, "Baja hasta ~90° de rodilla sin despegar la cadera del respaldo."),
    ("Sentadilla búlgara", ["cuadriceps", "gluteo", "aductores"], C, "Mancuernas", 0.05, "Pie trasero sobre el banco; torso ligeramente inclinado para más glúteo."),
    ("Zancadas con mancuernas", ["cuadriceps", "gluteo"], C, "Mancuernas", 0.05, "Paso amplio; rodilla trasera cerca del suelo."),
    ("Sentadilla goblet", ["cuadriceps", "gluteo"], C, "Mancuernas", 0.05, "Ideal para aprender el patrón de sentadilla."),
    ("Extensión de cuádriceps", ["cuadriceps"], A, "Máquina", 0.025, "Inclinar el respaldo atrás estira el recto femoral."),
    ("Peso muerto", ["isquios", "gluteo", "erectores", "trapecio"], C, "Barra", 0.05,
     "Barra pegada al cuerpo; espalda neutra; empuja el suelo con las piernas."),
    ("Peso muerto rumano", ["isquios", "gluteo", "erectores"], C, "Barra", 0.05, "Cadera atrás con rodillas casi rectas; baja hasta sentir estiramiento."),
    ("Peso muerto sumo", ["gluteo", "aductores", "cuadriceps", "erectores"], C, "Barra", 0.05, "Postura amplia, puntas hacia afuera, torso más vertical."),
    ("Hip thrust con barra", ["gluteo", "isquios"], C, "Barra", 0.05, "Barbilla al pecho; extiende la cadera y aprieta el glúteo arriba."),
    ("Puente de glúteo", ["gluteo"], A, "Peso corporal", 0.05, "Buena opción para principiantes o en casa."),
    ("Abducción de cadera en máquina", ["gluteo"], A, "Máquina", 0.025, "Trabaja el glúteo medio; inclinarse adelante aumenta el rango."),
    ("Aducción de cadera en máquina", ["aductores"], A, "Máquina", 0.025, "Recorrido completo y controlado."),
    ("Curl femoral acostado", ["isquios"], A, "Máquina", 0.025, "Cadera pegada al banco."),
    ("Curl femoral sentado", ["isquios"], A, "Máquina", 0.025, "Sentado, el isquio trabaja más estirado: tiende a dar más hipertrofia que acostado (Maeo 2021)."),
    ("Elevación de talones de pie", ["pantorrilla"], A, "Máquina", 0.025, "Pausa 1–2 s abajo, en el estiramiento; recorrido completo."),
    ("Elevación de talones sentado", ["pantorrilla"], A, "Máquina", 0.025, "Enfatiza el sóleo."),
    ("Elevación de puntas (tibial)", ["tibial"], A, "Peso corporal", 0.025, "Apoyado en la pared, eleva las puntas de los pies."),
    # ---------------- CORE ----------------
    ("Crunch en polea", ["abdomen"], A, "Polea", 0.025, "Flexiona la columna llevando el pecho hacia la cadera."),
    ("Elevación de piernas colgado", ["abdomen", "oblicuos"], A, "Peso corporal", 0.025, "Enrolla la pelvis; evita balancearte."),
    ("Rueda abdominal", ["abdomen", "oblicuos"], A, "Peso corporal", 0.025, "Sin arquear la zona lumbar."),
    ("Plancha", ["abdomen", "oblicuos"], A, "Peso corporal", 0.025, "Glúteos y abdomen firmes; progresa en tiempo o con carga."),
    ("Pallof press", ["oblicuos", "abdomen"], A, "Polea", 0.025, "Antirrotación: resiste el giro con los brazos extendidos."),
    ("Plancha lateral", ["oblicuos"], A, "Peso corporal", 0.025, "Cuerpo alineado; cadera arriba."),
]

# Grupo de volumen por músculo del mapa corporal
CA, MO = "Cardio", "Movilidad"
_LIB += [
    # ---------------- KETTLEBELL ----------------
    ("Swing con kettlebell", ["gluteo", "isquios", "erectores"], C, "Kettlebell", 0.04,
     "Bisagra de cadera, no sentadilla: empuja la cadera atrás y proyecta la pesa con un golpe de glúteo hasta la altura del pecho."),
    ("Sentadilla goblet con kettlebell", ["cuadriceps", "gluteo"], C, "Kettlebell", 0.04,
     "Pesa pegada al pecho, codos entre las rodillas; baja con el torso erguido."),
    ("Peso muerto con kettlebell", ["gluteo", "isquios", "erectores"], C, "Kettlebell", 0.04,
     "Pesa entre los pies; espalda neutra y empuja el suelo. Buen primer paso antes del peso muerto con barra."),
    ("Press de hombro con kettlebell", ["deltoide_ant", "triceps", "deltoide_lat"], C, "Kettlebell", 0.04,
     "Abdomen y glúteos firmes; la pesa descansa sobre el antebrazo y sube en línea recta."),
    ("Remo con kettlebell", ["dorsal", "romboides", "biceps"], C, "Kettlebell", 0.04,
     "Apoyo en banco o postura escalonada; lleva el codo hacia la cadera."),
    ("Levantamiento turco (Turkish get-up)", ["deltoide_ant", "oblicuos", "gluteo"], C, "Kettlebell", 0.04,
     "Brazo siempre vertical con la mirada en la pesa; aprende cada fase sin peso o con un zapato encima del puño."),
    ("Paseo del granjero", ["antebrazo", "trapecio", "oblicuos"], C, "Kettlebell", 0.05,
     "Pesas a los lados, hombros abajo y atrás; pasos cortos y torso erguido durante 20–40 m."),
    ("Clean con kettlebell", ["gluteo", "isquios", "deltoide_ant"], C, "Kettlebell", 0.04,
     "La pesa rueda alrededor de la mano hasta la posición de rack; no la dejes golpear el antebrazo."),
    # ---------------- BANDA ----------------
    ("Jalón con banda elástica", ["dorsal", "biceps"], C, "Banda elástica", 0.05,
     "Ancla la banda arriba; lleva los codos hacia las costillas con el pecho alto."),
    ("Remo con banda elástica", ["romboides", "dorsal", "biceps"], C, "Banda elástica", 0.05,
     "Sentado con piernas extendidas o anclada al frente; junta escápulas al final."),
    ("Face pull con banda", ["deltoide_post", "romboides", "trapecio"], A, "Banda elástica", 0.05,
     "Tira hacia la cara separando las manos; codos altos."),
    ("Press de pecho con banda", ["pectoral", "triceps", "deltoide_ant"], C, "Banda elástica", 0.05,
     "Banda por detrás de la espalda o anclada; empuja al frente sin encoger hombros."),
    ("Curl con banda elástica", ["biceps"], A, "Banda elástica", 0.05,
     "Pisa la banda; codos fijos a los costados y baja lento."),
    ("Extensión de tríceps con banda", ["triceps"], A, "Banda elástica", 0.05,
     "Ancla alta; codos pegados y extiende por completo."),
    ("Caminata lateral con banda", ["gluteo"], A, "Banda elástica", 0.05,
     "Banda sobre rodillas o tobillos; media sentadilla y pasos laterales sin juntar los pies."),
    ("Pallof press con banda", ["oblicuos", "abdomen"], A, "Banda elástica", 0.05,
     "Banda lateral a la altura del pecho; empuja al frente y resiste el giro 2–3 s."),
    ("Rotación externa de hombro con banda", ["deltoide_post"], A, "Banda elástica", 0.05,
     "Codo pegado al costado a 90°; gira el antebrazo hacia fuera sin mover el codo. Útil para la salud del hombro."),
    # ---------------- TRX ----------------
    ("Remo invertido en TRX", ["dorsal", "romboides", "biceps"], C, "TRX", 0.05,
     "Cuerpo en línea recta; entre más horizontal, más difícil."),
    ("Lagartija en TRX", ["pectoral", "triceps", "deltoide_ant"], C, "TRX", 0.05,
     "Correas cortas y cuerpo firme; controla que las asas no se abran."),
    ("Sentadilla asistida en TRX", ["cuadriceps", "gluteo"], C, "TRX", 0.05,
     "Las correas ayudan al equilibrio: ideal para aprender la sentadilla o con poca movilidad."),
    ("Curl femoral en TRX", ["isquios", "gluteo"], A, "TRX", 0.05,
     "Talones en las asas y cadera arriba; lleva los talones a los glúteos."),
    ("Y-T-W en TRX", ["deltoide_post", "trapecio", "romboides"], A, "TRX", 0.05,
     "Brazos rectos dibujando la letra; inclinación suave para empezar."),
    ("Plancha con pies en TRX", ["abdomen", "oblicuos"], A, "TRX", 0.05,
     "Pies en las asas; mantén la cadera alineada sin hundir la espalda."),
    # ---------------- BOSU ----------------
    ("Sentadilla sobre bosu", ["cuadriceps", "gluteo"], C, "Bosu", 0.05,
     "Lado plano o domo hacia arriba según el nivel; prioriza el control sobre la carga."),
    ("Plancha sobre bosu", ["abdomen", "oblicuos"], A, "Bosu", 0.05,
     "Antebrazos sobre el domo; abdomen y glúteos firmes."),
    ("Lagartija sobre bosu", ["pectoral", "triceps"], C, "Bosu", 0.05,
     "Manos en los bordes del lado plano; cuerpo en línea."),
    ("Equilibrio a una pierna en bosu", ["gluteo", "tibial"], A, "Bosu", 0.05,
     "Rodilla ligeramente flexionada; 20–30 s por pierna. Entrena el equilibrio y la estabilidad del tobillo."),
    # ---------------- SMITH ----------------
    ("Press de banca en máquina Smith", ["pectoral", "triceps", "deltoide_ant"], C, "Máquina Smith", 0.025,
     "Ajusta el banco para que la barra baje al pecho medio; usa los seguros."),
    ("Press inclinado en máquina Smith", ["pectoral", "deltoide_ant", "triceps"], C, "Máquina Smith", 0.025,
     "Banco a 30°; la barra toca la parte alta del pecho."),
    ("Hip thrust en máquina Smith", ["gluteo", "isquios"], C, "Máquina Smith", 0.025,
     "Espalda alta en el banco, barra sobre la cadera con almohadilla; sube hasta alinear tronco y muslos."),
    ("Elevación de talones en máquina Smith", ["pantorrilla"], A, "Máquina Smith", 0.025,
     "Antepiés sobre un disco; baja lento hasta estirar y sube por completo."),
    ("Zancada en máquina Smith", ["cuadriceps", "gluteo"], C, "Máquina Smith", 0.025,
     "Postura escalonada fija; baja vertical con el torso erguido."),
    # ---------------- BALÓN MEDICINAL ----------------
    ("Lanzamiento de balón al suelo (slam)", ["dorsal", "abdomen"], C, "Balón medicinal", 0.05,
     "Sube el balón por encima de la cabeza y lánzalo con todo el cuerpo; usa balón que no rebote."),
    ("Lanzamiento a la pared (wall ball)", ["cuadriceps", "gluteo", "deltoide_ant"], C, "Balón medicinal", 0.05,
     "Sentadilla y empuje en un solo movimiento; recibe el balón y baja de nuevo."),
    ("Giro ruso con balón", ["oblicuos", "abdomen"], A, "Balón medicinal", 0.05,
     "Pies apoyados al empezar; gira el tronco, no solo los brazos."),
    ("Pase de pecho con balón", ["pectoral", "triceps"], C, "Balón medicinal", 0.05,
     "Contra la pared o con compañero; empuje explosivo desde el pecho."),
    # ---------------- DISCO ----------------
    ("Elevación frontal con disco", ["deltoide_ant"], A, "Disco", 0.05,
     "Sujeta el disco a los lados; sube hasta la altura de los ojos sin balancear."),
    ("Halo con disco", ["deltoide_ant", "trapecio", "oblicuos"], A, "Disco", 0.05,
     "Rodea la cabeza con el disco cerca; abdomen firme y sin arquear la espalda."),
    ("Sentadilla con disco al frente", ["cuadriceps", "gluteo"], C, "Disco", 0.05,
     "Disco abrazado al pecho; útil para aprender la sentadilla."),
    ("Pinza con discos", ["antebrazo"], A, "Disco", 0.05,
     "Sujeta dos discos lisos con los dedos 20–30 s; fortalece el agarre."),
    # ---------------- CARDIO ----------------
    ("Caminata en caminadora", ["cuadriceps", "pantorrilla"], CA, "Cardio", 0,
     "Paso natural y brazos sueltos; empieza con 10–20 min y sube 5 min por semana."),
    ("Caminata inclinada en caminadora", ["gluteo", "pantorrilla"], CA, "Cardio", 0,
     "Inclinación 5–12 % a velocidad cómoda; no te sujetes del pasamanos."),
    ("Bicicleta estática", ["cuadriceps", "gluteo"], CA, "Cardio", 0,
     "Sillín a la altura de la cadera; rodilla casi extendida abajo. Sin impacto en las articulaciones."),
    ("Bicicleta reclinada", ["cuadriceps", "gluteo"], CA, "Cardio", 0,
     "Respaldo que apoya la espalda: buena opción con dolor lumbar, sobrepeso importante o poco equilibrio."),
    ("Elíptica", ["cuadriceps", "gluteo", "isquios"], CA, "Cardio", 0,
     "Bajo impacto; empuja con todo el pie y mantén el tronco erguido."),
    ("Remo ergómetro", ["dorsal", "cuadriceps", "gluteo"], CA, "Cardio", 0,
     "Piernas, tronco y brazos en ese orden; regresa en orden inverso."),
    ("Natación", ["dorsal", "deltoide_ant", "triceps"], CA, "Cardio", 0,
     "El agua sostiene el peso del cuerpo: cero impacto. Ideal con dolor articular o sobrepeso."),
    ("Caminata en agua (aquaeróbics)", ["cuadriceps", "gluteo"], CA, "Cardio", 0,
     "Agua a la altura del pecho; camina y haz ejercicios con flotadores."),
    ("Escaladora", ["gluteo", "cuadriceps", "pantorrilla"], CA, "Cardio", 0,
     "Pasos completos sin recargarte en los brazos."),
    ("Correr", ["cuadriceps", "pantorrilla", "isquios"], CA, "Cardio", 0,
     "Alto impacto: empieza alternando caminar y trotar. Sube máximo ~10 % el volumen semanal."),
    ("Saltar la cuerda", ["pantorrilla", "cuadriceps"], CA, "Cardio", 0,
     "Saltos bajos sobre las puntas; alto impacto, intervalos cortos al inicio."),
    ("Intervalos en bicicleta (HIIT)", ["cuadriceps", "gluteo"], CA, "Cardio", 0,
     "Ejemplo: 30 s fuerte y 90 s suave × 6–10. Solo con buena base y sin contraindicaciones médicas."),
    ("Burpees", ["cuadriceps", "pectoral", "deltoide_ant"], CA, "Cardio", 0,
     "Alto impacto y alta intensidad; versión sin salto para empezar."),
    # ---------------- ESTIRAMIENTOS ----------------
    ("Estiramiento de flexores de cadera", ["cuadriceps"], MO, "Estiramientos", 0,
     "Rodilla atrás en el suelo, aprieta el glúteo y lleva la cadera al frente. 30–60 s por lado."),
    ("Estiramiento de isquiotibiales", ["isquios"], MO, "Estiramientos", 0,
     "Pierna sobre un escalón, espalda recta e inclínate desde la cadera."),
    ("Estiramiento de pectoral en marco de puerta", ["pectoral", "deltoide_ant"], MO, "Estiramientos", 0,
     "Antebrazo en el marco a 90° y gira el torso al lado contrario."),
    ("Estiramiento de pantorrilla en pared", ["pantorrilla"], MO, "Estiramientos", 0,
     "Talón atrás pegado al suelo; rodilla recta (gemelo) y luego flexionada (sóleo)."),
    ("Estiramiento de cuádriceps de pie", ["cuadriceps"], MO, "Estiramientos", 0,
     "Lleva el talón al glúteo con rodillas juntas; apóyate en la pared si lo necesitas."),
    ("Estiramiento de dorsal en barra o rack", ["dorsal"], MO, "Estiramientos", 0,
     "Sujeta un soporte y lleva la cadera atrás y hacia un lado."),
    ("Estiramiento de glúteo (figura 4)", ["gluteo"], MO, "Estiramientos", 0,
     "Tobillo sobre la rodilla contraria; acerca la pierna al pecho. Hay versión sentada en silla."),
    # ---------------- YOGA ----------------
    ("Perro boca abajo", ["isquios", "pantorrilla", "deltoide_ant"], MO, "Yoga", 0,
     "Cadera arriba y atrás; rodillas flexionadas si los isquiotibiales están tensos."),
    ("Postura del niño", ["erectores", "dorsal"], MO, "Yoga", 0,
     "Rodillas separadas y glúteos a los talones; respira profundo 30–60 s."),
    ("Guerrero II", ["cuadriceps", "gluteo", "deltoide_lat"], MO, "Yoga", 0,
     "Rodilla delantera sobre el tobillo; brazos largos a la altura de los hombros."),
    ("Gato-vaca", ["erectores", "abdomen"], MO, "Yoga", 0,
     "En cuatro apoyos, alterna redondear y arquear la espalda con la respiración."),
    ("Saludo al sol (versión suave)", ["isquios", "erectores", "deltoide_ant"], MO, "Yoga", 0,
     "Secuencia continua y lenta; adapta con apoyo de manos en bloques o silla."),
    # ---------------- PILATES ----------------
    ("Puente de hombros (pilates)", ["gluteo", "isquios"], A, "Pilates", 0,
     "Sube la cadera vértebra por vértebra y baja igual de lento."),
    ("El cien (the hundred)", ["abdomen"], A, "Pilates", 0,
     "Cabeza y hombros despegados, brazos bombean 100 veces; piernas flexionadas para empezar."),
    ("Dead bug", ["abdomen", "oblicuos"], A, "Pilates", 0,
     "Espalda baja pegada al suelo; extiende brazo y pierna contrarios sin que la espalda se despegue."),
    ("Bird dog", ["erectores", "gluteo", "abdomen"], A, "Pilates", 0,
     "En cuatro apoyos, extiende brazo y pierna contrarios sin rotar la cadera. Ejercicio base para la espalda baja."),
    ("Patada lateral acostado (pilates)", ["gluteo"], A, "Pilates", 0,
     "Acostado de lado, cadera estable; la pierna superior va adelante y atrás controlada."),
    # ---------------- RECUPERACIÓN ----------------
    ("Rodillo de espuma en cuádriceps", ["cuadriceps"], MO, "Recuperación", 0,
     "Rueda lento 30–60 s; puede mejorar la sensación de rigidez a corto plazo. Evita rodar sobre articulaciones."),
    ("Rodillo de espuma en espalda alta", ["romboides", "erectores"], MO, "Recuperación", 0,
     "Rodillo bajo los omóplatos, cadera apoyada; no lo uses en la zona lumbar."),
    ("Pelota de masaje en glúteo", ["gluteo"], MO, "Recuperación", 0,
     "Siéntate sobre la pelota y busca puntos tensos 30–60 s."),
    ("Respiración diafragmática", ["abdomen"], MO, "Recuperación", 0,
     "Acostado, inhala por la nariz inflando el abdomen 4 s y exhala 6 s. Ayuda a bajar las pulsaciones después de entrenar."),
    ("Caminata de enfriamiento", ["cuadriceps"], MO, "Recuperación", 0,
     "5–10 min a ritmo suave al terminar la sesión."),
    # ---------------- PESO CORPORAL (bajo impacto, principiantes) ----------------
    ("Sentadilla a la silla", ["cuadriceps", "gluteo"], C, "Peso corporal", 0.05,
     "Siéntate y levántate de una silla sin usar las manos; la altura de la silla regula la dificultad."),
    ("Lagartija inclinada en pared o banco", ["pectoral", "triceps"], C, "Peso corporal", 0.05,
     "Manos en una superficie alta; entre más vertical, más fácil."),
    ("Subida a escalón", ["cuadriceps", "gluteo"], C, "Peso corporal", 0.05,
     "Escalón bajo y apoyo de una mano si hace falta; empuja con la pierna de arriba."),
]

GRUPO_DE = {
    "pectoral": "Pecho", "dorsal": "Espalda", "romboides": "Espalda", "trapecio": "Espalda", "erectores": "Espalda",
    "deltoide_ant": "Hombro", "deltoide_lat": "Hombro", "deltoide_post": "Hombro",
    "biceps": "Bíceps", "antebrazo": None, "triceps": "Tríceps",
    "abdomen": "Core", "oblicuos": "Core",
    "cuadriceps": "Cuádriceps", "isquios": "Isquiotibiales", "gluteo": "Glúteo",
    "aductores": None, "pantorrilla": "Pantorrilla", "tibial": None,
}
GRUPOS = ["Pecho", "Espalda", "Hombro", "Bíceps", "Tríceps", "Cuádriceps", "Isquiotibiales", "Glúteo", "Pantorrilla", "Core"]


def _slug(s):
    import unicodedata, re
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


EJERCICIOS = {}
for nombre, targets, tipo, equipo, inc, claves in _LIB:
    grupo = GRUPO_DE.get(targets[0])
    secundarios = []
    for t in targets[1:]:
        g = GRUPO_DE.get(t)
        if g and g != grupo and g not in secundarios:
            secundarios.append(g)
    EJERCICIOS[nombre] = {
        "nombre": nombre, "slug": _slug(nombre), "targets": targets, "tipo": tipo, "equipo": equipo,
        "incremento": inc, "claves": claves, "grupo": grupo or "Otros", "secundarios": secundarios,
    }

POR_SLUG = {e["slug"]: e for e in EJERCICIOS.values()}
EQUIPOS = sorted({e["equipo"] for e in EJERCICIOS.values()})


def sustitutos(nombre, equipo=None):
    """Ejercicios del mismo músculo principal y tipo, opcionalmente con otro equipo."""
    e = EJERCICIOS.get(nombre)
    if not e:
        return []
    out = [x for x in EJERCICIOS.values()
           if x["nombre"] != nombre and x["targets"][0] == e["targets"][0]
           and ((x["tipo"] in ("Compuesto", "Aislamiento")) == (e["tipo"] in ("Compuesto", "Aislamiento")))
           and (equipo is None or x["equipo"] == equipo)]
    out.sort(key=lambda x: (x["tipo"] != e["tipo"], x["nombre"]))
    return out
