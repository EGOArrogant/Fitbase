"""Artículos de investigación (bloque 2: nutrición; bloque 3: salud, recuperación, hábitos y suplementos)."""
from data.articulos_inv1 import PM, PMC, art, A  # noqa: F401  (comparte la lista A)

HELMS = ("Helms ER et al. Evidence-based recommendations for natural bodybuilding contest preparation: nutrition and supplementation. J Int Soc Sports Nutr. 2014.", PM + "24864135/", True)
THOMAS = ("Thomas DT et al. Nutrition and athletic performance (ACSM, AND, DC). Med Sci Sports Exerc. 2016.", PM + "26917108/", False)
JAGER = ("Jäger R et al. ISSN position stand: protein and exercise. J Int Soc Sports Nutr. 2017.", "10.1186/s12970-017-0177-8", True)
KERKSICK = ("Kerksick CM et al. ISSN position stand: nutrient timing. J Int Soc Sports Nutr. 2017.", "10.1186/s12970-017-0189-4", True)
MORTON = ("Morton RW et al. Br J Sports Med. 2018.", "10.1136/bjsports-2017-097608", True)
IOC = ("Maughan RJ et al. IOC consensus statement: dietary supplements and the high-performance athlete. Br J Sports Med. 2018.", PM + "29540367/", False)

# ---------------- NUTRICIÓN ----------------
art("¿Qué fórmula de calorías usar? Depende de quién eres", "Nutrición",
    "Mifflin-St Jeor funciona bien en población general; en deportistas, Cunningham (con masa libre de grasa) suele acercarse más.",
    ["Ninguna ecuación es exacta para una persona.", "En deportistas, Cunningham y Harris-Benedict se acercaron más a lo medido.", "Tu peso real a 2–3 semanas es la mejor calibración."],
    [("Lo que dice la ciencia", ["Un metaanálisis de O'Neill y colaboradores (2023) comparó ecuaciones de gasto en reposo con mediciones en atletas: Cunningham y Harris-Benedict no difirieron de forma significativa del valor medido, mientras que Mifflin-St Jeor subestimó.",
                                 "Por eso la app recomienda Cunningham si conoces tu masa libre de grasa y calcula tu gasto adaptativo con tu tendencia de peso."])],
    ["Captura tu % de grasa si lo conoces para usar Cunningham.", "Pésate 3–4 veces por semana y registra lo que comes.", "Ajusta 100–200 kcal según tu gasto adaptativo."],
    [("O'Neill JER et al. Accuracy of resting metabolic rate prediction equations in athletes: systematic review and meta-analysis. Sports Med. 2023.", "https://link.springer.com/article/10.1007/s40279-023-01896-z", True)])
art("Gasto adaptativo: deja que tus datos calculen tus calorías", "Nutrición",
    "Con tu peso diario y tus calorías registradas, la app estima cuánto gastas en realidad.",
    ["Las fórmulas tienen ±10 % de error.", "Tu tendencia de peso y tu ingesta revelan tu gasto real.", "Se necesitan 2–3 semanas de datos constantes."],
    [("Cómo funciona", ["Si en una semana comiste en promedio 2,300 kcal y tu tendencia bajó 0.3 kg, tu gasto real fue aproximadamente 2,300 + 0.3 × 7700 / 7 ≈ 2,630 kcal. La app hace este cálculo con tu tendencia suavizada, no con pesos sueltos.",
                       "El cuerpo también se adapta al déficit (baja un poco el gasto), por eso conviene recalcular cada pocas semanas."])],
    ["Registra peso y calorías al menos 5 días por semana.", "No reacciones a un solo día: mira la tendencia.", "Si el gasto adaptativo difiere más de 150 kcal de tu meta, ajusta."],
    [("Hall KD, Guo J. Obesity energetics. Gastroenterology. 2017.", "10.1053/j.gastro.2017.01.052", True)])
art("Superávit para ganar músculo: menos es más", "Nutrición",
    "Un superávit de 10–20 % sobre tu mantenimiento basta. Comer de más solo suma grasa.",
    ["Ganancia razonable: 0.25–0.5 % del peso por semana.", "Avanzados: aún más lento.", "La proteína y el entrenamiento importan más que el exceso de calorías."],
    [("Lo que dice la ciencia", ["Iraki y colaboradores (2019) recomiendan para culturistas fuera de competencia un superávit moderado de 10–20 %, con ganancias de peso pequeñas para limitar la grasa. Helms (2014) recomienda ritmos de pérdida de 0.5–1 % por semana en preparación."])],
    ["Usa la calculadora de energía con objetivo 'Ganar músculo'.", "Si subes más de 0.5 % por semana, baja 100–150 kcal.", "Mide tu cintura: si crece rápido, el superávit es alto."],
    [("Iraki J et al. Nutrition recommendations for bodybuilders in the off-season. Sports. 2019.", "https://www.mdpi.com/2075-4663/7/7/154", True), HELMS])
art("Recomposición: perder grasa y ganar músculo a la vez", "Pérdida de grasa",
    "Es posible, sobre todo en principiantes o al volver a entrenar, pero no maximiza ninguno de los dos objetivos.",
    ["Funciona mejor en principiantes, personas con más grasa o que regresan.", "Requiere proteína alta y entrenamiento de fuerza constante.", "El peso puede moverse poco: mide cintura y fuerza."],
    [("Lo que dice la ciencia", ["Las revisiones sobre nutrición para culturistas señalan que la recomposición se observa incluso en entrenados, con déficit leve o mantenimiento y proteína alta, aunque más lenta que una fase dedicada."])],
    ["Calorías cerca del mantenimiento o déficit leve.", "Proteína 1.8–2.2 g/kg.", "Juzga el progreso por fuerza, cintura y fotos, no solo la báscula."],
    [HELMS, ("Iraki J et al. Sports. 2019.", "https://www.mdpi.com/2075-4663/7/7/154", True)])
art("Proteína en déficit: protege tu músculo", "Pérdida de grasa",
    "Cuando comes menos, subir la proteína ayuda a conservar masa muscular, sobre todo si ya eres delgado.",
    ["En déficit, 1.8–2.2 g/kg de peso es un buen rango.", "Personas magras y entrenadas: 2.3–3.1 g/kg de masa libre de grasa.", "La proteína también da saciedad."],
    [("Lo que dice la ciencia", ["Helms y colaboradores (2014) recomiendan 2.3–3.1 g/kg de masa libre de grasa durante la preparación de competencia en atletas magros. Morton (2018) sitúa la meseta media en 1.6 g/kg en condiciones normales."])],
    ["Fija primero tu proteína y luego reparte el resto.", "Incluye proteína en cada comida.", "Si llegas con dificultad, usa lácteos o proteína en polvo."],
    [HELMS, MORTON])
art("Proteína vegetal: ¿alcanza para ganar músculo?", "Nutrición",
    "Sí, si cubres la cantidad total y combinas fuentes. Puede requerir un poco más de proteína por día.",
    ["Las proteínas vegetales suelen tener menos leucina por gramo.", "Combinar leguminosas y cereales completa los aminoácidos.", "Soya, tofu y proteína de chícharo son buenas opciones."],
    [("Lo que dice la ciencia", ["La postura de la ISSN sobre proteína (Jäger 2017) indica que las proteínas vegetales pueden apoyar las adaptaciones cuando se consume una cantidad suficiente; tienden a tener menor digestibilidad y leucina, lo que se compensa con dosis algo mayores o combinaciones."])],
    ["Apunta a la parte alta del rango: 1.8–2.2 g/kg.", "Frijol + tortilla, lenteja + arroz, tofu, soya texturizada.", "Considera creatina: en dietas vegetarianas eleva más las reservas musculares."],
    [JAGER])
art("Carbohidratos según tu entrenamiento", "Nutrición",
    "Quien entrena pesas suele necesitar 3–7 g de carbohidratos por kg al día. Deportes de resistencia, más.",
    ["Actividad ligera o moderada: 3–5 g/kg.", "Entrenamiento moderado de ~1 h diaria: 5–7 g/kg.", "Más solo para deportes de resistencia de alto volumen."],
    [("Lo que dice la ciencia", ["La postura conjunta del ACSM, la Academia de Nutrición y Dietética y Dietitians of Canada (Thomas 2016) recomienda periodizar los carbohidratos en gramos por kilo según la carga de entrenamiento, en lugar de usar porcentajes fijos de energía."])],
    ["Pon más carbohidratos los días de entrenamiento y alrededor de la sesión.", "Prefiere fuentes con fibra: avena, tortilla de maíz, frijol, fruta, papa.", "En déficit, baja primero grasas y carbohidratos, nunca la proteína."],
    [THOMAS])
art("Grasas: el mínimo que no debes cruzar", "Nutrición",
    "Las grasas deben aportar al menos 20 % de tus calorías. Bajar más puede afectar tus hormonas.",
    ["Rango general: 20–35 % de las calorías.", "Mínimo práctico: ~0.5 g/kg de peso.", "Las dietas muy bajas en grasa pueden bajar la testosterona."],
    [("Lo que dice la ciencia", ["Thomas (2016) recomienda 20–35 % de la energía como grasa. Helms (2014) acepta 15–30 % durante la preparación de competencia, por periodos limitados."])],
    ["La app nunca te pone menos de 0.5 g/kg ni de 20 % de grasa.", "Prioriza aceite de oliva, aguacate, nueces, pescado.", "Mide las grasas: 9 kcal por gramo."],
    [THOMAS, HELMS])
art("El mito de la ventana anabólica de 30 minutos", "Nutrición",
    "No tienes que tomar tu proteína corriendo al terminar. Importa más el total del día.",
    ["La ventana es amplia: varias horas antes y después.", "Si entrenas en ayunas, sí conviene comer pronto.", "Una comida con proteína 1–3 h antes y otra 1–3 h después es suficiente."],
    [("Lo que dice la ciencia", ["La postura de la ISSN sobre el momento de los nutrientes (Kerksick 2017) concluye que el total diario de proteína y energía es lo más importante; el momento cobra relevancia si se entrena en ayunas o con varias sesiones al día."])],
    ["Desayuna o come algo con proteína unas horas antes de entrenar.", "Haz una comida normal después.", "El licuado post-entreno es práctico, no obligatorio."],
    [KERKSICK])
art("Hidratación: cuánto tomar cuando entrenas", "Nutrición",
    "No hay una cifra única: depende de cuánto sudas. Pesarte antes y después de entrenar te lo dice.",
    ["Cada kilo perdido al entrenar ≈ 1 litro de sudor.", "Perder más de 2 % del peso puede bajar el rendimiento.", "El color claro de la orina es una guía sencilla."],
    [("Lo que dice la ciencia", ["La postura del ACSM sobre reposición de líquidos (Sawka 2007) recomienda programas individuales porque la tasa de sudoración y la pérdida de sodio varían mucho entre personas y condiciones."])],
    ["Pésate antes y después de una sesión típica.", "Repón ~1.25–1.5 L por cada kg perdido en las horas siguientes.", "En sesiones largas con mucho calor, agrega sodio."],
    [("Sawka MN et al. ACSM position stand: exercise and fluid replacement. Med Sci Sports Exerc. 2007.", PM + "17277604/", False)])
art("Carga de carbohidratos para competencias de resistencia", "Nutrición",
    "Para pruebas de más de 90 minutos, 10–12 g/kg de carbohidratos en las 36–48 h previas llenan el glucógeno. Ya no hace falta la fase de agotamiento.",
    ["Solo es útil en esfuerzos de más de 90 minutos.", "No necesitas vaciar el glucógeno antes.", "Durante esfuerzos de 1–2.5 h: 30–60 g de carbohidratos por hora."],
    [("Lo que dice la ciencia", ["Las posturas de la ISSN (Kerksick 2017) y de Thomas (2016) recomiendan 10–12 g/kg/día durante 36–48 h para la supercompensación, sin la fase de agotamiento clásica, y hasta 90 g/h en esfuerzos muy largos con mezclas de glucosa y fructosa."])],
    ["Practica la carga y la alimentación en entrenamientos, nunca por primera vez el día de la carrera.", "Reduce la fibra el día previo si te causa molestias.", "No aplica para sesiones de pesas normales."],
    [KERKSICK, THOMAS])
art("Hierro en mujeres que entrenan", "Mujeres y etapas de vida",
    "Las mujeres, vegetarianas y deportistas de resistencia tienen más riesgo de deficiencia de hierro.",
    ["La deficiencia de hierro causa cansancio y baja el rendimiento.", "La ferritina se mide en un análisis de sangre.", "No te suplementes a ciegas: el exceso también daña."],
    [("Lo que dice la ciencia", ["El consenso del COI sobre suplementos (2018) y las revisiones sobre atletas mujeres señalan el hierro como uno de los micronutrientes de mayor riesgo. Tomar el hierro por la mañana, lejos del ejercicio intenso, puede mejorar su absorción porque la hepcidina sube después de entrenar."])],
    ["Pide a tu médico ferritina si te sientes cansada sin motivo.", "Combina leguminosas y verduras verdes con vitamina C (limón, guayaba).", "Si te recetan hierro, tómalo según indicación, separado del café y del té."],
    [IOC, ("Estudio sobre el horario del ejercicio y la absorción de hierro, 2019.", PM + "31058762/", False)])
art("Vitamina D: ¿la necesitas?", "Suplementos",
    "Solo si tienes deficiencia comprobada o riesgo alto. No mejora el rendimiento por sí sola.",
    ["Riesgo: entrenar en interiores, piel oscura, poca exposición solar.", "La deficiencia se confirma con análisis de sangre.", "Las dosis muy altas pueden ser tóxicas."],
    [("Lo que dice la ciencia", ["Los Institutos Nacionales de Salud de EE. UU. establecen ingestas recomendadas y límites superiores para la vitamina D. La guía 2024 de la Endocrine Society recomienda no hacer análisis ni suplementar de rutina a adultos sanos menores de 75 años fuera de grupos de riesgo."])],
    ["Pregunta a tu médico si estás en un grupo de riesgo.", "Pescado graso, huevo y lácteos fortificados aportan vitamina D.", "Nunca superes el límite superior sin supervisión."],
    [("NIH Office of Dietary Supplements. Vitamin D fact sheet for health professionals.", "https://ods.od.nih.gov/factsheets/VitaminD-HealthProfessional/", True),
     ("Demay MB et al. Vitamin D for the prevention of disease: Endocrine Society guideline. 2024.", PM + "38828931/", False)])
art("Antioxidantes en dosis altas: pueden frenar tus avances", "Suplementos",
    "Tomar 1 g de vitamina C con vitamina E todos los días puede atenuar las adaptaciones al entrenamiento.",
    ["El estrés oxidativo del ejercicio también es una señal de adaptación.", "Las dosis altas de antioxidantes pueden bloquearla en parte.", "Frutas y verduras aportan antioxidantes sin ese problema."],
    [("Lo que dice la ciencia", ["Un metaanálisis de 2019 sobre suplementación con vitaminas C y E encontró que puede atenuar algunas adaptaciones al entrenamiento de fuerza y resistencia. El COI recomienda no usarlos de forma rutinaria."])],
    ["Come 5 porciones de frutas y verduras al día.", "Evita megadosis de vitamina C y E salvo indicación médica.", "Si las usas por una enfermedad, coméntalo con tu médico y tu entrenador."],
    [("Metaanálisis sobre suplementación antioxidante y adaptaciones al entrenamiento, 2019.", "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6490896/", True), IOC])
art("El Plato del Bien Comer y las guías mexicanas", "Nutrición",
    "Las guías alimentarias de México recomiendan variedad: verduras y frutas, cereales integrales y leguminosas, y alimentos de origen animal con moderación.",
    ["Combina los tres grupos en cada comida.", "Prefiere agua simple a bebidas azucaradas.", "Leguminosas varias veces por semana."],
    [("Lo que dice la ciencia", ["La NOM-043-SSA2-2012 (Plato del Bien Comer) y las Guías Alimentarias Saludables y Sostenibles para México 2023 son la referencia nacional. Coinciden con las recomendaciones de la OMS: más verduras, frutas, leguminosas y granos integrales; menos azúcar, sal y ultraprocesados."])],
    ["Usa el dietocálculo por equivalentes SMAE de la app, que sigue esta lógica.", "Arma tu plato: mitad verduras, un cuarto cereal, un cuarto proteína.", "Las recetas de la app usan ingredientes mexicanos accesibles."],
    [("Organización Mundial de la Salud. Alimentación sana (nota descriptiva).", "https://www.who.int/news-room/fact-sheets/detail/healthy-diet", True), THOMAS])
art("Por qué tu peso sube y baja cada día", "Pérdida de grasa",
    "Agua, sal, carbohidratos y digestión mueven la báscula hasta 1–2 kg. La tendencia es lo que cuenta.",
    ["Un día de comida salada o muchos carbohidratos retiene agua.", "El ciclo menstrual también cambia el peso.", "La tendencia de 7–14 días muestra el cambio real de grasa."],
    [("Cómo lo usa la app", ["La app suaviza tus pesos con una media móvil exponencial: cada día pesa un poco, pero ningún día aislado cambia la tendencia. Así decides con datos y no con el susto de una mañana.",
                             "Para calcular tu gasto real se usa esa tendencia, no el peso de un solo día."])],
    ["Pésate en las mismas condiciones: al despertar, después del baño, antes de comer.", "No ajustes tu plan por un solo dato.", "Combina el peso con cintura, fotos y fuerza."],
    [("Hall KD, Guo J. Gastroenterology. 2017.", "10.1053/j.gastro.2017.01.052", True), HELMS])

# ---------------- SALUD, RECUPERACIÓN Y HÁBITOS ----------------
art("Semanas de descarga: cuándo y cómo bajar la intensidad", "Recuperación y sueño",
    "Una descarga es una semana de menos estrés de entrenamiento para recuperarte. Muchos entrenadores la programan cada 4–6 semanas.",
    ["Baja volumen (series) a la mitad o la intensidad un poco.", "No es dejar de entrenar.", "Úsala si la fatiga se acumula o la fuerza cae."],
    [("Lo que dice la ciencia", ["Un consenso Delphi de entrenadores (Bell 2023) definió la descarga como un periodo de menor estrés para reducir la fatiga y preparar el siguiente bloque; en la práctica dura unos 7 días cada 4–6 semanas. La evidencia experimental aún es escasa.",
                                 "En principiantes, pausas de 3 semanas dentro de un programa largo no comprometieron la hipertrofia final (estudios de Ogasawara)."])],
    ["Haz la descarga con las mismas sesiones pero la mitad de series.", "Si te vas de vacaciones, tómala como descarga.", "Vuelve a tus cargas normales la semana siguiente."],
    [("Bell L et al. Overcoming the deload dilemma: a Delphi consensus. 2023.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC10511399/", True),
     ("Ogasawara R et al. Comparison of muscle hypertrophy following periodic and continuous training. Eur J Appl Physiol. 2013.", "https://link.springer.com/article/10.1007/s00421-012-2511-9", False)])
art("Sobreentrenamiento: más raro de lo que crees", "Recuperación y sueño",
    "Un bajón de unas semanas suele ser sobrealcance y se recupera con descanso. El síndrome de sobreentrenamiento real es raro y grave.",
    ["Sobrealcance funcional: bajón corto que se recupera en días.", "Sobrealcance no funcional: semanas a meses.", "Síndrome de sobreentrenamiento: meses, diagnóstico por exclusión."],
    [("Lo que dice la ciencia", ["El consenso del Colegio Europeo de Ciencias del Deporte y el ACSM (Meeusen 2013) distingue estos estados. Ningún marcador aislado lo diagnostica; se monitorea con rendimiento, cuestionarios de bienestar, carga por RPE de sesión y sueño."])],
    ["Registra energía y sueño en tu diario.", "Si la fuerza cae 2 semanas seguidas, baja el volumen.", "Revisa comida y sueño antes de culpar al entrenamiento.", "Cansancio persistente con otros síntomas: consulta al médico."],
    [("Meeusen R et al. Prevention, diagnosis and treatment of the overtraining syndrome: ECSS/ACSM consensus. Med Sci Sports Exerc. 2013.", PM + "23247672/", False)])
art("Baños de hielo después de las pesas: mejor no", "Recuperación y sueño",
    "Meterte al agua fría seguido después de entrenar fuerza puede reducir tus ganancias de músculo y fuerza.",
    ["El frío reduce la inflamación que forma parte de la adaptación.", "Puede servir entre competencias muy seguidas.", "No lo uses como rutina si buscas músculo."],
    [("Lo que dice la ciencia", ["Roberts y colaboradores (2015) mostraron que la inmersión en agua fría tras el entrenamiento de fuerza atenuó las ganancias de masa y fuerza. Metaanálisis posteriores (2022 para fuerza; Piñero 2024 para hipertrofia) confirmaron un efecto negativo pequeño."])],
    ["Si te gusta el frío, úsalo lejos de las sesiones de pesas.", "Para recuperarte: sueño, comida y descanso.", "En deportes con partidos seguidos puede tener sentido: consúltalo."],
    [("Roberts LA et al. Post-exercise cold water immersion attenuates acute anabolic signalling and long-term adaptations. J Physiol. 2015.", PMC + "PMC4594298", True),
     ("Piñero A et al. Cold water immersion and resistance training hypertrophy: meta-analysis. 2024.", "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11235606/", True)])
art("Dormir poco y lesiones en deportistas jóvenes", "Recuperación y sueño",
    "Los adolescentes que dormían menos de 8 horas tuvieron más lesiones deportivas en un estudio observacional.",
    ["El sueño es parte del entrenamiento.", "Los adolescentes necesitan más sueño que los adultos.", "La relación es observacional, no prueba causa."],
    [("Lo que dice la ciencia", ["Milewski y colaboradores (2014) encontraron que los deportistas adolescentes que dormían menos de 8 horas tenían más probabilidad de lesionarse. Junto con los estudios experimentales sobre síntesis de proteína, apoya priorizar el sueño."])],
    ["Adolescentes: 8–10 horas.", "Evita pantallas antes de dormir.", "Registra tu sueño en la app y compáralo con tu energía."],
    [("Milewski MD et al. Chronic lack of sleep is associated with increased sports injuries in adolescent athletes. J Pediatr Orthop. 2014.", PM + "25028798/", False)])
art("¿Necesito permiso médico para empezar a entrenar?", "Salud y movimiento",
    "Depende de tres cosas: si ya eres activo, si tienes síntomas o enfermedad cardiovascular, metabólica o renal, y qué tan intenso vas a entrenar.",
    ["La mayoría de las personas puede empezar con intensidad moderada.", "Síntomas como dolor de pecho o falta de aire requieren valoración.", "El PAR-Q+ es el cuestionario de referencia."],
    [("Lo que dice la ciencia", ["El algoritmo de cribado del ACSM (Riebe 2015) dejó de basarse en factores de riesgo y decide la autorización médica según actividad actual, síntomas o enfermedad conocida e intensidad deseada. El PAR-Q+ es la herramienta de autoevaluación recomendada."])],
    ["Contesta el PAR-Q+ de la evaluación de la app.", "Si alguna respuesta es sí, consulta antes de entrenar intenso.", "Empieza moderado y progresa poco a poco."],
    [("ACSM. Exercise preparticipation screening: removing barriers to initiating exercise.", "https://www.acsm.org/blog-detail/acsm-certified-blog/2018/02/01/exercise-preparticipation-screening-removing-barriers-initiating-exercise", True)])
art("Pesas con presión alta: seguras y útiles", "Salud y movimiento",
    "El entrenamiento de fuerza baja la presión arterial en reposo. Solo está contraindicado si la presión no está controlada.",
    ["La fuerza y el cardio reducen la presión arterial.", "No aguantes la respiración al empujar.", "Presión muy alta sin control: primero el médico."],
    [("Lo que dice la ciencia", ["Una declaración científica de la Asociación Americana del Corazón (2023) concluyó que el entrenamiento de fuerza es seguro y eficaz para reducir el riesgo cardiovascular y baja la presión en reposo. Pescatello (2019) encontró efectos mayores en personas con presión más alta."])],
    ["Exhala al hacer el esfuerzo.", "Deja 2–3 repeticiones en reserva en los básicos.", "Mide tu presión en reposo y regístrala en la evaluación."],
    [("Declaración científica de la AHA sobre entrenamiento de fuerza y salud cardiovascular, 2023.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC11209834", True),
     ("Pescatello LS et al. Med Sci Sports Exerc. 2019.", "10.1249/MSS.0000000000001943", False)])
art("Osteoporosis: cargas altas con supervisión", "Salud y movimiento",
    "En mujeres con baja masa ósea, un programa supervisado de alta intensidad fue seguro y mejoró el hueso.",
    ["El hueso responde a cargas progresivas.", "La supervisión y la técnica son clave.", "Evita flexionar la columna con carga."],
    [("Lo que dice la ciencia", ["El ensayo LIFTMOR (Watson 2018) aplicó entrenamiento de fuerza e impacto de alta intensidad supervisado en mujeres posmenopáusicas con baja masa ósea: mejoró la densidad ósea y la función sin lesiones relevantes. Las recomendaciones Too Fit To Fracture apoyan fuerza y equilibrio."])],
    ["Empieza con un profesional que conozca tu diagnóstico.", "Progresión lenta y técnica impecable.", "Incluye equilibrio para prevenir caídas."],
    [("Watson SL et al. High-intensity resistance and impact training improves bone in postmenopausal women with low bone mass (LIFTMOR). J Bone Miner Res. 2018.", PM + "28975661/", False),
     ("Giangregorio LM et al. Osteoporos Int. 2014.", "10.1007/s00198-013-2523-2", True)])
art("Pesas en el embarazo: lo que dicen las guías", "Mujeres y etapas de vida",
    "En un embarazo sin complicaciones, el entrenamiento de fuerza moderado es seguro y recomendable.",
    ["ACOG y la guía canadiense apoyan la fuerza en el embarazo.", "Evita el esfuerzo máximo y aguantar la respiración.", "Hay contraindicaciones: revísalas con tu médico."],
    [("Lo que dice la ciencia", ["La opinión del Colegio Americano de Obstetras y Ginecólogos (ACOG 2020, n.º 804) y la guía canadiense de 2019 recomiendan mantenerse activa durante el embarazo sin complicaciones, combinando aeróbico y fuerza, con contraindicaciones absolutas y relativas definidas."])],
    ["Cargas moderadas, 1–3 repeticiones en reserva.", "Prefiere máquinas o ejercicios estables conforme avanza el embarazo.", "Detente ante sangrado, contracciones, mareo o pérdida de líquido."],
    [("ACOG Committee Opinion No. 804: Physical activity and exercise during pregnancy and the postpartum period. Obstet Gynecol. 2020.", PM + "33481513/", False),
     ("Mottola MF et al. Br J Sports Med. 2018.", "10.1136/bjsports-2018-100056", True)])
art("¿Cuánto tarda en formarse un hábito?", "Salud y movimiento",
    "En promedio unos 2 meses, pero varía muchísimo: de unos días a casi un año. Fallar un día no lo rompe.",
    ["Mediana de ~59–66 días para volver automático un hábito simple.", "Un día fallado no borra el progreso.", "Ligar el hábito a una señal fija ayuda mucho."],
    [("Lo que dice la ciencia", ["Gardner y colaboradores (2012) resumieron que los hábitos de salud simples tardan semanas a meses en volverse automáticos. Planear con 'si ocurre X, entonces hago Y' (intenciones de implementación) tiene un efecto medio a grande para cumplir metas."])],
    ["Elige una señal: 'Al salir del trabajo, voy al gimnasio'.", "Empieza pequeño: 2 días por semana.", "Usa el comodín de racha de la app si fallas un día."],
    [("Gardner B, Lally P, Wardle J. Making health habitual: the psychology of habit-formation. Br J Gen Pract. 2012.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC3505409/", True)])
art("Registrar lo que comes funciona (con matices)", "Pérdida de grasa",
    "Las personas que se autorregistran pierden más peso de forma consistente, aunque la calidad de la evidencia es moderada.",
    ["Autorregistro de comida, peso y ejercicio = mejores resultados.", "No necesitas ser perfecto: la constancia importa más.", "Si te genera ansiedad, usa el modo bienestar."],
    [("Lo que dice la ciencia", ["Una revisión sistemática (Burke 2011) encontró una asociación consistente entre el autorregistro y la pérdida de peso. Combinarlo con metas y retroalimentación aumenta el efecto."])],
    ["Registra al menos 5 días por semana.", "Fotografía tus comidas si pesar es difícil.", "Revisa tu semana el domingo y ajusta una cosa."],
    [("Burke LE, Wang J, Sevick MA. Self-monitoring in weight loss: a systematic review. J Am Diet Assoc. 2011.", PM + "21185970/", False)])
art("Metas que sí funcionan: proceso y resultado", "Salud y movimiento",
    "Combina metas que controlas (entrenar 3 días) con metas de resultado realistas (bajar 0.5 % por semana).",
    ["Las metas de proceso dependen de ti.", "Las de resultado deben ser realistas.", "Revisarlas cada semana mantiene el rumbo."],
    [("Lo que dice la ciencia", ["Las técnicas de cambio de conducta con mejor respaldo combinan autorregistro, metas, retroalimentación y revisión de metas. Para pérdida de grasa en personas que entrenan, ritmos de 0.5–1 % del peso por semana ayudan a conservar músculo (Helms 2014)."])],
    ["Escribe 1 meta de proceso por semana.", "Pon tu ritmo de pérdida o ganancia en la evaluación.", "Celebra lo que sí cumpliste."],
    [("Michie S et al. Effective techniques in healthy eating and physical activity interventions: meta-regression. Health Psychol. 2009.", PM + "19916637/", False), HELMS])
art("Contar calorías sin obsesionarte", "Salud y movimiento",
    "El uso de contadores de calorías se asocia con síntomas de trastornos alimentarios en algunas personas. La app tiene un modo bienestar.",
    ["La asociación existe, sobre todo en jóvenes o con antecedentes.", "No está demostrado que el conteo los cause.", "Si te angustia, oculta los números."],
    [("Lo que dice la ciencia", ["Estudios transversales encontraron asociación entre usar contadores de calorías o de actividad y síntomas de trastornos de la conducta alimentaria. La causalidad no está establecida, pero justifica opciones como ocultar números y usar lenguaje neutro."])],
    ["Activa el modo bienestar en Ajustes si los números te generan ansiedad.", "Enfócate en conductas: proteína, verduras, sueño.", "Si tienes antecedentes de TCA, trabaja con un profesional de salud mental."],
    [("Estudio sobre contadores de calorías y síntomas de TCA, 2017.", PM + "28214452/", False)])
art("Suplementos contaminados: un riesgo real", "Suplementos",
    "Una parte de los suplementos contiene sustancias no declaradas, sobre todo los 'hormonales', quemadores y pre-entrenos.",
    ["Estimaciones de 14–50 % según el estudio.", "Pueden causar dopaje involuntario o daño a la salud.", "La certificación por lote reduce el riesgo."],
    [("Lo que dice la ciencia", ["Geyer y colaboradores (2008) documentaron suplementos contaminados o adulterados con sustancias dopantes. En México los suplementos no requieren registro sanitario ante COFEPRIS y no pueden declarar efectos terapéuticos."])],
    ["Busca certificaciones como NSF Certified for Sport o Informed Sport.", "Desconfía de promesas de 'efecto esteroide' o 'quema grasa'.", "Menos es más: creatina, proteína y cafeína cubren casi todo."],
    [("Geyer H et al. Nutritional supplements cross-contaminated and faked with doping substances. J Mass Spectrom. 2008.", PM + "18563865/", False), IOC])
art("Cómo saber si un suplemento funciona: el semáforo ABCD", "Suplementos",
    "El Instituto Australiano del Deporte clasifica los suplementos en A (evidencia fuerte), B (emergente), C (sin evidencia) y D (prohibidos o de alto riesgo).",
    ["Grupo A: creatina, cafeína, bicarbonato, beta-alanina, nitrato, proteína.", "Grupo C: BCAA, HMB y la mayoría de los 'quemadores'.", "Los suplementos tienen un papel menor si la dieta no está resuelta."],
    [("Lo que dice la ciencia", ["El consenso del COI (Maughan 2018) establece que los suplementos solo tienen sentido después de una alimentación adecuada y que pocos tienen buena evidencia. La guía de suplementos de la app usa esta clasificación."])],
    ["Revisa la sección Suplementos de la app antes de comprar.", "Prioriza comida, sueño y entrenamiento.", "Consulta si tomas medicamentos o compites con control antidopaje."],
    [IOC])
art("Bicarbonato y beta-alanina: para esfuerzos de 1 a 4 minutos", "Suplementos",
    "Funcionan en esfuerzos intensos de 1–4 minutos, como intervalos o pruebas de pista. Para hipertrofia aportan poco.",
    ["Bicarbonato: amortigua la acidez en esfuerzos muy intensos.", "Beta-alanina: efecto acumulativo tras semanas de uso.", "Hormigueo y molestias digestivas son efectos comunes."],
    [("Lo que dice la ciencia", ["La postura de la ISSN sobre bicarbonato de sodio (2021) concluye que mejora el rendimiento en esfuerzos intensos de corta duración, con dosis de 0.2–0.3 g/kg y riesgo de molestias gastrointestinales."])],
    ["Solo considéralos si tu deporte tiene esfuerzos de 1–4 minutos.", "Pruébalos en entrenamiento, nunca por primera vez en competencia.", "No son necesarios para ganar músculo."],
    [("Grgic J et al. ISSN position stand: sodium bicarbonate and exercise performance. J Int Soc Sports Nutr. 2021.", "https://link.springer.com/article/10.1186/s12970-021-00412-w", True)])
art("Creatina en adultos mayores y vegetarianos", "Suplementos",
    "Junto con pesas, la creatina ayuda a ganar masa magra en adultos mayores. En vegetarianos eleva más las reservas.",
    ["Mayores: más masa magra y fuerza de piernas con creatina + pesas.", "Vegetarianos: reservas musculares más bajas de inicio.", "Dosis: 3–5 g al día."],
    [("Lo que dice la ciencia", ["Revisiones recientes reportan que en adultos mayores la creatina combinada con entrenamiento de fuerza aumenta la masa magra (~1.4 kg más que placebo) y la fuerza del tren inferior. En vegetarianos, las reservas musculares suben más que en omnívoros, aunque el beneficio extra en rendimiento es inconsistente."])],
    ["Monohidrato, 3–5 g al día, con cualquier comida.", "Combínala siempre con entrenamiento de fuerza.", "Si tienes enfermedad renal, consulta antes."],
    [("Kreider RB et al. J Int Soc Sports Nutr. 2017.", "10.1186/s12970-017-0173-z", True),
     ("Revisión sobre creatina y entrenamiento de fuerza en adultos mayores, 2022.", "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9116910/", True)])
art("HMB, ashwagandha y otros: lo que (no) dice la evidencia", "Suplementos",
    "El HMB y el ácido D-aspártico no mejoran la composición corporal en entrenados. La ashwagandha tiene evidencia pequeña y de baja certeza.",
    ["HMB: sin beneficio claro en personas entrenadas.", "Ácido D-aspártico: no sube la testosterona de forma útil.", "Ashwagandha: pocos estudios, efecto pequeño."],
    [("Lo que dice la ciencia", ["Metaanálisis recientes no encontraron beneficios del HMB ni del ácido D-aspártico en la composición corporal de personas entrenadas. Para la ashwagandha hay 3 ensayos con 161 participantes y certeza baja a favor de la fuerza."])],
    ["No gastes en 'boosters' de testosterona.", "Si quieres probar algo, que sea del grupo A.", "Revisa interacciones con medicamentos."],
    [("Metaanálisis sobre HMB en personas entrenadas, 2022.", "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9469850/", True), IOC])
