"""Artículos de investigación (bloque 1: entrenamiento). Resúmenes propios basados en las notas de investigación
verificadas del proyecto; cada referencia enlaza a PubMed, PMC, DOI o la revista."""

A = []


def art(titulo, categoria, resumen, claves, secciones, aplicar, refs, minutos=3, slug=None):
    A.append(dict(titulo=titulo, categoria=categoria, resumen=resumen, claves=claves, secciones=secciones, aplicar=aplicar,
                  refs=refs, minutos=minutos, slug=slug))


PM = "https://pubmed.ncbi.nlm.nih.gov/"
PMC = "https://pmc.ncbi.nlm.nih.gov/articles/"

art("Series fraccionadas: cómo contar bien tu volumen", "Ganar músculo",
    "Un press de banca también entrena tríceps. Contar esas series como media serie da una imagen más real de tu volumen.",
    ["Una serie directa cuenta 1 para el músculo principal.", "Para los músculos que ayudan, cuenta 0.5.", "Así evitas creer que haces poco brazo o que haces demasiado pecho."],
    [("Lo que dice la ciencia", ["Las metarregresiones de Pelland y colaboradores (Sports Medicine, 2025) analizaron decenas de estudios de volumen y frecuencia. El método de conteo que mejor explicó los resultados fue el fraccionado: series directas = 1 e indirectas = 0.5.",
                                 "En esos modelos, más volumen semanal aumentó tanto la hipertrofia como la fuerza, con rendimientos decrecientes que fueron más marcados para la fuerza."])],
    ["Revisa la sección de volumen en Mi programa: ya cuenta así.", "Si tus brazos tienen muchas series indirectas, quizá no necesitas tanto trabajo directo.", "Busca 10–20 series fraccionadas por músculo a la semana."],
    [("Pelland JC et al. The resistance training dose response: meta-regressions on weekly volume and frequency. Sports Med. 2025.", PM + "41343037/", False)])
art("¿Hasta dónde sube el volumen? Rendimientos decrecientes", "Ganar músculo",
    "Más series ayudan, pero cada serie extra aporta un poco menos. Saber esto evita entrenar de más.",
    ["El volumen y el músculo van de la mano hasta cierto punto.", "Pasado ese punto, cada serie añade poco y cansa mucho.", "En fuerza la meseta llega antes que en hipertrofia."],
    [("Lo que dice la ciencia", ["Varios metaanálisis coinciden en que más series semanales producen más hipertrofia, con rendimientos decrecientes. Una revisión en personas entrenadas sugiere que entre 12 y 20 series semanales por músculo funcionan bien, y que por encima de 20 el beneficio adicional es inconsistente.",
                                 "Ralston (2017) también encontró que el volumen semanal influye en la fuerza, pero la fuerza se estanca antes que el tamaño muscular."])],
    ["Sube 2–4 series por músculo solo si llevas 3–4 semanas sin progresar y duermes bien.", "Más de 20 series semanales por músculo: solo en bloques cortos y para avanzados.", "Si la fuerza cae varias sesiones seguidas, baja el volumen."],
    [("Baz-Valle E et al. Systematic review of different training volumes on muscle hypertrophy in trained subjects. J Hum Kinet. 2022.", PMC + "PMC8884877", True),
     ("Ralston GW et al. The effect of weekly set volume on strength gain: a meta-analysis. Sports Med. 2017.", PM + "28755103/", False)])
art("Fuerza máxima: por qué necesitas cargas pesadas", "Ganar músculo",
    "Para ganar músculo funcionan muchas cargas. Para levantar más peso, hay que practicar con cargas altas.",
    ["La hipertrofia es parecida con cargas ligeras o pesadas si llegas cerca del fallo.", "La fuerza máxima mejora más con cargas de 80 % del 1RM o más.", "Es un principio de especificidad: mejoras en lo que practicas."],
    [("Lo que dice la ciencia", ["Un metaanálisis en red (Lopez y colaboradores, 2021) comparó cargas bajas (más de 15 repeticiones), moderadas (9–15) y altas (8 o menos), todas al fallo. El crecimiento muscular fue independiente de la carga, pero la fuerza fue superior con cargas altas.",
                                 "Swinton y colaboradores (2024) confirmaron que las cargas altas producen mayores mejoras del 1RM."])],
    ["Si quieres más fuerza, incluye series de 3–6 repeticiones en los básicos.", "Mantén las series de 8–15 para el volumen de hipertrofia.", "Calienta bien antes de las series pesadas y usa seguros."],
    [("Lopez P et al. Resistance training load effects on muscle hypertrophy and strength gain: network meta-analysis. Med Sci Sports Exerc. 2021.", PM + "33433148/", False),
     ("Swinton PA et al. Dose-response of resistance training for strength and conditioning: Bayesian meta-analysis. Sports Med. 2024.", PMC + "PMC11239729", True)])
art("¿Cuántos días por semana entreno cada músculo?", "Ganar músculo",
    "Con el mismo volumen, la frecuencia importa poco para crecer. Sirve para repartir el trabajo y practicar la técnica.",
    ["Con volumen igualado, 1, 2 o 3 sesiones por músculo dan crecimiento similar.", "Entrenar cada músculo 2 veces evita sesiones larguísimas.", "Para fuerza, practicar más seguido ayuda un poco."],
    [("Lo que dice la ciencia", ["Un metaanálisis de Schoenfeld, Grgic y Krieger (2019) concluyó que, igualando el volumen, la frecuencia no cambia de forma importante la hipertrofia.",
                                 "Las metarregresiones de Pelland (2025) apoyan que la frecuencia tiene un efecto pequeño una vez que se considera el volumen, y algo mayor para la fuerza."])],
    ["Elige la división que te deje cumplir tu volumen sin sesiones de más de 75–90 min.", "Si un músculo te queda atrasado, agrégale una segunda sesión corta.", "La mejor frecuencia es la que puedes sostener."],
    [("Schoenfeld BJ, Grgic J, Krieger J. How many times per week should a muscle be trained to maximize hypertrophy? J Sports Sci. 2019.", PM + "30558493/", False),
     ("Pelland JC et al. Sports Med. 2025.", PM + "41343037/", False)])
art("Full body, torso-pierna o push-pull-legs: ¿cuál es mejor?", "Ganar músculo",
    "Ninguna división gana por sí sola. Lo que importa es el volumen y la frecuencia que te permite cumplir.",
    ["Las divisiones son formas de repartir el volumen.", "Con volumen y frecuencia iguales, dan resultados parecidos.", "Elige según tus días disponibles."],
    [("Lo que dice la ciencia", ["No hay estudios que muestren que una división sea superior cuando se iguala el volumen semanal y la frecuencia por músculo. La evidencia viene de los metaanálisis de frecuencia y volumen."])],
    ["2–3 días: cuerpo completo.", "4 días: torso-pierna.", "5–6 días: push-pull-legs o torso-pierna con más días.", "Cambia de división solo si te ayuda a cumplir mejor."],
    [("Schoenfeld BJ et al. J Sports Sci. 2019.", PM + "30558493/", False), ("Schoenfeld BJ et al. Sports Med. 2016.", PM + "27102172/", False)])
art("Sobrecarga progresiva: el principio que no puede faltar", "Ganar músculo",
    "Sin progresión no hay adaptación a largo plazo. Puedes progresar en carga, repeticiones o series.",
    ["El cuerpo se adapta a lo que ya puede hacer.", "Progresar = más carga o más repeticiones con el mismo esfuerzo.", "La periodización ayuda algo a la fuerza, poco a la hipertrofia con el mismo volumen."],
    [("Lo que dice la ciencia", ["Las posturas del ACSM señalan la sobrecarga progresiva, la especificidad y la variación como principios básicos. Un metaanálisis encontró que la periodización ondulante mejora algo la fuerza en entrenados, sin ventaja clara para la hipertrofia cuando el volumen es el mismo."])],
    ["Usa la doble progresión: cuando completes el tope de repeticiones con el RIR objetivo, sube la carga 2.5–5 %.", "Registra tus series para saber cuándo subir.", "Si no progresas en 3 semanas, revisa sueño, comida y volumen."],
    [("Ratamess NA et al. ACSM position stand: progression models in resistance training. Med Sci Sports Exerc. 2009.", PM + "19204579/", False),
     ("Moesgaard L et al. Effects of periodization on strength and muscle hypertrophy: meta-analysis. Sports Med. 2022.", PM + "35044672/", False)])
art("Rango de movimiento: entrena en posiciones de estiramiento", "Ganar músculo",
    "Hacer el movimiento completo, o enfatizar la parte donde el músculo está estirado, parece dar más crecimiento.",
    ["El rango completo es preferible a medias repeticiones en la parte corta.", "Las parciales en estiramiento rinden al menos igual que el rango completo.", "Elige ejercicios que estiren el músculo con carga."],
    [("Lo que dice la ciencia", ["Revisiones recientes sugieren que entrenar con el músculo en longitudes largas (por ejemplo, la parte baja de una sentadilla profunda o un curl inclinado) favorece la hipertrofia. La evidencia es de calidad baja a moderada."])],
    ["Baja controlado hasta donde tu movilidad lo permita sin dolor.", "Prefiere variantes con estiramiento: curl inclinado, peso muerto rumano, extensión sobre la cabeza.", "No sacrifiques técnica por rango: el rango se gana con el tiempo."],
    [("Revisión sistemática sobre rango de movimiento e hipertrofia (2023), PubMed 36662126.", PM + "36662126/", False), ("Revisión sobre rango de movimiento y desarrollo muscular (2021), PubMed 34170576.", PM + "34170576/", False)])
art("Velocidad de las repeticiones: ¿lento es mejor?", "Ganar músculo",
    "Repeticiones de entre medio segundo y 8 segundos dan crecimiento parecido. Las muy lentas rinden peor.",
    ["No necesitas contar 4 segundos de bajada siempre.", "Controla la fase de bajada, sube con intención.", "Repeticiones de más de 8–10 segundos reducen la carga que puedes mover."],
    [("Lo que dice la ciencia", ["Un metaanálisis de duración de la repetición (Schoenfeld y colaboradores) encontró hipertrofia similar entre 0.5 y 8 segundos por repetición; las repeticiones muy lentas fueron menos eficaces."])],
    ["Baja en 1–3 segundos sin rebotar.", "Sube de forma controlada pero decidida.", "Usa tempo lento solo para aprender técnica o con cargas ligeras."],
    [("Schoenfeld BJ et al. Effect of repetition duration on muscle hypertrophy: meta-analysis. Sports Med. 2015.", PM + "25601394/", False)])
art("Cardio y pesas juntos: ¿se estorban?", "Ganar músculo",
    "Hacer cardio no frena el crecimiento muscular ni la fuerza máxima. Puede restar algo de potencia explosiva.",
    ["El efecto de interferencia es menor de lo que se creía.", "La potencia y los saltos son lo más afectado.", "La bicicleta interfiere menos que correr."],
    [("Lo que dice la ciencia", ["Un metaanálisis de 2022 (Schumann y colaboradores) concluyó que el entrenamiento concurrente no compromete la hipertrofia ni la fuerza máxima, pero sí atenúa la fuerza explosiva. Otro análisis sugirió que correr podría interferir más que pedalear."])],
    ["Separa cardio intenso y pesas por algunas horas si puedes.", "Si te importa la potencia, haz las pesas primero.", "Prefiere bicicleta o elíptica si haces mucho volumen de piernas."],
    [("Schumann M et al. Compatibility of concurrent aerobic and strength training: meta-analysis. Sports Med. 2022.", "https://link.springer.com/doi/10.1007/s40279-022-01688-x", True),
     ("Wilson JM et al. Concurrent training: a meta-analysis examining interference. J Strength Cond Res. 2012.", PM + "22002517/", False)])
art("RIR y RPE: cómo medir el esfuerzo de una serie", "Ganar músculo",
    "Contar las repeticiones que te quedaban es la forma más práctica de ajustar la intensidad cada día.",
    ["RIR = repeticiones en reserva al terminar la serie.", "RPE 8 equivale aproximadamente a RIR 2.", "Al principio subestimamos cuánto nos queda: se aprende con práctica."],
    [("Lo que dice la ciencia", ["La escala de RPE basada en repeticiones en reserva fue propuesta y validada por Zourdos y colaboradores (2016), y se usa para autorregular la carga según el día. La precisión mejora en personas entrenadas y cerca del fallo."])],
    ["Registra el RIR de tus series en la app.", "Para hipertrofia, termina la mayoría de las series con 0–3 RIR.", "Si un día todo pesa más, baja la carga y conserva el RIR."],
    [("Zourdos MC et al. Novel resistance training-specific RPE scale measuring repetitions in reserve. J Strength Cond Res. 2016.", PM + "26049792/", False)])
art("Las cargas que funcionan: del 30 % al 85 % del 1RM", "Ganar músculo",
    "Para ganar músculo puedes usar casi cualquier carga, siempre que llegues cerca del fallo.",
    ["Cargas desde ~30 % hasta ~85 % del 1RM producen hipertrofia similar.", "Con cargas ligeras necesitas muchas repeticiones.", "Combinar rangos te da variedad y cuida articulaciones."],
    [("Lo que dice la ciencia", ["Metaanálisis de Schoenfeld (2017) y Lopez (2021) encontraron crecimiento similar con cargas bajas, moderadas y altas cuando las series se llevan cerca del fallo."])],
    ["Básicos: 5–10 repeticiones.", "Aislamientos: 10–20 repeticiones.", "En casa con poco peso: series largas y lentas, hasta 1–2 del fallo."],
    [("Schoenfeld BJ et al. J Strength Cond Res. 2017.", "10.1519/JSC.0000000000002200", False), ("Lopez P et al. Med Sci Sports Exerc. 2021.", PM + "33433148/", False)])
art("Zonas de frecuencia cardiaca para tu cardio", "Salud y movimiento",
    "La intensidad moderada es 40–59 % de tu frecuencia cardiaca de reserva; la vigorosa, 60–89 %.",
    ["La frecuencia de reserva = máxima − reposo.", "Moderado: puedes hablar pero no cantar.", "Ya no se exige hacer bloques de al menos 10 minutos: todo suma."],
    [("Lo que dice la ciencia", ["La postura del ACSM (Garber 2011) define la intensidad moderada como 40–59 % de la FC de reserva y la vigorosa como 60–89 %. La OMS 2020 eliminó el requisito de bloques mínimos de 10 minutos."])],
    ["Calcula tus zonas en la calculadora de la app.", "Haz la mayoría de tu cardio en zona moderada.", "Agrega intervalos vigorosos solo si tienes buena base y no hay contraindicaciones."],
    [("Garber CE et al. ACSM position stand: quantity and quality of exercise. Med Sci Sports Exerc. 2011.", PM + "21694556/", False),
     ("Bull FC et al. WHO 2020 guidelines. Br J Sports Med. 2020.", "10.1136/bjsports-2020-102955", True)])
art("HIIT o cardio continuo: ¿cuál conviene?", "Pérdida de grasa",
    "Los dos mejoran la condición física. El HIIT ahorra tiempo; el continuo es más fácil de sostener al empezar.",
    ["El HIIT mejora el VO2máx en menos tiempo.", "El cardio continuo moderado es más seguro para empezar.", "Para perder grasa, importa más el total semanal y la dieta."],
    [("Lo que dice la ciencia", ["Una revisión de Weston y colaboradores sobre entrenamiento interválico de alta intensidad mostró mejoras importantes de la capacidad aeróbica en personas con enfermedades cardiometabólicas, comparables o superiores al cardio continuo, con menos tiempo de ejercicio."])],
    ["Empieza con cardio continuo 4–8 semanas.", "Después agrega 1–2 sesiones de intervalos por semana.", "Bicicleta o elíptica son las mejores opciones para intervalos de bajo impacto."],
    [("Weston KS et al. High-intensity interval training in patients with lifestyle-induced cardiometabolic disease. Br J Sports Med. 2014.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4072920", True)])
art("El test de Cooper: cómo estimar tu VO2máx corriendo 12 minutos", "Salud y movimiento",
    "La fórmula correcta es (distancia − 504.9) / 44.73. Una versión que circula en cursos sobreestima mucho el resultado.",
    ["Corre o camina lo más lejos posible en 12 minutos.", "Usa la fórmula original de Cooper (1968).", "Úsalo para ver tu progreso, no como diagnóstico."],
    [("Lo que dice la ciencia", ["La ecuación publicada por Cooper es VO2máx = (d − 504.9) / 44.73. La variante con coeficiente 0.0268 sobreestima unos 10 ml/kg/min a 2400 m. Para personas con sobrepeso o que no pueden correr, la caminata de Rockport (Kline 1987) es mejor opción."])],
    ["Haz la prueba en pista plana y con buen calentamiento.", "Si no puedes correr 12 minutos, usa la prueba de Rockport en la calculadora.", "Repite cada 8–12 semanas."],
    [("Kline GM et al. Estimation of VO2max from a one-mile track walk. Med Sci Sports Exerc. 1987.", PM + "3600239/", False)])
art("¿Cuánto descanso entre series para crecer?", "Ganar músculo",
    "Descansar más de 60 segundos ayuda un poco a crecer. Más allá de 90 segundos, la diferencia se vuelve pequeña.",
    ["Descansos muy cortos reducen las repeticiones de las series siguientes.", "Para hipertrofia, 90 s–2 min suelen bastar.", "Para fuerza máxima, 2–3 min o más."],
    [("Lo que dice la ciencia", ["Un metaanálisis bayesiano de 2024 (Singer y colaboradores) encontró una pequeña ventaja hipertrófica al descansar más de 60 s, probablemente porque permite mantener el volumen-carga. Más allá de ~90 s no hubo diferencias claras."])],
    ["Básicos pesados: 2–3 min.", "Aislamientos: 60–90 s.", "Si tienes poco tiempo, alterna ejercicios de músculos distintos."],
    [("Singer A et al. Give it a rest: a systematic review with Bayesian meta-analysis on rest interval duration. Front Sports Act Living. 2024.", "https://www.frontiersin.org/articles/10.3389/fspor.2024.1429789/full", True)])
art("Pesas en adolescentes: seguras y útiles con supervisión", "Mujeres y etapas de vida",
    "El entrenamiento de fuerza supervisado es seguro en jóvenes y la OMS recomienda fortalecer músculos 3 días por semana.",
    ["La fuerza no frena el crecimiento: es un mito.", "La técnica y la supervisión son lo más importante.", "La OMS pide 60 min diarios de actividad en promedio y fortalecimiento 3 días por semana."],
    [("Lo que dice la ciencia", ["Las guías de la OMS 2020 recomiendan a niños y adolescentes un promedio de 60 minutos diarios de actividad moderada a vigorosa y actividades de fortalecimiento al menos 3 días por semana. Las posturas de organismos de fuerza coinciden en que el entrenamiento supervisado es seguro."])],
    ["Empieza con peso corporal y técnica antes que cargas altas.", "Siempre con supervisión de un adulto capacitado.", "Combina con deporte y juego: no todo debe ser gimnasio."],
    [("Bull FC et al. WHO 2020 guidelines. Br J Sports Med. 2020.", "10.1136/bjsports-2020-102955", True), ("Lloyd RS et al. Position statement on youth resistance training. Br J Sports Med. 2014.", "https://bjsm.bmj.com/content/48/7/498.long", True)])
art("Lesiones en el gimnasio: menos de las que crees", "Salud y movimiento",
    "Los deportes de pesas tienen tasas de lesión bajas comparados con los deportes de equipo. Espalda baja y hombro son lo más afectado.",
    ["Culturismo: ~0.2–1 lesión por 1000 horas.", "Powerlifting y halterofilia: algo más, por las cargas máximas.", "La zona lumbar y el hombro son los sitios más comunes."],
    [("Lo que dice la ciencia", ["Revisiones de epidemiología de lesiones en deportes de fuerza reportan tasas de ~0.24–1 por 1000 h en culturismo, 1–4.4 en powerlifting y 2.4–3.3 en halterofilia. La mayoría de los datos son retrospectivos y de baja calidad."])],
    ["Progresa la carga poco a poco.", "Calienta con series ligeras del mismo ejercicio.", "Ante dolor punzante o que empeora, detente y consulta.", "Duerme y descansa: la fatiga aumenta el riesgo."],
    [("Keogh JWL, Winwood PW. The epidemiology of injuries across the weight-training sports. Sports Med. 2017.", PM + "27707741/", False)])
art("Calentamiento: qué hacer antes de las pesas", "Recuperación y sueño",
    "Unos minutos de cardio suave, movilidad dinámica y series de aproximación preparan tu cuerpo sin cansarte.",
    ["5 min de cardio suave elevan la temperatura muscular.", "Las series ligeras del primer ejercicio son el mejor calentamiento específico.", "Los estiramientos estáticos largos justo antes pueden restar algo de fuerza."],
    [("Lo que dice la ciencia", ["La revisión de Behm y colaboradores (2016) recomienda calentamientos que terminen con actividad dinámica; los estiramientos estáticos cortos dentro del calentamiento tienen un efecto mínimo en el rendimiento."])],
    ["5 min de bicicleta o caminata.", "Movilidad dinámica de las articulaciones que vas a usar.", "2–4 series de aproximación: 40 %, 60 %, 80 % de la carga de trabajo.", "La calculadora de discos genera tu calentamiento."],
    [("Behm DG et al. Appl Physiol Nutr Metab. 2016.", "10.1139/apnm-2015-0235", False)])
art("Ejercicio y diabetes tipo 2: fuerza y aeróbico juntos", "Salud y movimiento",
    "La combinación de pesas y cardio controla mejor la glucosa. Levantarte cada 30 minutos también ayuda.",
    ["Lo ideal es combinar fuerza y aeróbico.", "Interrumpe el tiempo sentado cada 30 minutos.", "Revisa tus pies y lleva azúcar si usas insulina."],
    [("Lo que dice la ciencia", ["La postura de la Asociación Americana de Diabetes (Colberg 2016) recomienda que los adultos con diabetes tipo 2 hagan aeróbico y fuerza, y que interrumpan el tiempo sentado con actividad ligera cada 30 minutos. En prediabetes, 150 min semanales más una pérdida de peso del 5–7 % ayudan a prevenir la diabetes."])],
    ["150 min por semana de cardio moderado repartido en 3 días o más.", "Fuerza 2–3 días por semana.", "Mide tu glucosa antes y después al inicio para conocer tu respuesta."],
    [("Colberg SR et al. Physical activity/exercise and diabetes: ADA position statement. Diabetes Care. 2016.", "10.2337/dc16-1728", True)])
