"""Artículos de divulgación basados en evidencia (estudios 2015–2023).

Textos propios en español que resumen investigaciones verificadas (DOI comprobado).
"libre": True indica que el artículo original se puede leer gratis (PubMed Central o revista de acceso abierto).
"""

CATEGORIAS = ["Ganar músculo", "Nutrición", "Pérdida de grasa", "Suplementos", "Recuperación y sueño", "Salud y movimiento",
              "Mujeres y etapas de vida", "Guías por músculo", "Técnica de ejercicios", "Equipo y lugar", "Mitos"]

ARTICULOS = [
    dict(
        slug="cuantas-series-para-ganar-musculo", categoria="Ganar músculo", minutos=4, destacado=True,
        titulo="¿Cuántas series necesitas para ganar músculo?",
        resumen="Más series por semana suelen dar más músculo, hasta cierto punto. Te decimos dónde empezar y cómo subir.",
        claves=["Hacer más series por músculo a la semana se asocia con más crecimiento.",
                "Un buen punto de partida son 10 series semanales por músculo; muchas personas progresan bien entre 10 y 20.",
                "Entrenar cada músculo 2 veces por semana ayuda a repartir ese volumen sin sesiones eternas."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Un metaanálisis de 2017 reunió 15 estudios y encontró una relación dosis-respuesta: a más series semanales por músculo, más ganancia de masa muscular. "
                "Los grupos que hicieron 10 o más series por semana tendieron a crecer más que los que hicieron menos de 5.",
                "Otro metaanálisis de 2016 comparó cuántas veces por semana se entrena un músculo. Entrenarlo al menos 2 veces fue mejor que 1 sola vez cuando no se igualaba el volumen total. "
                "Estudios posteriores sugieren que, con el mismo número de series, la frecuencia importa poco: sirve sobre todo para repartir el trabajo."]),
            ("Qué cuenta como serie", [
                "Solo cuentan las series «efectivas»: las que terminas cerca del fallo (a 0–3 repeticiones de no poder más). Las series de calentamiento no cuentan.",
                "Un press de banca también trabaja tríceps y hombro; por eso en la app esos músculos suman media serie."]),
        ],
        aplicar=["Empieza con unas 10 series por músculo a la semana.",
                 "Si después de 4–6 semanas ya no progresas y te recuperas bien, agrega 2–4 series.",
                 "Si estás muy cansado, duermes mal o te duelen las articulaciones, baja el volumen antes de subirlo.",
                 "Más de 8–10 series de un mismo músculo en una sola sesión suele ser poco eficiente: mejor divídelas en dos días."],
        refs=[("Schoenfeld BJ, Ogborn D, Krieger JW. Dose-response relationship between weekly resistance training volume and increases in muscle mass. J Sports Sci. 2017;35(11):1073-1082.", "10.1080/02640414.2016.1210197", False),
              ("Schoenfeld BJ, Ogborn D, Krieger JW. Effects of resistance training frequency on measures of muscle hypertrophy: a systematic review and meta-analysis. Sports Med. 2016;46(11):1689-1697.", "10.1007/s40279-016-0543-8", False)]),
    dict(
        slug="pesas-ligeras-o-pesadas", categoria="Ganar músculo", minutos=3,
        titulo="¿Pesas ligeras o pesadas? Para crecer, las dos funcionan",
        resumen="Si llegas cerca del fallo, cargas ligeras y pesadas construyen músculo de forma parecida. La fuerza máxima sí pide cargas altas.",
        claves=["Para ganar músculo, cargas bajas y altas dan resultados similares si las series son exigentes.",
                "Para levantar más peso (fuerza máxima), las cargas altas son superiores.",
                "Las cargas ligeras son útiles en casa, con molestias articulares o en ejercicios de aislamiento."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Un metaanálisis de 2017 comparó entrenar con cargas bajas (60 % del 1RM o menos) contra cargas altas (más de 60 %). "
                "La ganancia de 1RM fue claramente mayor con cargas altas, mientras que el crecimiento muscular fue similar entre ambos enfoques.",
                "La clave no es el peso en sí, sino el esfuerzo: con cargas ligeras necesitas muchas más repeticiones para llegar cerca del fallo."]),
            ("¿Por qué no siempre ligero?", [
                "Las series muy largas (25–30 repeticiones) generan mucho ardor y cansancio, y cuesta saber cuándo estás realmente cerca del fallo.",
                "Por eso la mayoría del entrenamiento suele hacerse entre 6 y 15 repeticiones: es eficiente y fácil de medir."]),
        ],
        aplicar=["En básicos (sentadilla, press, remo, peso muerto rumano) usa 5–10 repeticiones.",
                 "En aislamientos (curl, elevaciones laterales, extensiones) usa 10–20 repeticiones.",
                 "Si entrenas en casa con poco peso, compensa haciendo más repeticiones y más lentas, hasta quedar a 1–2 del fallo."],
        refs=[("Schoenfeld BJ, Grgic J, Ogborn D, Krieger JW. Strength and hypertrophy adaptations between low- vs. high-load resistance training: a systematic review and meta-analysis. J Strength Cond Res. 2017;31(12):3508-3523.", "10.1519/JSC.0000000000002200", False)]),
    dict(
        slug="hay-que-llegar-al-fallo", categoria="Ganar músculo", minutos=4,
        titulo="¿Hay que llegar al fallo muscular en cada serie?",
        resumen="Acercarte al fallo es importante; llegar siempre a él aporta poco y cansa mucho.",
        claves=["Entrenar al fallo dio una ventaja pequeña y poco consistente frente a quedarse cerca.",
                "Lo importante es terminar las series a 0–3 repeticiones del fallo (RIR 0–3).",
                "Reserva el fallo real para la última serie de ejercicios seguros, como máquinas o aislamientos."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Una revisión con metaanálisis de 2023 reunió 15 estudios. Llegar al fallo mostró una ventaja pequeña (tamaño del efecto 0.19) que no se mantuvo al analizar solo el fallo muscular momentáneo.",
                "Los autores proponen una relación no lineal: estar cerca del fallo importa, pero el último paso (el fallo total) agrega poco estímulo y bastante fatiga."]),
            ("RIR: tu herramienta para medir el esfuerzo", [
                "RIR significa «repeticiones en reserva»: cuántas repeticiones más podrías haber hecho con buena técnica. RIR 2 = te quedaban 2.",
                "Al principio cuesta calcularlo. Una forma de aprender es llevar al fallo, de vez en cuando, la última serie de un ejercicio seguro y comparar con lo que habías estimado."]),
        ],
        aplicar=["Básicos pesados: RIR 1–3. No vale la pena arriesgar la técnica.",
                 "Aislamientos y máquinas: RIR 0–2; puedes llegar al fallo en la última serie.",
                 "Si una semana estás muy cansado, sube el RIR en lugar de saltarte el entrenamiento."],
        refs=[("Refalo MC, Helms ER, Trexler ET, Hamilton DL, Fyfe JJ. Influence of resistance training proximity-to-failure on skeletal muscle hypertrophy: a systematic review with meta-analysis. Sports Med. 2023;53(3):649-665.", "10.1007/s40279-022-01784-y", True)]),
    dict(
        slug="descanso-entre-series", categoria="Ganar músculo", minutos=3,
        titulo="Descanso entre series: ¿1 minuto o 3?",
        resumen="Descansar más en los ejercicios pesados te deja rendir mejor en cada serie, y eso se traduce en más fuerza.",
        claves=["En hombres entrenados, descansar 3 minutos dio más fuerza y algo más de músculo que 1 minuto.",
                "Descansos cortos reducen las repeticiones de las series siguientes.",
                "Para básicos, 2–3 minutos; para aislamientos, 1–2 minutos."],
        secciones=[
            ("Lo que dice la ciencia", [
                "En un estudio de 2016, 21 hombres con experiencia entrenaron 8 semanas con el mismo programa, unos descansando 1 minuto y otros 3. "
                "El grupo de 3 minutos ganó más fuerza y mostró más crecimiento en algunas mediciones.",
                "Los propios autores esperaban lo contrario, porque durante años se recomendó descansar poco «para hipertrofia». El estudio es pequeño, pero apunta en la misma dirección que otras revisiones: el descanso corto no es necesario para crecer."]),
        ],
        aplicar=["Usa el temporizador de descanso de la sesión en la app.",
                 "Sentadilla, peso muerto, press: 2–3 minutos.",
                 "Curl, elevaciones, extensiones: 60–90 segundos.",
                 "Si tienes poco tiempo, alterna dos ejercicios de músculos distintos mientras descansas del otro."],
        refs=[("Schoenfeld BJ, Pope ZK, Benik FM, et al. Longer interset rest periods enhance muscle strength and hypertrophy in resistance-trained men. J Strength Cond Res. 2016;30(7):1805-1812.", "10.1519/JSC.0000000000001272", False)]),
    dict(
        slug="cuanta-proteina-necesitas", categoria="Nutrición", minutos=4, destacado=True,
        titulo="Proteína: cuánta necesitas de verdad",
        resumen="El análisis más citado del tema encontró que el beneficio se estabiliza alrededor de 1.6 g por kilo de peso al día.",
        claves=["La proteína ayuda a ganar músculo y fuerza cuando entrenas con pesas.",
                "El beneficio se estabilizó cerca de 1.6 g/kg al día; 2.2 g/kg cubre a casi todos.",
                "Lo que más importa es el total del día, y la comida normal basta."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Un metaanálisis de 2018 reunió 49 ensayos con 1,863 personas que entrenaban con pesas. La proteína extra aumentó el 1RM en unos 2.5 kg y la masa libre de grasa en unos 0.3 kg en promedio.",
                "El beneficio dejó de crecer alrededor de 1.62 g/kg al día. Por el margen de error, los autores sugieren hasta 2.2 g/kg para asegurar el efecto en casi todas las personas.",
                "La edad redujo el efecto y la experiencia entrenando lo aumentó."]),
            ("¿Y si estoy a dieta?", [
                "Cuando comes menos calorías para perder grasa, conviene quedarse en la parte alta (1.8–2.2 g/kg): ayuda a conservar músculo y da más saciedad."]),
        ],
        aplicar=["Multiplica tu peso por 1.6 a 2.2: esos son tus gramos de proteína al día. Ejemplo: 70 kg → 112–154 g.",
                 "Pollo, pescado, huevo, lácteos, atún, frijoles y lentejas cubren la meta sin suplementos.",
                 "La proteína en polvo es solo comida práctica: úsala si te cuesta llegar.",
                 "Con enfermedad renal, consulta a tu médico antes de subir la proteína."],
        refs=[("Morton RW, Murphy KT, McKellar SR, et al. A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults. Br J Sports Med. 2018;52(6):376-384.", "10.1136/bjsports-2017-097608", True)]),
    dict(
        slug="proteina-por-comida-mito-30-gramos", categoria="Nutrición", minutos=4,
        titulo="El mito de los 30 gramos de proteína por comida",
        resumen="Tu cuerpo no «desperdicia» la proteína de una comida grande. Repartirla ayuda, pero el total diario manda.",
        claves=["La idea de que solo aprovechas 20–30 g por comida viene de estudios con condiciones muy específicas.",
                "Una guía práctica: unos 0.4 g/kg por comida en al menos 4 comidas.",
                "En 2023, 100 g de proteína tras entrenar dieron una respuesta mayor y más larga que 25 g."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Una revisión de 2018 explica que la cantidad de proteína que se puede absorber es prácticamente ilimitada; lo discutido es cuánta se usa para construir músculo en una toma. "
                "Su recomendación práctica: alrededor de 0.4 g/kg por comida en al menos cuatro comidas, para llegar a 1.6 g/kg o más al día.",
                "Un estudio de 2023 dio 25 g o 100 g de proteína de leche después de entrenar. Con 100 g, la síntesis de proteína muscular fue mayor y duró más de 12 horas. "
                "Es un solo estudio, en condiciones de laboratorio, pero contradice la idea de un «tope» rígido."]),
        ],
        aplicar=["Calcula 0.4 g/kg por comida: con 70 kg son unos 28 g, por ejemplo 120 g de pollo o 4 claras con 2 huevos.",
                 "Si un día solo puedes hacer 2–3 comidas, no pasa nada: cumple el total.",
                 "Una comida con proteína 1–3 horas antes o después de entrenar es suficiente; no hay una «ventana» de 30 minutos."],
        refs=[("Schoenfeld BJ, Aragon AA. How much protein can the body use in a single meal for muscle-building? Implications for daily protein distribution. J Int Soc Sports Nutr. 2018;15:10.", "10.1186/s12970-018-0215-1", True),
              ("Trommelen J, van Lieshout GAA, Nyakayiru J, et al. The anabolic response to protein ingestion during recovery from exercise has no upper limit in magnitude and duration in vivo in humans. Cell Rep Med. 2023;4(12):101324.", "10.1016/j.xcrm.2023.101324", True)]),
    dict(
        slug="baja-en-carbohidratos-o-baja-en-grasa", categoria="Pérdida de grasa", minutos=4, destacado=True,
        titulo="¿Dieta baja en carbohidratos o baja en grasa? Empate",
        resumen="En un ensayo de un año con 609 adultos, las dos dietas hicieron perder casi lo mismo. Gana la que puedas sostener.",
        claves=["Bajo en carbohidratos y bajo en grasa dieron una pérdida de peso casi igual a 12 meses.",
                "Ni la genética ni la insulina predijeron quién respondía mejor a cada dieta.",
                "Con las mismas calorías y proteína, la proporción de carbohidratos y grasa importa poco para perder grasa."],
        secciones=[
            ("Lo que dice la ciencia", [
                "El ensayo DIETFITS (2018) asignó a 609 adultos a una dieta saludable baja en grasa o baja en carbohidratos durante 12 meses. "
                "Perdieron en promedio 5.3 kg y 6.0 kg: una diferencia de 0.7 kg que no fue significativa.",
                "Ambos grupos tenían algo en común: menos azúcar, menos harinas refinadas, más verduras y comida poco procesada.",
                "Una revisión de 2017 sobre el balance de energía concluye que, en dietas controladas con las mismas calorías, cambiar carbohidratos por grasa no produce diferencias prácticas en la grasa corporal."]),
        ],
        aplicar=["Elige el estilo que puedas mantener meses, no semanas.",
                 "Prioriza la proteína (1.6–2.2 g/kg) y las verduras en cualquier caso.",
                 "Si entrenas pesado, no quites los carbohidratos por completo: rendirás mejor con algo de avena, tortilla, papa o fruta.",
                 "Usa la calculadora de macros para probar repartos con las mismas calorías."],
        refs=[("Gardner CD, Trepanowski JF, Del Gobbo LC, et al. Effect of low-fat vs low-carbohydrate diet on 12-month weight loss in overweight adults (DIETFITS). JAMA. 2018;319(7):667-679.", "10.1001/jama.2018.0245", True),
              ("Hall KD, Guo J. Obesity energetics: body weight regulation and the effects of diet composition. Gastroenterology. 2017;152(7):1718-1727.", "10.1053/j.gastro.2017.01.052", True)]),
    dict(
        slug="ayuno-intermitente-funciona", categoria="Pérdida de grasa", minutos=3,
        titulo="Ayuno intermitente: ¿funciona mejor?",
        resumen="Comer solo de 12 a 8 pm no hizo perder más peso que comer tres veces al día en un ensayo de 12 semanas.",
        claves=["El ayuno 16:8 no fue mejor que comer a lo largo del día.",
                "Funciona solo si te ayuda a comer menos calorías en total.",
                "Si lo usas, cuida llegar a tu proteína en menos comidas."],
        secciones=[
            ("Lo que dice la ciencia", [
                "El ensayo TREAT (2020) asignó a 116 adultos con sobrepeso a comer solo entre las 12 y las 8 pm, o a hacer tres comidas estructuradas. "
                "Tras 12 semanas, el grupo de ayuno perdió 1.17 % de su peso y el otro 0.75 %, sin diferencia significativa entre ellos.",
                "El ayuno no tiene un efecto «quemagrasa» especial: es una forma más de organizar lo que comes."]),
        ],
        aplicar=["Si saltarte el desayuno te ayuda a controlar el hambre, puedes hacerlo.",
                 "Si te da ansiedad o comes de más en la noche, no es para ti.",
                 "Concentra la proteína: 2–3 comidas con 40–50 g cada una.",
                 "Con diabetes, embarazo o historial de trastornos alimentarios, consulta antes a un profesional."],
        refs=[("Lowe DA, Wu N, Rohdin-Bibby L, et al. Effects of time-restricted eating on weight loss and other metabolic parameters in women and men with overweight and obesity: the TREAT randomized clinical trial. JAMA Intern Med. 2020;180(11):1491-1499.", "10.1001/jamainternmed.2020.4153", True)]),
    dict(
        slug="creatina-guia-completa", categoria="Suplementos", minutos=4, destacado=True,
        titulo="Creatina: el suplemento con más respaldo",
        resumen="Mejora el rendimiento en esfuerzos intensos y es segura en personas sanas. Te explicamos cómo tomarla.",
        claves=["La creatina aumenta las reservas de energía rápida del músculo y mejora el rendimiento en esfuerzos cortos e intensos.",
                "Es segura a corto y largo plazo en personas sanas.",
                "La forma más estudiada es el monohidrato: 3–5 g al día, a cualquier hora."],
        secciones=[
            ("Lo que dice la ciencia", [
                "La Sociedad Internacional de Nutrición Deportiva (ISSN) publicó en 2017 su postura oficial: la creatina es uno de los suplementos más eficaces para el ejercicio de alta intensidad "
                "y ayuda a lograr mejores adaptaciones al entrenamiento.",
                "La misma revisión concluye que su uso a corto y largo plazo es seguro en personas sanas, desde niños hasta adultos mayores, en las dosis recomendadas."]),
            ("Dudas frecuentes", [
                "¿Retiene líquido? Es normal subir 1–2 kg los primeros días: es agua dentro del músculo, no grasa.",
                "¿Daña el riñón? En personas sanas no se ha observado daño. Si tienes enfermedad renal, consulta a tu médico.",
                "¿Hace falta carga? No. Con 3–5 g diarios las reservas se llenan en 3–4 semanas; la carga solo lo acelera."]),
        ],
        aplicar=["Monohidrato de creatina, 3–5 g al día, todos los días (también los de descanso).",
                 "Tómala con agua o con una comida, a la hora que te sea más fácil recordar.",
                 "Busca productos con certificación de terceros (por ejemplo, Informed Sport o NSF Certified for Sport)."],
        refs=[("Kreider RB, Kalman DS, Antonio J, et al. International Society of Sports Nutrition position stand: safety and efficacy of creatine supplementation in exercise, sport, and medicine. J Int Soc Sports Nutr. 2017;14:18.", "10.1186/s12970-017-0173-z", True)]),
    dict(
        slug="cafeina-para-entrenar", categoria="Suplementos", minutos=3,
        titulo="Cafeína para entrenar: cuánta y cuándo",
        resumen="La cafeína mejora el rendimiento a partir de unos 3 mg por kilo. Más no es mejor.",
        claves=["Funciona con 3–6 mg por kg de peso, y a veces desde 2 mg/kg.",
                "Tómala unos 60 minutos antes de entrenar.",
                "Dosis muy altas (9 mg/kg) causan efectos secundarios sin dar más beneficio."],
        secciones=[
            ("Lo que dice la ciencia", [
                "La postura de la ISSN de 2021 concluye que la cafeína mejora el rendimiento de forma consistente con 3–6 mg/kg, tanto en personas entrenadas como no entrenadas.",
                "El momento más usado es 60 minutos antes; los chicles de cafeína actúan más rápido que las cápsulas."]),
            ("Cuidado con", [
                "El sueño: la cafeína puede afectar tu descanso si la tomas en la tarde o noche, y dormir mal resta más de lo que suma.",
                "La ansiedad, la presión alta o las palpitaciones: si las tienes, consulta antes de usarla.",
                "El embarazo: consulta a tu médico; la recomendación habitual es no pasar de 200 mg al día."]),
        ],
        aplicar=["Ejemplo con 70 kg: 3 mg/kg = 210 mg, más o menos 2 tazas de café.",
                 "Empieza con la dosis baja y observa cómo te sientes.",
                 "Evítala en las 6–8 horas antes de dormir."],
        refs=[("Guest NS, VanDusseldorp TA, Nelson MT, et al. International Society of Sports Nutrition position stand: caffeine and exercise performance. J Int Soc Sports Nutr. 2021;18(1):1.", "10.1186/s12970-020-00383-4", True)]),
    dict(
        slug="dormir-para-crecer", categoria="Recuperación y sueño", minutos=4,
        titulo="Dormir para crecer: el sueño también es entrenamiento",
        resumen="Una sola noche sin dormir bajó 18 % la síntesis de proteína muscular. Los adultos necesitan 7 horas o más.",
        claves=["Los expertos en sueño recomiendan 7 horas o más por noche a los adultos.",
                "Una noche sin dormir redujo la síntesis de proteína muscular y la testosterona, y subió el cortisol.",
                "Dormir bien es de lo más barato y eficaz para recuperarte."],
        secciones=[
            ("Lo que dice la ciencia", [
                "En 2015, la Academia Americana de Medicina del Sueño y la Sociedad de Investigación del Sueño revisaron más de 5,000 artículos y recomendaron 7 horas o más por noche a los adultos de 18 a 60 años.",
                "En 2021, un experimento con 13 adultos jóvenes comparó una noche normal con una noche sin dormir. Tras no dormir, la síntesis de proteína muscular bajó 18 %, "
                "el cortisol subió 21 % y la testosterona bajó 24 %. Es un estudio pequeño y de una sola noche, pero ayuda a entender por qué el mal sueño frena el progreso."]),
        ],
        aplicar=["Acuéstate y levántate a la misma hora, incluso en fin de semana.",
                 "Cuarto oscuro, fresco y sin pantallas 30–60 minutos antes de dormir.",
                 "Evita la cafeína en la tarde y las cenas muy pesadas.",
                 "Registra tus horas de sueño en la app: verás cómo se relacionan con tu energía y tu fuerza."],
        refs=[("Watson NF, Badr MS, Belenky G, et al. Recommended amount of sleep for a healthy adult: a joint consensus statement of the AASM and SRS. Sleep. 2015;38(6):843-844.", "10.5665/sleep.4716", True),
              ("Lamon S, Morabito A, Arentson-Lantz E, et al. The effect of acute sleep deprivation on skeletal muscle protein synthesis and the hormonal environment. Physiol Rep. 2021;9(1):e14660.", "10.14814/phy2.14660", True)]),
    dict(
        slug="cuantos-pasos-al-dia", categoria="Salud y movimiento", minutos=3,
        titulo="¿Cuántos pasos al día bastan?",
        resumen="No hacen falta 10,000 exactos: el beneficio para la salud se estabiliza entre 6,000 y 10,000 pasos según tu edad.",
        claves=["Más pasos al día se asocian con menor riesgo de muerte por cualquier causa.",
                "El beneficio se estabiliza alrededor de 6,000–8,000 pasos en mayores de 60 y de 8,000–10,000 en menores de 60.",
                "La OMS recomienda 150–300 minutos de actividad moderada a la semana más ejercicios de fuerza."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Un metaanálisis de 2022 juntó 15 estudios con 47,471 adultos seguidos unos 7 años. Quienes caminaban más tuvieron un riesgo de muerte bastante menor que los que caminaban menos; "
                "el beneficio dejó de crecer alrededor de 6,000–8,000 pasos diarios en mayores de 60 años y de 8,000–10,000 en menores de 60.",
                "Las guías de la OMS de 2020 recomiendan a los adultos 150–300 minutos de actividad moderada (o 75–150 de vigorosa) por semana y ejercicios de fuerza al menos 2 días. "
                "También insisten en reducir el tiempo sentado: cualquier movimiento es mejor que ninguno."]),
        ],
        aplicar=["Mide tu promedio actual una semana y súmale 1,000–2,000 pasos.",
                 "Si estás perdiendo grasa, los pasos ayudan a mantener el gasto sin cansarte tanto como el cardio intenso.",
                 "Camina 5–10 minutos después de comer, toma llamadas caminando o bájate una parada antes."],
        refs=[("Paluch AE, Bajpai S, Bassett DR, et al. Daily steps and all-cause mortality: a meta-analysis of 15 international cohorts. Lancet Public Health. 2022;7(3):e219-e228.", "10.1016/S2468-2667(21)00302-9", True),
              ("Bull FC, Al-Ansari SS, Biddle S, et al. World Health Organization 2020 guidelines on physical activity and sedentary behaviour. Br J Sports Med. 2020;54(24):1451-1462.", "10.1136/bjsports-2020-102955", True)]),
    dict(
        slug="estirar-antes-de-entrenar", categoria="Recuperación y sueño", minutos=3,
        titulo="¿Estirar antes de entrenar te hace más débil?",
        resumen="Los estiramientos largos justo antes pueden restar un poco de fuerza. Dentro de un calentamiento completo, el efecto es mínimo.",
        claves=["El estiramiento estático largo, justo antes de rendir, puede bajar un poco la fuerza y la potencia.",
                "El estiramiento dinámico mejora ligeramente el rendimiento.",
                "La movilidad gana con cualquier tipo de estiramiento, pero el efecto agudo dura menos de 30 minutos."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Una revisión de 2016 analizó el efecto inmediato de estirar. El estiramiento estático y el FNP produjeron pequeñas bajas de rendimiento cuando se medía justo después; "
                "el dinámico produjo pequeñas mejoras.",
                "Los autores aclaran que muchos estudios usaban estiramientos más largos que en la práctica y sin calentamiento completo. "
                "Su recomendación: estirar dentro de un calentamiento que termine con movimientos dinámicos tiene efectos mínimos en el rendimiento y puede ayudar a la movilidad."]),
        ],
        aplicar=["Calienta 5 minutos de cardio suave y luego movilidad dinámica (balanceos, sentadillas sin peso).",
                 "Si necesitas estirar estático para moverte bien, hazlo menos de 60 segundos por músculo.",
                 "Termina con 2–3 series ligeras del primer ejercicio.",
                 "Los estiramientos largos guárdalos para después de entrenar o para otro momento del día."],
        refs=[("Behm DG, Blazevich AJ, Kay AD, McHugh M. Acute effects of muscle stretching on physical performance, range of motion, and injury incidence in healthy active individuals: a systematic review. Appl Physiol Nutr Metab. 2016;41(1):1-11.", "10.1139/apnm-2015-0235", False)]),
    dict(
        slug="mujeres-y-pesas", categoria="Mujeres y etapas de vida", minutos=3, destacado=True,
        titulo="Mujeres y pesas: mismos principios, mismo progreso relativo",
        resumen="Hombres y mujeres ganan músculo en proporción similar con el mismo programa. En fuerza del tren superior, ellas progresan incluso más.",
        claves=["Con el mismo entrenamiento, hombres y mujeres ganan un porcentaje similar de músculo.",
                "Las mujeres tuvieron más ganancia relativa de fuerza en el tren superior.",
                "Las pesas no te harán «voluminosa» por accidente: ganar músculo toma años de trabajo deliberado."],
        secciones=[
            ("Lo que dice la ciencia", [
                "Un metaanálisis de 2020 comparó a hombres y mujeres adultos con programas de fuerza iguales. Los cambios relativos de tamaño muscular y de fuerza del tren inferior fueron similares; "
                "en fuerza del tren superior, las mujeres mejoraron más en términos relativos.",
                "Es decir, las mismas reglas aplican: volumen suficiente, cerca del fallo y progresión de cargas."]),
        ],
        aplicar=["Usa las mismas plantillas de programa; ajusta solo según tus metas y tu recuperación.",
                 "No le temas a las cargas pesadas en sentadilla, peso muerto y remo.",
                 "Si tu ciclo menstrual cambia mucho tu energía, ajusta el RIR esos días; no hace falta un programa distinto.",
                 "Ciclos irregulares o ausentes con entrenamiento intenso son una señal de alerta: lee el artículo sobre comer muy poco (REDs)."],
        refs=[("Roberts BM, Nuckols G, Krieger JW. Sex differences in resistance training: a systematic review and meta-analysis. J Strength Cond Res. 2020;34(5):1448-1460.", "10.1519/JSC.0000000000003521", False)]),
    dict(
        slug="comer-muy-poco-reds", categoria="Salud y movimiento", minutos=4,
        titulo="Comer muy poco y entrenar mucho: qué es REDs",
        resumen="La deficiencia energética relativa en el deporte afecta hormonas, huesos y rendimiento, en mujeres y en hombres.",
        claves=["REDs ocurre cuando comes muy poco para todo lo que entrenas.",
                "Afecta la menstruación, los huesos, el sistema inmune, el ánimo y el rendimiento.",
                "Puede darse en cualquier deporte y también en hombres."],
        secciones=[
            ("Lo que dice la ciencia", [
                "El Comité Olímpico Internacional actualizó en 2023 su consenso sobre la deficiencia energética relativa en el deporte (REDs), con más de 170 estudios nuevos desde 2018. "
                "Describe cómo la baja disponibilidad de energía (lo que queda después de restar el ejercicio a lo que comes) altera muchos sistemas del cuerpo.",
                "El consenso incluye una herramienta clínica con semáforo para que los profesionales evalúen el riesgo."]),
            ("Señales de alerta", [
                "Menstruación irregular o ausente; fracturas por estrés o lesiones repetidas; cansancio constante; enfermarte seguido; bajo deseo sexual; ánimo bajo o irritabilidad; rendimiento que baja aunque entrenes más."]),
        ],
        aplicar=["No mantengas déficits grandes por mucho tiempo: 0.5 % de tu peso por semana es un buen tope.",
                 "Si entrenas mucho, come más en los días de más carga.",
                 "La app calcula tu disponibilidad energética si capturas tu % de grasa: valores bajos son motivo para revisar tu plan.",
                 "Si reconoces varias señales, busca a un médico deportivo y a un nutriólogo."],
        refs=[("Mountjoy M, Ackerman KE, Bailey DM, et al. 2023 International Olympic Committee's (IOC) consensus statement on Relative Energy Deficiency in Sport (REDs). Br J Sports Med. 2023;57(17):1073-1097.", "10.1136/bjsports-2023-106994", True)]),
    dict(
        slug="pesas-despues-de-los-60", categoria="Mujeres y etapas de vida", minutos=3,
        titulo="Pesas después de los 60: más fuerza, más independencia",
        resumen="La Asociación Nacional de Fuerza y Acondicionamiento recomienda el entrenamiento de fuerza a los adultos mayores, incluidas personas frágiles.",
        claves=["El entrenamiento de fuerza mejora la fuerza, la función y la independencia en adultos mayores.",
                "Los beneficios superan a los riesgos cuando el programa está bien diseñado.",
                "No hace falta entrenar al fallo para progresar."],
        secciones=[
            ("Lo que dice la ciencia", [
                "La postura oficial de la NSCA (2019) reúne la evidencia sobre fuerza en adultos mayores: mejora la masa muscular, la fuerza, el equilibrio y la capacidad de hacer tareas diarias, "
                "y ayuda a prevenir caídas, sarcopenia y fragilidad.",
                "Recomienda programas progresivos y supervisados, adaptados a cada persona; en personas frágiles, las máquinas son un buen punto de partida."]),
        ],
        aplicar=["Empieza con 2 días por semana y ejercicios de todo el cuerpo.",
                 "Incluye ejercicios para levantarte de una silla, subir escalones y cargar bolsas.",
                 "Agrega trabajo de equilibrio y potencia (moverte rápido con cargas ligeras) cuando ya tengas base.",
                 "Si tienes enfermedades del corazón, presión alta no controlada u osteoporosis, coordina el plan con tu médico."],
        refs=[("Fragala MS, Cadore EL, Dorgo S, et al. Resistance training for older adults: position statement from the National Strength and Conditioning Association. J Strength Cond Res. 2019;33(8):2019-2052.", "10.1519/JSC.0000000000003230", False)]),
    dict(
        slug="ejercicio-en-el-embarazo", categoria="Mujeres y etapas de vida", minutos=4,
        titulo="Ejercicio en el embarazo: seguro y recomendado",
        resumen="Las guías canadienses de 2019 recomiendan actividad física a todas las embarazadas sin contraindicaciones, con al menos 150 minutos por semana.",
        claves=["Todas las embarazadas sin contraindicaciones deberían mantenerse activas.",
                "La meta es al menos 150 minutos de actividad moderada por semana, repartidos en 3 días o más.",
                "Combinar aeróbico y fuerza da más beneficios; no se identificaron daños."],
        secciones=[
            ("Lo que dice la ciencia", [
                "La guía canadiense de actividad física en el embarazo (2019) revisó la evidencia y concluyó que la actividad física prenatal tiene beneficios moderados y no se identificaron daños. "
                "Recomienda al menos 150 minutos semanales de actividad moderada en un mínimo de 3 días, incluyendo ejercicios de fuerza.",
                "Las guías de la OMS de 2020 incluyeron por primera vez recomendaciones específicas para el embarazo y el posparto."]),
            ("Detente y consulta si", [
                "Sangrado vaginal, pérdida de líquido, contracciones regulares y dolorosas, mareo o desmayo, dolor en el pecho, falta de aire antes de empezar, dolor o hinchazón en la pantorrilla, o disminución de los movimientos del bebé."]),
        ],
        aplicar=["Antes de empezar o continuar, revisa con tu médico si tienes alguna contraindicación.",
                 "Usa la «prueba del habla»: debes poder conversar mientras te ejercitas.",
                 "Evita deportes de contacto o con riesgo de caída.",
                 "Si te mareas acostada boca arriba, cambia a ejercicios de lado o inclinados.",
                 "Incluye ejercicios de piso pélvico todos los días."],
        refs=[("Mottola MF, Davenport MH, Ruchat SM, et al. 2019 Canadian guideline for physical activity throughout pregnancy. Br J Sports Med. 2018;52(21):1339-1346.", "10.1136/bjsports-2018-100056", True),
              ("Bull FC, Al-Ansari SS, Biddle S, et al. World Health Organization 2020 guidelines on physical activity and sedentary behaviour. Br J Sports Med. 2020;54(24):1451-1462.", "10.1136/bjsports-2020-102955", True)]),
]



def _slug(t):
    import re
    import unicodedata
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-")[:80]


def _sumar():
    from data.articulos_guias import GUIAS
    from data.articulos_inv2 import A as INVESTIGACION
    vistos = {a["slug"] for a in ARTICULOS}
    for a in INVESTIGACION + GUIAS:
        a = dict(a)
        a["slug"] = a.get("slug") or _slug(a["titulo"])
        if a["slug"] in vistos:
            continue
        a.setdefault("destacado", False)
        a["tipo"] = "guia" if a["categoria"] in ("Guías por músculo", "Técnica de ejercicios", "Equipo y lugar", "Mitos") or a["slug"].startswith(("suplemento-", "condicion-")) else "investigacion"
        vistos.add(a["slug"])
        ARTICULOS.append(a)


for _a in ARTICULOS:
    _a.setdefault("tipo", "investigacion")
_sumar()


def enlace(ref):
    """URL de una referencia: DOI o enlace directo (PubMed, PMC, revista)."""
    return ref if ref.startswith("http") else f"https://doi.org/{ref}"


POR_SLUG = {a["slug"]: a for a in ARTICULOS}
