"""Contenido fijo: PAR-Q+, plantillas de programa, SMAE, suplementos, checklist, emergencias y METs."""

PARQ = [
    "¿Algún médico le ha dicho que tiene una afección cardíaca o presión arterial alta?",
    "¿Siente dolor en el pecho en reposo, en sus actividades diarias o al hacer actividad física?",
    "¿Ha perdido el equilibrio por mareo o ha perdido el conocimiento en los últimos 12 meses?",
    "¿Le han diagnosticado otra enfermedad crónica (además de cardiopatía o hipertensión)?",
    "¿Toma actualmente medicamentos recetados para una enfermedad crónica?",
    "¿Tiene (o tuvo en los últimos 12 meses) un problema de huesos, articulaciones o tejidos blandos que podría empeorar con más actividad física?",
    "¿Algún médico le ha dicho que solo debe hacer actividad física con supervisión médica?",
]

CONDICIONES = [
    ("embarazo", "Embarazo"),
    ("hipertension", "Hipertensión arterial"),
    ("diabetes", "Diabetes"),
    ("lesion", "Lesión o dolor actual"),
    ("osteoporosis", "Osteoporosis / baja masa ósea"),
]

ALERTAS_CONDICION = {
    "embarazo": "Embarazo: ≥150 min/sem de actividad moderada es recomendable si no hay contraindicaciones (ACOG 2020; guía canadiense 2019). Evita posiciones con riesgo de caída o golpe, el decúbito supino prolongado tras el primer trimestre y el esfuerzo máximo. Detén el ejercicio ante sangrado, contracciones regulares, mareo, dolor de pecho o pérdida de líquido. Requiere autorización de su médico.",
    "hipertension": "Hipertensión: la fuerza y el cardio reducen la presión en reposo (AHA 2023). No inicies ejercicio intenso si la presión en reposo está muy elevada (p. ej. ≥160/100) sin autorización médica; evita la maniobra de Valsalva prolongada y prioriza cargas moderadas.",
    "diabetes": "Diabetes: el ejercicio mejora el control glucémico (ADA/ACSM 2022). Si usa insulina o sulfonilureas, mida la glucosa antes y después; ante hipoglucemia aplique la regla de 15 g de carbohidrato rápido y vuelva a medir en 15 min.",
    "lesion": "Lesión o dolor actual: adapta los ejercicios que provocan dolor y deriva a fisioterapia o medicina si el dolor es intenso, nocturno, con inflamación, hormigueo o pérdida de fuerza.",
    "osteoporosis": "Baja masa ósea: el entrenamiento de fuerza progresivo y supervisado mejora el hueso (LIFTMOR); evita la flexión de columna cargada y prioriza la técnica.",
}

# Plantillas de programa
def _d(nombre, dia, ejercicios):
    return {"nombre": nombre, "dia": dia,
            "ejercicios": [dict(ex=e, series=s, rmin=a, rmax=b, rir=r, descanso=d) for e, s, a, b, r, d in ejercicios]}

PLANTILLAS = {
    "torso-pierna-4": {
        "nombre": "Torso / Pierna · 4 días", "nivel": "Intermedio", "dias_semana": 4,
        "descripcion": "Cada músculo 2 veces por semana con 10–20 series efectivas. Buena opción con 4 días disponibles.",
        "dias": [
            _d("Torso A", 0, [("Press de banca", 3, 6, 8, 2, 180), ("Remo con barra", 3, 6, 10, 2, 150), ("Press inclinado con mancuernas", 3, 8, 12, 2, 120), ("Jalón al pecho", 3, 8, 12, 1, 120), ("Elevaciones laterales con mancuernas", 3, 12, 15, 1, 60), ("Curl con barra EZ", 2, 10, 15, 1, 60), ("Extensión de tríceps en polea", 2, 10, 15, 1, 60)]),
            _d("Pierna A", 1, [("Sentadilla con barra", 3, 5, 8, 2, 180), ("Peso muerto rumano", 3, 6, 10, 2, 150), ("Prensa de piernas", 3, 10, 15, 1, 120), ("Curl femoral sentado", 3, 10, 15, 1, 90), ("Elevación de talones de pie", 4, 10, 15, 1, 60), ("Crunch en polea", 3, 10, 15, 1, 60)]),
            _d("Torso B", 3, [("Press inclinado con barra", 3, 6, 10, 2, 150), ("Remo en polea baja", 3, 8, 12, 2, 120), ("Press militar con mancuernas", 3, 8, 12, 2, 120), ("Jalón con agarre estrecho", 3, 10, 12, 1, 90), ("Elevaciones laterales en polea", 3, 12, 15, 1, 60), ("Face pulls", 2, 12, 20, 1, 60), ("Curl martillo", 2, 10, 15, 1, 60), ("Extensión con cuerda sobre la cabeza", 2, 10, 15, 1, 60)]),
            _d("Pierna B", 4, [("Peso muerto", 3, 4, 6, 2, 180), ("Sentadilla búlgara", 3, 8, 12, 2, 120), ("Hip thrust con barra", 3, 8, 12, 1, 120), ("Extensión de cuádriceps", 3, 12, 15, 1, 90), ("Curl femoral acostado", 2, 10, 15, 1, 90), ("Elevación de talones sentado", 4, 12, 20, 1, 60), ("Plancha lateral", 2, 8, 12, 1, 60)]),
        ]},
    "full-body-3": {
        "nombre": "Cuerpo completo · 3 días", "nivel": "Principiante", "dias_semana": 3,
        "descripcion": "Recomendado para principiantes: cada músculo 3 veces por semana con poco volumen por sesión.",
        "dias": [
            _d("Cuerpo completo A", 0, [("Sentadilla goblet", 3, 8, 12, 2, 120), ("Press de banca con mancuernas", 3, 8, 12, 2, 120), ("Jalón al pecho", 3, 8, 12, 2, 120), ("Peso muerto rumano", 2, 8, 12, 2, 120), ("Elevaciones laterales con mancuernas", 2, 12, 15, 1, 60), ("Plancha", 2, 8, 12, 1, 60)]),
            _d("Cuerpo completo B", 2, [("Prensa de piernas", 3, 10, 15, 2, 120), ("Press militar con mancuernas", 3, 8, 12, 2, 120), ("Remo con mancuerna a una mano", 3, 8, 12, 2, 90), ("Curl femoral sentado", 2, 10, 15, 1, 90), ("Curl con mancuernas", 2, 10, 15, 1, 60), ("Extensión de tríceps en polea", 2, 10, 15, 1, 60)]),
            _d("Cuerpo completo C", 4, [("Zancadas con mancuernas", 3, 8, 12, 2, 120), ("Press inclinado con mancuernas", 3, 8, 12, 2, 120), ("Remo en polea baja", 3, 10, 12, 2, 90), ("Hip thrust con barra", 2, 8, 12, 2, 90), ("Elevación de talones de pie", 3, 10, 15, 1, 60), ("Crunch en polea", 2, 10, 15, 1, 60)]),
        ]},
    "ppl-6": {
        "nombre": "Empuje / Jalón / Pierna · 6 días", "nivel": "Avanzado", "dias_semana": 6,
        "descripcion": "Alto volumen para avanzados con buena recuperación. Cada músculo 2 veces por semana.",
        "dias": [
            _d("Empuje A", 0, [("Press de banca", 3, 6, 8, 2, 180), ("Press militar con mancuernas", 3, 8, 12, 2, 120), ("Aperturas en polea (cruce de poleas)", 2, 12, 15, 1, 60), ("Elevaciones laterales en polea", 3, 12, 15, 1, 60), ("Extensión con cuerda sobre la cabeza", 3, 10, 15, 1, 60)]),
            _d("Jalón A", 1, [("Dominadas", 3, 6, 10, 2, 150), ("Remo con barra", 3, 6, 10, 2, 150), ("Face pulls", 3, 12, 20, 1, 60), ("Curl inclinado con mancuernas", 3, 10, 15, 1, 60), ("Encogimientos con mancuernas", 2, 10, 15, 1, 60)]),
            _d("Pierna A", 2, [("Sentadilla con barra", 3, 5, 8, 2, 180), ("Peso muerto rumano", 3, 6, 10, 2, 150), ("Extensión de cuádriceps", 3, 12, 15, 1, 90), ("Elevación de talones de pie", 4, 10, 15, 1, 60), ("Crunch en polea", 3, 10, 15, 1, 60)]),
            _d("Empuje B", 3, [("Press inclinado con barra", 3, 6, 10, 2, 150), ("Fondos en paralelas", 3, 8, 12, 2, 120), ("Elevaciones laterales con mancuernas", 3, 12, 20, 1, 60), ("Press francés con barra", 3, 10, 15, 1, 60)]),
            _d("Jalón B", 4, [("Jalón al pecho", 3, 8, 12, 2, 120), ("Remo en máquina con apoyo de pecho", 3, 8, 12, 1, 120), ("Deltoide posterior en máquina", 3, 12, 20, 1, 60), ("Curl martillo", 3, 10, 15, 1, 60)]),
            _d("Pierna B", 5, [("Prensa de piernas", 3, 10, 15, 2, 120), ("Hip thrust con barra", 3, 8, 12, 1, 120), ("Curl femoral sentado", 3, 10, 15, 1, 90), ("Aducción de cadera en máquina", 2, 12, 15, 1, 60), ("Elevación de talones sentado", 4, 12, 20, 1, 60), ("Pallof press", 2, 10, 12, 1, 60)]),
        ]},
    "casa-2": {
        "nombre": "Cuerpo completo en casa · 2 días", "nivel": "Principiante", "dias_semana": 2,
        "descripcion": "Mínimo eficaz (OMS: fuerza ≥2 días/sem) con mancuernas y peso corporal.",
        "dias": [
            _d("Casa A", 0, [("Sentadilla goblet", 3, 10, 15, 2, 90), ("Lagartijas", 3, 6, 15, 2, 90), ("Remo con mancuerna a una mano", 3, 10, 15, 2, 90), ("Puente de glúteo", 3, 12, 20, 1, 60), ("Plancha", 2, 8, 12, 1, 60)]),
            _d("Casa B", 3, [("Zancadas con mancuernas", 3, 8, 12, 2, 90), ("Press militar con mancuernas", 3, 8, 12, 2, 90), ("Curl con mancuernas", 2, 10, 15, 1, 60), ("Extensión de tríceps con mancuerna", 2, 10, 15, 1, 60), ("Plancha lateral", 2, 8, 12, 1, 60)]),
        ]},
}

NIVEL_SERIES = {"Principiante": (6, 12), "Intermedio": (10, 20), "Avanzado": (12, 24)}

# SMAE (Pérez Lizaur, Palacios y Castro, 3.ª ed.; valores verificados contra el PDF del curso)
SMAE = [
    ("Verduras", 25, 2, 0, 4), ("Frutas", 60, 0, 0, 15), ("Cereales sin grasa", 70, 2, 0, 15),
    ("Cereales con grasa", 115, 2, 5, 15), ("Leguminosas", 120, 8, 1, 20),
    ("AOA muy bajo en grasa", 40, 7, 1, 0), ("AOA bajo en grasa", 55, 7, 3, 0),
    ("AOA moderado en grasa", 75, 7, 5, 0), ("AOA alto en grasa", 100, 7, 8, 0),
    ("Leche descremada", 95, 9, 2, 12), ("Leche semidescremada", 110, 9, 4, 12), ("Leche entera", 150, 9, 8, 12),
    ("Leche con azúcar", 200, 8, 5, 30), ("Aceites y grasas sin proteína", 45, 0, 5, 0),
    ("Aceites y grasas con proteína", 70, 3, 5, 3), ("Azúcares sin grasa", 40, 0, 0, 10), ("Azúcares con grasa", 85, 0, 5, 10),
]
SMAE_EJEMPLO = {"Verduras": 5, "Frutas": 3, "Cereales sin grasa": 9, "Leguminosas": 1, "AOA muy bajo en grasa": 10,
                "AOA bajo en grasa": 5, "AOA moderado en grasa": 2, "Leche descremada": 2,
                "Aceites y grasas sin proteína": 4, "Aceites y grasas con proteína": 2}

ACTIVIDADES_MET = [
    ("Pesas: varios ejercicios, 8–15 reps", 3.5), ("Sentadilla / peso muerto, esfuerzo vigoroso", 5.0),
    ("Circuito de pesas con superseries", 5.8), ("Caminata moderada (~5 km/h)", 3.5), ("Trote general", 7.0),
    ("Bicicleta estática moderada", 6.8), ("Natación recreativa", 6.0), ("Fútbol recreativo", 7.0),
    ("Yoga / estiramientos", 2.5), ("Baile", 5.0),
]

SUPLEMENTOS = [
    ("Creatina monohidratada", "A", "3–5 g/día (carga opcional ~20 g/día × 5–7 días)", "Aumenta fuerza y masa magra. Segura en personas sanas (ISSN 2017)."),
    ("Cafeína", "A", "3–6 mg/kg, 30–60 min antes", "Mejora fuerza y resistencia. Evítala por la tarde; límite habitual 400 mg/día."),
    ("Proteína en polvo", "A", "La necesaria para llegar a la meta diaria", "Comodidad: equivale a la proteína de los alimentos (Morton 2018)."),
    ("Beta-alanina", "A", "4–6 g/día ≥2–4 semanas, tomas ≤1.6 g", "Útil en esfuerzos de 1–4 min; produce hormigueo inofensivo. Forma carnosina."),
    ("Bicarbonato de sodio", "A", "0.2–0.3 g/kg, 60–180 min antes", "Esfuerzos repetidos de alta intensidad; molestias digestivas frecuentes."),
    ("Vitamina D", "Salud", "Según análisis; límite superior 4,000 UI/día", "Solo corrige deficiencia; medir 25(OH)D antes de dosis altas."),
    ("Hierro", "Salud", "Solo con deficiencia diagnosticada", "No suplementar sin análisis (riesgo de sobrecarga)."),
    ("Omega-3", "B", "1–2 g/día EPA + DHA", "Salud cardiovascular; efecto muscular incierto."),
    ("Citrulina malato", "C", "6–8 g, 60 min antes", "Efecto pequeño (~+3 repeticiones) e inconsistente."),
    ("Ashwagandha", "C", "300–600 mg/día de extracto", "Evidencia de baja certeza; precaución con tiroides y embarazo."),
    ("BCAA / EAA", "D", "—", "Innecesarios si la proteína diaria es suficiente."),
    ("Glutamina, tribulus, ácido D-aspártico, 'quemadores'", "D", "—", "Sin efecto relevante; riesgo de contaminación."),
    ("SARMs, esteroides, prohormonales", "Riesgo", "No recomendado", "Daño hepático, cardiovascular y hormonal (FDA). Derivar al médico."),
]

CHECKLIST = [
    ("Nutrición y recuperación", [
        "Proteína diaria de 1.6–2.2 g/kg (en déficit 2.3–3.1 g/kg de masa libre de grasa)",
        "Al menos 3–4 comidas con ~0.4 g/kg de proteína",
        "Ritmo de cambio de peso dentro del objetivo (pérdida 0.5–1 %/sem; ganancia 0.25–0.5 %/sem)",
        "Sueño de 7 h o más por noche",
        "Me despierto descansado y con energía estable",
        "Sin dolor muscular persistente que limite el entrenamiento",
    ]),
    ("Entrenamiento", [
        "10–20 series efectivas por músculo a la semana",
        "Series a 0–3 repeticiones en reserva (RIR); fallo solo en la última serie de aislamientos",
        "Cada músculo se entrena al menos 2 veces por semana",
        "Descanso de 2–3 min en ejercicios básicos pesados",
        "Rango de movimiento completo, con énfasis en el estiramiento",
        "Registro cada serie y el rendimiento sube",
        "Ningún músculo principal sin series directas (pantorrilla, deltoide posterior, glúteo, core)",
        "Máximo ~8–10 series efectivas por músculo en una misma sesión",
        "Actividad aeróbica de 150–300 min/sem moderada (OMS 2020)",
        "Descarga cada 4–8 semanas o si el rendimiento cae 2 sesiones seguidas",
    ]),
]

EMERGENCIA = [
    ("Paro cardiaco (persona que no responde y no respira o solo boquea)", [
        "Verifica que la escena sea segura.",
        "Toca y habla fuerte: si no responde, pide ayuda, LLAMA AL 911 (pon el altavoz) y pide que traigan un DEA (desfibrilador).",
        "Revisa la respiración máximo 10 segundos. Si no respira o solo boquea: inicia compresiones.",
        "Compresiones en el centro del pecho: 5–6 cm de profundidad, 100–120 por minuto, deja que el pecho regrese por completo, mínimas interrupciones.",
        "Si estás entrenado: 30 compresiones y 2 ventilaciones. Si no: solo compresiones continuas.",
        "En cuanto llegue el DEA, enciéndelo y sigue sus instrucciones de voz. Reanuda compresiones de inmediato tras la descarga.",
        "Continúa hasta que llegue el servicio de emergencia o la persona se mueva y respire normalmente.",
    ]),
    ("Atragantamiento en adulto (no puede hablar, toser ni respirar)", [
        "Si puede toser con fuerza, anímalo a seguir tosiendo.",
        "Si no puede hablar ni toser: llama al 911 y alterna 5 golpes en la espalda (entre los omóplatos) y 5 compresiones abdominales (maniobra de Heimlich), según la actualización AHA 2025.",
        "Si pierde el conocimiento: bájalo al suelo e inicia RCP.",
    ]),
    ("Esguince, distensión o golpe", [
        "Primeros días (PEACE): Protege, Eleva, Evita antiinflamatorios y hielo prolongado los primeros días, Comprime, Educa.",
        "Después (LOVE): Carga progresiva, Optimismo, Vascularización (actividad aeróbica sin dolor), Ejercicio (Dubois y Esculier 2020).",
        "Deriva a evaluación médica si no puede apoyar, hay deformidad, adormecimiento o dolor intenso.",
    ]),
    ("Golpe de calor (confusión, piel caliente, temperatura muy alta)", [
        "Llama al 911.",
        "Enfría primero, traslada después: inmersión en agua fría o mojar y ventilar de forma continua.",
        "No des líquidos si está confundido o inconsciente.",
    ]),
    ("Hipoglucemia (temblor, sudor frío, confusión; frecuente en personas con diabetes)", [
        "Si está consciente y puede tragar: 15 g de carbohidrato rápido (jugo, azúcar, tabletas de glucosa).",
        "Vuelve a medir o evaluar en 15 min y repite si sigue baja.",
        "Si pierde el conocimiento: llama al 911; no le des nada por la boca.",
    ]),
    ("Golpe en la cabeza / posible conmoción", [
        "Retira a la persona de la actividad; no regresa ese mismo día.",
        "Llama al 911 si hay pérdida de conocimiento, vómito repetido, convulsión, confusión que empeora o debilidad.",
    ]),
]

MITOS = [
    ("El ácido láctico causa las agujetas", "Falso. El lactato se elimina en 1–2 h y se reutiliza como combustible; las agujetas son daño e inflamación muscular que aparecen 24–72 h después."),
    ("Hay una 'zona quema grasa' de baja intensidad", "Engañoso. A baja intensidad se usa mayor proporción de grasa, pero lo que determina la pérdida de grasa es el balance energético diario."),
    ("Las rodillas nunca deben pasar la punta del pie", "Falso. Restringirlo traslada estrés a la cadera y la espalda; es normal si no hay dolor."),
    ("Los abdominales queman la grasa del abdomen", "Falso. No existe la reducción localizada de grasa en forma práctica."),
    ("El músculo se convierte en grasa si dejas de entrenar", "Falso. Son tejidos distintos; puedes perder músculo y ganar grasa al mismo tiempo."),
    ("Más de 25–30 g de proteína por comida se desperdician", "Falso. 100 g produjeron una síntesis mayor y más prolongada que 25 g (Trommelen 2023); importa el total diario."),
    ("Hay que entrenar al fallo para crecer", "Falso. Con el mismo volumen, quedarse a 1–3 repeticiones del fallo da resultados similares y menos fatiga."),
    ("Estirar antes de entrenar previene lesiones", "No demostrado. Un calentamiento general y series de aproximación son más útiles."),
]
