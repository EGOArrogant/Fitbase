"""Variantes de platillos reales (familias de recetas) con ingredientes de la base.

Cada familia combina proteína, carbohidrato y verdura. Los macros se calculan por ingrediente
(data/recetas.py → ING, valores USDA/SMAE). Se agregan pasos y tips por familia.
"""
import re
import unicodedata

# gramos por unidad casera: (g, singular, plural)
UNIDAD = {
    "Tortilla de maíz": (30, "tortilla", "tortillas"), "Tostada horneada": (12, "tostada", "tostadas"),
    "Pan integral": (30, "rebanada", "rebanadas"), "Huevo entero": (50, "huevo", "huevos"), "Clara de huevo": (33, "clara", "claras"),
    "Galleta de arroz inflado": (9, "galleta", "galletas"), "Plátano": (120, "plátano", "plátanos"), "Manzana": (180, "manzana", "manzanas"),
    "Naranja": (140, "naranja", "naranjas"), "Guayaba": (55, "guayaba", "guayabas"), "Papa cocida": (150, "papa mediana", "papas medianas"),
    "Camote cocido": (130, "camote chico", "camotes chicos"), "Jitomate": (120, "jitomate", "jitomates"), "Zanahoria": (60, "zanahoria", "zanahorias"),
    "Chile serrano": (6, "chile", "chiles"), "Limón": (30, "limón", "limones"), "Jamón de pavo": (20, "rebanada", "rebanadas"),
    "Proteína de suero (polvo)": (30, "medida (scoop)", "medidas"), "Proteína vegetal en polvo (chícharo)": (30, "medida (scoop)", "medidas"),
    "Pimiento": (120, "pimiento", "pimientos"), "Chile poblano": (100, "chile poblano", "chiles poblanos"), "Tomate verde": (35, "tomate", "tomates"),
}
TAZA = {"Arroz blanco cocido": 160, "Arroz integral cocido": 195, "Quinoa cocida": 185, "Pasta cocida": 140, "Avena en hojuelas": 80,
        "Leche descremada": 240, "Leche de soya sin azúcar": 240, "Yogur griego natural sin grasa": 245, "Frijol negro cocido": 170,
        "Frijol pinto cocido": 170, "Lenteja cocida": 200, "Garbanzo cocido": 165, "Haba seca cocida": 170, "Fresas": 150,
        "Frutos rojos congelados": 140, "Mango": 165, "Papaya": 140, "Piña": 165, "Espinaca": 30, "Lechuga": 50, "Champiñones": 70,
        "Nopal": 150, "Calabacita": 120, "Brócoli": 90, "Pepino": 130, "Jícama": 130, "Ejotes": 110, "Chayote cocido": 160,
        "Caldo de pollo casero": 240, "Caldo de verduras": 240, "Queso cottage": 225, "Requesón": 245, "Chícharos cocidos": 160,
        "Elote desgranado": 150, "Col": 90, "Verdolagas": 45, "Flor de calabaza": 60, "Palomitas naturales (sin aceite)": 8,
        "Maíz pozolero cocido": 165, "Rábano": 115}
CUCHARADA = {"Aceite de oliva": 13.5, "Aceite de canola": 13.5, "Crema de cacahuate": 16, "Semillas de chía": 12, "Miel": 21,
             "Aguacate": 15, "Nuez": 8, "Almendras": 9, "Pepitas de calabaza": 9, "Salsa verde": 15, "Cebolla": 10, "Cilantro": 4,
             "Amaranto inflado": 4, "Queso fresco": 10, "Aceitunas verdes": 10}
CARNE = {"Pechuga de pollo cocida", "Muslo de pollo sin piel cocido", "Pechuga de pavo cocida", "Bistec de res magro cocido", "Lomo de cerdo cocido",
         "Carne molida de res 90/10 cocida", "Salmón cocido", "Tilapia cocida", "Camarón cocido", "Tofu firme", "Carne molida de pavo 93/7 cruda"}


def _frac(x):
    ent, r = int(x), x - int(x)
    f = min([(0, ""), (.25, "¼"), (1 / 3, "⅓"), (.5, "½"), (2 / 3, "⅔"), (.75, "¾"), (1, "")], key=lambda t: abs(t[0] - r))
    if f[0] == 1:
        ent, f = ent + 1, (0, "")
    return (str(ent) if ent else "") + ((" " if ent else "") + f[1] if f[1] else "") or "¼"


def medida(n, g):
    if n in UNIDAD:
        u, s1, s2 = UNIDAD[n]
        q = g / u
        return f"{_frac(q)} {s1 if q <= 1.1 else s2}"
    if n in TAZA:
        return f"{_frac(g / TAZA[n])} taza"
    if n in CUCHARADA:
        q = g / CUCHARADA[n]
        return f"{_frac(q)} cucharada{'s' if q > 1.1 else ''}" if q >= 0.9 else f"{_frac(q * 3)} cucharadita{'s' if q * 3 > 1.1 else ''}"
    if n == "Atún en agua (escurrido)":
        return f"{_frac(g / 100)} lata"
    if n == "Sardina en salsa de jitomate (lata, escurrida)":
        return f"{_frac(g / 120)} lata"
    if n in CARNE:
        return f"≈ {_frac(g / 100)} palma de la mano"
    if n in ("Queso panela", "Queso fresco"):
        return f"{_frac(g / 30)} rebanada{'s' if g > 33 else ''}"
    return f"{g} g"


def _slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")


PROT = {  # nombre en el platillo, ingrediente, gramos, etiquetas
    "pollo": ("pollo", "Pechuga de pollo cocida", 110, []),
    "muslo": ("muslo de pollo", "Muslo de pollo sin piel cocido", 110, []),
    "pavo": ("pavo", "Pechuga de pavo cocida", 110, []),
    "res": ("res", "Bistec de res magro cocido", 100, []),
    "molida": ("carne molida", "Carne molida de res 90/10 cocida", 100, []),
    "cerdo": ("lomo de cerdo", "Lomo de cerdo cocido", 100, []),
    "salmon": ("salmón", "Salmón cocido", 100, ["omega-3"]),
    "tilapia": ("tilapia", "Tilapia cocida", 120, []),
    "atun": ("atún", "Atún en agua (escurrido)", 100, ["económica"]),
    "camaron": ("camarón", "Camarón cocido", 110, []),
    "tofu": ("tofu", "Tofu firme", 150, ["vegetariana", "vegana"]),
    "huevo": ("huevo", "Huevo entero", 100, ["vegetariana", "económica"]),
    "panela": ("panela", "Queso panela", 70, ["vegetariana"]),
}
VEG_PROT = {"tofu", "huevo", "panela"}

CARB = {"arroz": ("arroz", "Arroz blanco cocido", 150), "integral": ("arroz integral", "Arroz integral cocido", 150),
        "quinoa": ("quinoa", "Quinoa cocida", 150), "camote": ("camote", "Camote cocido", 150), "papa": ("papa", "Papa cocida", 180),
        "pasta": ("pasta", "Pasta cocida", 140)}

TIP_COCCION = {
    "Pechuga de pollo cocida": "Cocina el pollo hasta 74 °C en el centro; si lo preparas para varios días, guárdalo en refrigeración máximo 3–4 días.",
    "Muslo de pollo sin piel cocido": "Retira la piel antes de cocinar: ahorras buena parte de la grasa. Cocina hasta 74 °C.",
    "Pechuga de pavo cocida": "El pavo se cocina igual que el pollo: 74 °C en el centro.",
    "Carne molida de res 90/10 cocida": "La carne molida debe llegar a 71 °C; escurre la grasa que suelte al dorarla.",
    "Bistec de res magro cocido": "Bistec a la plancha muy caliente 1–2 min por lado; déjalo reposar 3 min antes de cortar.",
    "Lomo de cerdo cocido": "El lomo de cerdo queda jugoso a 63 °C con 3 min de reposo.",
    "Salmón cocido": "El salmón aporta omega-3; cocínalo hasta que se separe en lajas (63 °C).",
    "Tilapia cocida": "El pescado está listo cuando se ve opaco y se separa con el tenedor.",
    "Camarón cocido": "El camarón se cocina en 2–3 min: cuando se pone rosado y curvo, retíralo para que no quede chicloso.",
    "Atún en agua (escurrido)": "Escurre bien el atún; si cuidas el sodio, enjuágalo unos segundos.",
    "Tofu firme": "Presiona el tofu 10 min entre servilletas antes de cocinarlo: absorbe mejor el sazón y se dora más.",
    "Huevo entero": "Cocina el huevo hasta que la clara esté firme.",
    "Queso panela": "La panela comercial varía mucho en grasa: revisa la etiqueta si estás en déficit.",
}
TIP_GRASA = "Mide el aceite con cucharita o usa aspersor: un chorro libre puede pasar de 120 kcal."


def receta(nombre, tipo, minutos, ing, pasos, tips, tags):
    return {"id": _slug(nombre), "nombre": nombre, "tipo": tipo, "minutos": minutos, "tags": sorted(set(tags)),
            "ingredientes": [{"nombre": n, "g": g, "medida": medida(n, g)} for n, g in ing if g],
            "pasos": pasos, "tips": [t for t in tips if t][:4]}


def generar():
    R = []

    # 1. Bowls
    verduras_bowl = [("brócoli", "Brócoli", 90), ("calabacita", "Calabacita", 100), ("ejotes", "Ejotes", 90), ("pepino y jitomate", "Pepino", 80)]
    for i, pk in enumerate(["pollo", "pavo", "res", "cerdo", "salmon", "tilapia", "atun", "camaron", "tofu", "muslo"]):
        pn, pi, pg, ptag = PROT[pk]
        for j, ck in enumerate(["arroz", "integral", "quinoa"]):
            cn, ci, cg = CARB[ck]
            vn, vi, vg = verduras_bowl[(i + j) % len(verduras_bowl)]
            ing = [(pi, pg), (ci, cg), (vi, vg), ("Jitomate", 60), ("Aguacate", 30), ("Limón", 15)]
            R.append(receta(f"Bowl de {pn} con {cn} y {vn}", "comida", 20, ing,
                            [f"Calienta el {cn} ya cocido.", f"Cocina {('el ' + pn) if pk != 'atun' else 'o escurre el atún'} a la plancha con sal, pimienta y ajo.",
                             f"Cuece {vn} al vapor 4–5 min para que quede crujiente.", "Arma el bowl: base de " + cn + ", proteína, verduras, jitomate y aguacate; termina con limón."],
                            [TIP_COCCION.get(pi), "Para meal prep, guarda la base y la proteína por separado y agrega el aguacate al servir.",
                             "Cocinar al vapor no 'quema grasa': solo evita agregar aceite."],
                            ["alta proteína", "meal prep", "sin gluten"] + ptag + (["vegetariana"] if pk in VEG_PROT else [])))

    # 2. Tacos
    for pk in ["pollo", "res", "cerdo", "tilapia", "camaron", "atun", "pavo", "molida", "tofu", "muslo", "salmon"]:
        pn, pi, pg, ptag = PROT[pk]
        ing = [("Tortilla de maíz", 90), (pi, pg), ("Cebolla", 20), ("Cilantro", 5), ("Salsa verde", 45), ("Aguacate", 30), ("Limón", 15)]
        estilo = "estilo Baja (a la plancha)" if pk in ("tilapia", "camaron", "salmon") else "con salsa verde"
        R.append(receta(f"Tacos de {pn} {estilo}", "comida", 20, ing,
                        [f"Sazona {'el' if pk not in ('atun',) else 'el'} {pn} con sal, pimienta, ajo y comino; cocínalo a la plancha.",
                         "Calienta las tortillas en comal hasta que se inflen.", "Pica cebolla y cilantro finos.",
                         "Sirve 3 tacos con la proteína, cebolla, cilantro, salsa y aguacate; exprime limón."],
                        [TIP_COCCION.get(pi), "Tortillas de maíz en lugar de harina: más fibra y menos grasa.", "Agrega col o rábano para más volumen con pocas calorías."],
                        ["alta proteína", "sin gluten", "rápida"] + ptag + (["vegetariana"] if pk in VEG_PROT else [])))

    # 3. A la plancha con guarnición
    guarn = [("camote y brócoli", [("Camote cocido", 150), ("Brócoli", 100)]), ("papa y ensalada", [("Papa cocida", 180), ("Lechuga", 60), ("Jitomate", 60)]),
             ("arroz y calabacitas", [("Arroz blanco cocido", 140), ("Calabacita", 120)]), ("quinoa y ejotes", [("Quinoa cocida", 140), ("Ejotes", 100)])]
    for i, pk in enumerate(["pollo", "pavo", "res", "cerdo", "salmon", "tilapia", "muslo", "tofu"]):
        pn, pi, pg, ptag = PROT[pk]
        for j in (0, 2) if i % 2 == 0 else (1, 3):
            gn, gi = guarn[j]
            base = {"pollo": "Pechuga de pollo", "pavo": "Pechuga de pavo", "res": "Bistec de res", "cerdo": "Lomo de cerdo", "salmon": "Salmón",
                    "tilapia": "Filete de tilapia", "muslo": "Muslo de pollo", "tofu": "Tofu"}[pk]
            ing = [(pi, pg + 10)] + gi + [("Aceite de oliva", 5), ("Limón", 15)]
            R.append(receta(f"{base} a la plancha con {gn}", "comida" if j % 2 == 0 else "cena", 25, ing,
                            [f"Marina la proteína 10 min con limón, ajo, sal y especias al gusto.", "Calienta un sartén antideslizante con 1 cucharadita de aceite.",
                             "Cocina a la plancha sin moverla hasta que se dore; voltea una sola vez.", f"Acompaña con {gn} preparados al vapor, hervidos u horneados."],
                            [TIP_COCCION.get(pi), TIP_GRASA, "Hornear o hacer al vapor las guarniciones evita grasa añadida."],
                            ["alta proteína", "sin gluten", "meal prep"] + ptag + (["vegetariana", "vegana"] if pk == "tofu" else [])))

    # 4. Ensaladas
    for pk, extra in [("pollo", ("Garbanzo cocido", 60)), ("atun", ("Elote desgranado", 60)), ("camaron", ("Mango", 80)), ("salmon", ("Quinoa cocida", 80)),
                      ("huevo", ("Papa cocida", 120)), ("panela", ("Fresas", 80)), ("tofu", ("Garbanzo cocido", 60)), ("pavo", ("Manzana", 90)),
                      ("res", ("Frijol negro cocido", 60)), ("tilapia", ("Elote desgranado", 60))]:
        pn, pi, pg, ptag = PROT[pk]
        ing = [("Lechuga", 80), ("Espinaca", 30), ("Jitomate", 60), ("Pepino", 60), (pi, pg), extra, ("Aceite de oliva", 7), ("Limón", 20)]
        en = {"Garbanzo cocido": "garbanzo", "Elote desgranado": "elote", "Mango": "mango", "Quinoa cocida": "quinoa", "Papa cocida": "papa",
              "Fresas": "fresas", "Manzana": "manzana", "Frijol negro cocido": "frijol"}[extra[0]]
        R.append(receta(f"Ensalada de {pn} con {en}", "cena" if pk in ("huevo", "panela", "pavo") else "comida", 15, ing,
                        ["Lava y desinfecta las hojas; sécalas bien.", f"Prepara {('el ' if pk != 'huevo' else 'los ') + pn} (a la plancha, cocido o escurrido).",
                         "Mezcla aceite, limón, sal y pimienta para el aderezo.", f"Combina hojas, verduras, {en} y proteína; aliña justo antes de comer."],
                        [TIP_COCCION.get(pi), "Prepara el aderezo aparte: así la ensalada aguanta 2–3 días en el refrigerador.",
                         "Mide el aceite del aderezo: es donde se esconden las calorías de una ensalada."],
                        ["alta proteína", "sin gluten", "rápida", "baja en calorías"] + ptag + (["vegetariana"] if pk in VEG_PROT else [])))

    # 5. Sopas y caldos
    for nombre, prot, extra, tags in [("Caldo de pollo con verduras", ("Pechuga de pollo cocida", 110), ("Arroz blanco cocido", 80), []),
                                      ("Caldo de res con verduras", ("Bistec de res magro cocido", 100), ("Elote desgranado", 60), []),
                                      ("Caldo de pescado (tilapia)", ("Tilapia cocida", 130), ("Arroz blanco cocido", 80), []),
                                      ("Sopa de albóndigas de pavo", ("Carne molida de pavo 93/7 cruda", 120), ("Arroz blanco cocido", 60), []),
                                      ("Sopa de lentejas con verduras", ("Lenteja cocida", 200), ("Papa cocida", 80), ["vegetariana", "vegana", "alta fibra"]),
                                      ("Sopa de garbanzo con espinaca", ("Garbanzo cocido", 180), ("Jitomate", 80), ["vegetariana", "vegana", "alta fibra"]),
                                      ("Sopa de frijol negro", ("Frijol negro cocido", 200), ("Tortilla de maíz", 30), ["vegetariana", "vegana", "alta fibra", "económica"]),
                                      ("Caldo de camarón ligero", ("Camarón cocido", 120), ("Papa cocida", 80), [])]:
        caldo = "Caldo de verduras" if "vegana" in tags else "Caldo de pollo casero"
        ing = [(caldo, 360), prot, extra, ("Zanahoria", 60), ("Calabacita", 80), ("Chayote cocido", 80), ("Cebolla", 20), ("Cilantro", 5)]
        R.append(receta(nombre, "comida", 35, ing,
                        ["Calienta el caldo con cebolla y ajo.", "Agrega zanahoria y chayote; cuece 10 min.",
                         f"Incorpora {prot[0].split(' (')[0].lower()} y la calabacita; cocina 8–10 min más.", "Sirve con cilantro y limón."],
                        [TIP_COCCION.get(prot[0]), "Desgrasa el caldo casero: refrigéralo y retira la capa de grasa de arriba.",
                         "Las sopas con mucha verdura llenan con pocas calorías: buena entrada si tienes hambre en déficit."],
                        ["sin gluten", "meal prep"] + tags))

    # 6. Pastas
    for pk, salsa in [("pollo", "jitomate y espinaca"), ("atun", "jitomate y aceitunas"), ("camaron", "ajo y limón"), ("molida", "boloñesa ligera"),
                      ("pavo", "champiñones"), ("tofu", "pesto de espinaca")]:
        pn, pi, pg, ptag = PROT[pk]
        extra = {"jitomate y espinaca": [("Jitomate", 120), ("Espinaca", 40)], "jitomate y aceitunas": [("Jitomate", 120), ("Aceitunas verdes", 15)],
                 "ajo y limón": [("Brócoli", 80), ("Limón", 20)], "boloñesa ligera": [("Jitomate", 150), ("Zanahoria", 40)],
                 "champiñones": [("Champiñones", 100), ("Leche descremada", 60)], "pesto de espinaca": [("Espinaca", 60), ("Nuez", 10)]}[salsa]
        ing = [("Pasta cocida", 150), (pi, pg)] + extra + [("Aceite de oliva", 5), ("Queso panela", 20)]
        R.append(receta(f"Pasta con {pn} en salsa de {salsa}", "comida", 25, ing,
                        ["Cuece la pasta al dente y reserva un poco del agua.", f"Cocina {('el ' + pn)} en un sartén con 1 cucharadita de aceite.",
                         f"Agrega los ingredientes de la salsa de {salsa}; cocina 5–8 min.", "Mezcla con la pasta, ajusta con agua de cocción y termina con panela rallada."],
                        [TIP_COCCION.get(pi), "Pasta al dente y luego enfriada tiene un poco más de almidón resistente; sigue contando sus calorías.", TIP_GRASA],
                        ["alta proteína"] + ptag + (["vegetariana", "vegana"] if pk == "tofu" else [])))

    # 7. Salteados de arroz
    for pk in ["pollo", "res", "cerdo", "camaron", "tofu", "huevo", "pavo", "atun"]:
        pn, pi, pg, ptag = PROT[pk]
        ing = [("Arroz blanco cocido", 150), (pi, pg), ("Brócoli", 70), ("Pimiento", 60), ("Zanahoria", 40), ("Chícharos cocidos", 40), ("Aceite de canola", 5)]
        R.append(receta(f"Arroz salteado con {pn} y verduras", "comida", 20, ing,
                        ["Usa arroz cocido del día anterior: se suelta mejor.", "Saltea las verduras 3–4 min a fuego alto con 1 cucharadita de aceite.",
                         f"Agrega {('el ' + pn) if pk != 'huevo' else 'el huevo batido'} y cocina hasta que esté listo.", "Incorpora el arroz y saltea 2 min; sazona con salsa de soya baja en sodio o limón."],
                        [TIP_COCCION.get(pi), "Enfría rápido el arroz que sobre (máximo 2 h a temperatura ambiente) y consúmelo en 3–4 días.", TIP_GRASA],
                        ["alta proteína", "meal prep", "rápida"] + ptag + (["vegetariana"] if pk in VEG_PROT else [])))

    # 8. Fajitas
    for pk in ["pollo", "res", "camaron", "tofu", "cerdo", "pavo"]:
        pn, pi, pg, ptag = PROT[pk]
        ing = [(pi, pg + 10), ("Pimiento", 100), ("Cebolla", 50), ("Tortilla de maíz", 60), ("Aguacate", 30), ("Aceite de oliva", 5), ("Limón", 15)]
        R.append(receta(f"Fajitas de {pn} con pimientos", "cena", 20, ing,
                        [f"Corta {('el ' + pn)} y los pimientos en tiras.", "Saltea pimiento y cebolla con 1 cucharadita de aceite hasta que se doren.",
                         "Agrega la proteína con comino, ajo y paprika; cocina hasta su punto.", "Sirve en tortillas con aguacate y limón."],
                        [TIP_COCCION.get(pi), "Usa pimientos de colores: más vitamina C y se ve mejor el plato.", TIP_GRASA],
                        ["alta proteína", "sin gluten"] + ptag + (["vegetariana", "vegana"] if pk == "tofu" else [])))

    # 9. Tostadas
    for pk in ["pollo", "atun", "camaron", "tilapia", "panela", "huevo", "pavo"]:
        pn, pi, pg, ptag = PROT[pk]
        ing = [("Tostada horneada", 36), ("Frijol negro cocido", 60), (pi, pg - 10), ("Lechuga", 40), ("Jitomate", 50), ("Salsa verde", 30), ("Aguacate", 20)]
        R.append(receta(f"Tostadas horneadas de {pn}", "cena", 15, ing,
                        ["Unta una capa delgada de frijol en cada tostada.", f"Coloca {('el ' + pn) if pk != 'huevo' else 'el huevo revuelto'} encima.",
                         "Agrega lechuga, jitomate, salsa y aguacate.", "Sirve de inmediato para que no se humedezcan."],
                        [TIP_COCCION.get(pi), "Tostadas horneadas en lugar de fritas: mucho menos aceite."],
                        ["alta proteína", "sin gluten", "rápida"] + ptag + (["vegetariana"] if pk in VEG_PROT else [])))

    # 10. Ceviches
    for pk in ["tilapia", "camaron", "atun"]:
        pn, pi, pg, ptag = PROT[pk]
        ing = [(pi, pg + 20), ("Limón", 60), ("Jitomate", 80), ("Pepino", 80), ("Cebolla", 25), ("Cilantro", 8), ("Aguacate", 30), ("Tostada horneada", 24)]
        R.append(receta(f"Ceviche de {pn} con pepino", "comida", 20, ing,
                        [f"Usa {pn} cocido y frío (más seguro que crudo marinado).", "Pica jitomate, pepino, cebolla y cilantro.",
                         "Mezcla con el jugo de limón, sal y chile al gusto; reposa 10 min en refrigeración.", "Sirve con aguacate y tostadas horneadas."],
                        ["El limón no 'cuece' el pescado crudo ni elimina bacterias: usa pescado cocido o muy fresco de proveedor confiable.",
                         "Consúmelo el mismo día."],
                        ["alta proteína", "sin gluten", "baja en calorías"] + ptag))

    # 11. Guisos de leguminosas
    for nombre, leg, prot, tags in [("Chili de frijol con carne molida", ("Frijol pinto cocido", 150), ("Carne molida de res 90/10 cocida", 80), ["alta fibra"]),
                                    ("Chili vegetariano de frijol y lenteja", ("Frijol negro cocido", 120), ("Lenteja cocida", 100), ["vegetariana", "vegana", "alta fibra"]),
                                    ("Garbanzos guisados con espinaca y huevo", ("Garbanzo cocido", 150), ("Huevo entero", 100), ["vegetariana", "alta fibra"]),
                                    ("Lentejas con pavo y zanahoria", ("Lenteja cocida", 150), ("Pechuga de pavo cocida", 80), ["alta fibra"]),
                                    ("Habas guisadas con nopales", ("Haba seca cocida", 170), ("Nopal", 120), ["vegetariana", "vegana", "alta fibra", "económica"]),
                                    ("Frijoles charros ligeros con pavo", ("Frijol pinto cocido", 170), ("Jamón de pavo", 40), ["alta fibra", "económica"])]:
        ing = [leg, prot, ("Jitomate", 100), ("Cebolla", 30), ("Chile serrano", 6), ("Aceite de oliva", 5), ("Tortilla de maíz", 30)]
        R.append(receta(nombre, "comida", 30, ing,
                        ["Acitrona cebolla, ajo y chile en 1 cucharadita de aceite.", "Agrega el jitomate picado y cocina 5 min.",
                         f"Incorpora {leg[0].split(' ')[0].lower()} y {prot[0].split(' (')[0].lower()}; cocina 10 min a fuego bajo.", "Sirve con una tortilla."],
                        ["Si usas leguminosas de lata, enjuágalas: reduces bastante sodio.", "Las leguminosas suman proteína y fibra: combínalas con cereal (tortilla, arroz).",
                         TIP_COCCION.get(prot[0])],
                        ["sin gluten", "meal prep"] + tags))

    # 12. Quesadillas y sándwiches
    for relleno, ing_r, tags in [("champiñones", [("Champiñones", 100)], ["vegetariana"]), ("flor de calabaza", [("Flor de calabaza", 70)], ["vegetariana"]),
                                 ("nopal", [("Nopal", 100)], ["vegetariana"]), ("espinaca", [("Espinaca", 60)], ["vegetariana"]),
                                 ("pollo", [("Pechuga de pollo cocida", 70)], ["alta proteína"]), ("pavo y champiñones", [("Jamón de pavo", 40), ("Champiñones", 60)], [])]:
        ing = [("Tortilla de maíz", 60), ("Queso panela", 50)] + ing_r + [("Salsa verde", 30), ("Lechuga", 30)]
        R.append(receta(f"Quesadillas de panela con {relleno}", "cena", 15, ing,
                        ["Saltea el relleno en sartén sin aceite o con aspersor.", "Rellena las tortillas con panela y el relleno.",
                         "Dóralas en comal por ambos lados hasta que el queso se suavice.", "Sirve con salsa y lechuga."],
                        ["La panela no escurre como el queso Oaxaca: dórala a fuego medio.", "Comal en lugar de freír: sin aceite añadido."],
                        ["sin gluten", "rápida"] + tags))
    for pk in ["pollo", "atun", "pavo", "huevo", "panela", "salmon"]:
        pn, pi, pg, ptag = PROT[pk]
        ing = [("Pan integral", 60), (pi, pg - 20), ("Lechuga", 30), ("Jitomate", 50), ("Aguacate", 20), ("Yogur griego natural sin grasa", 20)]
        R.append(receta(f"Sándwich integral de {pn}", "cena", 10, ing,
                        ["Tuesta ligeramente el pan.", "Mezcla el yogur con limón, sal y pimienta: será tu aderezo en lugar de mayonesa.",
                         f"Arma con {pn}, lechuga, jitomate y aguacate.", "Corta en diagonal y sirve."],
                        ["El yogur griego sustituye a la mayonesa con más proteína y menos grasa.", TIP_COCCION.get(pi)],
                        ["alta proteína", "rápida"] + ptag + (["vegetariana"] if pk in VEG_PROT else [])))

    # 13. Desayunos: omelettes
    verds = [("espinaca", "Espinaca", 50), ("champiñones", "Champiñones", 70), ("nopales", "Nopal", 80), ("calabacita", "Calabacita", 80),
             ("flor de calabaza", "Flor de calabaza", 60), ("pimiento", "Pimiento", 60), ("verdolagas", "Verdolagas", 50), ("rajas de poblano", "Chile poblano", 60)]
    for i, (vn, vi, vg) in enumerate(verds):
        q = ("panela", "Queso panela", 30) if i % 2 == 0 else ("queso cottage", "Queso cottage", 60)
        ing = [("Huevo entero", 100), ("Clara de huevo", 99), (vi, vg), (q[1], q[2]), ("Tortilla de maíz", 60), ("Salsa verde", 30)]
        R.append(receta(f"Omelette de {vn} con {q[0]}", "desayuno", 12, ing,
                        ["Bate los huevos con las claras, sal y pimienta.", f"Saltea {vn} 2–3 min en sartén antiadherente.",
                         "Vierte el huevo y cocina a fuego medio-bajo; agrega el queso antes de doblar.", "Sirve con tortillas calientes y salsa."],
                        ["Mezclar huevos enteros con claras sube la proteína y baja la grasa.", TIP_COCCION["Huevo entero"]],
                        ["alta proteína", "vegetariana", "sin gluten", "rápida"]))

    # 14. Avena
    frutas = [("plátano", "Plátano", 100), ("manzana y canela", "Manzana", 120), ("fresas", "Fresas", 120), ("frutos rojos", "Frutos rojos congelados", 100),
              ("mango", "Mango", 100), ("papaya", "Papaya", 140), ("piña", "Piña", 100)]
    extras = [("nuez", "Nuez", 10), ("crema de cacahuate", "Crema de cacahuate", 12), ("chía", "Semillas de chía", 10), ("almendras", "Almendras", 10)]
    for i, (fn, fi, fg) in enumerate(frutas):
        for en, ei, eg in (extras[i % 4], extras[(i + 2) % 4]):
            ing = [("Avena en hojuelas", 45), ("Leche descremada", 240), (fi, fg), (ei, eg), ("Proteína de suero (polvo)", 15)]
            R.append(receta(f"Avena cocida con {fn} y {en}", "desayuno", 10, ing,
                            ["Calienta la leche y agrega la avena; cocina 4–5 min moviendo.", "Retira del fuego y mezcla la proteína en polvo (fuera del fuego, para evitar grumos).",
                             f"Sirve con {fn} y {en} encima.", "Endulza con canela o vainilla si lo necesitas."],
                            ["Agrega la proteína en polvo fuera del fuego para que no se haga grumos.", "Usa avena certificada sin gluten si eres celiaco.",
                             f"{en.capitalize()} aporta grasas saludables pero es densa en calorías: mídela."],
                            ["alta proteína", "vegetariana", "alta fibra"]))

    # 15. Overnight oats y yogur
    for fn, fi, fg in frutas[:6]:
        ing = [("Avena en hojuelas", 40), ("Yogur griego natural sin grasa", 150), ("Leche descremada", 120), (fi, fg - 20), ("Semillas de chía", 8)]
        R.append(receta(f"Avena de refrigerador (overnight oats) de {fn.split(' y')[0]}", "desayuno", 5, ing,
                        ["Mezcla avena, yogur, leche y chía en un frasco.", "Refrigera mínimo 6 horas o toda la noche.", f"Por la mañana agrega {fn.split(' y')[0]} y sirve frío."],
                        ["Prepara 2–3 frascos a la vez: duran 2 días en refrigeración.", "El yogur griego aporta la mayor parte de la proteína."],
                        ["alta proteína", "vegetariana", "sin cocinar"]))
    for fn, fi, fg in frutas:
        for sn, si, sg in (("granola casera de amaranto", "Amaranto inflado", 15), ("pepitas", "Pepitas de calabaza", 10)):
            ing = [("Yogur griego natural sin grasa", 170), (fi, fg - 20), (si, sg), ("Miel", 5)]
            R.append(receta(f"Yogur griego con {fn.split(' y')[0]} y {sn}", "colacion", 5, ing,
                            ["Sirve el yogur en un tazón.", f"Agrega {fn.split(' y')[0]} picada.", f"Termina con {sn} y un hilo de miel."],
                            ["Elige yogur natural sin azúcar y endulza tú: controlas la cantidad.", "Buena colación alta en proteína antes de dormir."],
                            ["alta proteína", "vegetariana", "sin cocinar", "rápida", "sin gluten"]))

    # 16. Licuados
    for fn, fi, fg in frutas + [("guayaba", "Guayaba", 110), ("naranja", "Naranja", 140)]:
        for base_n, base_i, polvo in (("leche", "Leche descremada", "Proteína de suero (polvo)"), ("bebida de soya", "Leche de soya sin azúcar", "Proteína vegetal en polvo (chícharo)")):
            ing = [(base_i, 250), (polvo, 30), (fi, fg), ("Avena en hojuelas", 20)]
            veg = base_n != "leche"
            R.append(receta(f"Licuado de {fn.split(' y')[0]} con proteína{' vegetal' if veg else ''}", "postentreno", 5, ing,
                            [f"Licúa la {base_n} con la fruta y la avena.", "Agrega la proteína en polvo al final y licúa 10 segundos.", "Sirve frío; agrega hielo si quieres."],
                            ["Busca proteínas con certificación de terceros (Informed Sport, NSF).", "Útil si te cuesta llegar a tu proteína: no es obligatorio después de entrenar."],
                            ["alta proteína", "rápida", "sin cocinar"] + (["vegana", "vegetariana"] if veg else ["vegetariana"])))

    # 17. Hot cakes y molletes
    for fn, fi, fg in frutas[1:6]:
        ing = [("Avena en hojuelas", 40), ("Clara de huevo", 99), ("Plátano", 60), (fi, fg - 30), ("Yogur griego natural sin grasa", 60)]
        R.append(receta(f"Hot cakes de avena con {fn.split(' y')[0]}", "desayuno", 15, ing,
                        ["Licúa la avena con las claras y el plátano.", "Cocina porciones pequeñas en sartén antiadherente a fuego medio.",
                         "Voltea cuando salgan burbujas.", "Sirve con yogur y fruta."],
                        ["Sartén antiadherente o aspersor: no necesitas mantequilla.", "Usa avena certificada sin gluten si eres celiaco."],
                        ["alta proteína", "vegetariana"]))
    for top, ing_t, tags in [("pico de gallo", [("Jitomate", 60), ("Cebolla", 15)], ["vegetariana"]), ("champiñones", [("Champiñones", 70)], ["vegetariana"]),
                             ("huevo", [("Huevo entero", 50)], ["vegetariana"]), ("pavo", [("Jamón de pavo", 40)], [])]:
        ing = [("Pan integral", 60), ("Frijol negro cocido", 60), ("Queso panela", 40)] + ing_t + [("Salsa verde", 20)]
        R.append(receta(f"Molletes integrales con {top}", "desayuno", 15, ing,
                        ["Unta frijol en el pan integral.", "Agrega panela rallada y gratina en horno o sartén tapado.", f"Termina con {top} y salsa."],
                        ["Pan integral y panela en lugar de bolillo y queso amarillo: más fibra y menos grasa."], ["alta proteína"] + tags))

    # 18. Colaciones
    for nombre, ing, tags, pasos, tip in [
        ("Manzana con crema de cacahuate", [("Manzana", 180), ("Crema de cacahuate", 16)], ["vegetariana", "vegana", "sin cocinar", "rápida"], ["Corta la manzana en gajos.", "Sirve con la crema de cacahuate medida."], "Mide la crema de cacahuate: 1 cucharada son ~95 kcal."),
        ("Jícama, pepino y zanahoria con limón y chile", [("Jícama", 120), ("Pepino", 100), ("Zanahoria", 60), ("Limón", 20)], ["vegana", "vegetariana", "baja en calorías", "sin cocinar"], ["Corta las verduras en bastones.", "Agrega limón, sal y chile en polvo."], "Mucho volumen con pocas calorías: ideal si tienes hambre en déficit."),
        ("Requesón con piña", [("Requesón", 120), ("Piña", 100)], ["vegetariana", "alta proteína", "sin cocinar"], ["Sirve el requesón y agrega la piña picada."], "El requesón aporta proteína de digestión lenta."),
        ("Cottage con fresas y nuez", [("Queso cottage", 120), ("Fresas", 100), ("Nuez", 8)], ["vegetariana", "alta proteína", "sin cocinar"], ["Mezcla el cottage con fresas.", "Termina con nuez picada."], "Buena colación nocturna alta en proteína."),
        ("Galletas de arroz con crema de cacahuate y plátano", [("Galleta de arroz inflado", 18), ("Crema de cacahuate", 12), ("Plátano", 60)], ["vegetariana", "vegana", "rápida"], ["Unta la crema de cacahuate.", "Agrega rodajas de plátano."], "Buena opción 60–90 min antes de entrenar."),
        ("Palomitas naturales con almendras", [("Palomitas naturales (sin aceite)", 20), ("Almendras", 15)], ["vegana", "vegetariana", "alta fibra"], ["Prepara las palomitas en microondas sin aceite.", "Sirve con las almendras."], "Las palomitas sin mantequilla son un cereal integral con mucho volumen."),
        ("Hummus casero con bastones de verdura", [("Garbanzo cocido", 80), ("Aceite de oliva", 5), ("Limón", 15), ("Zanahoria", 60), ("Pepino", 80)], ["vegana", "vegetariana", "alta fibra"], ["Licúa el garbanzo con limón, ajo, aceite y un poco de agua.", "Sirve con bastones de zanahoria y pepino."], "Si el garbanzo es de lata, enjuágalo para bajar el sodio."),
        ("Rollitos de pavo con panela y pepino", [("Jamón de pavo", 60), ("Queso panela", 30), ("Pepino", 80)], ["alta proteína", "sin cocinar", "rápida"], ["Coloca panela y pepino sobre cada rebanada de pavo.", "Enrolla y sirve."], "Revisa el sodio del jamón de pavo en la etiqueta."),
        ("Huevos cocidos con jitomate y limón", [("Huevo entero", 100), ("Jitomate", 100), ("Limón", 10)], ["vegetariana", "alta proteína", "económica"], ["Cuece los huevos 10 min y enfríalos en agua.", "Sirve con jitomate, sal, limón y chile."], "Los huevos cocidos duran 1 semana en refrigeración con cáscara."),
        ("Atún con pepino y galletas de arroz", [("Atún en agua (escurrido)", 80), ("Pepino", 80), ("Galleta de arroz inflado", 18), ("Limón", 10)], ["alta proteína", "rápida", "económica"], ["Mezcla el atún con pepino picado, limón y pimienta.", "Sirve sobre las galletas."], "Colación alta en proteína y muy práctica para la oficina."),
        ("Garbanzos tostados con limón", [("Garbanzo cocido", 100), ("Limón", 10), ("Aceite de oliva", 3)], ["vegana", "vegetariana", "alta fibra"], ["Seca los garbanzos y mézclalos con aceite y especias.", "Hornea 25–30 min a 200 °C hasta que crujan."], "Garbanzos horneados: botana crujiente con fibra y proteína."),
        ("Naranja y almendras", [("Naranja", 160), ("Almendras", 12)], ["vegana", "vegetariana", "sin cocinar", "rápida"], ["Pela la naranja en gajos.", "Acompaña con almendras."], "Fruta entera en lugar de jugo: más fibra y saciedad."),
        ("Guayabas con requesón", [("Guayaba", 110), ("Requesón", 80)], ["vegetariana", "sin cocinar"], ["Corta las guayabas.", "Sirve con requesón y canela."], "La guayaba es de las frutas con más vitamina C."),
        ("Pepino relleno de atún", [("Pepino", 150), ("Atún en agua (escurrido)", 60), ("Yogur griego natural sin grasa", 20)], ["alta proteína", "baja en calorías", "sin cocinar"], ["Corta el pepino a lo largo y retira las semillas.", "Rellena con atún mezclado con yogur y limón."], "Colación con mucho volumen y proteína."),
    ]:
        R.append(receta(nombre, "colacion", 5, ing, pasos, [tip], tags))

    # 20. Platillos mexicanos ligeros
    for nombre, tipo, ing, pasos, tips, tags in [
        ("Pozole verde ligero de pollo", "comida", [("Caldo de pollo casero", 360), ("Maíz pozolero cocido", 150), ("Pechuga de pollo cocida", 110), ("Tomate verde", 100), ("Lechuga", 40), ("Rábano", 30), ("Pepitas de calabaza", 8)],
         ["Licúa tomate verde, chile, ajo y pepitas con un poco de caldo.", "Hierve la salsa con el resto del caldo 10 min.", "Agrega maíz pozolero y pollo deshebrado.", "Sirve con lechuga, rábano, orégano y limón."],
         ["Pollo deshebrado en lugar de cabeza de cerdo: mucha menos grasa.", "Las pepitas dan sabor y grasas saludables: mídelas."], ["alta proteína", "sin gluten"]),
        ("Pozole rojo ligero de cerdo", "comida", [("Caldo de pollo casero", 360), ("Maíz pozolero cocido", 150), ("Lomo de cerdo cocido", 100), ("Lechuga", 40), ("Rábano", 30), ("Cebolla", 15)],
         ["Usa lomo de cerdo (corte magro) cocido y deshebrado.", "Hierve el caldo con chile guajillo licuado y ajo.", "Agrega maíz y carne; cocina 10 min.", "Sirve con lechuga, rábano, cebolla y limón."],
         ["El lomo es de los cortes más magros del cerdo.", "Retira la grasa que flote al enfriar."], ["alta proteína", "sin gluten"]),
        ("Enfrijoladas de pollo", "comida", [("Tortilla de maíz", 90), ("Frijol negro cocido", 150), ("Pechuga de pollo cocida", 90), ("Queso fresco", 20), ("Cebolla", 15)],
         ["Licúa el frijol con un poco de su caldo hasta que quede espeso.", "Calienta las tortillas en comal y pásalas por la salsa de frijol.", "Rellena con pollo y dobla.", "Termina con queso fresco y cebolla."],
         ["Tortillas calentadas en comal, no fritas: misma textura con mucho menos aceite."], ["alta proteína", "sin gluten", "alta fibra"]),
        ("Enfrijoladas de huevo", "desayuno", [("Tortilla de maíz", 90), ("Frijol negro cocido", 150), ("Huevo entero", 100), ("Queso fresco", 20)],
         ["Licúa el frijol con un poco de su caldo.", "Haz huevo revuelto en sartén antiadherente.", "Pasa las tortillas por el frijol, rellena con huevo y dobla.", "Termina con queso fresco."],
         ["Frijol + tortilla + huevo: proteína completa y fibra a bajo costo."], ["vegetariana", "sin gluten", "económica", "alta fibra"]),
        ("Entomatadas de pollo", "comida", [("Tortilla de maíz", 90), ("Jitomate", 200), ("Pechuga de pollo cocida", 90), ("Queso fresco", 20), ("Cebolla", 15)],
         ["Asa el jitomate con ajo y cebolla; licúalo.", "Cocina la salsa 5 min con sal.", "Pasa las tortillas calientes por la salsa y rellena con pollo.", "Sirve con queso fresco y cebolla."],
         ["Salsa de jitomate casera: menos sodio que las de bote."], ["alta proteína", "sin gluten"]),
        ("Entomatadas de panela", "cena", [("Tortilla de maíz", 90), ("Tomate verde", 200), ("Queso panela", 70), ("Cebolla", 15)],
         ["Hierve los tomates verdes con chile y licúalos.", "Pasa las tortillas por la salsa.", "Rellena con panela y dobla.", "Sirve con cebolla."],
         ["Versión vegetariana con buena proteína gracias a la panela."], ["vegetariana", "sin gluten"]),
        ("Tinga de pollo en tostadas", "comida", [("Pechuga de pollo cocida", 110), ("Jitomate", 150), ("Cebolla", 50), ("Tostada horneada", 36), ("Lechuga", 40), ("Aguacate", 20)],
         ["Acitrona la cebolla en rodajas.", "Agrega jitomate licuado con chipotle y cocina 5 min.", "Incorpora el pollo deshebrado.", "Sirve sobre tostadas horneadas con lechuga y aguacate."],
         [TIP_COCCION["Pechuga de pollo cocida"], "Usa poco chipotle adobado: el adobo aporta sodio."], ["alta proteína", "sin gluten", "meal prep"]),
        ("Tinga de soya texturizada", "comida", [("Soya texturizada (seca)", 40), ("Jitomate", 150), ("Cebolla", 50), ("Tostada horneada", 36), ("Lechuga", 40)],
         ["Hidrata la soya 10 min en agua caliente y exprímela.", "Acitrona la cebolla y agrega jitomate con chipotle.", "Incorpora la soya y cocina 8 min.", "Sirve en tostadas con lechuga."],
         ["La soya texturizada tiene ~50 % de proteína en seco y es muy económica."], ["vegana", "vegetariana", "alta proteína", "económica"]),
        ("Picadillo de pavo con verduras", "comida", [("Carne molida de pavo 93/7 cruda", 120), ("Papa cocida", 100), ("Zanahoria", 60), ("Chícharos cocidos", 50), ("Jitomate", 100), ("Tortilla de maíz", 30)],
         ["Dora la carne molida de pavo en sartén antiadherente.", "Agrega jitomate licuado con ajo.", "Incorpora papa y zanahoria en cubos y los chícharos; cocina 10 min.", "Sirve con tortilla."],
         ["Cocina el pavo molido hasta 74 °C.", "Buen platillo para meal prep: dura 3–4 días refrigerado."], ["alta proteína", "sin gluten", "meal prep"]),
        ("Picadillo de soya con verduras", "comida", [("Soya texturizada (seca)", 40), ("Papa cocida", 100), ("Zanahoria", 60), ("Chícharos cocidos", 50), ("Jitomate", 100)],
         ["Hidrata la soya y exprímela.", "Sofríe ajo y cebolla, agrega jitomate licuado.", "Incorpora verduras y soya; cocina 10 min.", "Sirve con tortillas o arroz."],
         ["Sazona bien la soya: absorbe el sabor del caldillo."], ["vegana", "vegetariana", "alta proteína", "económica", "meal prep"]),
        ("Tilapia empapelada con verduras", "cena", [("Tilapia cocida", 140), ("Calabacita", 100), ("Jitomate", 60), ("Cebolla", 20), ("Limón", 20), ("Arroz blanco cocido", 100)],
         ["Coloca el filete sobre papel aluminio o encerado con verduras en rodajas.", "Agrega limón, ajo, sal y orégano; cierra el paquete.", "Hornea 18–20 min a 200 °C.", "Sirve con arroz."],
         ["Cocinar empapelado no requiere aceite: el vapor hace el trabajo.", TIP_COCCION["Tilapia cocida"]], ["alta proteína", "sin gluten"]),
        ("Salmón empapelado con espárragos de calabacita", "cena", [("Salmón cocido", 120), ("Calabacita", 120), ("Limón", 20), ("Papa cocida", 120)],
         ["Coloca el salmón con calabacita en tiras sobre papel.", "Agrega limón, eneldo, sal y pimienta; cierra.", "Hornea 15–18 min a 200 °C.", "Sirve con papa cocida."],
         [TIP_COCCION["Salmón cocido"]], ["alta proteína", "sin gluten", "omega-3"]),
        ("Brochetas de pollo con verduras", "comida", [("Pechuga de pollo cocida", 130), ("Pimiento", 80), ("Cebolla", 40), ("Calabacita", 80), ("Arroz blanco cocido", 120), ("Aceite de oliva", 5)],
         ["Corta pollo y verduras en cubos y marina 15 min con limón y especias.", "Ensarta alternando en palitos.", "Asa en parrilla o sartén 10–12 min volteando.", "Sirve con arroz."],
         [TIP_COCCION["Pechuga de pollo cocida"], TIP_GRASA], ["alta proteína", "sin gluten"]),
        ("Brochetas de camarón con piña", "comida", [("Camarón cocido", 130), ("Piña", 100), ("Pimiento", 80), ("Arroz blanco cocido", 120), ("Aceite de oliva", 5)],
         ["Marina el camarón con limón, ajo y chile.", "Ensarta camarón, piña y pimiento.", "Asa 2–3 min por lado.", "Sirve con arroz."],
         [TIP_COCCION["Camarón cocido"]], ["alta proteína", "sin gluten"]),
        ("Brochetas de res con champiñones", "cena", [("Bistec de res magro cocido", 120), ("Champiñones", 100), ("Cebolla", 40), ("Pimiento", 60), ("Tortilla de maíz", 60)],
         ["Corta la res en cubos y marina con limón y pimienta.", "Ensarta con champiñones, cebolla y pimiento.", "Asa a fuego alto 6–8 min.", "Sirve con tortillas."],
         [TIP_COCCION["Bistec de res magro cocido"]], ["alta proteína", "sin gluten"]),
        ("Hamburguesa de pavo en pan integral", "comida", [("Carne molida de pavo 93/7 cruda", 130), ("Pan integral", 60), ("Lechuga", 30), ("Jitomate", 50), ("Cebolla", 15), ("Aguacate", 20)],
         ["Sazona la carne y forma una torta de 2 cm.", "Cocina a la plancha hasta 74 °C en el centro.", "Tuesta el pan y arma con lechuga, jitomate, cebolla y aguacate.", "Acompaña con ensalada."],
         ["Pavo molido 93/7: menos grasa que la mayoría de la carne de res para hamburguesa.", "Pan integral en lugar de pan blanco: más fibra."], ["alta proteína"]),
        ("Hamburguesa de res sin pan con ensalada", "cena", [("Carne molida de res 90/10 cocida", 120), ("Lechuga", 80), ("Jitomate", 60), ("Pepino", 60), ("Aguacate", 30), ("Papa cocida", 120)],
         ["Forma la torta y cocínala a la plancha hasta 71 °C.", "Sirve sobre cama de lechuga con jitomate y pepino.", "Agrega aguacate.", "Acompaña con papa cocida u horneada."],
         [TIP_COCCION["Carne molida de res 90/10 cocida"]], ["alta proteína", "sin gluten"]),
        ("Hamburguesa de lenteja y avena", "comida", [("Lenteja cocida", 150), ("Avena en hojuelas", 25), ("Huevo entero", 50), ("Pan integral", 60), ("Lechuga", 30), ("Jitomate", 50)],
         ["Machaca la lenteja con avena, huevo, ajo y especias.", "Forma tortas y dóralas en sartén antiadherente.", "Arma en pan integral con lechuga y jitomate."],
         ["Si la mezcla está muy suave, agrega más avena."], ["vegetariana", "alta fibra", "económica"]),
        ("Calabacitas a la mexicana con pollo", "comida", [("Calabacita", 200), ("Elote desgranado", 60), ("Jitomate", 80), ("Pechuga de pollo cocida", 100), ("Tortilla de maíz", 60)],
         ["Sofríe cebolla y jitomate picados.", "Agrega calabacita en cubos y elote; tapa y cocina 8 min.", "Incorpora el pollo deshebrado.", "Sirve con tortillas."],
         ["Plato con mucho volumen y pocas calorías."], ["alta proteína", "sin gluten", "baja en calorías"]),
        ("Calabacitas a la mexicana con panela", "cena", [("Calabacita", 200), ("Elote desgranado", 60), ("Jitomate", 80), ("Queso panela", 70), ("Tortilla de maíz", 60)],
         ["Sofríe cebolla y jitomate.", "Agrega calabacita y elote; cocina tapado 8 min.", "Agrega la panela en cubos al final.", "Sirve con tortillas."],
         ["Agrega la panela al final para que no se deshaga."], ["vegetariana", "sin gluten"]),
        ("Poke de salmón con arroz y mango", "comida", [("Salmón cocido", 110), ("Arroz blanco cocido", 150), ("Mango", 80), ("Pepino", 80), ("Aguacate", 30), ("Limón", 15)],
         ["Usa salmón cocido y frío en cubos.", "Sirve el arroz como base.", "Agrega mango, pepino y aguacate en cubos.", "Aliña con limón y salsa de soya baja en sodio."],
         [TIP_COCCION["Salmón cocido"]], ["alta proteína", "sin gluten", "omega-3"]),
        ("Poke de atún con quinoa", "comida", [("Atún en agua (escurrido)", 100), ("Quinoa cocida", 150), ("Pepino", 80), ("Zanahoria", 40), ("Aguacate", 30), ("Limón", 15)],
         ["Escurre el atún.", "Sirve la quinoa como base.", "Agrega pepino y zanahoria en tiras y el aguacate.", "Aliña con limón."],
         [TIP_COCCION["Atún en agua (escurrido)"]], ["alta proteína", "sin gluten", "económica"]),
        ("Wraps de lechuga con pollo", "cena", [("Lechuga", 100), ("Pechuga de pollo cocida", 110), ("Zanahoria", 40), ("Pepino", 60), ("Yogur griego natural sin grasa", 30)],
         ["Usa hojas grandes de lechuga como tortilla.", "Rellena con pollo deshebrado, zanahoria y pepino.", "Agrega aderezo de yogur con limón."],
         ["Opción muy baja en calorías para la cena."], ["alta proteína", "sin gluten", "baja en calorías", "rápida"]),
        ("Wraps de lechuga con tofu salteado", "cena", [("Lechuga", 100), ("Tofu firme", 150), ("Pimiento", 60), ("Zanahoria", 40), ("Aceite de canola", 4)],
         ["Saltea el tofu en cubos con pimiento.", "Sirve en hojas de lechuga con zanahoria.", "Agrega salsa de soya baja en sodio o limón."],
         [TIP_COCCION["Tofu firme"]], ["vegana", "vegetariana", "sin gluten", "baja en calorías"]),
        ("Pudín de chía con mango", "colacion", [("Semillas de chía", 20), ("Leche de soya sin azúcar", 180), ("Mango", 80)],
         ["Mezcla la chía con la bebida de soya.", "Refrigera mínimo 4 horas.", "Sirve con mango picado."], ["La chía aporta fibra y omega-3 vegetal."], ["vegana", "vegetariana", "alta fibra", "sin cocinar"]),
        ("Pudín de chía con frutos rojos y yogur", "desayuno", [("Semillas de chía", 20), ("Leche descremada", 180), ("Frutos rojos congelados", 80), ("Yogur griego natural sin grasa", 100)],
         ["Mezcla la chía con la leche.", "Refrigera toda la noche.", "Sirve con yogur y frutos rojos."], ["Prepáralo en frascos para 2 días."], ["vegetariana", "alta fibra", "sin cocinar", "alta proteína"]),
        ("Chilaquiles horneados con huevo", "desayuno", [("Tortilla de maíz", 60), ("Salsa verde", 120), ("Huevo entero", 100), ("Queso fresco", 20), ("Cebolla", 15)],
         ["Hornea las tortillas en triángulos a 200 °C por 8–10 min.", "Calienta la salsa y mezcla los totopos.", "Sirve con huevo estrellado en sartén antiadherente.", "Termina con queso y cebolla."],
         ["Totopos horneados en lugar de fritos: mucho menos aceite."], ["vegetariana", "sin gluten"]),
        ("Chilaquiles rojos horneados con panela", "desayuno", [("Tortilla de maíz", 60), ("Jitomate", 150), ("Queso panela", 60), ("Yogur griego natural sin grasa", 30), ("Cebolla", 15)],
         ["Hornea los totopos.", "Licúa jitomate asado con chile guajillo y ajo; cocina 5 min.", "Mezcla con los totopos.", "Sirve con panela y yogur en lugar de crema."],
         ["El yogur griego sustituye la crema con más proteína."], ["vegetariana", "sin gluten"]),
        ("Nopales asados con pollo y frijoles", "comida", [("Nopal", 200), ("Pechuga de pollo cocida", 110), ("Frijol negro cocido", 100), ("Tortilla de maíz", 60), ("Salsa verde", 30)],
         ["Asa los nopales en comal hasta que cambien de color.", "Asa el pollo sazonado.", "Calienta los frijoles.", "Sirve todo con tortillas y salsa."],
         ["El nopal aporta fibra y casi no tiene calorías."], ["alta proteína", "sin gluten", "alta fibra"]),
        ("Huevos a la mexicana con frijoles", "desayuno", [("Huevo entero", 100), ("Clara de huevo", 66), ("Jitomate", 60), ("Cebolla", 15), ("Chile serrano", 6), ("Frijol negro cocido", 80), ("Tortilla de maíz", 60)],
         ["Sofríe jitomate, cebolla y chile en sartén antiadherente.", "Agrega huevos y claras batidos; revuelve hasta cocer.", "Sirve con frijoles y tortillas."],
         [TIP_COCCION["Huevo entero"]], ["vegetariana", "sin gluten", "alta proteína", "económica"]),
        ("Huevos con nopales y salsa verde", "desayuno", [("Huevo entero", 100), ("Clara de huevo", 66), ("Nopal", 120), ("Salsa verde", 40), ("Tortilla de maíz", 60)],
         ["Cuece o asa los nopales en tiras.", "Agrega el huevo batido y revuelve.", "Sirve con salsa verde y tortillas."],
         ["Nopales: volumen y fibra casi sin calorías."], ["vegetariana", "sin gluten", "alta proteína"]),
        ("Sardinas a la mexicana con tostadas", "cena", [("Sardina en salsa de jitomate (lata, escurrida)", 120), ("Cebolla", 20), ("Jitomate", 60), ("Tostada horneada", 36), ("Lechuga", 40), ("Limón", 15)],
         ["Desmenuza las sardinas.", "Mezcla con cebolla, jitomate, limón y chile.", "Sirve sobre tostadas con lechuga."],
         ["Las sardinas con espinas blandas aportan calcio y omega-3 a buen precio."], ["alta proteína", "sin gluten", "económica", "omega-3"]),
    ]:
        R.append(receta(nombre, tipo, 25, ing, pasos, tips, tags))

    # 19. Post-entreno sólidos
    for nombre, ing in [("Arroz con pollo y plátano post-entreno", [("Arroz blanco cocido", 160), ("Pechuga de pollo cocida", 110), ("Plátano", 100)]),
                        ("Camote con atún y yogur", [("Camote cocido", 180), ("Atún en agua (escurrido)", 100), ("Yogur griego natural sin grasa", 40)]),
                        ("Pan integral con huevo y fruta", [("Pan integral", 60), ("Huevo entero", 100), ("Clara de huevo", 66), ("Naranja", 140)]),
                        ("Papa con pavo y ensalada", [("Papa cocida", 200), ("Pechuga de pavo cocida", 110), ("Lechuga", 50)]),
                        ("Tortillas con frijol y huevo post-entreno", [("Tortilla de maíz", 90), ("Frijol negro cocido", 100), ("Huevo entero", 100)])]:
        R.append(receta(nombre, "postentreno", 15, ing,
                        ["Calienta los carbohidratos.", "Prepara la proteína a la plancha o cocida.", "Sirve junto; agrega verduras si es tu comida principal."],
                        ["Después de entrenar sirve una comida normal con proteína y carbohidratos; no hay ventana de 30 minutos.", TIP_COCCION.get(ing[1][0])],
                        ["alta proteína", "rápida"]))
    return R


VARIANTES = generar()
