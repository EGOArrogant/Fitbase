"""Recetas con macronutrientes calculados a partir de sus ingredientes.

Valores por 100 g aproximados (USDA FoodData Central y tablas mexicanas de composición).
Las porciones se escalan automáticamente a las calorías objetivo del usuario.
"""

# kcal, proteína, carbohidratos, grasa por 100 g
ING = {
    "Pechuga de pollo cocida": (165, 31, 0, 3.6),
    "Pechuga de pavo cocida": (135, 30, 0, 1),
    "Carne molida de res 90/10 cocida": (217, 26, 0, 12),
    "Bistec de res magro cocido": (190, 29, 0, 8),
    "Atún en agua (escurrido)": (116, 25.5, 0, 0.8),
    "Salmón cocido": (206, 22, 0, 12),
    "Tilapia cocida": (128, 26, 0, 2.7),
    "Camarón cocido": (99, 24, 0.2, 0.3),
    "Huevo entero": (143, 12.6, 0.7, 9.5),
    "Clara de huevo": (52, 10.9, 0.7, 0.2),
    "Jamón de pavo": (104, 17, 2, 3),
    "Queso panela": (230, 18, 3, 16),
    "Queso cottage": (98, 11, 3.4, 4.3),
    "Yogur griego natural sin grasa": (59, 10, 3.6, 0.4),
    "Leche descremada": (34, 3.4, 5, 0.1),
    "Proteína de suero (polvo)": (400, 80, 8, 6),
    "Tofu firme": (144, 17, 3, 9),
    "Frijol negro cocido": (132, 8.9, 23.7, 0.5),
    "Lenteja cocida": (116, 9, 20, 0.4),
    "Garbanzo cocido": (164, 8.9, 27.4, 2.6),
    "Arroz blanco cocido": (130, 2.7, 28, 0.3),
    "Arroz integral cocido": (123, 2.7, 25.6, 1),
    "Avena en hojuelas": (389, 16.9, 66, 6.9),
    "Tortilla de maíz": (218, 5.7, 44.6, 2.9),
    "Tostada horneada": (440, 8, 72, 13),
    "Pan integral": (247, 13, 41, 3.4),
    "Pasta cocida": (158, 5.8, 31, 0.9),
    "Quinoa cocida": (120, 4.4, 21.3, 1.9),
    "Papa cocida": (87, 1.9, 20, 0.1),
    "Camote cocido": (90, 2, 20.7, 0.2),
    "Elote desgranado": (86, 3.3, 19, 1.4),
    "Plátano": (89, 1.1, 22.8, 0.3),
    "Manzana": (52, 0.3, 14, 0.2),
    "Fresas": (32, 0.7, 7.7, 0.3),
    "Mango": (60, 0.8, 15, 0.4),
    "Papaya": (43, 0.5, 11, 0.3),
    "Frutos rojos congelados": (50, 0.7, 12, 0.3),
    "Aguacate": (160, 2, 8.5, 14.7),
    "Aceite de oliva": (884, 0, 0, 100),
    "Almendras": (579, 21, 22, 50),
    "Nuez": (654, 15, 14, 65),
    "Crema de cacahuate": (588, 25, 20, 50),
    "Semillas de chía": (486, 17, 42, 31),
    "Miel": (304, 0.3, 82, 0),
    "Espinaca": (23, 2.9, 3.6, 0.4),
    "Brócoli": (34, 2.8, 6.6, 0.4),
    "Jitomate": (18, 0.9, 3.9, 0.2),
    "Cebolla": (40, 1.1, 9.3, 0.1),
    "Pimiento": (31, 1, 6, 0.3),
    "Calabacita": (17, 1.2, 3.1, 0.3),
    "Nopal": (16, 1.3, 3.3, 0.1),
    "Lechuga": (15, 1.4, 2.9, 0.2),
    "Pepino": (15, 0.7, 3.6, 0.1),
    "Champiñones": (22, 3.1, 3.3, 0.3),
    "Zanahoria": (41, 0.9, 9.6, 0.2),
    "Salsa verde": (30, 1, 6, 0.5),
    "Limón": (29, 1.1, 9.3, 0.3),
}

# tipo: desayuno, comida, cena, colacion, postentreno
RECETAS = [
    dict(id="omelette-espinaca", nombre="Omelette de claras con espinaca y panela", tipo="desayuno", minutos=10,
         tags=["alta proteína", "vegetariana", "rápida"],
         ing=[("Clara de huevo", 200), ("Huevo entero", 50), ("Espinaca", 60), ("Queso panela", 40), ("Tortilla de maíz", 60), ("Salsa verde", 40)],
         pasos=["Bate las claras con el huevo y sal.", "Saltea la espinaca 1 min en sartén antiadherente.", "Agrega el huevo, el queso en cubos y cocina tapado 3–4 min.", "Sirve con tortillas calientes y salsa."]),
    dict(id="avena-proteica", nombre="Avena proteica con frutos rojos", tipo="desayuno", minutos=8,
         tags=["alta proteína", "vegetariana", "económica"],
         ing=[("Avena en hojuelas", 60), ("Leche descremada", 250), ("Proteína de suero (polvo)", 25), ("Frutos rojos congelados", 100), ("Semillas de chía", 10)],
         pasos=["Cuece la avena con la leche 3–4 min.", "Retira del fuego y mezcla la proteína (para que no se haga grumos).", "Sirve con los frutos rojos y la chía."]),
    dict(id="huevos-mexicana", nombre="Huevos a la mexicana con frijoles", tipo="desayuno", minutos=12,
         tags=["vegetariana", "económica"],
         ing=[("Huevo entero", 120), ("Clara de huevo", 100), ("Jitomate", 80), ("Cebolla", 30), ("Frijol negro cocido", 100), ("Tortilla de maíz", 60)],
         pasos=["Sofríe jitomate y cebolla picados.", "Agrega los huevos y las claras batidos y revuelve.", "Sirve con frijoles y tortillas."]),
    dict(id="yogur-granola", nombre="Bowl de yogur griego, fruta y nuez", tipo="desayuno", minutos=3,
         tags=["alta proteína", "vegetariana", "rápida", "sin cocinar"],
         ing=[("Yogur griego natural sin grasa", 250), ("Avena en hojuelas", 30), ("Fresas", 120), ("Nuez", 15), ("Miel", 10)],
         pasos=["Sirve el yogur.", "Añade la avena, las fresas picadas, la nuez y la miel."]),
    dict(id="hotcakes-avena", nombre="Hotcakes de avena y plátano", tipo="desayuno", minutos=15,
         tags=["vegetariana", "económica"],
         ing=[("Avena en hojuelas", 60), ("Plátano", 100), ("Huevo entero", 50), ("Clara de huevo", 100), ("Yogur griego natural sin grasa", 100), ("Miel", 10)],
         pasos=["Licúa avena, plátano, huevo y claras.", "Cocina porciones en sartén antiadherente 2 min por lado.", "Sirve con yogur y miel."]),
    dict(id="molletes-pavo", nombre="Molletes integrales con pavo y pico de gallo", tipo="desayuno", minutos=10,
         tags=["económica"],
         ing=[("Pan integral", 70), ("Frijol negro cocido", 80), ("Jamón de pavo", 60), ("Queso panela", 30), ("Jitomate", 60), ("Cebolla", 20)],
         pasos=["Unta los frijoles en el pan.", "Agrega pavo y panela; hornea 5 min.", "Cubre con pico de gallo."]),
    dict(id="pollo-arroz-brocoli", nombre="Pollo a la plancha con arroz y brócoli", tipo="comida", minutos=25,
         tags=["alta proteína", "económica", "meal prep"],
         ing=[("Pechuga de pollo cocida", 150), ("Arroz blanco cocido", 180), ("Brócoli", 150), ("Aceite de oliva", 8), ("Limón", 10)],
         pasos=["Sazona y cocina el pollo a la plancha 5–6 min por lado.", "Cuece el brócoli al vapor 4 min.", "Sirve con el arroz, un hilo de aceite de oliva y limón."]),
    dict(id="tacos-bistec-nopal", nombre="Tacos de bistec con nopales", tipo="comida", minutos=20,
         tags=["alta proteína"],
         ing=[("Bistec de res magro cocido", 150), ("Nopal", 150), ("Tortilla de maíz", 90), ("Cebolla", 30), ("Salsa verde", 50), ("Aguacate", 40)],
         pasos=["Asa el bistec y los nopales.", "Pica la carne y sirve en tortillas con nopales, cebolla, salsa y aguacate."]),
    dict(id="salmon-camote", nombre="Salmón con camote y ensalada", tipo="comida", minutos=30,
         tags=["omega-3"],
         ing=[("Salmón cocido", 140), ("Camote cocido", 200), ("Lechuga", 80), ("Pepino", 80), ("Aceite de oliva", 5), ("Limón", 10)],
         pasos=["Hornea el salmón 12–15 min a 200 °C.", "Cuece el camote al horno o al vapor.", "Acompaña con ensalada aliñada con aceite y limón."]),
    dict(id="bowl-atun", nombre="Bowl de atún, arroz integral y aguacate", tipo="comida", minutos=10,
         tags=["alta proteína", "rápida", "económica"],
         ing=[("Atún en agua (escurrido)", 140), ("Arroz integral cocido", 180), ("Aguacate", 50), ("Pepino", 80), ("Elote desgranado", 60), ("Limón", 10)],
         pasos=["Mezcla el atún con limón y sal.", "Sirve sobre el arroz con aguacate, pepino y elote."]),
    dict(id="pasta-pavo", nombre="Pasta con carne molida y salsa de jitomate", tipo="comida", minutos=25,
         tags=["meal prep"],
         ing=[("Pasta cocida", 200), ("Carne molida de res 90/10 cocida", 120), ("Jitomate", 150), ("Cebolla", 30), ("Champiñones", 80), ("Aceite de oliva", 5)],
         pasos=["Dora la carne con cebolla y champiñones.", "Agrega jitomate licuado y cocina 10 min.", "Mezcla con la pasta."]),
    dict(id="lentejas-guisadas", nombre="Lentejas guisadas con verduras y huevo", tipo="comida", minutos=30,
         tags=["vegetariana", "económica", "alta fibra"],
         ing=[("Lenteja cocida", 250), ("Zanahoria", 60), ("Jitomate", 80), ("Cebolla", 30), ("Huevo entero", 100), ("Arroz blanco cocido", 100)],
         pasos=["Sofríe cebolla, jitomate y zanahoria.", "Agrega las lentejas cocidas con su caldo; hierve 10 min.", "Sirve con arroz y huevo cocido."]),
    dict(id="tofu-salteado", nombre="Tofu salteado con verduras y quinoa", tipo="comida", minutos=20,
         tags=["vegetariana", "vegana"],
         ing=[("Tofu firme", 200), ("Quinoa cocida", 180), ("Pimiento", 80), ("Brócoli", 100), ("Calabacita", 80), ("Aceite de oliva", 8)],
         pasos=["Dora el tofu en cubos.", "Saltea las verduras 4–5 min.", "Sirve sobre la quinoa."]),
    dict(id="camarones-ajo", nombre="Camarones al ajo con arroz y ensalada", tipo="comida", minutos=15,
         tags=["alta proteína", "rápida"],
         ing=[("Camarón cocido", 180), ("Arroz blanco cocido", 150), ("Lechuga", 80), ("Jitomate", 80), ("Aceite de oliva", 8)],
         pasos=["Saltea los camarones con ajo y aceite 3–4 min.", "Sirve con arroz y ensalada."]),
    dict(id="pollo-mole-ligero", nombre="Tinga de pollo en tostadas", tipo="cena", minutos=25,
         tags=["alta proteína", "económica"],
         ing=[("Pechuga de pollo cocida", 120), ("Jitomate", 120), ("Cebolla", 50), ("Tostada horneada", 30), ("Lechuga", 50), ("Aguacate", 30)],
         pasos=["Deshebra el pollo.", "Guísalo con jitomate y cebolla (y chipotle al gusto).", "Sirve sobre tostadas con lechuga y aguacate."]),
    dict(id="ensalada-pollo", nombre="Ensalada completa de pollo", tipo="cena", minutos=10,
         tags=["alta proteína", "rápida", "baja en calorías"],
         ing=[("Pechuga de pollo cocida", 130), ("Lechuga", 120), ("Jitomate", 100), ("Pepino", 80), ("Aguacate", 40), ("Garbanzo cocido", 80), ("Aceite de oliva", 5)],
         pasos=["Corta las verduras.", "Agrega el pollo en tiras y los garbanzos.", "Aliña con aceite, limón y sal."]),
    dict(id="quesadillas-champi", nombre="Quesadillas de champiñón y panela", tipo="cena", minutos=10,
         tags=["vegetariana", "rápida"],
         ing=[("Tortilla de maíz", 90), ("Queso panela", 80), ("Champiñones", 120), ("Salsa verde", 40), ("Clara de huevo", 100)],
         pasos=["Saltea los champiñones.", "Rellena las tortillas con panela y champiñón; dora.", "Acompaña con claras revueltas y salsa."]),
    dict(id="tilapia-verduras", nombre="Tilapia al limón con verduras", tipo="cena", minutos=20,
         tags=["alta proteína", "baja en calorías"],
         ing=[("Tilapia cocida", 170), ("Calabacita", 120), ("Zanahoria", 60), ("Papa cocida", 150), ("Aceite de oliva", 5), ("Limón", 15)],
         pasos=["Cocina la tilapia con limón y pimienta.", "Cuece las verduras al vapor.", "Sirve con la papa."]),
    dict(id="sandwich-pavo", nombre="Sándwich integral de pavo y aguacate", tipo="cena", minutos=5,
         tags=["rápida", "sin cocinar"],
         ing=[("Pan integral", 70), ("Pechuga de pavo cocida", 90), ("Aguacate", 40), ("Lechuga", 30), ("Jitomate", 50)],
         pasos=["Arma el sándwich con todos los ingredientes."]),
    dict(id="burrito-frijol", nombre="Burrito de frijol, huevo y aguacate", tipo="cena", minutos=10,
         tags=["vegetariana", "económica"],
         ing=[("Tortilla de maíz", 90), ("Frijol negro cocido", 120), ("Huevo entero", 100), ("Aguacate", 40), ("Salsa verde", 30)],
         pasos=["Revuelve los huevos.", "Calienta los frijoles.", "Rellena las tortillas con frijol, huevo, aguacate y salsa."]),
    dict(id="licuado-post", nombre="Licuado post-entreno de plátano y proteína", tipo="postentreno", minutos=3,
         tags=["alta proteína", "rápida", "post-entreno"],
         ing=[("Leche descremada", 300), ("Proteína de suero (polvo)", 30), ("Plátano", 120), ("Avena en hojuelas", 30)],
         pasos=["Licúa todos los ingredientes con hielo."]),
    dict(id="arroz-con-leche-proteico", nombre="Arroz con leche proteico", tipo="postentreno", minutos=10,
         tags=["alta proteína", "vegetariana"],
         ing=[("Arroz blanco cocido", 150), ("Leche descremada", 200), ("Proteína de suero (polvo)", 25), ("Miel", 10)],
         pasos=["Calienta el arroz con la leche 5 min.", "Fuera del fuego, añade la proteína y la miel; canela al gusto."]),
    dict(id="cottage-fruta", nombre="Cottage con mango y almendras", tipo="colacion", minutos=3,
         tags=["alta proteína", "vegetariana", "sin cocinar"],
         ing=[("Queso cottage", 150), ("Mango", 120), ("Almendras", 12)],
         pasos=["Sirve el cottage con el mango en cubos y las almendras."]),
    dict(id="yogur-proteico", nombre="Yogur griego con proteína y chía", tipo="colacion", minutos=2,
         tags=["alta proteína", "vegetariana", "sin cocinar"],
         ing=[("Yogur griego natural sin grasa", 200), ("Proteína de suero (polvo)", 15), ("Semillas de chía", 10), ("Fresas", 80)],
         pasos=["Mezcla el yogur con la proteína.", "Agrega chía y fresas."]),
    dict(id="manzana-cacahuate", nombre="Manzana con crema de cacahuate", tipo="colacion", minutos=2,
         tags=["vegetariana", "vegana", "sin cocinar"],
         ing=[("Manzana", 180), ("Crema de cacahuate", 20)],
         pasos=["Rebana la manzana y acompaña con la crema de cacahuate."]),
    dict(id="huevo-cocido-papaya", nombre="Huevos cocidos con papaya", tipo="colacion", minutos=12,
         tags=["vegetariana", "económica"],
         ing=[("Huevo entero", 100), ("Papaya", 250)],
         pasos=["Cuece los huevos 10 min.", "Acompaña con papaya picada y limón."]),
    dict(id="rollitos-pavo", nombre="Rollitos de pavo con pepino y panela", tipo="colacion", minutos=5,
         tags=["alta proteína", "baja en calorías", "sin cocinar"],
         ing=[("Jamón de pavo", 80), ("Queso panela", 40), ("Pepino", 120)],
         pasos=["Enrolla bastones de pepino y panela en las rebanadas de pavo."]),
    dict(id="garbanzos-tostados", nombre="Garbanzos tostados con chile y limón", tipo="colacion", minutos=25,
         tags=["vegana", "económica", "alta fibra"],
         ing=[("Garbanzo cocido", 150), ("Aceite de oliva", 5), ("Limón", 10)],
         pasos=["Seca los garbanzos, mézclalos con aceite y especias.", "Hornea 20–25 min a 200 °C hasta que estén crujientes."]),
]

def _cargar_extra():
    """Recetas adicionales investigadas (data/recetas_extra.json): ingredientes con medida casera y tips."""
    import json, os
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "recetas_extra.json")
    if not os.path.exists(ruta):
        return
    try:
        with open(ruta, encoding="utf-8") as fh:
            data = json.load(fh)
    except (ValueError, OSError):
        return
    for nombre, v in data.get("ingredientes", {}).items():
        ING.setdefault(nombre, (v["kcal"], v["prot"], v["carb"], v["grasa"]))
    existentes = {r["id"] for r in RECETAS}
    for r in data.get("recetas", []):
        if r["id"] in existentes or r.get("tipo") not in ("desayuno", "comida", "cena", "colacion", "postentreno"):
            continue
        ing = [(i["nombre"], i["g"]) for i in r["ingredientes"] if i["nombre"] in ING and i.get("g")]
        if not ing:
            continue
        RECETAS.append(dict(id=r["id"], nombre=r["nombre"], tipo=r["tipo"], minutos=r.get("minutos", 15), tags=r.get("tags", []),
                            ing=ing, pasos=r.get("pasos", []), tips=r.get("tips", []),
                            medidas={i["nombre"]: i.get("medida", "") for i in r["ingredientes"]}))


_cargar_extra()


def _cargar_variantes():
    """Familias de platillos con variantes (data/recetas_variantes.py)."""
    from data.recetas_variantes import VARIANTES
    existentes = {r["id"] for r in RECETAS} | {r["nombre"].lower() for r in RECETAS}
    for r in VARIANTES:
        if r["id"] in existentes or r["nombre"].lower() in existentes:
            continue
        ing = [(i["nombre"], i["g"]) for i in r["ingredientes"] if i["nombre"] in ING]
        RECETAS.append(dict(id=r["id"], nombre=r["nombre"], tipo=r["tipo"], minutos=r["minutos"], tags=r["tags"], ing=ing,
                            pasos=r["pasos"], tips=r["tips"], medidas={i["nombre"]: i["medida"] for i in r["ingredientes"]}))
        existentes |= {r["id"], r["nombre"].lower()}


_cargar_variantes()

_TIPS = [
    (("Aceite de oliva",), "Mide el aceite con cuchara o usa aspersor: 1 cucharada son ~120 kcal y es donde más se 'escapan' calorías."),
    (("Pechuga de pollo cocida", "Pechuga de pavo cocida"), "Cocina el pollo o pavo hasta 74 °C en el centro; sin piel ahorras ~40 % de la grasa."),
    (("Frijol negro cocido", "Garbanzo cocido", "Lenteja cocida"), "Si usas leguminosas de lata, enjuágalas: reduces hasta ~40 % del sodio."),
    (("Brócoli", "Calabacita", "Espinaca", "Zanahoria", "Nopal"), "Cocina las verduras al vapor o a la plancha: no agregas grasa y conservan mejor su textura (no 'queman grasa', solo evitan calorías extra)."),
    (("Arroz blanco cocido", "Pasta cocida", "Papa cocida"), "Para meal prep, enfría rápido el arroz o la pasta y guárdalos máximo 3–4 días en refrigeración."),
    (("Proteína de suero (polvo)",), "Agrega la proteína en polvo fuera del fuego para evitar grumos."),
    (("Aguacate", "Nuez", "Almendras", "Crema de cacahuate"), "Las grasas saludables son densas en calorías: pésalas si tu objetivo es perder grasa."),
]
for _r in RECETAS:
    if not _r.get("tips"):
        nombres = {n for n, _ in _r["ing"]}
        _r["tips"] = [t for claves, t in _TIPS if nombres & set(claves)][:3]

TIPOS = {"desayuno": "Desayuno", "comida": "Comida", "cena": "Cena", "colacion": "Colación", "postentreno": "Post-entreno"}


def macros_receta(r, factor=1.0):
    k = p = c = g = 0.0
    for nombre, gramos in r["ing"]:
        kk, pp, cc, ff = ING[nombre]
        q = gramos * factor / 100
        k += kk * q; p += pp * q; c += cc * q; g += ff * q
    return {"kcal": round(k), "prot": round(p, 1), "carb": round(c, 1), "grasa": round(g, 1)}


for _r in RECETAS:
    _r["base"] = macros_receta(_r)
    _r["densidad_prot"] = round(_r["base"]["prot"] / max(_r["base"]["kcal"], 1) * 100, 1)  # g proteína / 100 kcal

POR_ID = {r["id"]: r for r in RECETAS}
