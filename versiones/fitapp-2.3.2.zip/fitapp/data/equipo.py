"""Categorías de equipo (con iconos propios en SVG de trazo) y atributos de cada ejercicio
para la selección inteligente (impacto, carga sobre la columna, suelo, equilibrio, etc.)."""
from data.ejercicios import EJERCICIOS

# nombre, icono (contenido SVG en un lienzo 24×24, trazo currentColor)
CATEGORIAS = [
    ("Barra", '<path d="M2 12h20"/><rect x="4" y="7" width="3" height="10" rx="1"/><rect x="17" y="7" width="3" height="10" rx="1"/>'),
    ("Mancuernas", '<path d="M7 12h10"/><rect x="3" y="8.5" width="4" height="7" rx="1"/><rect x="17" y="8.5" width="4" height="7" rx="1"/>'),
    ("Máquina", '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 3v18M8 14h8M12 9h4"/>'),
    ("Polea", '<circle cx="12" cy="5" r="2.5"/><path d="M12 7.5v9M8 19h8M12 16.5l-3 2.5M12 16.5l3 2.5"/>'),
    ("Kettlebell", '<path d="M9 7a3 3 0 0 1 6 0"/><path d="M8 9h8l1.5 3a6 6 0 1 1-11 0z"/>'),
    ("Peso corporal", '<circle cx="12" cy="4.5" r="2"/><path d="M12 7v7M7 10h10M12 14l-3 6M12 14l3 6"/>'),
    ("Disco", '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2"/>'),
    ("Balón medicinal", '<circle cx="12" cy="12" r="8.5"/><path d="M4 10c5 2 11 2 16 0M5 15c4 1.5 10 1.5 14 0"/>'),
    ("Banda elástica", '<path d="M3 9c4-4 8 4 12 0s6 0 6 0M3 15c4-4 8 4 12 0s6 0 6 0"/>'),
    ("TRX", '<path d="M12 2v4M12 6l-5 10M12 6l5 10"/><rect x="4.5" y="16" width="5" height="3" rx="1"/><rect x="14.5" y="16" width="5" height="3" rx="1"/>'),
    ("Bosu", '<path d="M3 17h18"/><path d="M5 17a7 7 0 0 1 14 0"/>'),
    ("Máquina Smith", '<path d="M5 3v18M19 3v18M3 21h4M17 21h4M5 10h14"/><rect x="7" y="8.5" width="2" height="3"/><rect x="15" y="8.5" width="2" height="3"/>'),
    ("Cardio", '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/><path d="M6 12h3l1.5-2 2 4 1.5-2H18"/>'),
    ("Estiramientos", '<circle cx="16" cy="4.5" r="2"/><path d="M15 7l-4 6 6 3M11 13l-6 7M4 11l7 2"/>'),
    ("Yoga", '<rect x="3" y="15" width="18" height="4" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v5M8 12h8"/>'),
    ("Pilates", '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="6"/><path d="M4 12H2M22 12h-2"/>'),
    ("Recuperación", '<rect x="3" y="9" width="18" height="6" rx="3"/><path d="M8 9v6M12 9v6M16 9v6"/>'),
]
ICONOS = dict(CATEGORIAS)
NOMBRES = [c for c, _ in CATEGORIAS]


def icono(nombre, tam=22):
    return (f'<svg viewBox="0 0 24 24" width="{tam}" height="{tam}" fill="none" stroke="currentColor" stroke-width="1.6" '
            f'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{ICONOS.get(nombre, "")}</svg>')


# Equipo típico según dónde entrena la persona
PERFILES_EQUIPO = {
    "Gimnasio completo": set(NOMBRES),
    "Casa con mancuernas": {"Mancuernas", "Peso corporal", "Banda elástica", "Cardio", "Estiramientos", "Yoga", "Pilates", "Recuperación"},
    "Solo peso corporal": {"Peso corporal", "Cardio", "Estiramientos", "Yoga", "Pilates", "Recuperación"},
}

# ---------- atributos para la selección inteligente ----------
_IMPACTO_ALTO = {"Correr", "Saltar la cuerda", "Burpees", "Lanzamiento a la pared (wall ball)"}
_AXIAL = {"Sentadilla con barra", "Sentadilla frontal", "Peso muerto", "Peso muerto sumo", "Peso muerto rumano", "Press militar con barra",
          "Remo con barra", "Encogimientos con mancuernas", "Paseo del granjero"}
_FLEXION_CARGADA = {"Crunch en polea", "Giro ruso con balón", "El cien (the hundred)", "Rueda abdominal", "Elevación de piernas colgado",
                    "Lanzamiento de balón al suelo (slam)"}
_SOBRE_CABEZA = {"Press militar con barra", "Press militar con mancuernas", "Press de hombro en máquina", "Press de hombro con kettlebell",
                 "Extensión con cuerda sobre la cabeza", "Levantamiento turco (Turkish get-up)", "Lanzamiento a la pared (wall ball)",
                 "Lanzamiento de balón al suelo (slam)", "Halo con disco", "Dominadas", "Fondos en paralelas"}
_SUPINO = {"Press de banca", "Press de banca con mancuernas", "Press cerrado en banca", "Aperturas con mancuernas", "Press francés con barra",
           "Press de banca en máquina Smith", "Puente de glúteo", "Puente de hombros (pilates)", "El cien (the hundred)", "Dead bug",
           "Curl femoral en TRX", "Respiración diafragmática"}
_PRONO = {"Curl femoral acostado", "Rodillo de espuma en cuádriceps"}
_EQUILIBRIO = {"Sentadilla búlgara", "Zancadas con mancuernas", "Zancada en máquina Smith", "Sentadilla sobre bosu",
               "Equilibrio a una pierna en bosu", "Levantamiento turco (Turkish get-up)", "Subida a escalón", "Guerrero II"}
_RODILLA_PROFUNDA = {"Sentadilla con barra", "Sentadilla frontal", "Sentadilla hack", "Sentadilla búlgara", "Zancadas con mancuernas",
                     "Sentadilla goblet", "Sentadilla goblet con kettlebell", "Zancada en máquina Smith", "Sentadilla en máquina Smith",
                     "Lanzamiento a la pared (wall ball)", "Burpees"}
_SUELO_EQUIPOS = {"Yoga", "Pilates"}
_SUELO = {"Plancha", "Plancha lateral", "Rueda abdominal", "Puente de glúteo", "Lagartijas", "Plancha sobre bosu", "Lagartija sobre bosu",
          "Plancha con pies en TRX", "Giro ruso con balón", "Rodillo de espuma en cuádriceps", "Rodillo de espuma en espalda alta",
          "Pelota de masaje en glúteo", "Respiración diafragmática", "Estiramiento de flexores de cadera", "Levantamiento turco (Turkish get-up)",
          "Burpees"}
_GUIADO = {"Máquina", "Máquina Smith", "Polea"}  # trayectoria guiada o estable: más fácil de aprender


def atributos(nombre):
    e = EJERCICIOS[nombre]
    return {
        "impacto_alto": nombre in _IMPACTO_ALTO,
        "carga_axial": nombre in _AXIAL,
        "flexion_cargada": nombre in _FLEXION_CARGADA,
        "sobre_cabeza": nombre in _SOBRE_CABEZA,
        "supino": nombre in _SUPINO,
        "prono": nombre in _PRONO,
        "equilibrio": nombre in _EQUILIBRIO,
        "rodilla_profunda": nombre in _RODILLA_PROFUNDA,
        "suelo": nombre in _SUELO or e["equipo"] in _SUELO_EQUIPOS,
        "guiado": e["equipo"] in _GUIADO,
        "tecnica_compleja": nombre in {"Peso muerto", "Sentadilla con barra", "Sentadilla frontal", "Levantamiento turco (Turkish get-up)",
                                       "Clean con kettlebell", "Swing con kettlebell", "Dominadas", "Fondos en paralelas", "Remo con barra"},
    }


ATRIBUTOS = {n: atributos(n) for n in EJERCICIOS}
