"""Asigna a cada ejercicio un patrón de movimiento animado en 3D (static/js/visor3d.js) y el accesorio que se muestra."""
from data.ejercicios import EJERCICIOS

REGLAS = [  # (palabras en el nombre, patrón, accesorio fijo o None para deducirlo del equipo)
    (("Remo ergómetro", "Escaladora", "Natación", "agua", "Elíptica", "Burpees", "Saltar"), None, None),
    (("Caminata en caminadora", "Caminata inclinada", "Correr", "Caminata de enfriamiento"), "caminar", ""),
    (("Bicicleta", "Intervalos en bicicleta"), "bicicleta", ""),
    (("Sentadilla frontal",), "sentadilla_frontal", "barra"),
    (("goblet", "Sentadilla con disco"), "sentadilla_frontal", "goblet"),
    (("Sentadilla a la silla", "Sentadilla sobre bosu", "Sentadilla asistida"), "sentadilla_frontal", ""),
    (("Sentadilla con barra", "Sentadilla en máquina Smith", "Sentadilla hack"), "sentadilla", "barra"),
    (("búlgara", "Zancada", "Subida a escalón"), "zancada", None),
    (("Swing",), "swing", "kettlebell"),
    (("Peso muerto rumano", "Hiperextensiones"), "bisagra", None),
    (("Peso muerto",), "peso_muerto", None),
    (("Hip thrust", "Puente de glúteo", "Puente de hombros"), "hip_thrust", None),
    (("Aperturas con mancuernas",), "aperturas", "mancuernas"),
    (("Press de banca", "Press inclinado", "Press cerrado", "Press de pecho en máquina"), "press_banca", None),
    (("Lagartija",), "lagartija", ""),
    (("Press militar", "Press de hombro"), "press_vertical", None),
    (("Dominadas",), "dominada", ""),
    (("Jalón",), "jalon", ""),
    (("Remo con barra", "Remo con mancuerna", "Remo con kettlebell", "Remo con banda"), "remo", None),
    (("Curl con", "Curl martillo", "Curl inclinado", "Curl en polea", "Curl predicador"), "curl", None),
    (("Extensión de tríceps en polea", "Extensión de tríceps con banda"), "extension_triceps", ""),
    (("Elevaciones laterales", "Elevación lateral"), "elevacion_lateral", None),
    (("Elevaciones frontales", "Elevación frontal"), "elevacion_frontal", None),
    (("Elevación de talones",), "talones", ""),
    (("Plancha",), "plancha", ""),
]
PROP_EQUIPO = {"Barra": "barra", "Mancuernas": "mancuernas", "Kettlebell": "kettlebell", "Máquina Smith": "smith", "Disco": "goblet"}


def animacion(nombre):
    e = EJERCICIOS.get(nombre)
    if not e:
        return None
    for claves, patron, prop in REGLAS:
        if any(k.lower() in nombre.lower() for k in claves):
            if not patron:
                return None
            if prop is None:
                prop = PROP_EQUIPO.get(e["equipo"], "")
            return {"patron": patron, "prop": prop}
    return None


CON_ANIMACION = {n: a for n in EJERCICIOS if (a := animacion(n))}
