"""Cumplimiento legal (México): consentimientos con constancia, datos del responsable, solicitudes ARCO.

Marco considerado (verificar siempre con un abogado antes de operar comercialmente):
- Ley Federal de Protección de Datos Personales en Posesión de los Particulares (DOF 20/03/2025; abrogó la de 2010).
  Los datos de salud son datos personales sensibles: requieren consentimiento EXPRESO Y POR ESCRITO
  (firma autógrafa, electrónica o cualquier mecanismo de autenticación). La autoridad es la Secretaría
  Anticorrupción y Buen Gobierno (antes INAI).
- Código de Comercio (arts. 89 y ss.): validez de los mensajes de datos y del consentimiento por medios electrónicos;
  NOM-151-SCFI-2016 para su conservación.
- Ley Federal de Protección al Consumidor (contratos de adhesión, art. 90: cláusulas abusivas no surten efecto).
- Código Civil Federal art. 2106: la responsabilidad por dolo no es renunciable; art. 2117: la responsabilidad
  civil puede regularse por convenio salvo disposición legal.
- Ley General de Salud: orientación alimentaria y nutricional; los suplementos (art. 215 fr. V) no son medicamentos.
"""
import datetime as dt
import hashlib
import json
import os
import secrets

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(BASE, "legal.json")
VERSION = "2026.11"            # al cambiar el contenido de los documentos, sube la versión: todos vuelven a aceptar
VIGENCIA = "23 de noviembre de 2026"

CAMPOS = [("razon_social", "Nombre o razón social del responsable", "[NOMBRE O RAZÓN SOCIAL]"),
          ("nombre_comercial", "Nombre comercial", "FitBase"),
          ("rfc", "RFC", "[RFC]"),
          ("domicilio", "Domicilio para oír y recibir notificaciones", "[CALLE, NÚMERO, COLONIA, CIUDAD, ESTADO, C.P.]"),
          ("correo_privacidad", "Correo del departamento de datos personales", "[correo de privacidad]"),
          ("telefono", "Teléfono de contacto", "[teléfono]"),
          ("sitio", "Sitio web", "[sitio web]"),
          ("ciudad", "Ciudad cuyos tribunales serán competentes", "[CIUDAD, ESTADO]"),
          ("encargado", "Persona o área responsable de datos personales", "Departamento de Datos Personales")]

# (tipo, título corto, obligatorio para usar la plataforma, texto que se acepta)
CONSENTIMIENTOS = [
    ("terminos", "Términos y condiciones", True,
     "Leí y acepto los Términos y Condiciones de uso y el Aviso de Privacidad Integral."),
    ("datos_salud", "Datos de salud (sensibles)", True,
     "Otorgo mi consentimiento expreso para que se traten mis datos personales sensibles de salud (peso, medidas, "
     "composición corporal, cuestionario de salud PAR-Q+, condiciones médicas, alergias, alimentación, entrenamiento, "
     "sueño y fotografías que yo decida subir) con la finalidad de calcular, personalizar y dar seguimiento a mi plan."),
    ("actividad_fisica", "Consentimiento informado de actividad física", True,
     "Entiendo que el ejercicio y los cambios de alimentación implican riesgos (lesiones, mareos, eventos cardiovasculares). "
     "Declaro que la información de salud que proporciono es verdadera, que consultaré a un médico si el cuestionario PAR-Q+ "
     "lo indica o si tengo síntomas, y que la plataforma ofrece información educativa que no sustituye la valoración médica."),
    ("compartir_coach", "Compartir mis datos con mi entrenador", False,
     "Autorizo que mi entrenador vinculado vea y use mis datos, incluidos los de salud, para asesorarme. Puedo desvincularlo y "
     "revocar esta autorización en cualquier momento."),
    ("ia", "Inteligencia artificial", False,
     "Autorizo que el texto de mis preguntas al Coach IA y las fotos de comida que yo envíe se procesen con el servicio de "
     "inteligencia artificial de Anthropic (Estados Unidos) solo para responderme. No se usan para entrenar modelos de IA."),
    ("mercadotecnia", "Novedades y promociones", False,
     "Acepto recibir novedades, promociones y encuestas de satisfacción (finalidad secundaria; puedo negarme sin afectar el servicio)."),
]
OBLIGATORIOS = [c[0] for c in CONSENTIMIENTOS if c[2]]
POR_TIPO = {c[0]: c for c in CONSENTIMIENTOS}
ARCO_TIPOS = [("acceso", "Acceso: conocer qué datos míos tienen"), ("rectificacion", "Rectificación: corregir datos inexactos"),
              ("cancelacion", "Cancelación: eliminar mis datos"), ("oposicion", "Oposición: que dejen de usar mis datos para un fin"),
              ("revocacion", "Revocar mi consentimiento"), ("limitacion", "Limitar el uso o divulgación de mis datos")]
ESTADOS_ARCO = {"recibida": "Recibida", "proceso": "En proceso", "respondida": "Respondida", "improcedente": "Improcedente"}

# Días inhábiles fijos/móviles comunes (art. 74 LFT) para calcular plazos en días hábiles
def _inhabiles(anio):
    def lunes(mes, n):
        d = dt.date(anio, mes, 1)
        d += dt.timedelta(days=(7 - d.weekday()) % 7)
        return d + dt.timedelta(weeks=n - 1)
    return {dt.date(anio, 1, 1), lunes(2, 1), lunes(3, 3), dt.date(anio, 5, 1), dt.date(anio, 9, 16), lunes(11, 3), dt.date(anio, 12, 25)}


def sumar_habiles(fecha, dias):
    d, n = fecha, 0
    while n < dias:
        d += dt.timedelta(days=1)
        if d.weekday() < 5 and d not in _inhabiles(d.year):
            n += 1
    return d


def leer_config():
    try:
        with open(CONFIG, encoding="utf-8") as fh:
            c = json.load(fh)
    except (OSError, ValueError):
        c = {}
    return {k: (c.get(k) or "").strip() for k, _, _ in CAMPOS}


def datos():
    """Datos del responsable para los documentos, con marcadores visibles donde falte información."""
    c = leer_config()
    out = {k: c[k] or defecto for k, _, defecto in CAMPOS}
    out["faltan"] = [t for k, t, _ in CAMPOS if not c[k] and k not in ("nombre_comercial", "encargado")]
    out["version"], out["vigencia"] = VERSION, VIGENCIA
    return out


def guardar_config(form):
    c = {k: (form.get(k) or "").strip()[:300] for k, _, _ in CAMPOS}
    tmp = CONFIG + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(c, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, CONFIG)


def huella(tipo):
    texto = POR_TIPO[tipo][3] if tipo in POR_TIPO else tipo
    return hashlib.sha256(f"{VERSION}|{texto}".encode()).hexdigest()[:24]


def registrar(con, uid, tipo, otorgado, request=None, version=VERSION, detalle=None):
    """Guarda una constancia (nunca se borra ni se edita: cada cambio es un registro nuevo)."""
    ip = ua = None
    if request is not None:
        ip = (request.headers.get("X-Forwarded-For") or request.remote_addr or "")[:64]
        ua = (request.headers.get("User-Agent") or "")[:300]
    con.execute("INSERT INTO consentimientos (usuario_id, tipo, otorgado, version, huella, ip, agente, detalle, creado) VALUES (?,?,?,?,?,?,?,?,?)",
                (uid, tipo, 1 if otorgado else 0, version, huella(tipo), ip, ua, json.dumps(detalle, ensure_ascii=False) if detalle else None,
                 dt.datetime.now().isoformat(timespec="seconds")))


def estado(con, uid):
    """Último registro de cada tipo: {tipo: {otorgado, version, creado}}."""
    out = {}
    for r in con.execute("SELECT * FROM consentimientos WHERE usuario_id=? ORDER BY id", (uid,)).fetchall():
        out[r["tipo"]] = {"otorgado": bool(r["otorgado"]), "version": r["version"], "creado": r["creado"]}
    return out


def pendientes(con, uid):
    e = estado(con, uid)
    return [t for t in OBLIGATORIOS if not (e.get(t, {}).get("otorgado") and e[t]["version"] == VERSION)]


def permitido(con, uid, tipo):
    return bool(estado(con, uid).get(tipo, {}).get("otorgado"))


def nueva_solicitud(con, uid, nombre, email, tipo, descripcion):
    folio = "ARCO-" + dt.date.today().strftime("%y%m") + "-" + "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(5))
    hoy = dt.date.today()
    con.execute("INSERT INTO solicitudes_arco (folio, usuario_id, nombre, email, tipo, descripcion, estado, creado, vence) VALUES (?,?,?,?,?,?,?,?,?)",
                (folio, uid, nombre[:120], email[:160], tipo, descripcion[:3000], "recibida", dt.datetime.now().isoformat(timespec="seconds"),
                 str(sumar_habiles(hoy, 20))))
    return folio
