"""Suplementación basada en evidencia con dosis personalizadas.

Reglas generales:
- Primero la comida: un suplemento solo complementa una alimentación adecuada.
- Menores de 18 años: no se recomiendan suplementos ergogénicos (creatina, cafeína, beta-alanina, bicarbonato);
  solo lo que indique su pediatra o nutriólogo.
- Embarazo y lactancia: solo lo que indique su médico.
- En México los suplementos alimenticios (Ley General de Salud, art. 215 fr. V) no pueden presentarse como
  tratamiento ni cura; COFEPRIS regula su etiquetado y publicidad.

Fuentes principales:
- ISSN: creatina (Kreider 2017), cafeína (Guest 2021), beta-alanina (Trexler 2015), bicarbonato (Grgic 2021),
  proteína (Jäger 2017).
- Consenso del COI sobre suplementos (Maughan 2018) y marco ABCD del Australian Institute of Sport.
- EFSA: cafeína (2015, hasta 400 mg/día en adultos y 200 mg/día en embarazo), vitamina D (2023, límite 100 µg/día),
  EPA y DHA (2012, hasta 5 g/día).
- Health Canada: cafeína en adolescentes (2.5 mg/kg/día).
"""

DEPORTES = [("fuerza", "Fuerza, gimnasio o culturismo"), ("intermitente", "Alta intensidad: CrossFit, HIIT, combate o equipo"),
            ("resistencia", "Resistencia: correr, ciclismo, natación o triatlón"), ("salud", "Salud y bienestar general")]
PREGUNTAS = [
    ("renal", "¿Tienes enfermedad de los riñones o te han dicho que tu función renal está baja?"),
    ("corazon", "¿Tienes arritmias, alguna enfermedad del corazón o te han dicho que evites estimulantes?"),
    ("ansiedad", "¿Sufres ansiedad, ataques de pánico o insomnio frecuente?"),
    ("anticoagulantes", "¿Tomas anticoagulantes o antiagregantes (warfarina, clopidogrel, aspirina diaria)?"),
    ("lactancia", "¿Estás en periodo de lactancia?"),
    ("medicamentos", "¿Tomas algún medicamento de forma diaria (antidepresivos, para la presión, tiroides, etc.)?"),
    ("pescado", "¿Comes pescado graso (salmón, sardina, atún) 2 o más veces por semana?"),
    ("sol", "¿Te da el sol en brazos y cara al menos 15 minutos casi todos los días?"),
    ("competidor", "¿Compites en un deporte con control antidopaje?"),
]


def _r(x, paso=0.5):
    return round(round(x / paso) * paso, 1)


def contexto(p, extra=None, prot_media=None, prot_meta=None):
    """Junta lo que necesitan las reglas: datos del perfil + respuestas del cuestionario de suplementación."""
    sc = dict(p.get("supl_ctx") or {})
    if extra:
        sc.update(extra)
    av = p.get("avanzado") or {}
    dep = sc.get("deporte")
    if not dep:
        d = (av.get("disciplina") or "").lower()
        dep = ("resistencia" if "resistencia" in d else "intermitente" if any(k in d for k in ("crossfit", "combate", "equipo")) else
               "fuerza" if d else "fuerza" if p.get("objetivo") in ("Ganar músculo", "Recomposición") else "salud")
    cond = set(p.get("condiciones") or [])
    return {"peso": float(p.get("peso") or 70), "edad": int(p.get("edad") or 30), "sexo": p.get("sexo", "Hombre"),
            "embarazo": "embarazo" in cond, "hipertension": "hipertension" in cond, "diabetes": "diabetes" in cond,
            "deporte": dep, "objetivo": p.get("objetivo"), "dieta": (p.get("dieta_tipo") or "omnivora"),
            "alergias": set(p.get("alergias") or []), "si": {k for k, _ in PREGUNTAS if sc.get(k) == "si"},
            "hora": sc.get("hora") or "", "prot_media": prot_media, "prot_meta": prot_meta}


# Cada suplemento: (clave, nombre, nivel, para qué sirve, función dosis(ctx) -> dict, función bloqueos(ctx) -> lista, avisos(ctx) -> lista, fuente)
def _creatina(c):
    m = 5 if c["peso"] >= 90 else 3 if c["peso"] < 60 else _r(0.04 * c["peso"], 0.5)
    m = min(5, max(3, m))
    return {"dosis": f"{m:g} g al día", "detalle": f"Opcional para saturar más rápido: {_r(0.3 * c['peso'], 1):g} g al día repartidos en 4 tomas durante 5-7 días y después {m:g} g diarios.",
            "momento": "Cualquier hora, todos los días (también los de descanso), de preferencia con una comida.", "cantidad": m, "unidad": "g"}


def _cafeina(c):
    base = 3 * c["peso"]
    tope = 400 if c["edad"] >= 18 else 2.5 * c["peso"]
    d = min(base, 400, tope)
    return {"dosis": f"{_r(d, 10):g} mg ({_r(d / c['peso'], 0.5):g} mg/kg)",
            "detalle": f"Empieza con {_r(2 * c['peso'], 10):g} mg para ver cómo la toleras. El rango con evidencia es de 3 a 6 mg/kg; más no suele ser mejor. Cuenta el café, el té y las bebidas energéticas: el total del día no debe pasar de 400 mg.",
            "momento": "30 a 60 minutos antes de entrenar; evita tomarla en las 6 horas previas a dormir.", "cantidad": _r(d, 10), "unidad": "mg"}


def _proteina(c):
    porcion = _r(0.35 * c["peso"], 5)
    porcion = max(20, min(40, porcion))
    falta = None
    if c.get("prot_meta") and c.get("prot_media"):
        falta = c["prot_meta"] - c["prot_media"]
    txt = (f"Te faltan en promedio {falta:.0f} g de proteína al día: 1 porción de {porcion:g} g los cubre en gran parte." if falta and falta > 15 else
           "Hoy cubres tu proteína con comida: no la necesitas, úsala solo por practicidad." if falta is not None else
           "Úsala solo si no llegas a tu meta de proteína con comida.")
    tipo = "vegetal (chícharo/arroz)" if c["dieta"] == "vegana" or "lacteos" in c["alergias"] else "de suero (whey) o vegetal"
    return {"dosis": f"{porcion:g} g por toma ({tipo})", "detalle": txt + " Meta diaria con evidencia: 1.6 a 2.2 g/kg repartidos en 3-5 comidas.",
            "momento": "Después de entrenar o en la comida donde te falte proteína.", "cantidad": porcion, "unidad": "g"}


def _beta(c):
    d = min(6.4, max(3.2, _r(0.065 * c["peso"], 0.4)))
    return {"dosis": f"{d:g} g al día", "detalle": f"Divididos en tomas de 0.8 a 1.6 g con comida, durante al menos 4 semanas (el efecto depende de acumular carnosina, no de tomarla antes). Puede dar hormigueo en la piel: es inofensivo.",
            "momento": "Repartida a lo largo del día con alimentos.", "cantidad": d, "unidad": "g"}


def _bicarb(c):
    d = _r(0.3 * c["peso"], 1)
    return {"dosis": f"{_r(0.2 * c['peso'], 1):g}-{d:g} g (0.2-0.3 g/kg)", "detalle": "Útil en esfuerzos máximos de 1 a 7 minutos. Pruébalo primero en entrenamiento: puede causar molestias estomacales; tomarlo con una comida con carbohidratos o en cápsulas ayuda.",
            "momento": "60 a 180 minutos antes del esfuerzo.", "cantidad": d, "unidad": "g"}


def _nitrato(c):
    return {"dosis": "6-8 mmol de nitrato (≈ 70-140 mL de jugo concentrado de betabel o 500 mL de jugo normal)",
            "detalle": "Mejora la eficiencia en resistencia y esfuerzos intermitentes, sobre todo en personas no élite. No uses enjuague bucal antiséptico ese día (reduce el efecto). La orina rosada es normal.",
            "momento": "2 a 3 horas antes de entrenar o competir.", "cantidad": 7, "unidad": "mmol"}


def _vitd(c):
    d = 2000 if not ("sol" in c["si"]) else 1000
    return {"dosis": f"{d} UI ({d // 40} µg) al día", "detalle": "Idealmente con un análisis de 25(OH)D antes: si sale bajo, tu médico ajustará la dosis. No pases de 4,000 UI al día sin indicación médica (límite seguro en adultos).",
            "momento": "Con la comida más grande del día (necesita grasa para absorberse).", "cantidad": d, "unidad": "UI"}


def _omega3(c):
    fuente = "aceite de algas" if c["dieta"] == "vegana" or "pescado" in c["alergias"] else "aceite de pescado o de algas"
    return {"dosis": "1-2 g de EPA + DHA al día", "detalle": f"Usa {fuente}. Fíjate en los mg de EPA + DHA, no en los mg de aceite. Comer pescado graso 2 veces por semana cubre lo básico.",
            "momento": "Con comida.", "cantidad": 1.5, "unidad": "g"}


def _b12(c):
    return {"dosis": "50 µg al día o 2,000 µg una vez por semana", "detalle": "Imprescindible en dieta vegana: la B12 casi no existe en alimentos de origen vegetal.",
            "momento": "Cualquier hora.", "cantidad": 50, "unidad": "µg"}


def _carbo(c):
    return {"dosis": "30-60 g de carbohidratos por hora (hasta 90 g/h en esfuerzos de más de 2.5 h)",
            "detalle": "En sesiones de más de 60-90 minutos. Geles, bebida deportiva, plátano o dátiles. Entrena el estómago antes de competir.",
            "momento": "Durante el ejercicio, cada 15-20 minutos.", "cantidad": 45, "unidad": "g/h"}


def _electrolitos(c):
    return {"dosis": "300-600 mg de sodio por hora de ejercicio", "detalle": "En sesiones largas, con calor o si sudas mucho (manchas blancas de sal en la ropa). Pésate antes y después: perder más del 2 % del peso indica que debes beber más.",
            "momento": "Durante el ejercicio, con agua.", "cantidad": 450, "unidad": "mg/h"}


SUPLEMENTOS = [
    ("creatina", "Creatina monohidratada", "A", "Más fuerza, potencia y masa muscular; también ayuda en adultos mayores y en la recuperación.",
     _creatina, lambda c: (["Enfermedad renal: solo con autorización de tu nefrólogo."] if "renal" in c["si"] else []),
     lambda c: ["Puede subir 1-2 kg tu peso por agua dentro del músculo: no es grasa."] + (["Compites con antidopaje: elige un producto con certificación (Informed Sport o NSF Certified for Sport)."] if "competidor" in c["si"] else []),
     "ISSN 2017 · AIS grupo A", ("fuerza", "intermitente", "resistencia", "salud")),
    ("cafeina", "Cafeína", "A", "Mejora el rendimiento en casi todos los deportes y retrasa la sensación de cansancio.",
     _cafeina, lambda c: (["Enfermedad del corazón o arritmias."] if "corazon" in c["si"] else []) + (["Ansiedad o insomnio."] if "ansiedad" in c["si"] else []) + (["Presión alta: consulta a tu médico antes."] if c["hipertension"] else []),
     lambda c: ["Si la usas a diario, el cuerpo se acostumbra: resérvala para sesiones clave."] + (["Interactúa con algunos antidepresivos y medicamentos para la tiroides: consulta a tu médico."] if "medicamentos" in c["si"] else []),
     "ISSN 2021 · EFSA 2015", ("fuerza", "intermitente", "resistencia")),
    ("proteina", "Proteína en polvo", "A", "Ayuda a llegar a tu meta diaria de proteína cuando con comida no alcanzas.",
     _proteina, lambda c: (["Enfermedad renal: tu médico debe indicar tu proteína diaria."] if "renal" in c["si"] else []),
     lambda c: (["Tienes alergia a lácteos: usa proteína vegetal y revisa la etiqueta."] if "lacteos" in c["alergias"] else []) + (["Tienes alergia a la soya: evita mezclas con soya."] if "soya" in c["alergias"] else []),
     "ISSN 2017 · COI 2018", ("fuerza", "intermitente", "resistencia", "salud")),
    ("beta_alanina", "Beta-alanina", "A", "Retrasa la fatiga en esfuerzos intensos de 1 a 10 minutos.",
     _beta, lambda c: [], lambda c: [], "ISSN 2015 · AIS grupo A", ("intermitente",)),
    ("bicarbonato", "Bicarbonato de sodio", "A", "Amortigua la acidez muscular en esfuerzos máximos de 1 a 7 minutos.",
     _bicarb, lambda c: (["Presión alta: aporta mucho sodio."] if c["hipertension"] else []) + (["Enfermedad renal."] if "renal" in c["si"] else []),
     lambda c: ["Aporta mucho sodio y puede causar diarrea: pruébalo antes de una competencia."], "ISSN 2021 · AIS grupo A", ("intermitente",)),
    ("nitrato", "Nitrato (jugo de betabel)", "A", "Hace más eficiente el uso de oxígeno en resistencia y esfuerzos intermitentes.",
     _nitrato, lambda c: [], lambda c: (["Si tomas medicamentos con nitratos o para la disfunción eréctil (sildenafil), consulta a tu médico: puede bajar la presión."] if "medicamentos" in c["si"] or c["hipertension"] else []),
     "COI 2018 · AIS grupo A", ("resistencia", "intermitente")),
    ("carbohidratos", "Carbohidratos durante el ejercicio", "A", "Mantienen la energía en sesiones de más de 60-90 minutos.",
     _carbo, lambda c: [], lambda c: (["Tienes diabetes: ajusta con tu médico según tu glucosa."] if c["diabetes"] else []), "COI 2018 · AIS grupo A", ("resistencia",)),
    ("electrolitos", "Electrolitos (sodio)", "A", "Reponen el sodio que pierdes al sudar en sesiones largas o con calor.",
     _electrolitos, lambda c: [], lambda c: (["Presión alta: consulta a tu médico sobre la cantidad de sodio."] if c["hipertension"] else []), "COI 2018 · AIS grupo A", ("resistencia", "intermitente")),
    ("vitamina_d", "Vitamina D", "B", "Para huesos, músculo y defensas, solo si tienes poca exposición al sol o deficiencia comprobada.",
     _vitd, lambda c: (["Enfermedad renal: solo con indicación médica."] if "renal" in c["si"] else []),
     lambda c: ["Lo ideal es medir tu nivel en sangre antes de suplementar."], "EFSA 2023 · COI 2018", ("fuerza", "intermitente", "resistencia", "salud")),
    ("omega3", "Omega-3 (EPA + DHA)", "B", "Salud cardiovascular; puede ayudar a la recuperación y al ánimo.",
     _omega3, lambda c: [], lambda c: (["Tomas anticoagulantes: consulta a tu médico antes (dosis altas pueden aumentar el sangrado)."] if "anticoagulantes" in c["si"] else []),
     "EFSA 2012 · COI 2018", ("fuerza", "intermitente", "resistencia", "salud")),
    ("b12", "Vitamina B12", "A", "Indispensable si eres vegano/a: previene anemia y daño nervioso.",
     _b12, lambda c: [], lambda c: [], "Academia de Nutrición y Dietética 2016", ("fuerza", "intermitente", "resistencia", "salud")),
]
NO_RECOMENDADOS = [
    ("BCAA (aminoácidos ramificados)", "Si comes suficiente proteína no aportan nada extra."),
    ("Quemadores de grasa / termogénicos", "Poca evidencia y riesgo cardiovascular; algunos contienen sustancias prohibidas por COFEPRIS (como efedrina o yohimbina)."),
    ("«Potenciadores de testosterona» (tribulus, etc.)", "No suben la testosterona de forma relevante en personas sanas; riesgo de contaminación con esteroides."),
    ("Glutamina para ganar músculo", "No mejora la fuerza ni la masa muscular en personas sanas."),
    ("CLA, cetonas de frambuesa, garcinia", "Sin efecto real sobre la grasa corporal."),
    ("Suplementos «milagro» que prometen curar o adelgazar sin esfuerzo", "En México no pueden anunciarse como tratamiento; COFEPRIS emite alertas frecuentes sobre ellos."),
]


def recomendar(ctx, supl_plan=None):
    """Devuelve (recomendados, no_para_ti, bloqueo_general). Cada recomendado trae dosis personalizada."""
    supl_plan = supl_plan or {}
    if ctx["edad"] < 18:
        return [], [], ("menor", "Eres menor de 18 años: no recomendamos suplementos para rendimiento (creatina, cafeína, beta-alanina, "
                                 "bicarbonato). Tu prioridad es comer suficiente, dormir y entrenar bien. Si un pediatra o nutriólogo te indica "
                                 "algún suplemento (por ejemplo vitamina D o B12), síguelo con la autorización de tu madre, padre o tutor.")
    if ctx["embarazo"] or "lactancia" in ctx["si"]:
        return [], [], ("embarazo", "En embarazo o lactancia solo debes tomar los suplementos que indique tu médico (por ejemplo ácido fólico, hierro, "
                                    "vitamina D o DHA). Limita la cafeína total a 200 mg al día. No uses creatina, beta-alanina ni bicarbonato.")
    recs, no = [], []
    for clave, nombre, nivel, para, fdosis, fbloq, favisos, fuente, deportes in SUPLEMENTOS:
        bloqueos = fbloq(ctx)
        relevante = ctx["deporte"] in deportes or clave in ("proteina", "vitamina_d", "omega3")
        if clave == "b12":
            relevante = ctx["dieta"] == "vegana"
        if clave == "omega3" and "pescado" in ctx["si"]:
            relevante = False
        if clave == "vitamina_d" and "sol" in ctx["si"] and ctx["edad"] < 60:
            relevante = False
        item = {"clave": clave, "nombre": nombre, "nivel": nivel, "para": para, "fuente": fuente, "en_plan": clave in supl_plan}
        if bloqueos:
            item["motivos"] = bloqueos
            no.append(item)
            continue
        if not relevante:
            continue
        item.update(fdosis(ctx))
        item["avisos"] = favisos(ctx)
        if ctx["edad"] >= 60 and clave in ("creatina", "proteina", "vitamina_d"):
            item["avisos"] = item["avisos"] + ["A partir de los 60 años es especialmente útil para conservar músculo y hueso."]
        recs.append(item)
    orden = {"A": 0, "B": 1}
    recs.sort(key=lambda x: (not x["en_plan"], orden.get(x["nivel"], 2)))
    return recs, no, None
