"""Mapa corporal en SVG (hombre/mujer, frente/espalda) a partir del dibujo base.

El dibujo original (PNG) se vectorizó: cada zona gris es un músculo seleccionable (data-musculo) y las
líneas blancas se conservan como trazo. La versión femenina ajusta las proporciones del mismo dibujo.
Datos en data/cuerpo_svg.json (generados con scripts/vectorizar_cuerpo.py).
"""
import json
import os

_RUTA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "cuerpo_svg.json")
with open(_RUTA, encoding="utf-8") as _f:
    _DATOS = json.load(_f)

# Músculos que no tienen zona propia en el dibujo (se eligen desde los botones)
SIN_ZONA = ["deltoide_lat", "aductores"]


def body_svg(sexo="Hombre", vista="frente", holo=False):
    sexo = "Mujer" if sexo == "Mujer" else "Hombre"
    vista = "espalda" if vista == "espalda" else "frente"
    d = _DATOS[sexo][vista]
    p = [f'<path class="silueta" d="{d["silueta"]}"></path>', '<g class="musculos">']
    for mid, ruta in d["zonas"]:
        if mid:
            p.append(f'<path class="musculo" data-musculo="{mid}" d="{ruta}" tabindex="0" role="button" aria-label="{mid}"></path>')
        else:
            p.append(f'<path class="neutro" d="{ruta}"></path>')
    p.append(f'</g><path class="lineas" d="{d["lineas"]}" fill-rule="evenodd"></path>')
    titulo = f"Cuerpo {'femenino' if sexo == 'Mujer' else 'masculino'}, vista de {vista}"
    vb = " ".join(str(x) for x in d["vb"])
    return f'<svg viewBox="{vb}" class="bodymap" role="img" aria-label="{titulo}">' + "".join(p) + "</svg>"
