"""Generador de PDF para todo lo que el cliente descarga (ReportLab + tipografía DejaVu incluida).

Uso: generar(titulo, bloques, subtitulo) -> bytes
Bloques (tuplas):
  ("h", texto)                       subtítulo de sección
  ("p", texto)                       párrafo (admite <b> e <i>)
  ("nota", texto)                    texto pequeño gris
  ("lista", [textos])                viñetas
  ("kv", [(etiqueta, valor), ...])   tabla de dos columnas
  ("tabla", encabezados, filas[, anchos_relativos])
  ("metricas", [(etiqueta, valor, unidad), ...])   tarjetas grandes en una fila
  ("aviso", texto)                   recuadro destacado
  ("grafica", "linea"|"barras", titulo, etiquetas, [(nombre, valores, color), ...])
  ("dona", titulo, [(etiqueta, valor, color), ...], texto_centro)
  ("progreso", etiqueta, valor, meta, unidad)   barra de avance contra una meta
  ("salto",)                         salto de página
"""
import datetime as dt
import io
import os
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (KeepTogether, ListFlowable, ListItem, PageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

_FUENTES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "fonts")
try:
    pdfmetrics.registerFont(TTFont("DV", os.path.join(_FUENTES, "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DVB", os.path.join(_FUENTES, "DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFontFamily("DV", normal="DV", bold="DVB", italic="DV", boldItalic="DVB")
    F, FB = "DV", "DVB"
except Exception:  # si faltara la tipografía, Helvetica (sin algunos símbolos)
    F, FB = "Helvetica", "Helvetica-Bold"

ACENTO = colors.HexColor("#6048D0")
ACENTO2 = colors.HexColor("#9B6BDB")
TINTA = colors.HexColor("#1D1A25")
GRIS = colors.HexColor("#5B5766")
LINEA = colors.HexColor("#E4E0EE")
SUAVE = colors.HexColor("#F5F3FB")
CEBRA = colors.HexColor("#FAF9FD")
AVISO = colors.HexColor("#FFF6DB")
# colores de categoría (los mismos de la app)
PALETA = [colors.HexColor(c) for c in ("#6048D0", "#2563EB", "#11804F", "#B45F06", "#C8401F", "#B8327A", "#0E7C8B")]

S = {
    "h": ParagraphStyle("h", fontName=FB, fontSize=12.5, leading=16, textColor=TINTA),
    "p": ParagraphStyle("p", fontName=F, fontSize=9.8, leading=14.5, textColor=TINTA, spaceAfter=5),
    "nota": ParagraphStyle("nota", fontName=F, fontSize=7.8, leading=11, textColor=GRIS, spaceAfter=4),
    "celda": ParagraphStyle("celda", fontName=F, fontSize=8.8, leading=11.5, textColor=TINTA),
    "celdab": ParagraphStyle("celdab", fontName=FB, fontSize=8.8, leading=11.5, textColor=TINTA),
    "cab": ParagraphStyle("cab", fontName=FB, fontSize=8.2, leading=10.5, textColor=colors.white),
    "met_v": ParagraphStyle("met_v", fontName=FB, fontSize=17, leading=21, textColor=TINTA),
    "met_l": ParagraphStyle("met_l", fontName=FB, fontSize=7.2, leading=9, textColor=GRIS),
    "met_u": ParagraphStyle("met_u", fontName=F, fontSize=7.8, leading=10, textColor=GRIS),
}


def _t(x):
    """Texto seguro para Paragraph: escapa todo salvo <b>, <i> y <br/> que ponemos nosotros."""
    s = escape("" if x is None else str(x))
    for tag in ("b", "i"):
        s = s.replace(f"&lt;{tag}&gt;", f"<{tag}>").replace(f"&lt;/{tag}&gt;", f"</{tag}>")
    return s.replace("&lt;br/&gt;", "<br/>")


def _tabla(enc, filas, anchos, total):
    data = []
    if enc:
        data.append([Paragraph(_t(c), S["cab"]) for c in enc])
    for f in filas:
        data.append([Paragraph(_t(c), S["celda"]) for c in f])
    n = len(data[0]) if data else 1
    anchos = anchos or [1] * n
    suma = float(sum(anchos))
    t = Table(data, colWidths=[total * a / suma for a in anchos], repeatRows=1 if enc else 0)
    estilo = [("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
              ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7), ("LINEBELOW", (0, 0), (-1, -1), 0.3, LINEA)]
    ini = 1 if enc else 0
    for i in range(ini, len(data)):
        if (i - ini) % 2 == 1:
            estilo.append(("BACKGROUND", (0, i), (-1, i), CEBRA))
    if enc:
        estilo += [("BACKGROUND", (0, 0), (-1, 0), ACENTO), ("ROUNDEDCORNERS", [5, 5, 0, 0])]
    t.setStyle(TableStyle(estilo))
    return t


def _seccion(texto, i, ancho):
    """Título de sección con barra de color de la marca."""
    col = PALETA[i % len(PALETA)]
    t = Table([["", Paragraph(_t(texto), S["h"])]], colWidths=[4, ancho - 4])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, 0), col), ("LEFTPADDING", (1, 0), (1, 0), 9), ("TOPPADDING", (0, 0), (-1, -1), 3),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 3), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    return KeepTogether([Spacer(1, 10), t, Spacer(1, 6)])


def _grafica(b, ancho):
    """("grafica", "linea"|"barras", titulo, etiquetas, [(nombre, valores, color_hex|None), ...])"""
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    from reportlab.graphics.charts.linecharts import HorizontalLineChart
    from reportlab.graphics.shapes import Drawing, String
    _, tipo, titulo, etiquetas, series = b[:5]
    series = [(n, [v if v is not None else None for v in vals], c) for n, vals, c in series if any(v is not None for v in vals)]
    if not series or not etiquetas:
        return None
    alto = 170
    d = Drawing(ancho, alto)
    ch = VerticalBarChart() if tipo == "barras" else HorizontalLineChart()
    ch.x, ch.y, ch.width, ch.height = 34, 30, ancho - 50, alto - 62
    datos = []
    for _n, vals, _c in series:
        if tipo == "barras":
            datos.append([v or 0 for v in vals])
        else:  # rellena huecos con el valor anterior para que la línea sea continua
            ult, fila = next((v for v in vals if v is not None), 0), []
            for v in vals:
                ult = v if v is not None else ult
                fila.append(ult)
            datos.append(fila)
    ch.data = datos
    todos = [v for fila in datos for v in fila if v is not None]
    lo, hi = min(todos), max(todos)
    marg = (hi - lo) * .12 or (abs(hi) * .05 or 1)
    ch.valueAxis.valueMin = 0 if tipo == "barras" else lo - marg
    ch.valueAxis.valueMax = hi + marg
    ch.valueAxis.labels.fontName, ch.valueAxis.labels.fontSize = F, 7
    ch.valueAxis.labels.fillColor = GRIS
    ch.valueAxis.strokeColor = LINEA
    ch.valueAxis.gridStrokeColor = LINEA
    ch.valueAxis.visibleGrid = 1
    ch.categoryAxis.categoryNames = [str(e) for e in etiquetas]
    ch.categoryAxis.labels.fontName, ch.categoryAxis.labels.fontSize = F, 6.5
    ch.categoryAxis.labels.fillColor = GRIS
    ch.categoryAxis.strokeColor = LINEA
    paso = max(1, len(etiquetas) // 10)
    ch.categoryAxis.categoryNames = [str(e) if i % paso == 0 else "" for i, e in enumerate(etiquetas)]
    for i, (_n, _v, c) in enumerate(series):
        col = colors.HexColor(c) if c else PALETA[i % len(PALETA)]
        if tipo == "barras":
            ch.bars[i].fillColor = col
            ch.bars[i].strokeColor = None
        else:
            ch.lines[i].strokeColor = col
            ch.lines[i].strokeWidth = 2.2 if i == 0 else 1.4
    if tipo == "barras":
        ch.barSpacing, ch.groupSpacing = 1, 4
    d.add(ch)
    d.add(String(0, alto - 12, titulo, fontName=FB, fontSize=9.5, fillColor=TINTA))
    x = ancho
    for i, (n, _v, c) in enumerate(reversed(series)):
        col = colors.HexColor(c) if c else PALETA[(len(series) - 1 - i) % len(PALETA)]
        x -= 8 + 5.2 * len(n)
        from reportlab.graphics.shapes import Rect
        d.add(Rect(x - 10, alto - 12, 7, 7, fillColor=col, strokeColor=None))
        d.add(String(x, alto - 11.5, n, fontName=F, fontSize=7.5, fillColor=GRIS))
        x -= 14
    return d


def _dona(b, ancho):
    """("dona", titulo, [(etiqueta, valor, color_hex|None), ...], texto_centro)"""
    from reportlab.graphics.charts.doughnut import Doughnut
    from reportlab.graphics.shapes import Drawing, Rect, String
    _, titulo, partes = b[:3]
    centro = b[3] if len(b) > 3 else ""
    partes = [(e, v, c) for e, v, c in partes if v]
    if not partes:
        return None
    alto = 150
    d = Drawing(ancho, alto)
    dn = Doughnut()
    dn.x, dn.y, dn.width, dn.height = 10, 10, 118, 118
    dn.data = [v for _e, v, _c in partes]
    dn.labels = None
    dn.innerRadiusFraction = .62
    dn.strokeColor = colors.white
    dn.strokeWidth = 2
    dn.slices.strokeColor = colors.white
    dn.slices.strokeWidth = 2
    for i, (_e, _v, c) in enumerate(partes):
        dn.slices[i].fillColor = colors.HexColor(c) if c else PALETA[i % len(PALETA)]
    d.add(dn)
    if centro:
        d.add(String(69, 66, centro, fontName=FB, fontSize=11, fillColor=TINTA, textAnchor="middle"))
    d.add(String(150, alto - 16, titulo, fontName=FB, fontSize=10, fillColor=TINTA))
    total = sum(v for _e, v, _c in partes) or 1
    for i, (e, v, c) in enumerate(partes):
        y = alto - 40 - i * 20
        d.add(Rect(150, y, 10, 10, fillColor=colors.HexColor(c) if c else PALETA[i % len(PALETA)], strokeColor=None))
        d.add(String(166, y + 1, f"{e}: {v:,.0f} ({v / total * 100:.0f} %)", fontName=F, fontSize=9, fillColor=TINTA))
    return d


def _barra_meta(b, ancho):
    """("progreso", etiqueta, valor, meta, unidad)"""
    from reportlab.graphics.shapes import Drawing, Rect, String
    _, etq, val, meta, uni = b[:5]
    d = Drawing(ancho, 26)
    pct = 0 if not meta else max(0, min(1.25, (val or 0) / meta))
    col = colors.HexColor("#11804F") if .9 <= pct <= 1.1 else (colors.HexColor("#B45F06") if pct < .9 else colors.HexColor("#C8401F"))
    d.add(String(0, 16, etq, fontName=FB, fontSize=8.5, fillColor=TINTA))
    d.add(String(ancho, 16, f"{(val or 0):,.0f} / {meta:,.0f} {uni} ({pct * 100:.0f} %)", fontName=F, fontSize=8.5, fillColor=GRIS, textAnchor="end"))
    d.add(Rect(0, 2, ancho, 8, rx=4, ry=4, fillColor=SUAVE, strokeColor=None))
    d.add(Rect(0, 2, ancho * min(pct, 1) / 1, 8, rx=4, ry=4, fillColor=col, strokeColor=None))
    return d


def _canvas_numerado(app, titulo):
    """Canvas que escribe «Página X de Y» y el encabezado/pie con la marca en cada hoja."""
    from reportlab.pdfgen import canvas as _cv

    class C(_cv.Canvas):
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self._paginas = []

        def showPage(self):
            self._paginas.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._paginas)
            for st in self._paginas:
                self.__dict__.update(st)
                self._decorar(total)
                super().showPage()
            super().save()

        def _decorar(self, total):
            W, H = letter
            m = 16 * mm
            n = self._pageNumber
            self.saveState()
            if n == 1:   # portada: banda con degradado de la marca
                alto = 46 * mm
                pasos = 40
                for i in range(pasos):
                    f = i / (pasos - 1)
                    r1, g1, b1 = 0x60 / 255, 0x48 / 255, 0xD0 / 255
                    r2, g2, b2 = 0x9B / 255, 0x6B / 255, 0xDB / 255
                    self.setFillColorRGB(r1 + (r2 - r1) * f, g1 + (g2 - g1) * f, b1 + (b2 - b1) * f)
                    self.rect(W * i / pasos, H - alto, W / pasos + 1, alto, stroke=0, fill=1)
                self.setFillColorRGB(1, 1, 1, alpha=0.08)
                self.circle(W - 40 * mm, H - 6 * mm, 30 * mm, stroke=0, fill=1)
                self.circle(W - 12 * mm, H - 38 * mm, 18 * mm, stroke=0, fill=1)
                self.setFillColor(colors.white)
                self.roundRect(m, H - 17 * mm, 9 * mm, 9 * mm, 2.4 * mm, stroke=0, fill=1)
                self.setFillColor(ACENTO)
                self.setFont(FB, 15)
                self.drawCentredString(m + 4.5 * mm, H - 14.6 * mm, app[:1])
                self.setFillColor(colors.white)
                self.setFont(FB, 13)
                self.drawString(m + 12 * mm, H - 14.2 * mm, app)
                self.setFont(F, 8.5)
                self.drawRightString(W - m, H - 14.2 * mm, dt.date.today().strftime("%d/%m/%Y"))
                self.setFont(FB, 21)
                self.drawString(m, H - 31 * mm, titulo[:58])
                if getattr(self, "_subtitulo", ""):
                    self.setFont(F, 10)
                    self.drawString(m, H - 38.5 * mm, self._subtitulo[:110])
            else:        # páginas siguientes: barra delgada
                self.setFillColor(ACENTO)
                self.rect(0, H - 11 * mm, W, 11 * mm, stroke=0, fill=1)
                self.setFillColor(colors.white)
                self.setFont(FB, 10)
                self.drawString(m, H - 7 * mm, app)
                self.setFont(F, 8.5)
                self.drawRightString(W - m, H - 7 * mm, titulo[:80])
            self.setStrokeColor(LINEA)
            self.setLineWidth(.6)
            self.line(m, 14 * mm, W - m, 14 * mm)
            self.setFillColor(GRIS)
            self.setFont(F, 7)
            self.drawString(m, 9.5 * mm, "Información educativa: no sustituye la valoración de un médico ni de un nutriólogo con cédula profesional.")
            self.setFont(FB, 7.5)
            self.drawRightString(W - m, 9.5 * mm, f"Página {n} de {total}")
            self.restoreState()
    return C


def generar(titulo, bloques, subtitulo="", app="FitBase"):
    buf = io.BytesIO()
    margen = 16 * mm
    doc = SimpleDocTemplate(buf, pagesize=letter, leftMargin=margen, rightMargin=margen, topMargin=17 * mm,
                            bottomMargin=20 * mm, title=titulo, author=app, subject=subtitulo or titulo, creator=app)
    ancho = letter[0] - 2 * margen
    Canvas = _canvas_numerado(app, titulo)

    def _inicio(c, d):
        c._subtitulo = subtitulo

    story = [Spacer(1, 36 * mm)]   # espacio para la portada
    seccion = 0
    for b in bloques:
        k = b[0]
        if k in ("kv", "lista") and not b[1]:
            continue
        if k == "tabla" and not b[2]:
            continue
        if k == "h":
            story.append(_seccion(b[1], seccion, ancho))
            seccion += 1
        elif k == "p":
            story.append(Paragraph(_t(b[1]), S["p"]))
        elif k == "nota":
            story.append(Paragraph(_t(b[1]), S["nota"]))
        elif k == "lista":
            story.append(ListFlowable([ListItem(Paragraph(_t(x), S["p"]), leftIndent=12, value="circle") for x in b[1]],
                                      bulletType="bullet", start="●", leftIndent=14, bulletFontName=F, bulletFontSize=6, bulletColor=ACENTO))
        elif k == "kv":
            filas = [[Paragraph(_t(a), S["celda"]), Paragraph(_t(v), S["celdab"])] for a, v in b[1]]
            t = Table(filas, colWidths=[ancho * 0.58, ancho * 0.42])
            est = [("LINEBELOW", (0, 0), (-1, -1), 0.3, LINEA), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                   ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7), ("ALIGN", (1, 0), (1, -1), "RIGHT")]
            est += [("BACKGROUND", (0, i), (-1, i), CEBRA) for i in range(0, len(filas), 2)]
            t.setStyle(TableStyle(est))
            story.append(t)
        elif k == "tabla":
            story.append(_tabla(b[1], b[2], b[3] if len(b) > 3 else None, ancho))
            story.append(Spacer(1, 6))
        elif k == "metricas":
            n = len(b[1])
            w = ancho / n
            celdas = []
            for i, (l, v, u) in enumerate(b[1]):
                inner = Table([[Paragraph(_t(str(l)).upper(), S["met_l"])], [Paragraph(_t(v), S["met_v"])], [Paragraph(_t(u or " "), S["met_u"])]],
                              colWidths=[w - 14])
                inner.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("TOPPADDING", (0, 0), (-1, -1), 1), ("BOTTOMPADDING", (0, 0), (-1, -1), 1)]))
                celdas.append(inner)
            t = Table([celdas], colWidths=[w] * n)
            est = [("TOPPADDING", (0, 0), (-1, -1), 9), ("BOTTOMPADDING", (0, 0), (-1, -1), 9), ("LEFTPADDING", (0, 0), (-1, -1), 10),
                   ("BACKGROUND", (0, 0), (-1, -1), SUAVE), ("LINEAFTER", (0, 0), (-2, -1), 3, colors.white)]
            est += [("LINEABOVE", (i, 0), (i, 0), 3, PALETA[i % len(PALETA)]) for i in range(n)]
            t.setStyle(TableStyle(est))
            story.append(KeepTogether([t, Spacer(1, 10)]))
        elif k == "aviso":
            t = Table([["!", Paragraph(_t(b[1]), S["p"])]], colWidths=[18, ancho - 18])
            t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), AVISO), ("LINEBEFORE", (0, 0), (0, 0), 3, colors.HexColor("#E8A33D")),
                                   ("FONTNAME", (0, 0), (0, 0), FB), ("TEXTCOLOR", (0, 0), (0, 0), colors.HexColor("#9A6400")),
                                   ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                                   ("LEFTPADDING", (0, 0), (-1, -1), 7), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
            story += [Spacer(1, 4), t, Spacer(1, 6)]
        elif k == "grafica":
            g = _grafica(b, ancho)
            if g:
                story += [Spacer(1, 4), g, Spacer(1, 8)]
        elif k == "dona":
            g = _dona(b, ancho)
            if g:
                story += [Spacer(1, 4), g, Spacer(1, 6)]
        elif k == "progreso":
            story += [_barra_meta(b, ancho), Spacer(1, 4)]
        elif k == "salto":
            story.append(PageBreak())
    doc.build(story, onFirstPage=_inicio, onLaterPages=_inicio, canvasmaker=Canvas)
    return buf.getvalue()


def nombre_archivo(texto):
    import re
    import unicodedata
    s = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode().lower()
    return (re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "documento")[:60] + ".pdf"
