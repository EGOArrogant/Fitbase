"""Base de alimentos: valores por 100 g, porciones caseras en gramos y equivalente SMAE.

Lee data/alimentos_a.json y data/alimentos_b.json (formato documentado en LEEME.md) y
completa con los ingredientes de las recetas que no estén en esos archivos.
"""
import json
import os
import unicodedata

from data.recetas import ING

BASE = os.path.dirname(os.path.abspath(__file__))


def _norm(s):
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()


def _cargar():
    lista = []
    for f in ("alimentos_a.json", "alimentos_b.json", "alimentos_c.json"):
        p = os.path.join(BASE, "data", f)
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as fh:
                    lista.extend(json.load(fh))
            except (ValueError, OSError):
                pass
    vistos = {_norm(a["nombre"]) for a in lista}
    for nombre, (k, p_, c, g) in ING.items():
        if _norm(nombre) not in vistos:
            lista.append({"nombre": nombre, "categoria": "Ingredientes de recetas", "smae": None,
                          "por100g": {"kcal": k, "prot": p_, "carb": c, "grasa": g, "fibra": None},
                          "porciones": [], "eq_smae_g": None, "fuente": "USDA (referencia)"})
    for i, a in enumerate(lista):
        a["id"] = i
        a["clave"] = _norm(a["nombre"])
        a.setdefault("porciones", [])
        a["porciones"] = [x for x in a["porciones"] if x.get("g")]
        if a.get("eq_smae_g") and a.get("smae"):
            a["porciones"].append({"desc": f"1 equivalente SMAE ({a['smae']})", "g": a["eq_smae_g"]})
        a["porciones"].append({"desc": "100 g", "g": 100})
    lista.sort(key=lambda a: (a.get("categoria", ""), a["nombre"]))
    return lista


ALIMENTOS = _cargar()
POR_ID = {a["id"]: a for a in ALIMENTOS}
CATEGORIAS = sorted({a.get("categoria", "Otros") for a in ALIMENTOS})


def macros(a, gramos):
    f = gramos / 100
    v = a["por100g"]
    return {"kcal": round((v.get("kcal") or 0) * f), "prot": round((v.get("prot") or 0) * f, 1),
            "carb": round((v.get("carb") or 0) * f, 1), "grasa": round((v.get("grasa") or 0) * f, 1)}


def buscar(q="", categoria=""):
    qn = _norm(q.strip())
    return [a for a in ALIMENTOS if (not categoria or a.get("categoria") == categoria) and (not qn or qn in a["clave"])]


def para_js():
    """Datos compactos para el buscador del diario."""
    return [{"id": a["id"], "n": a["nombre"], "c": a.get("categoria", ""), "v": a["por100g"],
             "p": [[x["desc"], x["g"]] for x in a["porciones"]]} for a in ALIMENTOS]
