"""Pagos de planes: tarjeta y OXXO con Stripe Checkout (página segura de Stripe) y transferencia/depósito SPEI manual.

Seguridad: los datos de la tarjeta NUNCA pasan por este servidor. Se capturan en la página de Stripe (certificada PCI DSS)
y aquí solo guardamos el folio, el estado y el identificador de la sesión de pago.
"""
import hashlib
import hmac
import json
import os
import re
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
import datetime as dt

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(BASE, "pagos.json")
STRIPE = "https://api.stripe.com/v1"
OXXO_MAX = 10000_00   # Stripe: un pago OXXO va de $10 a $10,000 MXN
OXXO_MIN = 10_00

# ------------------------------------------------------------------ catálogo (MXN, IVA incluido, en centavos)
CATALOGO = {
    "pro": {"nombre": "Pro", "tipo": "pro", "clientes": None, "mensual": 99_00, "anual": 799_00,
            "resumen": "Automatización y análisis para ti"},
    "coach15": {"nombre": "Coach 15", "tipo": "coach", "clientes": 15, "mensual": 349_00, "anual": 3490_00,
                "resumen": "Hasta 15 clientes · ellos reciben Pro incluido"},
    "coach40": {"nombre": "Coach 40", "tipo": "coach", "clientes": 40, "mensual": 699_00, "anual": 6990_00,
                "resumen": "Hasta 40 clientes · ellos reciben Pro incluido"},
    "coach100": {"nombre": "Coach 100", "tipo": "coach", "clientes": 100, "mensual": 1290_00, "anual": 12900_00,
                 "resumen": "Hasta 100 clientes · equipos y estudios"},
}
DIAS_PERIODO = {"mensual": 30, "anual": 365}
COACH_GRATIS = 3          # el entrenador sin plan pagado puede tener hasta 3 clientes
METODOS = {"tarjeta": "Tarjeta de crédito o débito", "oxxo": "Efectivo en OXXO", "transferencia": "Transferencia o depósito (SPEI)"}
ESTADOS = {"pendiente": "Pendiente de pago", "oxxo": "Ficha OXXO generada: paga en tienda", "revision": "En revisión (comprobante enviado)",
           "pagado": "Pagado", "cancelado": "Cancelado", "rechazado": "Rechazado", "vencido": "Vencido"}
REGIMENES = ["601 General de Ley Personas Morales", "603 Personas Morales con Fines no Lucrativos", "605 Sueldos y Salarios",
             "606 Arrendamiento", "612 Personas Físicas con Actividades Empresariales y Profesionales", "616 Sin obligaciones fiscales",
             "621 Incorporación Fiscal", "626 Régimen Simplificado de Confianza"]
USOS_CFDI = ["G03 Gastos en general", "D01 Honorarios médicos, dentales y gastos hospitalarios", "S01 Sin efectos fiscales"]
RFC_OK = re.compile(r"^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$")
CLABE_OK = re.compile(r"^\d{18}$")


def precio(clave, periodo):
    p = CATALOGO.get(clave)
    return p and p.get(periodo)


def pesos(centavos):
    return f"${centavos / 100:,.0f}" if centavos % 100 == 0 else f"${centavos / 100:,.2f}"


def ahorro_anual(clave):
    p = CATALOGO[clave]
    return round(100 - p["anual"] / (p["mensual"] * 12) * 100)


# ------------------------------------------------------------------ configuración local (archivo protegido)
def leer_config():
    try:
        with open(CONFIG, encoding="utf-8") as fh:
            c = json.load(fh)
    except (OSError, ValueError):
        c = {}
    c.setdefault("transferencia", {})
    c.setdefault("cobro_activo", False)
    return c


def guardar_config(c):
    tmp = CONFIG + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(c, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, CONFIG)


def stripe_clave(cfg=None):
    return os.environ.get("STRIPE_SECRET_KEY") or (cfg or leer_config()).get("stripe_secret") or ""


def stripe_modo(cfg=None):
    k = stripe_clave(cfg)
    if not k:
        return None
    return "prueba" if k.startswith(("sk_test_", "rk_test_")) else "real"


def transferencia_lista(cfg=None):
    t = (cfg or leer_config()).get("transferencia", {})
    return bool(CLABE_OK.match(t.get("clabe", "")) and t.get("beneficiario"))


def metodos_disponibles(monto, cfg=None):
    cfg = cfg or leer_config()
    out = {}
    if stripe_clave(cfg):
        out["tarjeta"] = True
        out["oxxo"] = OXXO_MIN <= monto <= OXXO_MAX and not cfg.get("sin_oxxo")
    if transferencia_lista(cfg):
        out["transferencia"] = True
    return {k: v for k, v in out.items() if v}


# ------------------------------------------------------------------ Stripe (API REST, sin SDK)
class ErrorPago(Exception):
    pass


def _aplanar(d, prefijo=""):
    """{'a': {'b': [1, 2]}} -> a[b][0]=1&a[b][1]=2 (formato de Stripe)."""
    out = []
    if isinstance(d, dict):
        for k, v in d.items():
            out += _aplanar(v, f"{prefijo}[{k}]" if prefijo else k)
    elif isinstance(d, (list, tuple)):
        for i, v in enumerate(d):
            out += _aplanar(v, f"{prefijo}[{i}]")
    elif d is not None:
        out.append((prefijo, "true" if d is True else "false" if d is False else str(d)))
    return out


def _stripe(metodo, ruta, datos=None, clave=None, idem=None):
    clave = clave or stripe_clave()
    if not clave:
        raise ErrorPago("Los pagos con tarjeta y OXXO aún no están configurados.")
    cuerpo = urllib.parse.urlencode(_aplanar(datos or {})).encode() if datos else None
    req = urllib.request.Request(STRIPE + ruta, data=cuerpo, method=metodo)
    req.add_header("Authorization", "Bearer " + clave)
    req.add_header("Stripe-Version", "2024-06-20")
    if idem:
        req.add_header("Idempotency-Key", idem)
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("error", {}).get("message") or str(e)
        except ValueError:
            msg = str(e)
        raise ErrorPago(f"Stripe respondió: {msg}")
    except (urllib.error.URLError, OSError) as e:
        raise ErrorPago(f"No se pudo conectar con Stripe ({getattr(e, 'reason', e)}). Revisa tu conexión a internet.")


def crear_checkout(pedido, url_exito, url_cancelar):
    """Crea la página de pago de Stripe y devuelve (id, url). El cliente captura su tarjeta allá, no aquí."""
    plan = CATALOGO[pedido["plan"]]
    metodos = ["oxxo"] if pedido["metodo"] == "oxxo" else ["card"]
    datos = {
        "mode": "payment", "locale": "es-419", "client_reference_id": pedido["folio"], "customer_email": pedido["email"],
        "success_url": url_exito, "cancel_url": url_cancelar, "payment_method_types": metodos,
        "line_items": [{"quantity": 1, "price_data": {"currency": "mxn", "unit_amount": pedido["monto"], "product_data": {
            "name": f"{plan['nombre']} · {'1 año' if pedido['periodo'] == 'anual' else '1 mes'}",
            "description": plan["resumen"]}}}],
        "metadata": {"folio": pedido["folio"], "plan": pedido["plan"], "periodo": pedido["periodo"], "usuario_id": pedido["usuario_id"]},
        "payment_intent_data": {"description": f"Folio {pedido['folio']}", "metadata": {"folio": pedido["folio"]}},
        "expires_at": int(time.time()) + 23 * 3600,
    }
    if pedido["metodo"] == "oxxo":
        datos["payment_method_options"] = {"oxxo": {"expires_after_days": 3}}
    elif pedido["periodo"] == "anual":
        datos["payment_method_options"] = {"card": {"installments": {"enabled": True}}}   # meses sin intereses (tarjetas de México)
    try:
        s = _stripe("POST", "/checkout/sessions", datos, idem="cs-" + pedido["folio"])
    except ErrorPago:
        if "payment_method_options" not in datos or pedido["metodo"] == "oxxo":
            raise
        datos.pop("payment_method_options")   # la cuenta no tiene meses sin intereses: se cobra de contado
        s = _stripe("POST", "/checkout/sessions", datos, idem="cs2-" + pedido["folio"])
    return s["id"], s["url"]


def consultar_checkout(sesion_id):
    """Estado de la sesión de Stripe → 'pagado' | 'oxxo' | 'pendiente' | 'vencido'."""
    s = _stripe("GET", "/checkout/sessions/" + urllib.parse.quote(sesion_id) + "?expand[]=payment_intent")
    return estado_de_sesion(s), s


def estado_de_sesion(s):
    if s.get("payment_status") in ("paid", "no_payment_required"):
        return "pagado"
    if s.get("status") == "expired":
        return "vencido"
    if s.get("status") == "complete":   # ficha OXXO generada, falta pagar en tienda
        return "oxxo"
    pi = s.get("payment_intent")
    if isinstance(pi, dict) and pi.get("status") == "canceled":
        return "vencido"
    return "pendiente"


def ficha_oxxo(s):
    pi = s.get("payment_intent")
    if isinstance(pi, dict):
        d = (pi.get("next_action") or {}).get("oxxo_display_details") or {}
        if d:
            return {"numero": d.get("number"), "vence": dt.datetime.fromtimestamp(d["expires_after"]).strftime("%d/%m/%Y")
                    if d.get("expires_after") else None, "url": d.get("hosted_voucher_url")}
    return None


def verificar_webhook(cuerpo, firma, secreto, tolerancia=300):
    """Valida la firma 'Stripe-Signature' (t=...,v1=...) con HMAC-SHA256."""
    if not (firma and secreto):
        return False
    pares = [p.strip().split("=", 1) for p in firma.split(",") if "=" in p]
    t = next((v for k, v in pares if k == "t"), "")
    firmas = [v for k, v in pares if k == "v1"]
    if not t.isdigit() or abs(time.time() - int(t)) > tolerancia:
        return False
    esperado = hmac.new(secreto.encode(), f"{t}.".encode() + cuerpo, hashlib.sha256).hexdigest()
    return any(hmac.compare_digest(esperado, f) for f in firmas)


# ------------------------------------------------------------------ pedidos
def nuevo_folio():
    return "FB-" + dt.date.today().strftime("%y%m") + "-" + "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(5))


def referencia_spei(folio):
    """Referencia numérica de 7 dígitos (el campo 'referencia' de SPEI solo acepta números)."""
    return str(int(hashlib.sha256(folio.encode()).hexdigest(), 16) % 9_000_000 + 1_000_000)


def activar(con, pedido):
    """Aplica el plan pagado: suma el periodo a la vigencia actual (no se pierden días si renueva antes)."""
    actual = con.execute("SELECT estado FROM pedidos WHERE id=?", (pedido["id"],)).fetchone()
    u = con.execute("SELECT * FROM usuarios WHERE id=?", (pedido["usuario_id"],)).fetchone()
    if not u or not actual or actual["estado"] == "pagado":   # nunca se aplica dos veces el mismo pago
        return None
    hoy = dt.date.today()
    base = hoy
    if u["plan"] == pedido["plan"] and u["plan_vence"]:
        try:
            base = max(hoy, dt.date.fromisoformat(u["plan_vence"]))
        except ValueError:
            pass
    credito = 0
    if u["plan"] in CATALOGO and u["plan"] != pedido["plan"] and u["plan_vence"]:
        # cambio de plan con días pagados vigentes: se convierten a días del plan nuevo según su valor
        try:
            restantes = (dt.date.fromisoformat(u["plan_vence"]) - hoy).days
        except ValueError:
            restantes = 0
        if restantes > 0:
            viejo, nuevo = CATALOGO[u["plan"]]["mensual"] / 30, CATALOGO[pedido["plan"]]["mensual"] / 30
            credito = int(restantes * viejo / nuevo)
    vence = base + dt.timedelta(days=DIAS_PERIODO[pedido["periodo"]] + credito)
    con.execute("UPDATE usuarios SET plan=?, plan_vence=?, plan_nota=? WHERE id=?",
                (pedido["plan"], str(vence), f"Pagado · folio {pedido['folio']}", u["id"]))
    if CATALOGO[pedido["plan"]]["tipo"] == "coach" and u["rol"] != "entrenador":
        codigo = u["codigo_coach"] or "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6))
        con.execute("UPDATE usuarios SET rol='entrenador', codigo_coach=? WHERE id=?", (codigo, u["id"]))
    con.execute("UPDATE pedidos SET estado='pagado', pagado_en=?, vigencia_hasta=? WHERE id=? AND estado!='pagado'",
                (dt.datetime.now().isoformat(timespec="seconds"), str(vence), pedido["id"]))
    con.commit()
    return vence
