"""Bot de diagnóstico: prueba la app completa sobre una COPIA de la base de datos y reporta fallas y discrepancias.

Uso: python diagnostico.py      (lo lanza Administración → Diagnóstico; no toca los datos reales)
Escribe el resultado en diagnostico/ultimo.json.
"""
import datetime as dt
import json
import os
import re
import shutil
import sys
import time
import traceback

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(BASE, "diagnostico")
SALIDA = os.path.join(CARPETA, "ultimo.json")
ESTADO = os.path.join(CARPETA, "estado.json")


def _escribir(ruta, datos):
    os.makedirs(CARPETA, exist_ok=True)
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(datos, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, ruta)


def leer():
    try:
        with open(SALIDA, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def corriendo():
    try:
        with open(ESTADO, encoding="utf-8") as fh:
            e = json.load(fh)
        return e.get("corriendo") and time.time() - e.get("inicio", 0) < 900
    except (OSError, ValueError):
        return False


class Bot:
    def __init__(self):
        self.res = []

    def ok(self, grupo, nombre, detalle=""):
        self.res.append({"grupo": grupo, "nombre": nombre, "estado": "ok", "detalle": detalle})

    def aviso(self, grupo, nombre, detalle):
        self.res.append({"grupo": grupo, "nombre": nombre, "estado": "aviso", "detalle": detalle})

    def falla(self, grupo, nombre, detalle):
        self.res.append({"grupo": grupo, "nombre": nombre, "estado": "falla", "detalle": detalle})

    def prueba(self, grupo, nombre, fn):
        try:
            r = fn()
            if r is True or r is None:
                self.ok(grupo, nombre)
            elif isinstance(r, tuple):
                getattr(self, r[0])(grupo, nombre, r[1])
            else:
                self.ok(grupo, nombre, str(r))
        except AssertionError as e:
            self.falla(grupo, nombre, str(e) or "La verificación no se cumplió.")
        except Exception as e:  # noqa: BLE001
            self.falla(grupo, nombre, f"{type(e).__name__}: {e}\n" + traceback.format_exc(limit=3)[-600:])


def ejecutar():
    inicio = time.time()
    _escribir(ESTADO, {"corriendo": True, "inicio": inicio})
    prueba_db = os.path.join(CARPETA, "prueba.db")
    os.makedirs(CARPETA, exist_ok=True)
    real = os.path.join(BASE, "fitapp.db")
    if os.path.exists(prueba_db):
        os.remove(prueba_db)
    if os.path.exists(real):
        shutil.copy2(real, prueba_db)
    os.environ["FITAPP_DB"] = prueba_db
    sys.path.insert(0, BASE)
    bot = Bot()
    try:
        import app as A  # noqa: E402  (al importarse prepara la base de prueba)
        import i18n
        import restricciones as R
        A.app.config.update(TESTING=False, PROPAGATE_EXCEPTIONS=False)
        _pruebas(bot, A, i18n, R)
    except Exception as e:  # noqa: BLE001
        bot.falla("General", "Cargar la aplicación", f"{type(e).__name__}: {e}\n{traceback.format_exc()[-1500:]}")
    fin = time.time()
    resumen = {"fecha": dt.datetime.now().isoformat(timespec="seconds"), "segundos": round(fin - inicio, 1),
               "version": open(os.path.join(BASE, "VERSION")).read().strip() if os.path.exists(os.path.join(BASE, "VERSION")) else "?",
               "total": len(bot.res), "fallas": sum(1 for r in bot.res if r["estado"] == "falla"),
               "avisos": sum(1 for r in bot.res if r["estado"] == "aviso"), "resultados": bot.res}
    _escribir(SALIDA, resumen)
    _escribir(ESTADO, {"corriendo": False, "fin": fin})
    try:
        os.remove(prueba_db)
    except OSError:
        pass
    return resumen


def _cliente(A, email=None, rol=None):
    c = A.app.test_client()
    if email:
        r = c.post("/login", data={"email": email, "password": "demo1234"})
        assert r.status_code in (302, 303), f"No se pudo iniciar sesión con {email}"
    return c


def _pruebas(bot, A, i18n, R):
    import sqlite3
    db = sqlite3.connect(os.environ["FITAPP_DB"])
    db.row_factory = sqlite3.Row
    # cuenta admin de prueba (en la copia)
    db.execute("UPDATE usuarios SET es_admin=1 WHERE email='coach@fitapp.local'")
    db.commit()
    rutas = sorted({r.rule for r in A.app.url_map.iter_rules() if "GET" in r.methods and not r.arguments
                    and not r.rule.startswith(("/static", "/demo", "/salir", "/idioma", "/actualizaciones/", "/api/"))
                    and r.endpoint not in ("reiniciar",)})
    clientes = {"visitante": _cliente(A), "cliente": _cliente(A, "demo@fitapp.local"), "entrenador y admin": _cliente(A, "coach@fitapp.local")}

    # 1. Todas las páginas, por rol e idioma
    for quien, c in clientes.items():
        for lang in ("es", "en", "fr"):
            c.set_cookie("idioma", lang)
            malas, lentas = [], []
            for ru in rutas:
                t0 = time.time()
                try:
                    r = c.get(ru)
                except Exception as e:  # noqa: BLE001
                    malas.append(f"{ru} → {type(e).__name__}")
                    continue
                dt_ = time.time() - t0
                if r.status_code >= 500:
                    malas.append(f"{ru} → error {r.status_code}")
                elif r.mimetype == "text/html" and ru != "/admin/diagnostico" and ("Traceback" in r.get_data(as_text=True) or "{{" in r.get_data(as_text=True).split("<script")[0]):
                    malas.append(f"{ru} → la página muestra código sin procesar")
                if dt_ > 2.5:
                    lentas.append(f"{ru} ({dt_:.1f} s)")
            if malas:
                bot.falla("Páginas", f"{len(rutas)} páginas como {quien} ({lang.upper()})", "\n".join(malas[:25]))
            else:
                bot.ok("Páginas", f"{len(rutas)} páginas como {quien} ({lang.upper()})")
            if lentas:
                bot.aviso("Velocidad", f"Páginas lentas como {quien} ({lang.upper()})", ", ".join(lentas[:10]))
            c.set_cookie("idioma", "es")

    co, cl = clientes["entrenador y admin"], clientes["cliente"]
    cid = db.execute("SELECT id FROM usuarios WHERE email='demo@fitapp.local'").fetchone()[0]

    # 2. Páginas con parámetros
    def con_param():
        malas = []
        for ru in [f"/coach/cliente/{cid}", f"/coach/cliente/{cid}/dieta", f"/coach/cliente/{cid}/diario", f"/coach/cliente/{cid}/mediciones",
                   f"/coach/cliente/{cid}/fotos", f"/coach/cliente/{cid}/expediente", f"/coach/cliente/{cid}/sondeo-avanzado",
                   f"/coach/cliente/{cid}/menu-semanal", f"/coach/cliente/{cid}/suplementacion", f"/coach/cliente/{cid}/preferencias",
                   "/pagar/pro", "/pagar/coach40?periodo=anual"]:
            r = co.get(ru)
            if r.status_code >= 400 and not (r.status_code == 402 and A.cobro_activo()):
                malas.append(f"{ru} → {r.status_code}")
        from data.ejercicios import EJERCICIOS
        from data.articulos import ARTICULOS
        from data.recetas import RECETAS
        for ru in [f"/recetas/{RECETAS[0]['id']}", f"/recetas/{RECETAS[-1]['id']}"]:
            if cl.get(ru).status_code >= 400:
                malas.append(ru)
        assert not malas, "\n".join(malas)
        return f"{len(EJERCICIOS)} ejercicios, {len(ARTICULOS)} artículos y {len(RECETAS)} recetas cargados"
    bot.prueba("Páginas", "Fichas de cliente, recetas y pagos", con_param)

    # 3. Todos los PDF
    def pdfs():
        pdf_rutas = sorted({r.rule for r in A.app.url_map.iter_rules() if "GET" in r.methods and "pdf" in r.rule and "<" not in r.rule})
        malas = []
        for ru in pdf_rutas:
            for c in (cl, co):
                r = c.get(ru)
                if r.status_code == 200 and not r.data.startswith(b"%PDF"):
                    malas.append(f"{ru} no devolvió un PDF válido")
                elif r.status_code >= 500:
                    malas.append(f"{ru} → error {r.status_code}")
        for ru in [f"/coach/cliente/{cid}/expediente.pdf", f"/coach/cliente/{cid}/reporte-mensual.pdf"]:
            r = co.get(ru)
            if r.status_code == 200 and not r.data.startswith(b"%PDF"):
                malas.append(ru)
        assert not malas, "\n".join(malas)
        return f"{len(pdf_rutas)} documentos generados correctamente"
    bot.prueba("PDF", "Generación de PDF", pdfs)

    # 4. Flujo completo de un usuario nuevo
    def flujo():
        c = A.app.test_client()
        email = f"bot{int(time.time())}@prueba.local"
        r = c.post("/registro", data={"email": email, "nombre": "Bot de prueba", "password": "prueba123", "edad_legal": "mayor",
                                      "c_terminos": "1", "c_datos_salud": "1", "c_actividad_fisica": "1", "c_ia": "1"})
        assert r.status_code in (302, 303), f"Registro: {r.status_code}"
        r = c.post("/sondeo", data={"edad": 30, "peso": 80, "talla": 175, "sexo": "Hombre", "experiencia": "menos6", "objetivo": "Perder grasa",
                                    "dias": 3, "duracion": 45, "dieta_tipo": "vegetariana", "alergias": ["lacteos"]})
        assert r.status_code in (302, 303), f"Sondeo: {r.status_code}"
        for ru, datos in [("/habitos", {"peso": "80.2", "pasos": "8000", "sueno": "7"})]:
            assert c.post(ru, data=datos).status_code in (200, 302, 303), ru
        assert c.post("/registrar/guardar", json={"tiempo": "Comida", "items": [{"nombre": "Arroz", "gramos": 150, "por100g": {"kcal": 130, "prot": 2.7, "carb": 28, "grasa": .3}}]}).status_code == 200
        r = c.get("/menu-semanal")
        # Con el cobro activo, un usuario gratuito recibe 402 (pantalla «función Pro»): es lo esperado, no una falla
        esperado = (200, 402) if A.cobro_activo() else (200,)
        assert r.status_code in esperado, f"Menú semanal: {r.status_code}"
        if r.status_code == 402:
            assert "Pro" in r.get_data(as_text=True), "Menú semanal: 402 sin la pantalla de Pro"
        return "Registro → sondeo → registro diario → comida → menú semanal"
    bot.prueba("Flujos", "Usuario nuevo de principio a fin", flujo)

    # 5. El idioma no cambia solo al navegar ni con cargas anticipadas
    def idioma():
        c = _cliente(A, "demo@fitapp.local")
        c.get("/idioma/fr?next=/app")
        c.get("/idioma/en?next=/app", headers={"Sec-Purpose": "prefetch"})   # simulación de carga anticipada del navegador
        for ru in ("/app", "/diario", "/progreso", "/retos", "/ajustes"):
            r = c.get(ru)
            assert 'lang="fr"' in r.get_data(as_text=True)[:400], f"El idioma cambió al abrir {ru}"
        return "Se mantiene en francés tras 5 cambios de sección y una carga anticipada"
    bot.prueba("Idiomas", "El idioma se mantiene", idioma)

    # 6. API móvil
    def api():
        c = A.app.test_client()
        t = c.post("/api/v1/login", json={"email": "demo@fitapp.local", "password": "demo1234"}).get_json()
        assert t and t.get("ok"), "No se pudo iniciar sesión por la API"
        h = {"Authorization": "Bearer " + t["token"]}
        malas = [ru for ru in ("/api/v1/yo", "/api/v1/hoy", "/api/v1/progreso", "/api/v1/retos", "/api/v1/notificaciones", "/api/v1/guia")
                 if c.get(ru, headers=h).status_code != 200]
        assert not malas, "Fallaron: " + ", ".join(malas)
        return "7 servicios de la app móvil responden"
    bot.prueba("API", "Servicios para la app móvil", api)

    # 7. Discrepancias de cálculo
    def macros():
        import calc
        malos = []
        for u in db.execute("SELECT * FROM usuarios WHERE perfil IS NOT NULL").fetchall():
            for dieta in ("omnivora", "keto", "baja_carbos", "mediterranea"):
                with A.app.test_request_context():
                    p = json.loads(u["perfil"])
                    p["dieta_tipo"] = dieta
                    uu = dict(u)
                    uu["perfil"] = json.dumps(p)
                    _p, comp, en, mac = A.calcular(uu)
                tot = mac["prot"] * 4 + mac["carb"] * 4 + mac["grasa"] * 9
                if abs(tot - mac["kcal"]) / mac["kcal"] > .04:
                    malos.append(f"{u['email']} ({dieta}): macros suman {tot:.0f} kcal vs meta {mac['kcal']:.0f}")
                if dieta == "keto" and mac["carb"] > 31:
                    malos.append(f"{u['email']}: keto con {mac['carb']:.0f} g de carbohidratos")
        assert not malos, "\n".join(malos[:10])
        return "Proteína, carbohidratos y grasa suman la meta de calorías en todas las dietas"
    bot.prueba("Discrepancias", "Macros cuadran con las calorías", macros)

    def recetas():
        from data.recetas import RECETAS, macros_receta
        malas = [r["nombre"] for r in RECETAS if abs(macros_receta(r)["kcal"] - r["base"]["kcal"]) > max(15, .03 * r["base"]["kcal"])]
        if malas:
            return ("aviso", f"{len(malas)} recetas con calorías que no coinciden con sus ingredientes: " + ", ".join(malas[:8]))
        return f"{len(RECETAS)} recetas: calorías coinciden con la suma de sus ingredientes"
    bot.prueba("Discrepancias", "Calorías de las recetas", recetas)

    def alergias():
        from data.recetas import RECETAS
        p = {"alergias": ["lacteos", "gluten", "cacahuate"], "dieta_tipo": "vegana"}
        malas = []
        for r in RECETAS:
            ok, _m, pres = R.revisar_receta(r, p)
            if ok and set(pres) & set(p["alergias"]):
                malas.append(r["nombre"])
        assert not malas, "Recetas marcadas como seguras que contienen alérgenos: " + ", ".join(malas[:10])
        with A.app.test_request_context():
            cands = A.candidatas("comida", p, "Mantener")
        assert all(not (set(R.revisar_receta(x, p)[2]) & set(p["alergias"])) for x in cands), "El menú sugiere recetas con alérgenos"
        return f"Ninguna receta sugerida contiene alérgenos marcados ({len(cands)} opciones veganas sin lácteos, gluten ni cacahuate)"
    bot.prueba("Discrepancias", "Alergias respetadas en recetas y menú", alergias)

    def suplementos():
        import suplementacion as S
        malos = []
        for edad, peso in [(16, 60), (30, 50), (30, 120), (70, 70)]:
            ctx = S.contexto({"edad": edad, "peso": peso, "sexo": "Hombre", "objetivo": "Ganar músculo"})
            recs, no, bloq = S.recomendar(ctx)
            if edad < 18 and (recs or not bloq):
                malos.append("Se recomiendan suplementos a un menor de edad")
            for x in recs:
                if x["clave"] == "cafeina" and x["cantidad"] > 400:
                    malos.append(f"Cafeína de {x['cantidad']} mg (> 400 mg)")
                if x["clave"] == "creatina" and not 3 <= x["cantidad"] <= 5:
                    malos.append(f"Creatina de {x['cantidad']} g fuera de 3-5 g")
        assert not malos, "\n".join(malos)
        return "Dosis dentro de límites seguros; menores de edad sin suplementos ergogénicos"
    bot.prueba("Discrepancias", "Dosis de suplementos", suplementos)

    # 8. Enlaces internos y archivos
    def enlaces():
        vistos, rotos = set(), []
        for ru in ("/app", "/nutricion", "/progreso", "/coach", "/planes", "/guia", "/"):
            html = co.get(ru).get_data(as_text=True)
            for href in re.findall(r'(?:href|src)="(/[^"#?]*)', html):
                if href in vistos or href.startswith(("/idioma", "/salir", "/demo", "/api/", "/notificaciones/")):
                    continue
                vistos.add(href)
                r = co.get(href)
                if r.status_code == 404:
                    rotos.append(href)
        assert not rotos, "Enlaces o archivos que no existen: " + ", ".join(rotos[:15])
        return f"{len(vistos)} enlaces y archivos revisados"
    bot.prueba("Enlaces", "Enlaces internos y archivos", enlaces)

    # 9. Traducciones
    def traducciones():
        falt = {k: len(i18n.faltantes(k)) for k in ("en", "fr")}
        if max(falt.values()) > 400:
            return ("aviso", f"Frases sin traducir detectadas: inglés {falt['en']}, francés {falt['fr']}. Tradúcelas en Administración → Idiomas.")
        return f"Frases sin traducir: inglés {falt['en']}, francés {falt['fr']}"
    bot.prueba("Idiomas", "Cobertura de traducción", traducciones)

    # 10. Datos y negocio
    def datos():
        avisos = []
        hoy = str(dt.date.today())
        n = db.execute("SELECT COUNT(*) FROM pedidos WHERE estado='pagado' AND (vigencia_hasta IS NULL OR vigencia_hasta='')").fetchone()[0]
        if n:
            avisos.append(f"{n} pagos confirmados sin vigencia registrada")
        n = db.execute("SELECT COUNT(*) FROM pedidos WHERE estado='revision'").fetchone()[0]
        if n:
            avisos.append(f"{n} transferencias esperando tu confirmación")
        n = db.execute("SELECT COUNT(*) FROM solicitudes_arco WHERE estado IN ('recibida','proceso') AND vence < ?", (hoy,)).fetchone()[0]
        if n:
            avisos.append(f"{n} solicitudes ARCO vencidas sin responder (obligación legal)")
        n = db.execute("SELECT COUNT(*) FROM errores WHERE resuelto=0").fetchone()[0]
        if n:
            avisos.append(f"{n} errores registrados mientras la gente usaba la app")
        import legal
        if legal.datos()["faltan"]:
            avisos.append("Faltan datos del responsable en el aviso de privacidad (Administración → Legal)")
        if avisos:
            return ("aviso", "; ".join(avisos))
        return "Pagos, solicitudes ARCO y datos legales en orden"
    bot.prueba("Datos", "Pagos, ARCO y avisos legales", datos)
    db.close()


if __name__ == "__main__":
    r = ejecutar()
    print(f"Diagnóstico: {r['total']} pruebas · {r['fallas']} fallas · {r['avisos']} avisos · {r['segundos']} s")
    for x in r["resultados"]:
        if x["estado"] != "ok":
            print(f" [{x['estado'].upper()}] {x['grupo']} · {x['nombre']}: {x['detalle'][:300]}")
