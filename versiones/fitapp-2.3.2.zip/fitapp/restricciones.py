"""Alergias, intolerancias y tipos de dieta: qué alimentos y recetas son compatibles con cada persona."""
import re
import unicodedata


def _n(t):
    return "".join(c for c in unicodedata.normalize("NFD", (t or "").lower()) if unicodedata.category(c) != "Mn")


# Alérgenos principales (los 8 de declaración obligatoria más comunes en México + soya y sésamo)
ALERGENOS = {
    "gluten": ("Gluten (trigo, avena, cebada, centeno)", ["pan", "pasta", "trigo", "avena", "harina", "galleta", "cebada", "centeno", "cuscus", "bulgur", "tortilla de harina", "seitan"]),
    "lacteos": ("Leche y lácteos (incluye lactosa)", ["leche descremada", "leche entera", "leche de vaca", "queso", "yogur", "requeson", "suero", "crema", "mantequilla", "cottage", "panela", "jocoque"]),
    "huevo": ("Huevo", ["huevo", "clara"]),
    "pescado": ("Pescado", ["atun", "salmon", "tilapia", "sardina", "pescado", "bacalao", "mojarra", "trucha", "merluza"]),
    "mariscos": ("Mariscos y crustáceos", ["camaron", "langosta", "pulpo", "calamar", "ostion", "mejillon", "jaiba", "cangrejo", "marisco"]),
    "cacahuate": ("Cacahuate", ["cacahuate", "mani"]),
    "frutos_secos": ("Frutos secos (nuez, almendra, etc.)", ["almendra", "nuez", "avellana", "pistache", "pistacho", "anacardo", "nuez de la india", "macadamia"]),
    "soya": ("Soya", ["soya", "tofu", "edamame", "tempeh", "miso"]),
    "sesamo": ("Ajonjolí / sésamo", ["ajonjoli", "sesamo", "tahini"]),
}
# Grupos para tipos de dieta
GRUPOS = {
    "carne": ["pollo", "pavo", "res", "bistec", "cerdo", "jamon", "carne", "chorizo", "tocino", "muslo", "caldo de pollo", "salchicha", "cecina", "arrachera"],
    "cerdo": ["cerdo", "tocino", "chorizo", "carnitas", "chicharron"],
    "pescado": ALERGENOS["pescado"][1] + ALERGENOS["mariscos"][1],
    "huevo": ALERGENOS["huevo"][1],
    "lacteos": ALERGENOS["lacteos"][1],
    "miel": ["miel"],
    "cereales": ["arroz", "avena", "tortilla", "tostada", "pan", "pasta", "quinoa", "maiz", "elote", "amaranto", "galleta", "palomitas", "harina", "pozolero"],
    "legumbres": ["frijol", "lenteja", "garbanzo", "haba", "chicharo", "soya", "tofu", "cacahuate", "alubia"],
    "procesados": ["jamon", "salchicha", "chorizo", "embutido"],
    "mediterraneo": ["aceite de oliva", "salmon", "sardina", "atun", "lenteja", "garbanzo", "frijol", "aceituna", "nuez", "almendra", "espinaca", "jitomate", "brocoli", "quinoa", "integral"],
}
# (clave, nombre, descripción, grupos excluidos, carbohidratos máx. por porción de receta o None)
DIETAS = [
    ("omnivora", "Omnívora", "Sin restricciones: comes de todo.", [], None),
    ("mediterranea", "Mediterránea", "Prioriza pescado, aceite de oliva, legumbres, verduras y granos integrales; poca carne roja y procesados.", [], None),
    ("vegetariana", "Vegetariana", "Sin carne, aves ni pescado. Incluye huevo y lácteos.", ["carne", "pescado"], None),
    ("vegana", "Vegana", "Nada de origen animal: sin carne, pescado, huevo, lácteos ni miel.", ["carne", "pescado", "huevo", "lacteos", "miel"], None),
    ("pescetariana", "Pescetariana", "Sin carne ni aves; sí pescado, mariscos, huevo y lácteos.", ["carne"], None),
    ("keto", "Cetogénica (keto)", "Muy baja en carbohidratos (≈20-50 g al día) y alta en grasa. Requiere supervisión si tienes diabetes, enfermedad renal o tomas medicamentos.", ["cereales"], 12),
    ("baja_carbos", "Baja en carbohidratos", "Carbohidratos moderados (≈25 % de la energía), más proteína y grasas saludables.", [], 30),
    ("paleo", "Paleo", "Sin cereales, legumbres ni lácteos; carnes, pescado, huevo, verduras, frutas y semillas.", ["cereales", "legumbres", "lacteos"], None),
    ("sin_cerdo", "Sin cerdo", "Excluye carne de cerdo y derivados (por religión o preferencia).", ["cerdo"], None),
]
DIETA_POR_CLAVE = {d[0]: d for d in DIETAS}
INTOLERANCIAS = {"lactosa": "Intolerancia a la lactosa", "fructosa": "Malabsorción de fructosa", "fodmap": "Sensibilidad a FODMAP (colon irritable)"}


def contiene(nombre, palabras):
    t = _n(nombre)
    return any(re.search(r"\b" + re.escape(_n(p)) + r"(s|es)?\b", t) for p in palabras)


def alergenos_de(nombre):
    """Alérgenos que probablemente contiene un alimento según su nombre."""
    out = [k for k, (_, pal) in ALERGENOS.items() if contiene(nombre, pal)]
    if "leche de soya" in _n(nombre) or "leche de almendra" in _n(nombre) or "leche de coco" in _n(nombre):
        out = [x for x in out if x != "lacteos"]
    if "crema de cacahuate" in _n(nombre):
        out = [x for x in out if x != "lacteos"]
    if "galleta de arroz" in _n(nombre) or "harina de maiz" in _n(nombre) or "harina de almendra" in _n(nombre):
        out = [x for x in out if x != "gluten"]
    return out


def grupos_de(nombre):
    out = [k for k, pal in GRUPOS.items() if contiene(nombre, pal)]
    n = _n(nombre)
    if "leche de soya" in n or "crema de cacahuate" in n:
        out = [x for x in out if x != "lacteos"]
    if "caldo de verduras" in n:
        out = [x for x in out if x != "carne"]
    if "proteina vegetal" in n:
        out = [x for x in out if x not in ("lacteos",)]
    return out


def de_perfil(p):
    p = p or {}
    dieta = p.get("dieta_tipo")
    if not dieta:  # compatibilidad con perfiles anteriores
        prefs = p.get("preferencias") or []
        dieta = "vegana" if "vegana" in prefs else "vegetariana" if "vegetariana" in prefs else "omnivora"
    alergias = [a for a in (p.get("alergias") or []) if a in ALERGENOS]
    if "lactosa" in (p.get("intolerancias") or []) and "lacteos" not in alergias:
        alergias.append("lacteos")
    return {"dieta": dieta if dieta in DIETA_POR_CLAVE else "omnivora", "alergias": alergias,
            "otras": [x.strip() for x in (p.get("alergia_otra") or "").split(",") if x.strip()]}


def tiene_restricciones(p):
    r = de_perfil(p)
    return r["dieta"] != "omnivora" or bool(r["alergias"]) or bool(r["otras"])


def revisar_alimento(nombre, p):
    """Lista de avisos para un alimento: alergias (graves) y choque con su tipo de dieta."""
    r = de_perfil(p)
    avisos = []
    for a in alergenos_de(nombre):
        if a in r["alergias"]:
            avisos.append(("alergia", f"Contiene {ALERGENOS[a][0].split(' (')[0].lower()}: indicaste alergia o intolerancia."))
    for o in r["otras"]:
        if contiene(nombre, [o]):
            avisos.append(("alergia", f"Coincide con «{o}», que indicaste que no puedes comer."))
    excl = DIETA_POR_CLAVE[r["dieta"]][3]
    for gk in grupos_de(nombre):
        if gk in excl:
            avisos.append(("dieta", f"No va con tu dieta {DIETA_POR_CLAVE[r['dieta']][1].lower()}."))
            break
    return avisos


def revisar_receta(receta, p):
    """(compatible, motivos, alérgenos que contiene). Las alergias nunca se relajan."""
    r = de_perfil(p)
    motivos, presentes = [], set()
    excl = DIETA_POR_CLAVE[r["dieta"]][3]
    for nombre, _g in receta.get("ing", []):
        for a in alergenos_de(nombre):
            presentes.add(a)
            if a in r["alergias"]:
                motivos.append(f"contiene {ALERGENOS[a][0].split(' (')[0].lower()}")
        for o in r["otras"]:
            if contiene(nombre, [o]):
                motivos.append(f"contiene {o}")
        if excl and any(gk in excl for gk in grupos_de(nombre)):
            motivos.append(f"{nombre.lower()} no va con dieta {DIETA_POR_CLAVE[r['dieta']][1].lower()}")
    carb_max = DIETA_POR_CLAVE[r["dieta"]][4]
    base = receta.get("base") or {}
    if carb_max is not None and (base.get("carb") or 0) > carb_max:
        motivos.append(f"{base.get('carb', 0):.0f} g de carbohidratos por porción")
    return (not motivos), list(dict.fromkeys(motivos)), sorted(presentes)


def puntaje_mediterraneo(receta):
    n = sum(1 for nombre, _ in receta.get("ing", []) if contiene(nombre, GRUPOS["mediterraneo"]))
    m = sum(1 for nombre, _ in receta.get("ing", []) if contiene(nombre, GRUPOS["procesados"] + ["res", "bistec", "cerdo"]))
    return n - 2 * m


def ajustar_macros(p, kcal, prot, grasa, carb):
    """Reparte los macros según el tipo de dieta. Devuelve (grasa, carb, nota)."""
    dieta = de_perfil(p)["dieta"]
    if dieta == "keto":
        carb = min(carb, 30.0)
        grasa = max(0.0, (kcal - prot * 4 - carb * 4) / 9)
        return grasa, carb, "Cetogénica: carbohidratos limitados a 30 g al día y el resto de la energía en grasa."
    if dieta == "baja_carbos":
        carb = min(carb, 0.25 * kcal / 4)
        grasa = max(0.0, (kcal - prot * 4 - carb * 4) / 9)
        return grasa, carb, "Baja en carbohidratos: ≈25 % de la energía en carbohidratos."
    if dieta == "mediterranea":
        grasa = max(grasa, 0.33 * kcal / 9)
        carb = max(0.0, (kcal - prot * 4 - grasa * 9) / 4)
        return grasa, carb, "Mediterránea: ≈33 % de la energía en grasas, sobre todo aceite de oliva, pescado y frutos secos."
    return grasa, carb, None
