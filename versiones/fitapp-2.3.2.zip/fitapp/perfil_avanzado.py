"""Sondeo avanzado: experiencia, marcas de fuerza, competencias y personalización por nivel.

Niveles: Novato · Principiante · Intermedio · Avanzado · Élite (y competidor amateur o profesional).
- Fuerza relativa: 1RM estimado (Epley) ÷ peso corporal, comparado con estándares orientativos por sexo. No son normas
  científicas oficiales: sirven para ubicar a la persona y elegir volumen, progresión y cargas iniciales.
- Volumen: relación dosis-respuesta (Schoenfeld, Ogborn y Krieger 2017, J Sports Sci 35:1073); más volumen solo si se recupera.
- Preparación de competencia natural: Helms, Aragon y Fitschen 2014 (JISSN 11:20) y Helms et al. 2015 (J Sports Med Phys Fitness).
- Fuera de temporada: Iraki, Fitschen, Espinar y Helms 2019 (Sports 7:154).
- Semana pico: Escalante et al. 2021 (BMC Sports Sci Med Rehabil 13:68): evidencia limitada, evitar manipulaciones extremas.
"""
import datetime as dt

LEVANTAMIENTOS = [
    ("sentadilla", "Sentadilla con barra", "Sentadilla con barra"),
    ("banca", "Press de banca", "Press de banca"),
    ("muerto", "Peso muerto", "Peso muerto"),
    ("militar", "Press militar con barra", "Press militar con barra"),
    ("remo", "Remo con barra", "Remo con barra"),
    ("dominadas", "Dominadas (peso corporal + lastre)", "Dominadas"),
    ("hip_thrust", "Hip thrust con barra", "Hip thrust con barra"),
]
# múltiplos del peso corporal para 1RM: (principiante, intermedio, avanzado, élite)
ESTANDARES = {
    "Hombre": {"sentadilla": (.75, 1.25, 1.75, 2.25), "banca": (.5, 1.0, 1.25, 1.6), "muerto": (1.0, 1.5, 2.25, 2.75),
               "militar": (.35, .6, .8, 1.05), "remo": (.5, .85, 1.15, 1.5), "dominadas": (1.05, 1.3, 1.55, 1.8),
               "hip_thrust": (1.0, 1.5, 2.25, 3.0)},
    "Mujer": {"sentadilla": (.5, 1.0, 1.5, 1.9), "banca": (.35, .6, .9, 1.2), "muerto": (.75, 1.25, 1.75, 2.3),
              "militar": (.25, .4, .6, .8), "remo": (.3, .55, .8, 1.05), "dominadas": (.85, 1.1, 1.35, 1.6),
              "hip_thrust": (.75, 1.25, 2.0, 2.75)},
}
NIVELES = ["Novato", "Principiante", "Intermedio", "Avanzado", "Élite"]
DISCIPLINAS = ["Fitness y salud", "Culturismo / fisicoculturismo", "Powerlifting", "Halterofilia", "CrossFit / funcional",
               "Calistenia", "Deporte de equipo", "Resistencia (correr, ciclismo, natación)", "Deporte de combate"]
COMPETENCIA = [("no", "No compito"), ("amateur", "Compito como amateur"), ("pro", "Soy profesional (tarjeta pro)")]
FEDERACIONES = ["IFBB Pro League", "NPC", "IFBB (Elite Pro / amateur)", "WNBF / natural", "OCB", "Powerlifting (IPF, USAPL, WRPF…)", "Otra"]
CATEGORIAS = ["Men's Physique", "Classic Physique", "Bodybuilding", "212 Bodybuilding", "Bikini", "Wellness", "Figure",
              "Women's Physique", "Fitness", "Powerlifting", "Otra"]
SPLITS = ["Cuerpo completo", "Torso / pierna", "Empuje / jalón / pierna", "Un músculo por día (bro split)", "Híbrido / especialización", "No sigo una rutina fija"]
SUPLEMENTOS = ["Creatina", "Proteína en polvo", "Cafeína", "Beta-alanina", "Omega-3", "Vitamina D", "Multivitamínico", "Citrulina", "Electrolitos"]
MODOS = [("sencillo", "Sencillo", "Te guío paso a paso, sin tecnicismos."), ("completo", "Completo", "Todas las herramientas con explicaciones."),
         ("atleta", "Atleta", "Todas las métricas: e1RM, RIR, volumen por músculo, preparación y check-ins.")]
MUSCULOS_DEBILES = ["Pecho", "Espalda (amplitud)", "Espalda (grosor)", "Hombro lateral", "Hombro posterior", "Bíceps", "Tríceps",
                    "Cuádriceps", "Isquiotibiales", "Glúteo", "Pantorrilla", "Abdomen", "Antebrazo", "Trapecio"]


def e1rm(peso, reps):
    if not peso or not reps:
        return None
    reps = max(1, min(int(reps), 15))
    return peso if reps == 1 else peso * (1 + reps / 30)


def fuerza(sexo, peso_corporal, marcas):
    """marcas: {clave: {"peso": kg, "reps": n}}. Para dominadas, 'peso' es el lastre añadido."""
    est = ESTANDARES.get(sexo, ESTANDARES["Hombre"])
    filas = []
    for k, nombre, ej in LEVANTAMIENTOS:
        m = marcas.get(k) or {}
        carga = (m.get("peso") or 0) + (peso_corporal if k == "dominadas" and m.get("reps") else 0)
        rm = e1rm(carga, m.get("reps"))
        if not rm or not peso_corporal:
            continue
        rel = rm / peso_corporal
        cortes = est[k]
        idx = sum(1 for c in cortes if rel >= c)          # 0 = Novato … 4 = Élite
        siguiente = cortes[idx] * peso_corporal if idx < 4 else None
        filas.append({"clave": k, "nombre": nombre, "ejercicio": ej, "peso": m.get("peso"), "reps": m.get("reps"), "e1rm": rm,
                      "relativo": rel, "nivel": NIVELES[idx], "idx": idx,
                      "pct": min(100, rel / cortes[3] * 100),
                      "siguiente": (siguiente - (peso_corporal if k == "dominadas" else 0)) if siguiente else None,
                      "siguiente_nivel": NIVELES[idx + 1] if idx < 4 else None})
    total_sbd = sum(f["e1rm"] for f in filas if f["clave"] in ("sentadilla", "banca", "muerto"))
    return filas, total_sbd


def clasificar(av, filas):
    """Nivel combinado: años constantes + fuerza relativa + competencia."""
    anios = (av.get("anios") or 0) + (av.get("meses") or 0) / 12
    if av.get("constancia") == "intermitente":
        anios *= .6
    base = 0 if anios < .5 else 1 if anios < 1 else 2 if anios < 3 else 3
    if filas:
        med = sorted(f["idx"] for f in filas)[len(filas) // 2]
        base = int((base + med) / 2 + .5)        # promedio entre experiencia y fuerza (redondeo hacia arriba)
    if av.get("compite") == "pro":
        base = 4
    elif av.get("compite") == "amateur":
        base = max(base, 3)
    base = max(0, min(4, base))
    return NIVELES[base], {0: "Principiante", 1: "Principiante", 2: "Intermedio", 3: "Avanzado", 4: "Avanzado"}[base]


def semanas_para(fecha):
    try:
        d = dt.date.fromisoformat(fecha)
    except (TypeError, ValueError):
        return None
    dias = (d - dt.date.today()).days
    return round(dias / 7, 1) if dias >= 0 else None


ENFOQUE = {
    "Novato": {"dias": "2-3 días de cuerpo completo", "volumen": "6-10 series por músculo a la semana", "esfuerzo": "Deja 2-3 repeticiones en reserva (RIR 2-3)",
               "progresion": "Progresión lineal: si completas todas las repeticiones, sube un poco el peso la siguiente sesión.",
               "prioridad": "Aprender la técnica de 6-8 ejercicios básicos y crear el hábito. Cualquier progreso cuenta.",
               "plantilla": "full-body-3"},
    "Principiante": {"dias": "3-4 días (cuerpo completo o torso/pierna)", "volumen": "8-14 series por músculo a la semana", "esfuerzo": "RIR 1-3",
                     "progresion": "Doble progresión: sube repeticiones dentro del rango y, al llegar al tope, sube el peso.",
                     "prioridad": "Constancia, técnica y comer suficiente proteína (1.6-2.2 g/kg).", "plantilla": "full-body-3"},
    "Intermedio": {"dias": "4-5 días (torso/pierna o empuje/jalón/pierna)", "volumen": "10-20 series por músculo a la semana", "esfuerzo": "RIR 0-3 según el ejercicio",
                   "progresion": "Doble progresión con descarga cada 6-8 semanas o cuando el rendimiento cae 2 sesiones seguidas.",
                   "prioridad": "Distribuir el volumen 2 veces por semana por músculo y registrar cada sesión.", "plantilla": "torso-pierna-4"},
    "Avanzado": {"dias": "5-6 días con especialización", "volumen": "12-24 series por músculo; más en tus puntos débiles, mantenimiento en los fuertes",
                 "esfuerzo": "Autorregulación por RIR/RPE; series al fallo solo en aislamientos", "progresion": "Periodización ondulante o por bloques; descarga cada 4-6 semanas.",
                 "prioridad": "Prioriza tus puntos débiles al inicio de la sesión y vigila la recuperación (sueño, rendimiento, articulaciones).", "plantilla": "ppl-6"},
    "Élite": {"dias": "5-6 días, periodizado por fase (fuera de temporada, preparación, semana pico)", "volumen": "Individual: ajusta con tu historial de respuesta",
              "esfuerzo": "RPE/RIR por ejercicio; técnica impecable con cargas altas", "progresion": "Bloques de acumulación, intensificación y descarga programada.",
              "prioridad": "Detalle por grupo muscular, simetría, posing y check-ins semanales con fotos y medidas.", "plantilla": "ppl-6"},
}


def recomendaciones(nivel, av, p):
    r = dict(ENFOQUE[nivel])
    r["extra"] = []
    debiles = av.get("debiles") or []
    if debiles:
        r["extra"].append(f"Puntos débiles a priorizar: {', '.join(debiles)}. Ponlos al inicio de la sesión, 2-3 veces por semana, con 2-4 series extra.")
    sem = semanas_para(av.get("fecha_comp"))
    if av.get("compite") in ("amateur", "pro") and av.get("disciplina", "").startswith("Culturismo"):
        if sem is not None and sem <= 24:
            r["fase"] = "Preparación de competencia"
            r["extra"] += [f"Faltan {sem:g} semanas para tu competencia.",
                           "Pérdida de peso de 0.5-1 % por semana para conservar músculo (Helms 2014).",
                           "Proteína 2.3-3.1 g por kg de masa magra; grasa 15-30 % de las calorías; carbohidratos con el resto.",
                           "Mantén la intensidad (cargas) y reduce volumen solo si la recuperación lo pide.",
                           "Check-in semanal: peso promedio, fotos en las mismas condiciones y medidas.",
                           "Semana pico: la evidencia es limitada; evita cortar agua o sodio de forma extrema (Escalante 2021)."]
        else:
            r["fase"] = "Fuera de temporada"
            r["extra"] += ["Superávit moderado para ganar 0.25-0.5 % del peso por semana (Iraki 2019).",
                           "Proteína 1.6-2.2 g/kg; aprovecha para mejorar puntos débiles y fuerza.",
                           "Planea cuántas semanas necesitas para llegar a tarima: con más grasa que perder, más semanas de preparación."]
    if av.get("disciplina") == "Powerlifting":
        r["extra"].append("Prioriza sentadilla, banca y peso muerto con frecuencia 2-3 por semana; accesorios para tus puntos débiles técnicos.")
    if av.get("sustancias") == "si":
        r["extra"].append("Por tu salud: análisis de sangre periódicos (lípidos, hematocrito, hígado, riñón, presión) y seguimiento con un médico. "
                          "Esta app no da dosis ni protocolos de fármacos.")
    if (av.get("sueno") or 8) < 7:
        r["extra"].append("Duermes menos de 7 h: mejorar el sueño suele rendir más que subir el volumen.")
    return r


def modo(p):
    av = p.get("avanzado") or {}
    if av.get("modo"):
        return av["modo"]
    return "sencillo" if p.get("nivel") == "Principiante" else "completo"


def carga_inicial(p, ejercicio, rmin, rmax, rir):
    """Peso sugerido para la primera sesión de un ejercicio con base en las marcas del sondeo avanzado."""
    av = p.get("avanzado") or {}
    marcas = av.get("marcas") or {}
    for k, _, ej in LEVANTAMIENTOS:
        if ej == ejercicio and marcas.get(k, {}).get("reps"):
            m = marcas[k]
            carga = (m.get("peso") or 0) + (p.get("peso") or 0 if k == "dominadas" else 0)
            rm = e1rm(carga, m["reps"])
            reps_objetivo = (rmin + rmax) / 2 + (rir or 0)
            peso = rm / (1 + reps_objetivo / 30) - (p.get("peso") or 0 if k == "dominadas" else 0)
            return max(0, round(peso / 2.5) * 2.5)
    return None
