"""Convierte los dibujos base (PNG) en data/cuerpo_svg.json. Requiere opencv-python-headless.

Uso: python scripts/vectorizar_cuerpo.py
Zonas grises -> músculos seleccionables; líneas claras -> trazo. Si cambias un dibujo, ajusta MAPA
(centro aproximado de cada zona, en píxeles de la imagen ya escalada) y vuelve a ejecutar.
"""
import json
import os

import cv2
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))

CONFIG = {
    "Hombre": dict(
        archivo="cuerpo_base.png", escala=1, gris=(70, 160), blanco=160, abrir=0, fondo=40,
        vistas={"frente": (30, 0, 600, None), "espalda": (668, 0, 1238, None)}, centro={"frente": 299, "espalda": 953},
        mapa={"frente": [((250, 170), "trapecio"), ((196, 210), "deltoide_ant"), ((253, 231), "pectoral"), ((164, 289), "biceps"),
                         ((232, 336), "oblicuos"), ((299, 361), "abdomen"), ((107, 374), "antebrazo"), ((62, 465), None),
                         ((242, 555), "cuadriceps"), ((216, 815), "tibial")],
              "espalda": [((953, 178), "trapecio"), ((852, 206), "deltoide_post"), ((953, 233), "romboides"), ((814, 282), "triceps"),
                          ((894, 299), "dorsal"), ((953, 366), "erectores"), ((754, 375), "antebrazo"), ((715, 474), None),
                          ((917, 466), "gluteo"), ((892, 578), "isquios"), ((872, 768), "pantorrilla")]}),
    "Mujer": dict(
        archivo="cuerpo_base_mujer.png", escala=4, gris=(95, 118), blanco=132, abrir=3, fondo=45,
        vistas={"frente": (97, 0, 907, None), "espalda": (989, 0, 1799, None)}, centro={"frente": 502, "espalda": 1394},
        mapa={"frente": [((386, 383), "deltoide_ant"), ((452, 403), "pectoral"), ((353, 468), "biceps"), ((502, 472), "abdomen"),
                         ((502, 540), "abdomen"), ((502, 632), "abdomen"), ((431, 533), "oblicuos"), ((277, 561), "antebrazo"),
                         ((213, 654), None), ((427, 786), "cuadriceps"), ((390, 1148), "tibial")],
              "espalda": [((1393, 324), "trapecio"), ((1286, 362), "deltoide_post"), ((1394, 390), "romboides"), ((1243, 448), "triceps"),
                          ((1336, 459), "dorsal"), ((1394, 554), "erectores"), ((1167, 554), "antebrazo"), ((1104, 658), None),
                          ((1345, 666), "gluteo"), ((1315, 813), "isquios"), ((1286, 1057), "pantorrilla")]}),
}


def _curva(pts, n=12):
    """Puntos de control -> polilínea suave (Catmull-Rom)."""
    pts = [np.array(p, float) for p in pts]
    out = []
    for i in range(len(pts) - 1):
        p0 = pts[max(i - 1, 0)]; p1 = pts[i]; p2 = pts[i + 1]; p3 = pts[min(i + 2, len(pts) - 1)]
        for t in np.linspace(0, 1, n, endpoint=False):
            t2, t3 = t * t, t * t * t
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    out.append(pts[-1])
    return np.array(out, np.int32).reshape(-1, 1, 2)


def _trazo(img, pts, g, cerrado=False):
    cv2.polylines(img, [_curva(pts + ([pts[0]] if cerrado else []))], False, 255, g, cv2.LINE_AA)


def retocar(img, sexo):
    """Cabezas redibujadas (peinado propio) sobre el dibujo base; el cuerpo no se toca."""
    if sexo == "Hombre":
        g = 3
        img[0:145, 245:356] = 15
        _trazo(img, [(262, 60), (262, 100), (267, 113), (280, 129), (299, 138), (318, 129), (331, 113), (336, 100), (336, 60)], g)  # cara
        for x0, s in ((262, -1), (336, 1)):  # orejas
            _trazo(img, [(x0, 76), (x0 + 7 * s, 74), (x0 + 9 * s, 88), (x0 + 6 * s, 104), (x0, 104)], g)
        _trazo(img, [(262, 64), (258, 46), (266, 28), (283, 18), (301, 15), (318, 18), (333, 28), (341, 45), (336, 64)], g)  # pelo
        _trazo(img, [(262, 62), (270, 50), (284, 45), (298, 47), (312, 44), (326, 48), (336, 60)], g)  # nacimiento del pelo
        _trazo(img, [(284, 45), (280, 33), (283, 21)], 2)  # raya al lado
        _trazo(img, [(267, 113), (267, 145)], g); _trazo(img, [(331, 113), (331, 145)], g)  # cuello
        img[0:140, 900:1011] = 15
        _trazo(img, [(921, 116), (911, 92), (907, 62), (914, 34), (933, 17), (953, 13), (973, 17), (992, 34), (999, 62), (995, 92), (985, 116)], g)
        for x0, s in ((909, -1), (997, 1)):
            _trazo(img, [(x0, 72), (x0 + 6 * s, 74), (x0 + 7 * s, 88), (x0 + 4 * s, 100), (x0, 100)], g)
        _trazo(img, [(913, 98), (928, 106), (941, 102), (953, 108), (965, 102), (978, 106), (993, 98)], g)  # nuca
        _trazo(img, [(921, 112), (921, 142)], g); _trazo(img, [(985, 112), (985, 142)], g)
    else:
        g = 5
        img[0:318, 415:596] = 26
        _trazo(img, [(454, 222), (453, 258), (465, 284), (485, 301), (505, 306), (525, 301), (545, 284), (557, 258), (556, 222)], g)  # cara
        _trazo(img, [(442, 266), (438, 222), (446, 186), (472, 163), (505, 155), (538, 163), (564, 186), (572, 222), (568, 266)], g)  # pelo
        _trazo(img, [(458, 226), (474, 200), (498, 190), (520, 196), (540, 190), (552, 224)], g)  # flequillo de lado
        _trazo(img, [(442, 266), (446, 288), (456, 304)], g); _trazo(img, [(568, 266), (564, 288), (554, 304)], g)  # mechones
        cv2.ellipse(img, (505, 150), (24, 18), 0, 180, 360, 255, g, cv2.LINE_AA)  # chongo
        _trazo(img, [(483, 152), (505, 158), (527, 152)], 4)
        _trazo(img, [(474, 292), (466, 318)], g); _trazo(img, [(536, 292), (544, 318)], g)  # cuello
        img[0:318, 1290:1500] = 26
        _trazo(img, [(1350, 268), (1336, 236), (1334, 200), (1348, 168), (1372, 152), (1394, 148), (1416, 152), (1440, 168), (1454, 200), (1452, 236), (1438, 268)], g)
        cv2.ellipse(img, (1394, 150), (26, 20), 0, 180, 360, 255, g, cv2.LINE_AA)  # chongo
        _trazo(img, [(1368, 152), (1394, 160), (1420, 152)], 4)
        _trazo(img, [(1352, 236), (1366, 196), (1386, 164)], 3); _trazo(img, [(1436, 236), (1422, 196), (1402, 164)], 3)  # pelo recogido
        _trazo(img, [(1350, 268), (1372, 276), (1394, 272), (1416, 276), (1438, 268)], g)  # nuca
        _trazo(img, [(1360, 274), (1350, 318)], g); _trazo(img, [(1428, 274), (1437, 318)], g)
    return img


def ruta(contornos, dx, dy, eps, k=1.0):
    partes = []
    for c in contornos:
        if cv2.contourArea(c) < 4:
            continue
        a = cv2.approxPolyDP(c, eps, True).reshape(-1, 2)
        if len(a) >= 3:
            partes.append("M" + " L".join(f"{(x - dx) * k:.0f} {(y - dy) * k:.0f}" for x, y in a) + "Z")
    return "".join(partes)


def procesar(sexo, cfg):
    img = cv2.imread(os.path.join(AQUI, cfg["archivo"]), cv2.IMREAD_GRAYSCALE)
    img[:10 * cfg["escala"] if cfg["escala"] == 1 else 0, :] = 15
    if cfg["escala"] != 1:
        img = cv2.resize(img, None, fx=cfg["escala"], fy=cfg["escala"], interpolation=cv2.INTER_CUBIC)
    img = retocar(img, sexo)
    H = img.shape[0]
    k = 937 / H  # misma escala de salida para ambos dibujos
    lo, hi = cfg["gris"]
    gris = ((img >= lo) & (img <= hi)).astype(np.uint8)
    if cfg["abrir"]:
        gris = cv2.morphologyEx(gris, cv2.MORPH_OPEN, np.ones((cfg["abrir"], cfg["abrir"]), np.uint8))
    blanco = (img >= cfg["blanco"]).astype(np.uint8) * 255
    if cfg["escala"] > 1:  # adelgaza el trazo escalado para que se parezca al del dibujo de hombre
        blanco = cv2.erode(blanco, np.ones((2, 2), np.uint8), iterations=1)
    n, lab, st, cen = cv2.connectedComponentsWithStats(gris, 4)
    minimo = 150 if cfg["escala"] == 1 else 150 * cfg["escala"] ** 2 / 2
    out = {}
    for vista, (x0, y0, x1, _) in cfg["vistas"].items():
        c_ref, refs, zonas = cfg["centro"][vista], cfg["mapa"][vista], []
        for i in range(1, n):
            cx, cy = cen[i]
            if st[i, 4] < minimo or not (x0 <= cx < x1):
                continue
            lado = 1 if cx >= c_ref else -1
            mejor, dist = None, 1e18
            for (rx, ry), mid in refs:
                rx2 = rx if (rx - c_ref) * lado >= 0 or abs(rx - c_ref) < 5 * cfg["escala"] else 2 * c_ref - rx
                d = (rx2 - cx) ** 2 + (ry - cy) ** 2
                if d < dist:
                    mejor, dist = mid, d
            m = (lab == i).astype(np.uint8) * 255
            m = cv2.dilate(m, np.ones((3, 3), np.uint8), iterations=3 if cfg["escala"] > 1 else 2)
            cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            zonas.append([mejor, ruta(cs, x0, y0, 1.0 * cfg["escala"], k)])
        sub = blanco[y0:H, x0:x1]
        cs, _ = cv2.findContours(sub, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
        lineas = ruta(cs, 0, 0, 0.6 * cfg["escala"], k)
        cuerpo = (img[y0:H, x0:x1] > cfg["fondo"]).astype(np.uint8) * 255
        cuerpo = cv2.morphologyEx(cuerpo, cv2.MORPH_CLOSE, np.ones((5 * cfg["escala"], 5 * cfg["escala"]), np.uint8))
        cs, _ = cv2.findContours(cuerpo, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        silueta = ruta([c for c in cs if cv2.contourArea(c) > 5000 * cfg["escala"] ** 2], 0, 0, 1.0 * cfg["escala"], k)
        out[vista] = {"vb": [0, 0, round((x1 - x0) * k), round((H - y0) * k)], "zonas": zonas, "lineas": lineas, "silueta": silueta}
        print(cfg["archivo"], vista, len(zonas), sorted({z[0] or "-" for z in zonas}))
    return out


if __name__ == "__main__":
    res = {s: procesar(s, c) for s, c in CONFIG.items()}
    with open(os.path.join(AQUI, "..", "data", "cuerpo_svg.json"), "w") as f:
        json.dump(res, f, separators=(",", ":"))
