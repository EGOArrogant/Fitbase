"""Crea o recupera la cuenta de administrador desde la terminal (por si olvidaste la contraseña).

Uso (en la carpeta de FitBase, con la app cerrada):
    Windows:      .venv\\Scripts\\python.exe scripts\\crear_admin.py
    Mac / Linux:  .venv/bin/python scripts/crear_admin.py
"""
import getpass
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from werkzeug.security import generate_password_hash  # noqa: E402

import db  # noqa: E402

con = db.conectar()
db.init_db(con)
email = input("Correo del administrador: ").strip().lower()
if "@" not in email:
    sys.exit("Correo no válido.")
pw = getpass.getpass("Nueva contraseña (mínimo 10 caracteres): ")
if len(pw) < 10 or pw != getpass.getpass("Repítela: "):
    sys.exit("La contraseña no cumple o no coincide.")
u = con.execute("SELECT id FROM usuarios WHERE email=?", (email,)).fetchone()
if u:
    con.execute("UPDATE usuarios SET password=?, es_admin=1, rol='entrenador', activo=1 WHERE id=?", (generate_password_hash(pw), u["id"]))
    print("Listo: la cuenta ahora es administrador y tiene la contraseña nueva.")
else:
    nombre = input("Tu nombre: ").strip() or "Administrador"
    uid = db.crear_usuario(con, email, nombre, pw, rol="entrenador", perfil=db.perfil_base())
    con.execute("UPDATE usuarios SET es_admin=1 WHERE id=?", (uid,))
    print("Listo: cuenta de administrador creada.")
con.commit()
