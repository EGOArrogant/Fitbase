"""Genera el cuerpo 3D esculpido (una sola malla con piel continua) para el visor de ejercicios.

Cómo funciona:
1. El cuerpo se describe como formas suaves (elipsoides y conos redondeados) pegadas a los huesos del maniquí:
   núcleo (caja torácica, pelvis, huesos largos) + músculos con nombre. Se funden con "unión suave", que deja
   surcos entre músculos como en una escultura de arcilla.
2. Se convierte en malla con marching cubes, se suaviza (Taubin) y se simplifica.
3. Cada vértice recibe pesos de piel (qué hueso lo mueve), el músculo al que pertenece (para resaltarlo) y dos
   deformaciones (más grasa, más músculo) que el visor mezcla según las mediciones de la persona.

Uso:  pip install scikit-image trimesh fast-simplification scipy
      python scripts/generar_cuerpo3d.py         -> static/cuerpo3d/hombre.bin y mujer.bin
"""
import json
import os
import struct
import sys

import numpy as np

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SALIDA = os.path.join(BASE, "static", "cuerpo3d")

# Orden de huesos: debe coincidir con visor3d.js
HUESOS = ["root", "spine", "chest", "shL", "elL", "manoL", "shR", "elR", "manoR", "hipL", "knL", "anL", "hipR", "knR", "anR"]
BIND_HOMBRO, BIND_CADERA = 35.0, 9.0   # abducción en la pose de amarre (grados)


# ------------------------------------------------------------------ matrices
def T(x, y, z):
    m = np.eye(4); m[:3, 3] = (x, y, z); return m


def Rz(g):
    a = np.radians(g); c, s = np.cos(a), np.sin(a); m = np.eye(4); m[0, 0], m[0, 1], m[1, 0], m[1, 1] = c, -s, s, c; return m


def Rx(g):
    a = np.radians(g); c, s = np.cos(a), np.sin(a); m = np.eye(4); m[1, 1], m[1, 2], m[2, 1], m[2, 2] = c, -s, s, c; return m


def Ry(g):
    a = np.radians(g); c, s = np.cos(a), np.sin(a); m = np.eye(4); m[0, 0], m[0, 2], m[2, 0], m[2, 2] = c, s, -s, c; return m


def esqueleto(mujer):
    aH, aC = (.86, 1.1) if mujer else (1, 1)
    M = {"root": T(0, .97, 0)}
    M["spine"] = M["root"] @ T(0, .06, 0)
    M["chest"] = M["spine"] @ T(0, .26, 0)
    for s, k in ((1, "L"), (-1, "R")):
        M["sh" + k] = M["chest"] @ T(s * .225 * aH, .27, 0) @ Rz(s * BIND_HOMBRO)
        M["el" + k] = M["sh" + k] @ T(0, -.3, 0)
        M["mano" + k] = M["el" + k] @ T(0, -.27, 0)
        M["hip" + k] = M["root"] @ T(s * .095 * aC, -.05, 0) @ Rz(s * BIND_CADERA)
        M["kn" + k] = M["hip" + k] @ T(0, -.44, 0)
        M["an" + k] = M["kn" + k] @ T(0, -.43, 0)
    return M


# ------------------------------------------------------------------ formas
class Forma:
    def __init__(self, hueso, tipo, k, tag, **p):
        self.hueso, self.tipo, self.k, self.tag, self.p = hueso, tipo, k, tag, p

    def mundo(self, M):
        m = M[self.hueso]
        R = m[:3, :3]
        if self.tipo == "e":
            rot = self.p.get("rot", (0, 0, 0))
            Rl = (Rx(rot[0]) @ Ry(rot[1]) @ Rz(rot[2]))[:3, :3]
            self.c = (m @ np.r_[self.p["c"], 1])[:3]; self.r = np.array(self.p["r"], float); self.R = R @ Rl
            lo = self.c - self.r.max(); hi = self.c + self.r.max()
        else:
            self.a = (m @ np.r_[self.p["a"], 1])[:3]; self.b = (m @ np.r_[self.p["b"], 1])[:3]
            self.r1, self.r2 = self.p["r1"], self.p["r2"]
            rr = max(self.r1, self.r2)
            lo = np.minimum(self.a, self.b) - rr; hi = np.maximum(self.a, self.b) + rr
        self.lo, self.hi = lo - self.k - .01, hi + self.k + .01
        return self

    def sdf(self, P):
        if self.tipo == "e":
            q = (P - self.c) @ self.R
            k0 = np.linalg.norm(q / self.r, axis=1); k1 = np.linalg.norm(q / (self.r * self.r), axis=1)
            return np.where(k1 > 1e-9, k0 * (k0 - 1) / np.maximum(k1, 1e-9), -self.r.min())
        a, b, r1, r2 = self.a, self.b, self.r1, self.r2       # cono redondeado (Inigo Quilez)
        ba = b - a; l2 = ba @ ba; rr = r1 - r2; a2 = l2 - rr * rr; il2 = 1 / l2
        pa = P - a; y = pa @ ba; z = y - l2
        x2 = np.sum((pa * l2 - np.outer(y, ba)) ** 2, axis=1); y2 = y * y * l2; z2 = z * z * l2
        k = np.sign(rr) * rr * rr * x2
        d3 = (np.sqrt(np.maximum(x2 * a2 * il2, 0)) + y * rr) * il2 - r1
        d1 = np.sqrt(x2 + z2) * il2 - r2
        d2 = np.sqrt(x2 + y2) * il2 - r1
        return np.where(np.sign(z) * a2 * z2 > k, d1, np.where(np.sign(y) * a2 * y2 < k, d2, d3))


def smin(a, b, k):
    if k <= 0:
        return np.minimum(a, b)
    h = np.maximum(k - np.abs(a - b), 0) / k
    return np.minimum(a, b) - h * h * k * .25


def cuerpo(mujer, f=1.0, m=1.0):
    """Lista de formas. f: factor de grasa; m: factor muscular (1 = base)."""
    L = []
    mb = (.8 if mujer else 1.0) * m          # volumen muscular base
    km = .02 if mujer else .010              # dureza de los surcos entre músculos
    aH, aC, rL = (.86, 1.1, .86) if mujer else (1, 1, 1)
    cf = lambda r: r * f                      # núcleo: crece con la grasa
    mm = lambda r: r * mb * (1 + (f - 1) * .45)

    def E(h, c, r, k, tag=None, rot=(0, 0, 0)):
        L.append(Forma(h, "e", k, tag, c=c, r=r, rot=rot))

    def C(h, a, b, r1, r2, k, tag=None):
        L.append(Forma(h, "c", k, tag, a=a, b=b, r1=r1, r2=r2))

    # ---------------- pelvis (root) ----------------
    E("root", (0, -.015, 0), (cf(.145 * aC), .115, cf(.105)), 0)
    E("root", (0, .03, .03), (cf(.125 * aC), .08, cf(.08)), .05)
    for s in (1, -1):
        E("root", (s * .072 * aC, -.045, -.07), (mm(.078) * aC * (1.1 if mujer else 1), .095 * (1.08 if mujer else 1), mm(.07) * (1.15 if mujer else 1)), km * 1.6, "gluteo", (0, 0, s * 8))
        E("root", (s * .11 * aC, -.0, -.01), (mm(.045), .065, mm(.055)), .03, "gluteo")          # glúteo medio
        if mujer:
            E("root", (s * .135 * aC, -.07, 0), (cf(.05), .08, cf(.07)), .05)                     # cadera
    # ---------------- abdomen (spine) ----------------
    cin = .9 if mujer else 1
    E("spine", (0, .12, -.005), (cf(.125 * cin), .17, cf(.092)), .06)
    for i, y in enumerate((.035, .105, .175)):
        for s in (1, -1):
            E("spine", (s * .032, y, cf(.077)), (mm(.03), .033, mm(.022)), km * .8, "abdomen")
    E("spine", (0, -.03, cf(.07)), (mm(.065), .05, mm(.03)), km, "abdomen")
    for s in (1, -1):
        E("spine", (s * .1 * cin, .09, .01), (mm(.042), .11, mm(.072)), km * 1.3, "oblicuos", (0, 0, s * 6))
        E("spine", (s * .036, .12, -.08), (mm(.028), .15, mm(.03)), km, "erectores")
    if f > 1:   # grasa abdominal y de flancos
        E("spine", (0, .07, .05), (.11 * (f - 1) * 3 + .001, .1, .06 * (f - 1) * 3 + .001), .08)
        for s in (1, -1):
            E("spine", (s * .11, .02, -.01), (.05 * (f - 1) * 3 + .001, .06, .06 * (f - 1) * 3 + .001), .08)
    # ---------------- tórax (chest) ----------------
    E("chest", (0, .12, -.005), (cf(.16 * aH), .2, cf(.115)), .06)
    E("chest", (0, .28, -.01), (cf(.12 * aH), .07, cf(.08)), .06)
    E("chest", (0, .235, 0), (cf(.19 * aH), .075, cf(.1)), .05)                  # clavículas y hombros
    for s in (1, -1):
        E("chest", (s * .19 * aH, .255, -.005), (.055, .048, .062), .04)          # acromion
    for s in (1, -1):
        if mujer:
            E("chest", (s * .072, .17, .085), (mm(.075), .055, mm(.035)), .03, "pectoral", (0, 0, s * 12))
            E("chest", (s * .078, .135, .11), (.062 * f, .06 * f, .058 * f), .035, None, (10, s * 10, 0))   # mama
        else:
            E("chest", (s * .074, .185, .088), (mm(.088), .068, mm(.046)), km, "pectoral", (0, 0, s * 14))
            E("chest", (s * .055, .145, .09), (mm(.06), .035, mm(.035)), km, "pectoral")
        E("chest", (s * .135 * aH, .07, -.04), (mm(.068), .18, mm(.07)), km * 1.4, "dorsal", (0, 0, -s * 24))
        E("chest", (s * .095 * aH, .2, -.095), (mm(.05), .06, mm(.03)), km, "dorsal", (0, 0, s * 20))       # infraespinoso
        E("chest", (s * .05, .16, -.1), (mm(.04), .08, mm(.028)), km, "romboides")
        E("chest", (s * .14 * aH, .1, .05), (mm(.03), .06, mm(.035)), km, "oblicuos", (0, 0, -s * 30))    # serrato
        C("chest", (0, .37, -.03), (s * .18 * aH, .285, -.02), mm(.055) * (.8 if mujer else 1), mm(.042), km * 1.5, "trapecio")
    E("chest", (0, .22, -.1), (mm(.09) * aH, .11, mm(.03)), km, "trapecio")
    # cuello y cabeza
    C("chest", (0, .3, -.01), (0, .43, .005), .062 * rL * (1.12 if not mujer else 1), .053 * rL, .03)
    E("chest", (0, .495, .005), (.083 * rL, .105, .098), .025)
    E("chest", (0, .44, .035), (.06 * rL, .05, .068), .03)
    E("chest", (0, .408, .074), (.024, .022, .02), .02)
    E("chest", (0, .478, .1), (.011, .022, .016), .01, None, (-15, 0, 0))   # nariz
    E("chest", (0, .515, .088), (.058, .013, .02), .015)                    # arco ciliar
    for s in (1, -1):
        E("chest", (s * .085 * rL, .48, -.005), (.012, .028, .02), .01)       # orejas
        E("chest", (s * .045, .465, .075), (.022, .018, .02), .02)            # pómulos
    if mujer:
        E("chest", (0, .515, -.015), (.092, .105, .107), .02, "pelo")
        E("chest", (0, .565, -.085), (.045, .045, .045), .02, "pelo")
        C("chest", (0, .56, -.1), (0, .42, -.13), .028, .018, .02, "pelo")
    else:
        E("chest", (0, .525, -.01), (.087, .082, .1), .012, "pelo")
    # ---------------- brazos ----------------
    for s, k in ((1, "L"), (-1, "R")):
        sh, el, ma = "sh" + k, "el" + k, "mano" + k
        # hombro: deltoides en tres cabezas
        E(sh, (s * .028, -.045, 0), (mm(.055), mm(.085), mm(.06)), km, "deltoide_lat")
        E(sh, (s * .008, -.05, .04), (mm(.045), mm(.08), mm(.042)), km, "deltoide_ant", (-12, 0, 0))
        E(sh, (s * .008, -.05, -.04), (mm(.045), mm(.078), mm(.042)), km, "deltoide_post", (12, 0, 0))
        C(sh, (0, -.03, 0), (0, -.29, 0), .045 * rL * f ** .5, .034 * rL, .03)
        E(sh, (0, -.165, .03), (mm(.036) * rL, .088, mm(.04) * rL), km, "biceps")
        E(sh, (-s * .012, -.135, -.033), (mm(.038) * rL, .105, mm(.038) * rL), km, "triceps")
        E(sh, (s * .026, -.115, -.022), (mm(.028) * rL, .07, mm(.028) * rL), km, "triceps")
        E(sh, (s * .022, -.225, .008), (mm(.024) * rL, .05, mm(.028) * rL), km, "biceps")          # braquial
        # antebrazo
        C(el, (0, .0, 0), (0, -.245, 0), .038 * rL, .025 * rL, .025)
        E(el, (0, 0, -.028), (.022, .025, .02), .015)                                               # olécranon
        E(el, (s * .016, -.06, .014), (mm(.03) * rL, .075, mm(.03) * rL), km, "antebrazo")
        E(el, (-s * .014, -.08, -.002), (mm(.032) * rL, .085, mm(.033) * rL), km, "antebrazo")
        # mano en puño relajado
        E(ma, (0, -.045, .002), (.02 * rL, .048, .04 * rL), .015)
        E(ma, (-s * .002, -.085, .006), (.024 * rL, .022, .038 * rL), .015)
        C(ma, (-s * .012, -.015, .028), (-s * .02, -.06, .042), .012 * rL, .01 * rL, .012)
    # ---------------- piernas ----------------
    for s, k in ((1, "L"), (-1, "R")):
        hp, kn, an = "hip" + k, "kn" + k, "an" + k
        C(hp, (0, -.02, 0), (0, -.42, 0), cf(.082) * rL * (1.12 if mujer else 1), cf(.05) * rL * (1.1 if mujer else 1), .04)
        E(hp, (0, -.19, .052), (mm(.05) * rL, .18, mm(.045)), km, "cuadriceps")                     # recto femoral
        E(hp, (s * .05, -.2, .012), (mm(.054) * rL, .19, mm(.058)), km, "cuadriceps")             # vasto lateral
        E(hp, (-s * .036, -.32, .035), (mm(.047) * rL, .08, mm(.045)), km, "cuadriceps")            # vasto medial (gota)
        E(hp, (s * .018, -.2, -.052), (mm(.05) * rL, .17, mm(.05)), km, "isquios")
        E(hp, (-s * .022, -.22, -.044), (mm(.038) * rL, .15, mm(.04)), km, "isquios")
        E(hp, (-s * .046, -.11, -.005), (mm(.04) * rL, .12, mm(.05)), km * 1.4, "aductores")
        E(hp, (s * .035, -.12, .035), (mm(.025), .1, mm(.025)), km, "cuadriceps", (0, 0, s * 25))   # sartorio/TFL
        E(hp, (0, -.425, .042), (.024, .028, .014), .015)                                          # rótula
        # pierna
        C(kn, (0, 0, 0), (0, -.415, 0), .048 * rL, .029 * rL, .03)
        E(kn, (-s * .022, -.11, -.034), (mm(.04) * rL, .095, mm(.044)), km, "pantorrilla")
        E(kn, (s * .022, -.1, -.03), (mm(.035) * rL, .085, mm(.038)), km, "pantorrilla")
        E(kn, (0, -.2, -.022), (mm(.038) * rL, .1, mm(.028)), km * 1.3, "pantorrilla")              # sóleo
        E(kn, (s * .014, -.15, .03), (mm(.019), .12, mm(.02)), km, "tibial")
        for t in (1, -1):
            E(kn, (t * .028 * rL, -.41, 0), (.018, .02, .02), .012)                                # maléolos
        # pie
        E(an, (0, -.05, -.03), (.03 * rL, .034, .04), .02)
        E(an, (0, -.058, .05), (.043 * rL, .03, .095), .03)
        E(an, (0, -.07, .135), (.042 * rL, .018, .042), .02)
    return L


# ------------------------------------------------------------------ evaluación
def evaluar(formas, P):
    d = np.full(len(P), 1.0)
    for F in formas:
        msk = np.all((P >= F.lo) & (P <= F.hi), axis=1)
        if msk.any():
            d[msk] = smin(d[msk], F.sdf(P[msk]), F.k)
    return d


def malla(formas, paso=.0045):
    from skimage.measure import marching_cubes
    lo = np.min([F.lo for F in formas], axis=0) - .02; hi = np.max([F.hi for F in formas], axis=0) + .02
    n = np.ceil((hi - lo) / paso).astype(int) + 1
    B = 8
    vol = np.ones(n, np.float32)
    nb = np.ceil(n / B).astype(int)
    for i in range(nb[0]):
        xs = lo[0] + paso * np.arange(i * B, min((i + 1) * B, n[0]))
        for j in range(nb[1]):
            ys = lo[1] + paso * np.arange(j * B, min((j + 1) * B, n[1]))
            cx = np.array([[xs.mean(), ys.mean(), lo[2] + paso * (kk * B + B / 2)] for kk in range(nb[2])])
            dc = evaluar(formas, cx)
            for kk in range(nb[2]):
                if dc[kk] > paso * B * 1.8:
                    continue
                zs = lo[2] + paso * np.arange(kk * B, min((kk + 1) * B, n[2]))
                G = np.stack(np.meshgrid(xs, ys, zs, indexing="ij"), -1).reshape(-1, 3)
                vol[i * B:i * B + len(xs), j * B:j * B + len(ys), kk * B:kk * B + len(zs)] = evaluar(formas, G).reshape(len(xs), len(ys), len(zs))
    v, f, _, _ = marching_cubes(vol, 0, spacing=(paso, paso, paso))
    return v + lo, f


def construir(mujer):
    import fast_simplification
    import scipy.sparse as sp
    import trimesh
    M = esqueleto(mujer)
    base = [F.mundo(M) for F in cuerpo(mujer)]
    v, f = malla(base)
    tm = trimesh.Trimesh(v, f, process=True)
    if tm.volume < 0:
        tm.invert()
    tm = max(tm.split(only_watertight=False), key=lambda x: len(x.faces))
    trimesh.smoothing.filter_taubin(tm, lamb=.5, nu=-.53, iterations=14)
    v2, f2 = fast_simplification.simplify(tm.vertices.astype(np.float32), tm.faces.astype(np.int32), target_reduction=.8)
    tm = trimesh.Trimesh(v2, f2, process=True)
    V, Fc = np.asarray(tm.vertices), np.asarray(tm.faces)
    N = np.asarray(tm.vertex_normals)
    print(("mujer" if mujer else "hombre"), "vértices", len(V), "triángulos", len(Fc))
    # distancias a cada forma
    D = np.stack([F.sdf(V) for F in base], 1)
    # músculo de cada vértice
    tags = sorted({F.tag for F in base if F.tag})
    tid = np.zeros(len(V), np.uint8)
    dmin = D.min(1)
    for j, F in enumerate(base):
        if F.tag:
            sel = (D[:, j] <= dmin + .0025) & (tid == 0)
            tid[sel] = tags.index(F.tag) + 1
    # pesos de piel: cercanía a las formas de cada hueso, luego suavizado sobre la malla
    W = np.zeros((len(V), len(HUESOS)))
    sig = .014
    for j, F in enumerate(base):
        b = HUESOS.index(F.hueso)
        W[:, b] = np.maximum(W[:, b], np.exp(-np.maximum(D[:, j], 0) / sig))
    W /= W.sum(1, keepdims=True)
    e = tm.edges_unique
    A = sp.coo_matrix((np.ones(len(e) * 2), (np.r_[e[:, 0], e[:, 1]], np.r_[e[:, 1], e[:, 0]])), shape=(len(V), len(V))).tocsr()
    deg = np.asarray(A.sum(1)).ravel()
    for _ in range(8):
        W = .5 * W + .5 * (A @ W) / deg[:, None]
    idx = np.argsort(-W, 1)[:, :4]
    w = np.take_along_axis(W, idx, 1); w /= w.sum(1, keepdims=True)
    # deformaciones (morph): superficie con más grasa / más músculo, proyectada sobre la normal
    def morph(formas):
        d = evaluar([F.mundo(M) for F in formas], V)
        d = np.where(np.abs(d) > .06, 0, d)          # fuera de toda forma: sin deformación
        return (-d)[:, None] * N
    mg = morph(cuerpo(mujer, f=1.3))
    mm_ = morph(cuerpo(mujer, m=1.25))
    return V, Fc, idx, w, tid, tags, mg, mm_


def guardar(nombre, V, Fc, idx, w, tid, tags, mg, mm_):
    os.makedirs(SALIDA, exist_ok=True)
    meta = json.dumps({"huesos": HUESOS, "tags": tags, "nv": int(len(V)), "nf": int(len(Fc)),
                       "bind": {"hombro": BIND_HOMBRO, "cadera": BIND_CADERA}, "morph_esc": 2e-4}).encode()
    meta += b" " * (-len(meta) % 4)
    q = lambda a: np.clip(np.round(a / 2e-4), -32767, 32767).astype(np.int16)
    w8 = np.round(w * 255).astype(np.int32)
    w8[:, 0] += 255 - w8.sum(1)
    partes = [V.astype(np.float32), Fc.astype(np.uint16 if len(V) < 65536 else np.uint32), idx.astype(np.uint8),
              w8.clip(0, 255).astype(np.uint8), tid, q(mg), q(mm_)]
    with open(os.path.join(SALIDA, nombre + ".bin"), "wb") as fh:
        fh.write(struct.pack("<I", len(meta))); fh.write(meta)
        for a in partes:
            b = a.tobytes(); fh.write(b); fh.write(b"\0" * (-len(b) % 4))
    print("guardado", nombre, os.path.getsize(os.path.join(SALIDA, nombre + ".bin")) // 1024, "KB")


if __name__ == "__main__":
    for mujer in ([False, True] if len(sys.argv) < 2 else [sys.argv[1] == "mujer"]):
        guardar("mujer" if mujer else "hombre", *construir(mujer))
