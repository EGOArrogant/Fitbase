"""Crea un paquete de actualización y su manifiesto.

Uso:  python scripts/crear_paquete.py 2.1.0 "Notas de la versión" --github usuario/repositorio
      python scripts/crear_paquete.py 2.1.0 "Notas de la versión" --repo usuario/repositorio   (archivos en la rama main)
      python scripts/crear_paquete.py 2.1.0 "Notas de la versión" https://tusitio.com/fitapp-2.1.0.zip
1. Cambia el archivo VERSION a la nueva versión.
2. Genera dist/fitapp-2.1.0.zip (sin base de datos, respaldos, claves ni videos).
3. Genera dist/version.json con la firma SHA-256. Sube ambos archivos (por ejemplo a GitHub Releases o tu hosting)
   y apunta FITAPP_UPDATE_URL al version.json en cada computadora que quieras actualizar.
"""
import hashlib
import json
import os
import sys
import zipfile

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)
import actualizador  # noqa: E402

if len(sys.argv) < 2:
    sys.exit(__doc__)
version, notas = sys.argv[1], (sys.argv[2] if len(sys.argv) > 2 else "")
with open(os.path.join(BASE, "VERSION"), "w", encoding="utf-8") as f:
    f.write(version + "\n")
os.makedirs(os.path.join(BASE, "dist"), exist_ok=True)
destino = os.path.join(BASE, "dist", f"fitapp-{version}.zip")
with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
    for raiz, dirs, files in os.walk(BASE):
        rel_raiz = os.path.relpath(raiz, BASE).replace("\\", "/")
        dirs[:] = [d for d in dirs if d not in ("__pycache__", "dist", ".git", "fotos")
                   and not actualizador._protegido((rel_raiz + "/" + d + "/").lstrip("./"))]
        for fn in files:
            rel = os.path.relpath(os.path.join(raiz, fn), BASE).replace("\\", "/")
            if not actualizador._protegido(rel) and not rel.endswith(".pyc"):
                z.write(os.path.join(raiz, fn), "fitapp/" + rel)
sha = hashlib.sha256(open(destino, "rb").read()).hexdigest()
if "--repo" in sys.argv:
    repo = sys.argv[sys.argv.index("--repo") + 1]
    url = f"https://raw.githubusercontent.com/{repo}/main/versiones/fitapp-{version}.zip"
elif "--github" in sys.argv:
    repo = sys.argv[sys.argv.index("--github") + 1]
    url = f"https://github.com/{repo}/releases/download/v{version}/fitapp-{version}.zip"
else:
    url = sys.argv[3] if len(sys.argv) > 3 else f"https://TU-SITIO/fitapp-{version}.zip"
with open(os.path.join(BASE, "dist", "version.json"), "w", encoding="utf-8") as f:
    json.dump({"version": version, "url": url, "sha256": sha, "notas": notas}, f, ensure_ascii=False, indent=2)
print(f"Paquete: {destino}\nSHA-256: {sha}\nManifiesto: dist/version.json")
if "--repo" in sys.argv:
    print(f"\nSube al repositorio (rama main): dist/fitapp-{version}.zip → versiones/fitapp-{version}.zip y dist/version.json → version.json")
elif "--github" in sys.argv:
    print(f"\nAhora en GitHub: Releases > Draft a new release > etiqueta v{version} > sube los 2 archivos de dist/ > Publish.")
