@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Instalar FitBase
cd /d "%~dp0"
echo.
echo  ===== Instalacion de FitBase =====
echo.

call :buscar_python
if not defined PY (
  echo  No se encontro Python 3.10 o superior en esta computadora.
  echo  Nota: el "python" de la Microsoft Store que trae Windows es solo un acceso directo y no sirve.
  echo.
  where winget >nul 2>nul
  if not errorlevel 1 (
    choice /c SN /m " Quieres que FitBase instale Python automaticamente ahora"
    if !errorlevel! equ 1 (
      echo.
      echo  Instalando Python 3.12... puede tardar unos minutos. Si Windows pide permiso, acepta.
      winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
      call :buscar_python
    )
  )
)
if not defined PY (
  echo.
  echo  Instala Python a mano en 3 pasos:
  echo    1. Se abrira la pagina python.org: descarga "Python 3.12" para Windows.
  echo    2. En la PRIMERA pantalla del instalador marca la casilla "Add python.exe to PATH" y pulsa "Install Now".
  echo    3. Al terminar, cierra esta ventana y vuelve a abrir instalar_windows.bat
  echo.
  start "" "https://www.python.org/downloads/windows/"
  pause
  exit /b 1
)
!PY! -c "import sys; print('  Python', sys.version.split()[0], 'encontrado.')"

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys" >nul 2>nul || rmdir /s /q .venv
) else (
  if exist ".venv" rmdir /s /q .venv
)
if not exist ".venv\Scripts\python.exe" (
  echo  Creando entorno de FitBase...
  !PY! -m venv .venv
  if errorlevel 1 (
    echo  No se pudo crear el entorno. Reinstala Python marcando "Add python.exe to PATH" e intenta de nuevo.
    pause
    exit /b 1
  )
)
set "VPY=%~dp0.venv\Scripts\python.exe"
echo  Instalando componentes (1-3 minutos, necesita internet)...
"%VPY%" -m pip install -q --upgrade pip
"%VPY%" -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo.
  echo  No se pudieron instalar los componentes. Revisa tu conexion a internet y vuelve a abrir este archivo.
  pause
  exit /b 1
)
"%VPY%" -m pip install -q -r requirements-opcional.txt >nul 2>nul

echo  Creando acceso directo en el Escritorio...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\FitBase.lnk'); $s.TargetPath='%~dp0iniciar_windows.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%SystemRoot%\System32\shell32.dll,137'; $s.Save()" >nul 2>nul
echo.
choice /c SN /m " Quieres que FitBase arranque solo al encender la computadora"
if !errorlevel! equ 1 (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\FitBase.lnk'); $s.TargetPath='%~dp0iniciar_windows.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()" >nul 2>nul
  echo  Listo: arrancara al iniciar Windows.
)
echo.
echo  ===== Instalacion terminada =====
echo  Abre "FitBase" desde tu Escritorio.
echo  Si Windows pregunta por el Firewall, permite "Redes privadas" para usarla desde tu celular.
echo.
choice /c SN /m " Abrir FitBase ahora"
if !errorlevel! equ 1 start "" "%~dp0iniciar_windows.bat"
exit /b 0

:buscar_python
rem Busca un Python real (3.10+). Ignora el acceso directo de la Microsoft Store.
set "PY="
for %%C in ("py -3" "python" "python3") do (
  if not defined PY (
    %%~C -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul && set "PY=%%~C"
  )
)
if not defined PY for /d %%D in ("%LocalAppData%\Programs\Python\Python3*") do (
  if not defined PY if exist "%%D\python.exe" "%%D\python.exe" -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul && set PY="%%D\python.exe"
)
if not defined PY for /d %%D in ("%ProgramFiles%\Python3*") do (
  if not defined PY if exist "%%D\python.exe" "%%D\python.exe" -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul && set PY="%%D\python.exe"
)
exit /b 0
