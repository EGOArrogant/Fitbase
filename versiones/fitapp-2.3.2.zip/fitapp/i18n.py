"""Idiomas: español de Latinoamérica (original), inglés y francés.

Cómo funciona: las páginas se escriben en español y, si el usuario eligió otro idioma, el HTML ya armado se traduce
frase por frase con los diccionarios de la carpeta idiomas/ (base incluida con la app) e idiomas/auto/ (frases que el
administrador tradujo con IA desde Administración → Idiomas). Lo que aún no tiene traducción se muestra en español y
queda anotado como «faltante» para traducirlo después.
"""
import html as htmlmod
import json
import os
import re
import threading

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(BASE, "idiomas")
AUTO = os.path.join(CARPETA, "auto")
IDIOMAS = {"es": ("Español (Latinoamérica)", "es-419", "ES"), "en": ("English", "en", "EN"), "fr": ("Français", "fr", "FR")}
ORIGEN = "es"
_dic = {}
_patrones = {}
_faltantes = {"en": {}, "fr": {}}
_lock = threading.Lock()
LETRA = re.compile(r"[A-Za-zÁÉÍÓÚÑáéíóúñü¿¡]")
SALTAR = ("script", "style", "textarea", "code", "pre", "svg")
ATRIBUTOS = re.compile(r'\b(placeholder|aria-label|title|alt|data-mensual|data-anual)="([^"]*)"')
SOLO_NUM = re.compile(r"[\d\s.,:;+\-−×/%~±·()$#*≈<>=]*(kcal|kg|g|cm|mm|min|h|d|lpm|mmHg|MXN|RIR|e1RM)?[\d\s.,:;+\-−×/%~±·()$#*≈<>=]*")
TOKEN = re.compile(r"(<!--.*?-->|<[^>]+>)", re.S)


def _leer(ruta):
    try:
        with open(ruta, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def compilar_fuente():
    """idiomas/fuente_ui.txt (es ||| en ||| fr) → idiomas/en.json y fr.json."""
    ruta = os.path.join(CARPETA, "fuente_ui.txt")
    if not os.path.exists(ruta):
        return
    out = {"en": {}, "fr": {}}
    with open(ruta, encoding="utf-8") as fh:
        for linea in fh:
            if not linea.strip() or linea.startswith("#"):
                continue
            partes = [x.strip() for x in linea.rstrip("\n").split("|||")]
            if len(partes) != 3:
                continue
            es, en, fr = partes
            clave = es if es.startswith("re:") else normalizar(es)
            out["en"][clave], out["fr"][clave] = en, fr
    for k, d in out.items():
        with open(os.path.join(CARPETA, k + ".json"), "w", encoding="utf-8") as fh:
            json.dump(d, fh, ensure_ascii=False, indent=0)


def cargar():
    """Carga (o recarga) los diccionarios. Las traducciones automáticas no reemplazan a las revisadas."""
    with _lock:
        for k in IDIOMAS:
            if k == ORIGEN:
                continue
            base = _leer(os.path.join(CARPETA, k + ".json"))
            auto = _leer(os.path.join(AUTO, k + ".json"))
            d = {**auto, **{a: b for a, b in base.items() if not a.startswith("re:")}}
            _dic[k] = d
            _patrones[k] = [(re.compile(a[3:]), b) for a, b in base.items() if a.startswith("re:")]


def normalizar(t):
    return re.sub(r"\s+", " ", t).strip()


def t(texto, lang):
    """Traduce una frase (texto plano). Devuelve el original si no hay traducción."""
    if not texto or lang not in _dic:
        return texto
    clave = normalizar(texto)
    d = _dic[lang]
    if clave in d:
        return d[clave]
    for rx, rep in _patrones.get(lang, ()):
        m = rx.fullmatch(clave)
        if m:
            return re.sub(r"\{(\d)\}", lambda k: t(m.group(int(k.group(1))) or "", lang), rep)
    if LETRA.search(clave) and len(clave) < 400 and not SOLO_NUM.fullmatch(clave):
        f = _faltantes[lang]
        if len(f) < 5000:
            f[clave] = f.get(clave, 0) + 1
    return texto


def _texto(seg, lang):
    crudo = htmlmod.unescape(seg)
    clave = normalizar(crudo)
    if not clave or not LETRA.search(clave):
        return seg
    trad = t(clave, lang)
    if trad == clave:
        return seg
    ini = seg[:len(seg) - len(seg.lstrip())]
    fin = seg[len(seg.rstrip()):]
    return ini + htmlmod.escape(trad, quote=False) + fin


def _attr(m, lang):
    nombre, valor = m.group(1), m.group(2)
    if nombre == "content" and not LETRA.search(valor):
        return m.group(0)
    crudo = htmlmod.unescape(valor)
    trad = t(crudo, lang)
    return m.group(0) if trad == crudo else f'{nombre}="{htmlmod.escape(trad)}"'


def traducir_html(doc, lang):
    if lang not in _dic:
        return doc
    partes = TOKEN.split(doc)
    salto = None
    out = []
    for p in partes:
        if not p:
            continue
        if p.startswith("<"):
            if p.startswith("<!--"):
                out.append(p)
                continue
            m = re.match(r"<(/?)([a-zA-Z0-9]+)", p)
            if m:
                tag = m.group(2).lower()
                if salto:
                    if m.group(1) and tag == salto:
                        salto = None
                    out.append(p)
                    continue
                if not m.group(1) and tag in SALTAR and not p.endswith("/>"):
                    salto = tag
                out.append(ATRIBUTOS.sub(lambda x: _attr(x, lang), p) if not m.group(1) else p)
            else:
                out.append(p)
        else:
            out.append(p if salto else _texto(p, lang))
    return "".join(out)


def faltantes(lang):
    return sorted(_faltantes.get(lang, {}).items(), key=lambda x: -x[1])


def cobertura(lang):
    return len(_dic.get(lang, {}))


def guardar_auto(lang, nuevas):
    os.makedirs(AUTO, exist_ok=True)
    ruta = os.path.join(AUTO, lang + ".json")
    d = _leer(ruta)
    d.update({normalizar(a): b for a, b in nuevas.items() if a and b})
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=0, sort_keys=True)
    os.replace(tmp, ruta)
    for a in nuevas:
        _faltantes.get(lang, {}).pop(normalizar(a), None)
    cargar()
    return len(d)


ESQUEMA = {"type": "object", "properties": {"traducciones": {"type": "array", "items": {
    "type": "object", "properties": {"i": {"type": "integer"}, "t": {"type": "string"}}, "required": ["i", "t"], "additionalProperties": False}}},
    "required": ["traducciones"], "additionalProperties": False}


def traducir_con_ia(frases, lang, modelo):
    """Traduce una lista de frases con Claude (usa la clave ANTHROPIC_API_KEY de la computadora). Devuelve (dict, error)."""
    try:
        import anthropic
    except ImportError:
        return {}, "Falta la librería anthropic."
    destino = IDIOMAS[lang][0]
    numeradas = "\n".join(f"{i}\t{f}" for i, f in enumerate(frases))
    try:
        r = anthropic.Anthropic().messages.create(
            model=modelo, max_tokens=min(16000, 1500 + 120 * len(frases)), output_config={"effort": "low", "format": {"type": "json_schema", "schema": ESQUEMA}},
            system=(f"Traduce textos de la interfaz de una app de entrenamiento y nutrición del español (Latinoamérica) al {destino}. "
                    "Tono cercano y claro, como una app de consumo. Conserva números, unidades, símbolos, emojis y nombres propios "
                    "(FitBase, Coach IA, Pro, Coach, OXXO, SPEI, RIR, ISAK, PAR-Q+). Si una frase es un nombre de ejercicio o alimento, "
                    "usa el nombre común en ese idioma. Devuelve cada traducción con su número."),
            messages=[{"role": "user", "content": numeradas}])
    except Exception as e:  # noqa: BLE001
        return {}, f"No se pudo consultar la IA: {type(e).__name__}."
    if r.stop_reason == "refusal":
        return {}, "La IA no pudo traducir este lote."
    try:
        datos = json.loads(next((b.text for b in r.content if b.type == "text"), "{}"))
    except ValueError:
        return {}, "La IA respondió en un formato inesperado."
    out = {}
    for x in datos.get("traducciones", []):
        if 0 <= x["i"] < len(frases) and x["t"].strip():
            out[frases[x["i"]]] = x["t"].strip()
    return out, None


compilar_fuente()
cargar()
