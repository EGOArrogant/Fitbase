@echo off
chcp 65001 >nul
title FitBase - servidor (no cierres esta ventana)
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Primera vez: se ejecutara el instalador.
  call "%~dp0instalar_windows.bat"
  exit /b
)
set "VPY=%~dp0.venv\Scripts\python.exe"
"%VPY%" -m pip install -q -r requirements.txt
"%VPY%" -m pip install -q -r requirements-opcional.txt >nul 2>nul
set FITAPP_ABRIR=1
"%VPY%" app.py
echo.
echo El servidor se detuvo. Puedes cerrar esta ventana.
pause
