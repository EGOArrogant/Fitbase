#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d .venv ] || { ./instalar_mac_linux.sh || exit 1; }
. .venv/bin/activate
pip install -q -r requirements.txt
pip install -q -r requirements-opcional.txt 2>/dev/null || true
FITAPP_ABRIR=1 python app.py
