"""Menú de la app por categorías, con color e ícono minimalista para cada sección."""
from markupsafe import Markup

# Íconos de línea (24×24, trazo). Sin marcas de terceros.
ICONOS = {
    "inicio": "M4 11l8-7 8 7v9h-5v-6H9v6H4z",
    "diario-hab": "M4 6h16v14H4zM4 10h16M8 3v4M16 3v4M9 15l2 2 4-4",
    "ia": "M12 3l1.8 4.7 4.7 1.8-4.7 1.8L12 16l-1.8-4.7-4.7-1.8 4.7-1.8zM18 15l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z",
    "programa": "M9 3.5h6v3H9zM15 5h3v16H6V5h3M9 11h6M9 15h4",
    "plan": "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18zM12 7a5 5 0 1 0 0 10 5 5 0 1 0 0-10zM12 11a1 1 0 1 0 0 2 1 1 0 1 0 0-2z",
    "pesa": "M3 10v4M6 7v10M9 12h6M18 7v10M21 10v4",
    "cronometro": "M12 8v5l3 2M9 2h6M12 4.5a8 8 0 1 0 0 16 8 8 0 1 0 0-16z",
    "cuerpo": "M12 3a2 2 0 1 0 0 4 2 2 0 1 0 0-4zM6 9h12M12 9v6M12 15l-3 6M12 15l3 6M8 9l-1 5M16 9l1 5",
    "cuadricula": "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
    "pastel": "M12 3v9h9A9 9 0 1 1 12 3zM15 3.5A9 9 0 0 1 20.5 9H15z",
    "intercambio": "M7 7h12l-3-3M17 17H5l3 3",
    "mas": "M12 8v8M8 12h8M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18z",
    "libro": "M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11",
    "estrella": "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z",
    "calendario": "M4 6h16v14H4zM4 10h16M9 10v10M15 10v10M8 3v4M16 3v4",
    "olla": "M4 11h16v1a7 7 0 0 1-7 7h-2a7 7 0 0 1-7-7zM2 11h2M20 11h2M9 7c0-1.5 1.5-1.5 1.5-3M14 7c0-1.5 1.5-1.5 1.5-3",
    "manzana": "M12 7c-3-2-8-1-8 5s4 9 6 9c1 0 1.5-.5 2-.5s1 .5 2 .5c2 0 6-3 6-9s-5-7-8-5zM12 7c0-2 1-4 3-4",
    "tendencia": "M3 17l6-6 4 4 8-8M15 7h6v6",
    "regla": "M3 17L17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2",
    "grupo": "M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 20a6 6 0 0 1 12 0M16 5.5a3 3 0 0 1 0 5.5M18 14a5 5 0 0 1 3 6",
    "pulso": "M3 12h4l2-6 4 12 2-6h6",
    "invitar": "M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 20a6 6 0 0 1 12 0M19 8v6M16 11h6",
    "trofeo": "M8 4h8v5a4 4 0 0 1-8 0zM8 6H4.5v1.5A3.5 3.5 0 0 0 8 11M16 6h3.5v1.5A3.5 3.5 0 0 1 16 11M12 13v4M8 21h8M9.5 17h5v4h-5z",
    "chat": "M4 5h16v11H9l-5 4z",
    "bandera": "M5 21V4M5 4h12l-2 4 2 4H5",
    "bandeja": "M4 13l2-8h12l2 8v6H4zM4 13h5l1 2h4l1-2h5",
    "calculadora": "M6 3h12v18H6zM9 7h6M9 11.5h.01M12 11.5h.01M15 11.5h.01M9 15h.01M12 15h.01M15 15h.01M9 18h.01M12 18h.01M15 18h.01",
    "articulo": "M4 5h13v14H6a2 2 0 0 1-2-2zM17 9h3v8a2 2 0 0 1-2 2M7 9h7M7 13h7M7 16h4",
    "corona": "M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z",
    "capsula": "M9 15l6-6M7.5 16.5a4.2 4.2 0 0 1 0-6l3-3a4.2 4.2 0 0 1 6 6l-3 3a4.2 4.2 0 0 1-6 0z",
    "foco": "M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9V16h7v-2.1A6 6 0 0 0 12 3z",
    "corazon": "M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10zM8 11.5h2l1-2 2 4 1-2h2",
    "check": "M9 3.5h6v3H9zM15 5h3v16H6V5h3M9 13l2 2 4-4",
    "ajustes-l": "M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1M15 4v4M9 10v4M17 16v4",
    "camara": "M4 8h3l2-3h6l2 3h3v11H4zM12 17a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z",
    "ficha": "M4 5h16v14H4zM8 10a2 2 0 1 0 4 0 2 2 0 1 0-4 0M6.5 16a3.5 3.5 0 0 1 7 0M15 9h3M15 13h3",
    "descarga": "M12 4v11M7 10l5 5 5-5M5 20h14",
    "brujula": "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18zM15.5 8.5l-2 5-5 2 2-5z",
    "campana": "M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15zM10 20.5a2 2 0 0 0 4 0",
    "engrane": "M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1",
    "recargar": "M20 12a8 8 0 1 1-2.3-5.6M20 4v5h-5",
    "escudo": "M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z",
    "salir": "M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10",
    "tarjeta": "M3 6h18v12H3zM3 10h18M7 15h4",
    "chevron": "M9 6l6 6-6 6",
    "escudo-hoja": "M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6zM9 13c0-3 3-5 6-5 0 3-2 6-5 6M9 13l3-2",
    "balanza": "M12 4v16M5 20h14M6 8h12M6 8l-3 6a3 3 0 0 0 6 0zM18 8l-3 6a3 3 0 0 0 6 0z",
    "documento": "M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6",
    "bicho": "M9 9a3 3 0 0 1 6 0v6a3 3 0 0 1-6 0zM12 9v9M6 10l3 1M18 10l-3 1M5 15h4M15 15h4M7 20l2-2M17 20l-2-2M10 5l-1-2M14 5l1-2",
}


def ico(nombre, clase="ico"):
    d = ICONOS.get(nombre, ICONOS["cuadricula"])
    return Markup(f'<svg class="{clase}" viewBox="0 0 24 24" aria-hidden="true"><path d="{d}"/></svg>')


# (clave, título, color, ícono, [(endpoint, texto, ícono, endpoints que lo marcan activo, quién lo ve)])
# quién lo ve: None = todos, "entrenador", "admin"
GRUPOS = [
    ("hoy", "Tu día", "gen", "inicio", [
        ("dashboard", "Inicio", "inicio", ("dashboard",), None),
        ("habitos", "Registro diario y hábitos", "diario-hab", ("habitos",), None),
        ("asistente_view", "Coach IA", "ia", ("asistente_view",), None),
    ]),
    ("entrenamiento", "Entrenamiento", "ent", "pesa", [
        ("programa_view", "Mi programa", "programa", ("programa_view",), None),
        ("plan_inteligente", "Mi plan inteligente", "plan", ("plan_inteligente",), None),
        ("entrenar", "Entrenar hoy (elegir músculos)", "pesa", ("entrenar",), None),
        ("sesion_view", "Sesión de hoy", "cronometro", ("sesion_view",), None),
        ("cuerpo", "Mapa muscular", "cuerpo", ("cuerpo",), None),
        ("ejercicios", "Ejercicios", "cuadricula", ("ejercicios", "ejercicio"), None),
    ]),
    ("nutricion", "Nutrición", "nut", "manzana", [
        ("nutricion", "Mi plan", "pastel", ("nutricion",), None),
        ("registrar", "Registrar comida", "mas", ("registrar",), None),
        ("diario", "Diario de comidas", "libro", ("diario", "coach_diario"), None),
        ("puntaje_nutricional", "Puntaje nutricional", "estrella", ("puntaje_nutricional",), None),
        ("menu_semanal", "Menú semanal", "calendario", ("menu_semanal",), None),
        ("dieta_propia", "Dieta por equivalentes", "intercambio", ("dieta_propia", "coach_dieta"), None),
        ("preferencias_alimentarias", "Alergias y tipo de dieta", "escudo-hoja", ("preferencias_alimentarias",), None),
        ("suplementacion", "Mi suplementación", "capsula", ("suplementacion",), None),
        ("recetas", "Recetas", "olla", ("recetas", "receta", "plan_dia", "receta_nueva"), None),
        ("alimentos_view", "Tabla de alimentos", "manzana", ("alimentos_view",), None),
    ]),
    ("progreso", "Progreso", "ana", "tendencia", [
        ("progreso", "Progreso", "tendencia", ("progreso",), None),
        ("mediciones", "Mediciones corporales", "regla", ("mediciones", "coach_mediciones"), None),
        ("fotos_progreso", "Fotos de progreso", "camara", ("fotos_progreso", "coach_fotos"), None),
        ("sondeo_avanzado", "Sondeo avanzado", "ajustes-l", ("sondeo_avanzado", "coach_sondeo_avanzado"), None),
        ("descargas", "Mis descargas (PDF)", "descarga", ("descargas",), None),
    ]),
    ("coach", "Entrenador", "coa", "grupo", [
        ("coach", "Modo entrenador", "grupo", ("coach", "coach_cliente", "coach_expediente"), "entrenador"),
        ("coach_actividad", "Actividad en vivo", "pulso", ("coach_actividad",), "entrenador"),
        ("coach_invitar", "Invitar clientes", "invitar", ("coach_invitar",), "entrenador"),
        ("coach_retos", "Organizar retos", "bandera", ("coach_retos",), "entrenador"),
        ("coach_feedback", "Feedback de clientes", "bandeja", ("coach_feedback",), "entrenador"),
    ]),
    ("comunidad", "Comunidad", "com", "trofeo", [
        ("retos_view", "Retos y niveles", "trofeo", ("retos_view", "reto_detalle"), None),
        ("feedback_view", "Tu opinión (feedback)", "chat", ("feedback_view",), None),
    ]),
    ("aprende", "Aprende", "her", "foco", [
        ("articulos", "Artículos", "articulo", ("articulos", "articulo"), None),
        ("calculadoras", "Calculadoras", "calculadora", ("calculadoras",), None),
        ("suplementos", "Suplementos", "capsula", ("suplementos",), None),
        ("mitos", "Mitos vs evidencia", "foco", ("mitos",), None),
        ("emergencia", "Emergencias", "corazon", ("emergencia",), None),
    ]),
    ("cuenta", "Tu cuenta", "cue", "engrane", [
        ("guia", "Guía de uso", "brujula", ("guia",), None),
        ("notificaciones_view", "Notificaciones", "campana", ("notificaciones_view",), None),
        ("planes", "Planes", "corona", ("planes", "pagar", "pago_ver"), None),
        ("mis_pagos", "Mis pagos", "tarjeta", ("mis_pagos",), None),
        ("sondeo", "Sondeo inicial", "check", ("sondeo",), None),
        ("evaluacion", "Evaluación y perfil", "ficha", ("evaluacion",), None),
        ("privacidad_centro", "Mi privacidad", "escudo", ("privacidad_centro", "consentimiento"), None),
        ("ajustes", "Ajustes y mis datos", "engrane", ("ajustes", "dispositivos"), None),
        ("actualizaciones", "Actualizaciones", "recargar", ("actualizaciones",), None),
    ]),
]
ADMIN_EPS = ("admin_panel", "admin_crear", "admin_pagos", "admin_idiomas", "admin_legal", "admin_diagnostico", "admin_ia")


def menu_para(u, endpoint):
    """Grupos visibles para el usuario, con el ítem activo marcado. Devuelve (grupos, categoría activa)."""
    rol = "admin" if u.get("es_admin") else u.get("rol")
    out, activa = [], None
    for clave, titulo, color, icono, items in GRUPOS:
        vis = []
        for ep, texto, ic, activos, solo in items:
            if solo == "entrenador" and rol not in ("entrenador", "admin"):
                continue
            if solo == "admin" and rol != "admin":
                continue
            on = endpoint in activos
            vis.append({"ep": ep, "texto": texto, "ico": ic, "on": on})
            if on and not activa:
                activa = (clave, color, ic)
        if vis:
            out.append({"clave": clave, "titulo": titulo, "color": color, "ico": icono, "elementos": vis, "abierto": any(i["on"] for i in vis)})
    if endpoint in ADMIN_EPS:
        activa = ("admin", "gen", "escudo")
    return out, activa
