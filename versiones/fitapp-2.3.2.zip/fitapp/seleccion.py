"""Selección inteligente de ejercicios a partir del sondeo inicial.

Cada regla dice qué evitar o preferir, por qué, y en qué se basa. Las reglas no diagnostican:
ante señales de alarma o PAR-Q+ positivo, la app pide valoración médica antes de entrenar.
"""
from data.ejercicios import EJERCICIOS
from data.equipo import ATRIBUTOS, PERFILES_EQUIPO

F = {
    "donnelly": "Donnelly JE et al. ACSM position stand: intervenciones de actividad física para perder peso y no recuperarlo. Med Sci Sports Exerc. 2009;41(2):459-471. doi:10.1249/MSS.0b013e3181949333",
    "oarsi": "Bannuru RR et al. Guías OARSI para el manejo no quirúrgico de la artrosis de rodilla, cadera y poliarticular. Osteoarthritis Cartilage. 2019;27(11):1578-1589. doi:10.1016/j.joca.2019.06.011",
    "hayden": "Hayden JA et al. Ejercicio para el dolor lumbar crónico (revisión Cochrane). 2021. doi:10.1002/14651858.CD009790.pub2",
    "fragala": "Fragala MS et al. Entrenamiento de fuerza en adultos mayores: postura de la NSCA. J Strength Cond Res. 2019;33(8):2019-2052. doi:10.1519/JSC.0000000000003230",
    "oms": "Bull FC et al. Guías de la OMS 2020 sobre actividad física y sedentarismo. Br J Sports Med. 2020;54:1451-1462. doi:10.1136/bjsports-2020-102955",
    "mottola": "Mottola MF et al. Guía canadiense 2019 de actividad física en el embarazo. Br J Sports Med. 2018;52:1339-1346. doi:10.1136/bjsports-2018-100056",
    "giangregorio": "Giangregorio LM et al. Too Fit To Fracture: ejercicio en osteoporosis y fractura vertebral. Osteoporos Int. 2014;25:821-835. doi:10.1007/s00198-013-2523-2",
    "pescatello": "Pescatello LS et al. Actividad física para prevenir y tratar la hipertensión (revisión). Med Sci Sports Exerc. 2019;51(6):1314-1323. doi:10.1249/MSS.0000000000001943",
    "colberg": "Colberg SR et al. Actividad física y diabetes: postura de la ADA. Diabetes Care. 2016;39(11):2065-2079. doi:10.2337/dc16-1728",
    "ratamess": "Ratamess NA et al. ACSM position stand: modelos de progresión en entrenamiento de fuerza. Med Sci Sports Exerc. 2009;41(3):687-708. doi:10.1249/MSS.0b013e3181915670",
}

CARDIO_ORDEN = ["Caminata en caminadora", "Bicicleta estática", "Elíptica", "Caminata inclinada en caminadora", "Remo ergómetro",
                "Natación", "Caminata en agua (aquaeróbics)", "Bicicleta reclinada", "Escaladora", "Correr", "Intervalos en bicicleta (HIIT)",
                "Saltar la cuerda", "Burpees"]


def _imc(p):
    try:
        return p["peso"] / (p["talla"] / 100) ** 2
    except (KeyError, TypeError, ZeroDivisionError):
        return None


def evaluar(p):
    """Devuelve reglas activas, atributos a evitar, preferencias y cardio ordenado para el perfil."""
    s = p.get("sondeo") or {}
    cond = set(p.get("condiciones") or [])
    dolor = set(s.get("dolor") or [])
    imc, peso, edad = _imc(p), p.get("peso") or 0, p.get("edad") or 30
    reglas, evitar, prefer = [], set(), set()
    cardio_bonus, cardio_quitar = {}, set()

    def regla(titulo, texto, fuente, tipo="info"):
        reglas.append({"titulo": titulo, "texto": texto, "fuente": F.get(fuente, fuente), "tipo": tipo})

    if (imc and imc >= 35) or peso >= 120:
        evitar |= {"impacto_alto"}
        cardio_quitar |= {"Correr", "Saltar la cuerda", "Burpees", "Intervalos en bicicleta (HIIT)"}
        for c, b in (("Bicicleta estática", 5), ("Bicicleta reclinada", 5), ("Elíptica", 4), ("Natación", 4), ("Caminata en agua (aquaeróbics)", 4)):
            cardio_bonus[c] = cardio_bonus.get(c, 0) + b
        prefer.add("guiado")
        regla("Cardio de bajo impacto primero",
              "Con un peso corporal alto, correr y saltar multiplican la carga sobre rodillas, tobillos y espalda. Empieza con bicicleta "
              "estática o reclinada, elíptica, caminata o ejercicio en agua. Sube poco a poco hasta 150 min a la semana; para bajar de peso "
              "de forma clara y no recuperarlo, la meta es más de 250 min a la semana junto con la dieta.",
              "Práctica clínica de bajo impacto en obesidad; cantidades: " + F["donnelly"], "aviso")
    elif imc and imc >= 30:
        cardio_quitar |= {"Burpees"}
        cardio_bonus["Elíptica"] = cardio_bonus.get("Elíptica", 0) + 2
        cardio_bonus["Bicicleta estática"] = cardio_bonus.get("Bicicleta estática", 0) + 2
        regla("Progresión de impacto", "Empieza caminando y con bicicleta o elíptica. Si después de 8–12 semanas caminas 30–45 min sin molestias, "
              "puedes probar intervalos cortos de trote.", "donnelly")

    if "rodilla" in dolor:
        evitar |= {"impacto_alto", "rodilla_profunda"}
        cardio_quitar |= {"Correr", "Saltar la cuerda", "Burpees", "Escaladora"}
        cardio_bonus["Bicicleta estática"] = cardio_bonus.get("Bicicleta estática", 0) + 3
        cardio_bonus["Natación"] = cardio_bonus.get("Natación", 0) + 3
        regla("Rodilla: fuerza sí, impacto no",
              "El ejercicio de fuerza es el tratamiento base del dolor de rodilla por artrosis. Usa sentadilla a la silla, prensa en rango cómodo, "
              "extensiones y puentes; evita saltos y sentadillas profundas con carga mientras haya dolor. El dolor al entrenar debe ser leve (≤3/10) "
              "y no aumentar al día siguiente.", "oarsi", "aviso")

    if "espalda" in dolor:
        evitar |= {"carga_axial", "flexion_cargada"}
        prefer.add("guiado")
        cardio_bonus["Bicicleta reclinada"] = cardio_bonus.get("Bicicleta reclinada", 0) + 3
        regla("Espalda baja: muévete, con apoyo",
              "El ejercicio reduce el dolor lumbar crónico. Empieza con bird dog, dead bug, puentes, remo con apoyo de pecho y máquinas; deja para "
              "después la sentadilla y el peso muerto con barra, e introdúcelos con poca carga según tolerancia.", "hayden", "aviso")

    if "cadera" in dolor:
        evitar |= {"impacto_alto"}
        regla("Cadera: fuerza y bajo impacto", "El ejercicio estructurado es tratamiento base del dolor de cadera por artrosis. Prioriza puentes, "
              "abducción con banda o máquina y bicicleta; ajusta el rango de movimiento a lo que no duela.", "oarsi", "aviso")

    if "hombro" in dolor:
        evitar |= {"sobre_cabeza"}
        regla("Hombro: evita empujes por encima de la cabeza por ahora",
              "Prioriza rotaciones externas con banda, face pulls y presses en ángulo bajo. Si el dolor dura más de 2–3 semanas o hay pérdida de fuerza, "
              "consulta a un fisioterapeuta.", "Recomendación práctica de rehabilitación; valoración profesional si persiste", "aviso")

    if edad >= 65:
        prefer |= {"guiado"}
        evitar |= {"tecnica_compleja"}
        regla("Fuerza, equilibrio y potencia después de los 65",
              "Empieza con máquinas y ejercicios estables, 2–3 días por semana, y suma equilibrio (con apoyo al inicio) al menos 3 días. "
              "Cuando tengas base, mueve cargas ligeras con rapidez para ganar potencia.", "fragala")
        regla("Actividad multicomponente", "Combina fuerza, equilibrio y aeróbico; cualquier actividad es mejor que nada.", "oms")

    if "embarazo" in cond:
        evitar |= {"supino", "prono", "equilibrio", "impacto_alto", "flexion_cargada"}
        cardio_quitar |= {"Correr", "Saltar la cuerda", "Burpees", "Intervalos en bicicleta (HIIT)"}
        cardio_bonus["Caminata en caminadora"] = cardio_bonus.get("Caminata en caminadora", 0) + 3
        cardio_bonus["Natación"] = cardio_bonus.get("Natación", 0) + 3
        regla("Embarazo: activa y segura",
              "Meta de 150 min por semana de actividad moderada (prueba del habla). Evita acostarte boca arriba si te mareas, deportes con riesgo de caída "
              "y ejercicios boca abajo. Detente ante sangrado, pérdida de líquido, contracciones, mareo o dolor en el pecho.", "mottola", "riesgo")

    if "osteoporosis" in cond:
        evitar |= {"flexion_cargada"}
        regla("Osteoporosis: fuerza y equilibrio, sin flexionar la columna con carga",
              "Se recomienda entrenamiento de fuerza progresivo y de equilibrio. Evita abdominales tipo crunch, giros con carga y tocar las puntas "
              "de los pies; usa planchas, bird dog y puentes.", "giangregorio", "aviso")

    if "hipertension" in cond:
        regla("Presión alta: respira y deja repeticiones en reserva",
              "La actividad física baja la presión arterial. No aguantes la respiración al empujar, deja 2–3 repeticiones en reserva en los básicos "
              "y haz aeróbico la mayoría de los días. Con presión ≥160/100 o síntomas, consulta antes de entrenar intenso.", "pescatello", "aviso")

    if "diabetes" in cond:
        regla("Diabetes: combina aeróbico y fuerza",
              "Lo ideal es hacer ambos. Interrumpe el tiempo sentado cada 30 min con movimiento ligero, revisa tus pies y lleva una fuente de azúcar "
              "si usas insulina o medicamentos que bajan la glucosa.", "colberg")

    if s.get("suelo") == "no":
        evitar |= {"suelo"}
        regla("Sin ejercicios en el suelo por ahora", "Usamos versiones de pie, en banco o en máquina. Practicar sentarte y levantarte de una silla "
              "es un buen primer paso.", "Recomendación práctica de adaptación")

    if s.get("camina10") == "no":
        cardio_quitar |= {"Correr", "Saltar la cuerda", "Burpees", "Intervalos en bicicleta (HIIT)", "Escaladora", "Remo ergómetro"}
        regla("Empieza con bloques cortos", "Haz 3–5 bloques de 3–5 min de caminata o bicicleta con descansos, y suma 1–2 min por semana. "
              "Si sientes dolor en el pecho, falta de aire desproporcionada o mareo, detente y consulta.", "oms", "aviso")

    if p.get("nivel") == "Principiante":
        prefer.add("guiado")
        evitar.add("tecnica_compleja")
        regla("Principiante: primero patrones estables",
              "Las primeras 4–8 semanas usa máquinas, mancuernas y peso corporal, 2–3 días por semana, dejando 2–3 repeticiones en reserva. "
              "Los básicos con barra llegan cuando domines la técnica.", "ratamess")

    if any(p.get("parq") or []):
        regla("PAR-Q+ con alguna respuesta positiva", "Antes de entrenar intenso, consulta a tu médico. Mientras tanto, mantente en intensidad ligera a moderada.",
              "PAR-Q+ (cuestionario de aptitud para la actividad física)", "riesgo")

    cardio = []
    for i, n in enumerate(CARDIO_ORDEN):
        if n in cardio_quitar or n not in EJERCICIOS:
            continue
        if ATRIBUTOS[n]["impacto_alto"] and "impacto_alto" in evitar:
            continue
        cardio.append((n, cardio_bonus.get(n, 0) * 10 - i))
    cardio.sort(key=lambda x: -x[1])
    return {"reglas": reglas, "evitar": evitar, "prefer": prefer, "cardio": [n for n, _ in cardio][:5],
            "cardio_evitar": sorted(cardio_quitar), "imc": imc}


def permitido(nombre, ev):
    """(True/False, motivo) según los atributos del ejercicio y lo que el perfil debe evitar."""
    a = ATRIBUTOS.get(nombre, {})
    motivos = {"impacto_alto": "alto impacto", "carga_axial": "carga pesada sobre la columna", "flexion_cargada": "flexión de columna con carga",
               "sobre_cabeza": "empuje sobre la cabeza", "supino": "boca arriba", "prono": "boca abajo", "equilibrio": "requiere equilibrio",
               "rodilla_profunda": "flexión profunda de rodilla con carga", "suelo": "en el suelo", "tecnica_compleja": "técnica compleja"}
    malos = [motivos[k] for k in ev["evitar"] if a.get(k)]
    return (not malos, ", ".join(malos))


def equipo_disponible(p):
    s = p.get("sondeo") or {}
    if s.get("equipo"):
        return set(s["equipo"])
    return set(PERFILES_EQUIPO.get(p.get("equipo") or "Gimnasio completo", PERFILES_EQUIPO["Gimnasio completo"]))
