"""Antropometría básica y avanzada (protocolo ISAK).

Fórmulas revisadas en la investigación del proyecto (módulo 6), con las correcciones de los errores del curso:
- Durnin & Womersley 1974 (4 pliegues, coeficientes por edad y sexo) + Siri 1961.
- Jackson & Pollock 1978 (hombres) y Jackson, Pollock & Ward 1980 (mujeres), 3 pliegues.
- Yuhasz modificada por Carter (Σ6).
- Somatotipo antropométrico de Heath & Carter 1967 (mínimo 0.1 por componente; central si ninguno difiere >1).
- Masa muscular esquelética de Lee et al. 2000 (con pliegues y modelo peso-talla).
- Masa ósea de von Döbeln modificada por Rocha 1975; residual de Würch; muscular por diferencia (De Rose & Guimarães).
- Complexión por índice talla/muñeca (Grant).
- Riesgo: cintura (NOM-008-SSA3-2017: ≥90 H, ≥80 M), ICC (OMS: ≥0.90 H, ≥0.85 M), ICE ≥0.5.
Todas son estimaciones de campo con error individual; sirven sobre todo para comparar a la misma persona en el tiempo.
"""
import math

import calc

PLIEGUES = [("triceps", "Tríceps"), ("subescapular", "Subescapular"), ("biceps", "Bíceps"), ("cresta", "Cresta ilíaca"),
            ("supraespinal", "Supraespinal"), ("abdominal", "Abdominal"), ("muslo", "Muslo frontal"), ("pantorrilla", "Pantorrilla medial"),
            ("pectoral", "Pectoral (solo hombres, Jackson-Pollock)")]
PERIMETROS = [("brazo_relajado", "Brazo relajado"), ("brazo_contraido", "Brazo flexionado y contraído"), ("muslo_medio", "Muslo medio"),
              ("pantorrilla_max", "Pantorrilla máxima")]
DIAMETROS = [("humero", "Húmero (biepicondilar)"), ("femur", "Fémur (bicondilar)"), ("biestiloideo", "Muñeca (biestiloideo)")]
BASICOS = [("peso", "Peso", "kg"), ("talla", "Estatura", "cm"), ("cintura", "Cintura", "cm"), ("cadera", "Cadera", "cm"),
           ("cuello", "Cuello", "cm"), ("muneca", "Perímetro de muñeca", "cm"), ("grasa_bia", "% de grasa por báscula de bioimpedancia (opcional)", "%")]


def _n(d, k):
    return calc.num(d.get(k))


def durnin(sexo, edad, d):
    s4 = [_n(d, k) for k in ("biceps", "triceps", "subescapular", "cresta")]
    if not all(s4):
        return None
    L = math.log10(sum(s4))
    if sexo == "Hombre":
        tabla = [(20, 1.1620, .0630), (30, 1.1631, .0632), (40, 1.1422, .0544), (50, 1.1620, .0700), (999, 1.1715, .0779)]
    else:
        tabla = [(20, 1.1549, .0678), (30, 1.1599, .0717), (40, 1.1423, .0632), (50, 1.1333, .0612), (999, 1.1339, .0645)]
    c, m = next((c, m) for lim, c, m in tabla if edad < lim)
    dens = c - m * L
    return (4.95 / dens - 4.50) * 100


def jackson_pollock3(sexo, edad, d):
    if sexo == "Hombre":
        s = [_n(d, k) for k in ("pectoral", "abdominal", "muslo")]
        if not all(s):
            return None
        S = sum(s)
        dens = 1.10938 - 0.0008267 * S + 0.0000016 * S ** 2 - 0.0002574 * edad
    else:
        s = [_n(d, k) for k in ("triceps", "cresta", "muslo")]
        if not all(s):
            return None
        S = sum(s)
        dens = 1.0994921 - 0.0009929 * S + 0.0000023 * S ** 2 - 0.0001392 * edad
    return (4.95 / dens - 4.50) * 100


def sumas(d):
    s6k = ("triceps", "subescapular", "supraespinal", "abdominal", "muslo", "pantorrilla")
    s6 = [_n(d, k) for k in s6k]
    out = {"s6": sum(s6) if all(s6) else None}
    extra = [_n(d, "biceps"), _n(d, "cresta")]
    out["s8"] = out["s6"] + sum(extra) if out["s6"] and all(extra) else None
    return out


def carter_yuhasz(sexo, s6):
    if not s6:
        return None
    return 0.1051 * s6 + 2.585 if sexo == "Hombre" else 0.1548 * s6 + 3.580


def somatotipo(peso, talla, d):
    tri, sub, sup = _n(d, "triceps"), _n(d, "subescapular"), _n(d, "supraespinal")
    hum, fem, bc, pt, plp = _n(d, "humero"), _n(d, "femur"), _n(d, "brazo_contraido"), _n(d, "pantorrilla_max"), _n(d, "pantorrilla")
    if not all([tri, sub, sup, hum, fem, bc, pt, plp, peso, talla]):
        return None
    X = (tri + sub + sup) * 170.18 / talla
    endo = -0.7182 + 0.1451 * X - 0.00068 * X ** 2 + 0.0000014 * X ** 3
    meso = 0.858 * hum + 0.601 * fem + 0.188 * (bc - tri / 10) + 0.161 * (pt - plp / 10) - 0.131 * talla + 4.5
    hwr = talla / peso ** (1 / 3)
    ecto = 0.732 * hwr - 28.58 if hwr >= 40.75 else (0.463 * hwr - 17.63 if hwr > 38.25 else 0.1)
    endo, meso, ecto = (max(0.1, v) for v in (endo, meso, ecto))
    return {"endo": endo, "meso": meso, "ecto": ecto, "x": ecto - endo, "y": 2 * meso - (endo + ecto), "hwr": hwr,
            "categoria": categoria(endo, meso, ecto)}


def categoria(en, me, ec):
    v = {"endo": en, "meso": me, "ecto": ec}
    if max(v.values()) - min(v.values()) <= 1.0:
        return "Central"
    orden = sorted(v, key=v.get, reverse=True)
    a, b, c = orden
    nombre = {"endo": "endomorfo", "meso": "mesomorfo", "ecto": "ectomorfo"}
    pref = {"endo": "endo", "meso": "meso", "ecto": "ecto"}
    if v[a] - v[b] <= 0.5:  # dos dominantes iguales
        par = {frozenset(("endo", "meso")): "Mesomorfo-endomorfo", frozenset(("meso", "ecto")): "Mesomorfo-ectomorfo",
               frozenset(("endo", "ecto")): "Endomorfo-ectomorfo"}
        return par[frozenset((a, b))]
    if v[b] - v[c] <= 0.5:
        return f"{nombre[a].capitalize()} balanceado"
    return f"{pref[b].capitalize()}-{nombre[a]}"


def lee(sexo, edad, talla, d, peso=None):
    """Masa muscular esquelética (kg). Con perímetros y pliegues; si faltan, modelo peso-talla."""
    s = 1 if sexo == "Hombre" else 0
    br, tri, mu, plm, pa, plp = (_n(d, k) for k in ("brazo_relajado", "triceps", "muslo_medio", "muslo", "pantorrilla_max", "pantorrilla"))
    if all([br, tri, mu, plm, pa, plp, talla]):
        cag, ctg, ccg = br - math.pi * tri / 10, mu - math.pi * plm / 10, pa - math.pi * plp / 10
        return talla / 100 * (0.00744 * cag ** 2 + 0.00088 * ctg ** 2 + 0.00441 * ccg ** 2) + 2.4 * s - 0.048 * edad + 7.8, "Lee 2000 (perímetros y pliegues)"
    if peso and talla:
        return 0.244 * peso + 7.80 * talla / 100 - 0.098 * edad + 6.6 * s - 3.3, "Lee 2000 (modelo peso-talla)"
    return None, None


def rocha(talla, d):
    be, fem = _n(d, "biestiloideo"), _n(d, "femur")
    if not all([talla, be, fem]):
        return None
    return 3.02 * ((talla / 100) ** 2 * (be / 100) * (fem / 100) * 400) ** 0.712


def complexion(sexo, talla, muneca):
    if not (talla and muneca):
        return None, None
    r = talla / muneca
    if sexo == "Hombre":
        c = "Pequeña" if r > 10.4 else ("Mediana" if r >= 9.6 else "Grande")
    else:
        c = "Pequeña" if r > 11.0 else ("Mediana" if r >= 10.1 else "Grande")
    return r, c


def calcular(p, d):
    """p: perfil (sexo, edad); d: datos de la medición. Devuelve todos los indicadores disponibles."""
    sexo, edad = p.get("sexo", "Hombre"), p.get("edad") or 30
    peso, talla = _n(d, "peso") or p.get("peso"), _n(d, "talla") or p.get("talla")
    cint, cad, cue = _n(d, "cintura"), _n(d, "cadera"), _n(d, "cuello")
    r = {"peso": peso, "talla": talla, "imc": calc.imc(peso, talla) if peso and talla else None}
    r["imc_clase"] = calc.imc_clase(r["imc"]) if r["imc"] else None
    r["ice"] = cint / talla if cint and talla else None
    r["icc"] = cint / cad if cint and cad else None
    r["riesgo_cintura"] = (cint >= (90 if sexo == "Hombre" else 80)) if cint else None
    r["riesgo_icc"] = (r["icc"] >= (0.90 if sexo == "Hombre" else 0.85)) if r["icc"] else None
    navy = calc.grasa_navy(sexo, talla, cue, cint, cad)
    r["grasa_navy"] = navy * 100 if navy else None
    r["grasa_bia"] = _n(d, "grasa_bia")
    r["grasa_dw"] = durnin(sexo, edad, d)
    r["grasa_jp3"] = jackson_pollock3(sexo, edad, d)
    r.update(sumas(d))
    r["grasa_carter"] = carter_yuhasz(sexo, r["s6"])
    # % de grasa de referencia: DW > JP3 > bioimpedancia > Marina
    for k, nombre in (("grasa_dw", "Durnin-Womersley"), ("grasa_jp3", "Jackson-Pollock 3"), ("grasa_bia", "Bioimpedancia"), ("grasa_navy", "Marina EE. UU.")):
        if r.get(k):
            r["grasa"], r["grasa_metodo"] = r[k], nombre
            break
    else:
        r["grasa"], r["grasa_metodo"] = None, None
    if r["grasa"] and peso:
        r["masa_grasa"] = peso * r["grasa"] / 100
        r["mlg"] = peso - r["masa_grasa"]
        r["ffmi"] = r["mlg"] / (talla / 100) ** 2
        r["ffmi_norm"] = r["ffmi"] + 6.1 * (1.8 - talla / 100)
    r["smm"], r["smm_metodo"] = lee(sexo, edad, talla, d, peso)
    r["osea"] = rocha(talla, d)
    r["residual"] = peso * (0.241 if sexo == "Hombre" else 0.209) if peso else None
    if r.get("osea") and r.get("masa_grasa"):
        r["muscular_derose"] = peso - r["masa_grasa"] - r["osea"] - r["residual"]
    r["complexion_r"], r["complexion"] = complexion(sexo, talla, _n(d, "muneca"))
    r["somatotipo"] = somatotipo(peso, talla, d)
    return r


def somatocarta_svg(puntos, tam=300):
    """Somatocarta: X = ecto − endo, Y = 2·meso − (endo + ecto). puntos: lista de (x, y, etiqueta)."""
    W = H = tam
    sx = lambda x: W / 2 + x * W / 21
    sy = lambda y: H * 18 / 28 - y * H / 28
    s = [f'<svg viewBox="0 0 {W} {H}" class="somatocarta" role="img" aria-label="Somatocarta">']
    # contorno aproximado (triángulo curvo de Reuleaux)
    a, b, c = (sx(0), sy(16)), (sx(-8), sy(-8)), (sx(8), sy(-8))
    s.append(f'<path d="M{a[0]},{a[1]} Q{sx(-7.5)},{sy(5.5)} {b[0]},{b[1]} Q{sx(0)},{sy(-12)} {c[0]},{c[1]} Q{sx(7.5)},{sy(5.5)} {a[0]},{a[1]}Z" '
             f'fill="var(--surface-2)" stroke="var(--border)" stroke-width="1.5"/>')
    s.append(f'<line x1="{sx(0)}" y1="{sy(16)}" x2="{sx(0)}" y2="{sy(0)}" stroke="var(--border)"/>'
             f'<line x1="{sx(-8)}" y1="{sy(-8)}" x2="{sx(0)}" y2="{sy(0)}" stroke="var(--border)"/><line x1="{sx(8)}" y1="{sy(-8)}" x2="{sx(0)}" y2="{sy(0)}" stroke="var(--border)"/>')
    s.append(f'<text x="{sx(0)}" y="{sy(16) - 8}" text-anchor="middle" font-size="12" fill="var(--text-2)">Mesomorfo</text>'
             f'<text x="{sx(-7)}" y="{sy(-8) + 18}" text-anchor="middle" font-size="12" fill="var(--text-2)">Endomorfo</text>'
             f'<text x="{sx(7)}" y="{sy(-8) + 18}" text-anchor="middle" font-size="12" fill="var(--text-2)">Ectomorfo</text>')
    for i, (x, y, et) in enumerate(puntos):
        ultimo = i == len(puntos) - 1
        s.append(f'<circle cx="{sx(x):.1f}" cy="{sy(y):.1f}" r="{6 if ultimo else 4}" fill="{"var(--accent)" if ultimo else "var(--muted)"}" stroke="var(--surface)" stroke-width="2"><title>{et}</title></circle>')
    if len(puntos) > 1:
        s.append('<polyline fill="none" stroke="var(--accent)" stroke-dasharray="3 3" points="' + " ".join(f"{sx(x):.1f},{sy(y):.1f}" for x, y, _ in puntos) + '"/>')
    s.append("</svg>")
    return "".join(s)
