#!/usr/bin/env bash
# Instalación de FitBase en macOS o Linux.
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"
echo; echo " ===== Instalación de FitBase ====="; echo
if ! command -v python3 >/dev/null 2>&1; then
  echo " No se encontró Python 3. Instálalo desde https://www.python.org/downloads/ (Mac) o con tu gestor de paquetes (Linux)."; exit 1
fi
python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" || { echo " Necesitas Python 3.10 o superior."; exit 1; }
[ -d .venv ] || { echo " Creando entorno virtual..."; python3 -m venv .venv; }
. .venv/bin/activate
echo " Instalando dependencias..."
python -m pip install -q --upgrade pip
pip install -q -r requirements.txt
pip install -q -r requirements-opcional.txt 2>/dev/null || echo " (Lector de códigos desde foto no disponible; lo demás funciona.)"
chmod +x iniciar_mac_linux.sh
if [ "$(uname)" = "Darwin" ]; then
  LANZ="$HOME/Desktop/FitBase.command"
  printf '#!/bin/bash\n"%s/iniciar_mac_linux.sh"\n' "$DIR" > "$LANZ"; chmod +x "$LANZ"
  echo " Acceso directo creado: Escritorio/FitBase.command"
else
  mkdir -p "$HOME/.local/share/applications"
  cat > "$HOME/.local/share/applications/fitbase.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=FitBase
Exec=bash -c '"$DIR/iniciar_mac_linux.sh"'
Terminal=true
Categories=Utility;
DESK
  [ -d "$HOME/Desktop" ] && cp "$HOME/.local/share/applications/fitbase.desktop" "$HOME/Desktop/" && chmod +x "$HOME/Desktop/fitbase.desktop" || true
  echo " Acceso directo creado en el menú de aplicaciones."
fi
echo; echo " Instalación terminada. Para abrir: doble clic en FitBase o ejecuta ./iniciar_mac_linux.sh"
