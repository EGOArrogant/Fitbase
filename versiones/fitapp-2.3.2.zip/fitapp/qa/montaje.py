"""Uso: python qa/montaje.py salida.png archivo1 archivo2 ...  -> hoja de contactos con etiquetas (para revisar acercamientos)."""
import sys
from PIL import Image, ImageDraw
out = sys.argv[1]; fs = sys.argv[2:]
ims = []
for f in fs:
    im = Image.open(f).convert('RGB'); s = min(1, 150 / im.height * 1.0, 420 / im.width) if im.height > 150 or im.width > 420 else 1
    im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s)))); ims.append((f.split('/')[-1], im))
W = 1500; x = y = 0; rowh = 0; pos = []
for n, im in ims:
    if x + im.width > W: x = 0; y += rowh + 16; rowh = 0
    pos.append((x, y)); x += im.width + 10; rowh = max(rowh, im.height)
sheet = Image.new('RGB', (W, y + rowh + 16), 'white'); d = ImageDraw.Draw(sheet)
for (n, im), (x, y) in zip(ims, pos):
    sheet.paste(im, (x, y + 12)); d.text((x, y), n.replace('_antes', '')[:40], fill=(200, 0, 0))
sheet.save(out)
