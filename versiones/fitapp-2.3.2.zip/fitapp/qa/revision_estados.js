// Estados de interfaz: drawer, categorías, tabbar, toast, notificaciones, acceso rápido, guía (modal). Uso: node qa/revision_estados.js tag
const { chromium, devices } = require('playwright');
const OUT = '/home/user/fitapp/qa/salida/visual_todas';
const TAG = process.argv[2] || 'antes';
const VIS = { ios: { ...devices['iPhone 14 Pro Max'], deviceScaleFactor: 1 }, and: { viewport: { width: 360, height: 780 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true }, tab: { viewport: { width: 1024, height: 1366 }, deviceScaleFactor: 1 }, pc: { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 } };
(async () => {
  const br = await chromium.launch();
  for (const [v, o] of Object.entries(VIS)) for (const t of ['light', 'dark']) {
    const c = await br.newContext({ ...o, colorScheme: t });
    await c.addInitScript(t => { try { localStorage.setItem('tema', t); } catch (e) { } }, t);
    const p = await c.newPage();
    await p.goto('http://localhost:5002/login'); await p.fill('form:has([name=password]) [name=email]', 'lucia.qa@example.com'); await p.fill('form:has([name=password]) [name=password]', 'Lucia2026!');
    await Promise.all([p.waitForLoadState('load'), p.click('form:has([name=password]) button')]); await p.waitForTimeout(700);
    const n = s => `${OUT}/estado_${s}_${v}_${t === 'light' ? 'claro' : 'oscuro'}_${TAG}.png`;
    const ir = async u => { await p.goto('http://localhost:5002' + u); await p.waitForTimeout(500); };
    const cerrarGuia = async () => { if (await p.locator('.guia-capa').count()) { await p.screenshot({ path: n('guia_modal') }); await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
    await ir('/app'); await cerrarGuia();
    await p.screenshot({ path: n('inicio_vista') });
    // toast
    await p.evaluate(() => { const T = document.querySelector('.toasts'); if (!T) return; for (const [ti, tx] of [['Nueva rutina asignada', 'Tu coach te asignó «Cuerpo completo A» para esta semana.'], ['Reto completado', '']]) { const a = document.createElement('a'); a.className = 'toast'; a.href = '#'; a.innerHTML = '<span class="toast-ic">🏆</span><span><b>' + ti + '</b>' + (tx ? '<small>' + tx + '</small>' : '') + '</span>'; T.appendChild(a); requestAnimationFrame(() => a.classList.add('on')); } });
    await p.waitForTimeout(300); await p.screenshot({ path: n('toast') });
    await p.evaluate(() => document.querySelectorAll('.toasts .toast').forEach(e => e.remove()));
    // drawer / menú lateral
    const mv = v === 'ios' || v === 'and' || v === 'tab';
    if (mv && await p.locator('.topbar [data-menu]').first().isVisible()) {
      await p.locator('.topbar [data-menu]').first().click(); await p.waitForTimeout(500);
      await p.screenshot({ path: n('drawer') });
      // abrir categoría (menú de categorías) y bajar
      const g = p.locator('.side details.ngrupo').nth(1); if (await g.count()) { await g.locator('summary').click(); await p.waitForTimeout(300); }
      await p.screenshot({ path: n('drawer_categoria') });
      await p.locator('.side').evaluate(e => e.scrollTo(0, e.scrollHeight)); await p.waitForTimeout(250); await p.screenshot({ path: n('drawer_fondo') });
      await p.keyboard.press('Escape'); await p.evaluate(() => document.body.classList.remove('menu-abierto')); await p.waitForTimeout(300);
    } else { // escritorio: menú expandido
      await p.evaluate(() => { document.body.classList.remove('menu-riel'); }); await p.waitForTimeout(300); await p.screenshot({ path: n('menu_expandido') });
      await p.evaluate(() => { document.body.classList.add('menu-riel'); });
    }
    // acceso rápido (CTA)
    const cta = p.locator('.side [data-rapido]').first();
    if (v === 'pc' || v === 'tab') { if (await cta.isVisible()) { await cta.hover().catch(() => { }); await cta.click({ trial: false }).catch(() => { }); await p.waitForTimeout(300); await p.screenshot({ path: n('rapido') }); await p.keyboard.press('Escape'); } }
    else { const tab = p.locator('.tabbar .tab-cta'); await tab.click().catch(() => { }); await p.waitForTimeout(300); await p.screenshot({ path: n('tab_registrar') }); await p.goBack().catch(() => { }); }
    // notificaciones (panel)
    await ir('/app');
    const nb = p.locator((v === 'pc' || v === 'tab') ? '.side [data-notif]' : '.topbar [data-notif]').first();
    if (await nb.isVisible()) { await nb.click({ force: true }).catch(() => { }); await p.waitForTimeout(500); await p.screenshot({ path: n('notif_panel') }); }
    // modal de la guía de uso
    await ir('/guia'); await p.waitForTimeout(500); await p.screenshot({ path: n('guia') });
    await c.close();
  }
  await br.close();
})();
