const { chromium, devices } = require('playwright');
(async()=>{const br=await chromium.launch();const c=await br.newContext({...devices['iPhone 14 Pro Max']});const p=await c.newPage();
await p.goto('http://localhost:5001/login');await p.fill('form:has([name=password]) [name=email]','demo@fitapp.local');await p.fill('form:has([name=password]) [name=password]','demo1234');await Promise.all([p.waitForLoadState('load'),p.click('form:has([name=password]) button')]);await p.waitForTimeout(900);if(await p.locator('.guia-capa').count())await p.keyboard.press('Escape');
for(const u of ['/ejercicios','/suplementos']){await p.goto('http://localhost:5001'+u);await p.waitForTimeout(400);
console.log(u,await p.evaluate(()=>{const vw=document.documentElement.clientWidth;const o=[];document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.right>vw+0.5&&r.width>0)o.push(e.tagName+'.'+e.className+' '+r.right.toFixed(1)+' w'+r.width.toFixed(0))});return [vw,document.documentElement.scrollWidth,o.slice(0,8)]}))}
await p.goto('http://localhost:5001/app');await p.waitForTimeout(300);await p.click('button[data-menu]:visible');await p.waitForTimeout(500);
console.log('side',await p.evaluate(()=>JSON.stringify(document.querySelector('.side').getBoundingClientRect())),await p.evaluate(()=>document.body.className));
console.log(await p.evaluate(()=>[...document.querySelectorAll('[data-cerrar-menu]')].map(e=>e.className+' '+JSON.stringify(e.getBoundingClientRect())+' hid:'+e.hidden)));
await p.locator('[data-cerrar-menu]:visible').first().click();await p.waitForTimeout(600);
console.log('side2',await p.evaluate(()=>JSON.stringify(document.querySelector('.side').getBoundingClientRect())),await p.evaluate(()=>document.body.className));
await p.goto('http://localhost:5001/guia');await p.waitForTimeout(500);console.log((await p.locator('main').innerText()).slice(0,600));console.log(await p.evaluate(()=>[...document.querySelectorAll('main button,main a')].map(e=>e.textContent.trim().slice(0,25)).slice(0,20)));
await p.goto('http://localhost:5001/planes');console.log(await p.evaluate(()=>[...document.querySelectorAll('main button,main [role=tab],main a')].map(e=>e.textContent.trim().slice(0,25)).slice(0,20)));
await br.close()})()
