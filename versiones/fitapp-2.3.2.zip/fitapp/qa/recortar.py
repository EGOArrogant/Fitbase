"""Uso: python qa/recortar.py imagen.jpg salida_prefijo [alto_trozo]  -> parte una captura alta en trozos legibles"""
import sys
from PIL import Image
im = Image.open(sys.argv[1]); pre = sys.argv[2]; h = int(sys.argv[3]) if len(sys.argv) > 3 else 1400
n = 0
for y in range(0, im.height, h):
    im.crop((0, y, im.width, min(im.height, y + h))).save(f'{pre}_{n}.png'); n += 1
print(n, im.size)
