"""Une cada X_antes.png con X_despues.png en un solo par_X.png (izquierda antes, derecha después)."""
import glob, os, sys
from PIL import Image, ImageDraw
d = '/home/user/fitapp/qa/salida/2026-11-23/visual2'
for a in sorted(glob.glob(d + '/*_antes.png')):
    b = a.replace('_antes.png', '_despues.png')
    if not os.path.exists(b): continue
    A, B = Image.open(a).convert('RGB'), Image.open(b).convert('RGB')
    h = max(A.height, B.height) + 28
    im = Image.new('RGB', (A.width + B.width + 30, h), (255, 255, 255)); dr = ImageDraw.Draw(im)
    dr.text((4, 4), 'ANTES', fill=(200, 0, 0)); dr.text((A.width + 34, 4), 'DESPUES', fill=(0, 140, 0))
    im.paste(A, (0, 24)); im.paste(B, (A.width + 30, 24))
    im.save(d + '/par_' + os.path.basename(a).replace('_antes.png', '.png'))
