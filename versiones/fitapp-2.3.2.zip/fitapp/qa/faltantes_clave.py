# Frases sin traducir (EN) por pantalla clave. Uso: FITAPP_DB=qa/salida/falt.db python qa/faltantes_clave.py
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as A, i18n
PAG = {'coach@fitapp.local': ['/app', '/coach', '/coach/actividad', '/coach/cliente/2', '/coach/invitar', '/coach/retos', '/planes', '/pagar/pro', '/guia', '/admin'],
       'demo@fitapp.local': ['/app', '/mi-plan', '/programa', '/nutricion', '/progreso', '/habitos', '/retos', '/planes', '/mis-pagos', '/ajustes', '/notificaciones']}
c = A.app.test_client(); c.set_cookie('idioma', os.environ.get('L', 'en'))
L = os.environ.get('L', 'en'); res = {}
for email, pags in PAG.items():
    c.get('/salir'); c.post('/login', data={'email': email, 'password': 'demo1234'})
    for p in pags:
        antes = dict(i18n._faltantes[L]); r = c.get(p)
        nuevas = {k: v for k, v in i18n._faltantes[L].items() if k not in antes}
        res[email[:5] + p] = list(nuevas)
        c.get('/app?guia=1')
json.dump(res, open('qa/salida/faltantes_clave.json', 'w'), ensure_ascii=False, indent=0)
for k, v in res.items(): print(k, len(v))
