// Revisor automático de la web de FitBase. Uso:
//   node qa/revisor_web.js [salida.json]   (env: B=http://localhost:5001, VIEWS=pc,tab,cel, TEMAS=light,dark, LANGS=es,en,fr, RAPIDO=1)
// Mide: desbordes horizontales, elementos que sobresalen, anchos de barras contra el dato, idioma tras navegar,
// errores de consola/HTTP>=400, y clics en flechas/botones de navegación. Guarda un JSON y capturas de muestra.
const { chromium, devices } = require('playwright');
const fs = require('fs'), path = require('path');
const B = process.env.B || 'http://localhost:5001';
const OUT = process.argv[2] || path.join(__dirname, 'salida', '2026-11-23', 'revision.json');
const CAP = path.join(path.dirname(OUT), 'capturas_revisor');
fs.mkdirSync(CAP, { recursive: true });
const VIEWS = (process.env.VIEWS || 'pc,tab,cel').split(',');
const TEMAS = (process.env.TEMAS || 'light,dark').split(',');
const LANGS = (process.env.LANGS || 'es,en,fr').split(',');
const VP = { pc: { viewport: { width: 1440, height: 900 } }, tab: { viewport: { width: 1024, height: 768 } }, cel: Object.assign({}, devices['iPhone 14 Pro Max']) };
const PAGINAS_USR = ['/app', '/mi-plan', '/programa', '/sesion', '/habitos', '/progreso', '/nutricion', '/dieta', '/recetas', '/plan-del-dia', '/cuerpo', '/entrenar', '/alimentos', '/diario', '/ejercicios', '/calculadoras', '/suplementos', '/emergencia', '/mitos', '/articulos', '/puntaje', '/menu-semanal', '/registrar', '/retos', '/feedback', '/fotos', '/mediciones', '/mi-expediente', '/planes', '/mis-pagos', '/notificaciones', '/ajustes', '/descargas', '/guia', '/mi-privacidad'];
const PAGINAS_COACH = ['/coach', '/coach/actividad', '/coach/retos', '/coach/feedback', '/coach/invitar', '/coach/cliente/2', '/coach/cliente/2/puntaje', '/coach/cliente/2/mediciones', '/admin', '/admin/pagos', '/admin/idiomas', '/admin/diagnostico', '/admin/crear'];
const PUBLICAS = ['/', '/login', '/registro'];
const R = { fecha: new Date().toISOString(), base: B, paginas: [], idioma_navegando: [], flechas: [], consola: [], resumen: {} };
const guardar = () => fs.writeFileSync(OUT, JSON.stringify(R, null, 1));
const slug = u => (u.replace(/^\//, '').replace(/[^a-z0-9]+/gi, '_').replace(/_$/, '') || 'inicio');

async function ctxNuevo(br, vista, tema, lang) {
  const ctx = await br.newContext(Object.assign({ deviceScaleFactor: 1, colorScheme: tema }, VP[vista]));
  await ctx.addInitScript(t => { try { localStorage.setItem('tema', t); } catch (e) { } }, tema);
  await ctx.addCookies([{ name: 'idioma', value: lang, url: B }]);
  return ctx;
}
async function login(page, email) {
  await page.goto(B + '/login');
  await page.fill('form:has([name=password]) [name=email]', email);
  await page.fill('form:has([name=password]) [name=password]', 'demo1234');
  await Promise.all([page.waitForLoadState('load'), page.click('form:has([name=password]) button')]);
  await page.waitForTimeout(900);
  if (await page.locator('.guia-capa').count()) await page.keyboard.press('Escape');
}
function vigilar(page, ctxt) {
  page.on('console', m => { if (m.type() === 'error') R.consola.push({ ...ctxt(), tipo: 'console', texto: m.text().slice(0, 200) }); });
  page.on('pageerror', e => R.consola.push({ ...ctxt(), tipo: 'pageerror', texto: String(e).slice(0, 200) }));
  page.on('response', r => { if (r.status() >= 400 && !/favicon/.test(r.url())) R.consola.push({ ...ctxt(), tipo: 'http' + r.status(), texto: r.url().replace(B, '') }); });
}

// ---- medición dentro de la página
const medir = () => {
  const out = { desborde_x: 0, sobresalen: [], barras: [], cortados: [], sin_nombre: [], esp_visible: [] };
  const de = document.documentElement, vw = de.clientWidth;
  out.desborde_x = Math.max(0, de.scrollWidth - vw);
  const vis = el => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const desc = el => el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.') : '');
  // elementos que se salen del viewport por la derecha (fuera de contenedores con scroll propio)
  const enScroll = el => { for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) { const o = getComputedStyle(p).overflowX; if ((o === 'auto' || o === 'scroll' || o === 'hidden') && p.scrollWidth <= p.clientWidth + 1 || o === 'auto' || o === 'scroll') return true; } return false; };
  if (out.desborde_x > 1) {
    for (const el of document.querySelectorAll('body *')) {
      if (!vis(el)) continue; const r = el.getBoundingClientRect();
      if (r.right > vw + 2 && !enScroll(el) && out.sobresalen.length < 6) out.sobresalen.push(desc(el) + ' der=' + Math.round(r.right));
    }
  }
  // texto cortado: elementos con overflow hidden cuyo contenido es más ancho y sin ellipsis intencional
  for (const el of document.querySelectorAll('button, .btn, a.nav span, h1, h2, h3, .tab, .chip, label, th')) {
    if (!vis(el)) continue; const cs = getComputedStyle(el);
    if (el.scrollWidth > el.clientWidth + 2 && cs.overflowX === 'hidden' && cs.textOverflow !== 'ellipsis' && out.cortados.length < 6) out.cortados.push(desc(el) + ' "' + (el.textContent || '').trim().slice(0, 30) + '"');
  }
  // botones/íconos sin nombre accesible
  for (const el of document.querySelectorAll('button, a')) {
    if (!vis(el)) continue;
    if (!(el.textContent || '').trim() && !el.getAttribute('aria-label') && !el.getAttribute('title') && !el.querySelector('img[alt]:not([alt=""])') && out.sin_nombre.length < 5) out.sin_nombre.push(desc(el));
  }
  // barras: inline width/left en % contra ancho renderizado y contra el texto cercano
  const cand = [...document.querySelectorAll('[style*="width"],[style*="left"],progress,meter,[role=progressbar]')];
  for (const el of cand) {
    const st = el.getAttribute('style') || '';
    let m = st.match(/(?:^|;)\s*(width|left)\s*:\s*(-?[\d.]+)%/);
    let tipo = 'css';
    if (!m && (el.tagName === 'PROGRESS' || el.tagName === 'METER')) { m = ['', 'width', String((el.value / (el.max || 1)) * 100)]; tipo = el.tagName; }
    if (!m) continue;
    const par = el.parentElement; if (!par) continue;
    const rp = par.getBoundingClientRect(), re = el.getBoundingClientRect();
    if (!rp.width) continue;
    const nominal = parseFloat(m[2]);
    const real = m[1] === 'width' ? re.width / rp.width * 100 : (re.left - rp.left + re.width / 2) / rp.width * 100;
    let cont = par; for (let i = 0; i < 3 && cont.parentElement && cont.parentElement !== document.body; i++) cont = cont.parentElement;
    const nums = [...(cont.innerText || '').matchAll(/(\d+(?:[.,]\d+)?)\s*%/g)].map(x => parseFloat(x[1].replace(',', '.')));
    const casa = nums.length ? nums.some(n => Math.abs(n - nominal) <= 1.5) : null;
    const sob = m[1] === 'width' ? (re.right > rp.right + 1.5) : (re.left > rp.right || re.right < rp.left);
    out.barras.push({ el: desc(el), prop: m[1], nominal: +nominal.toFixed(1), real: +real.toFixed(1), padre_ancho: Math.round(rp.width), visible: vis(el), sobresale: sob, texto_pct: nums.slice(0, 4), concuerda_texto: casa, texto: (cont.innerText || '').replace(/\s+/g, ' ').slice(0, 60) });
  }
  // SVG: barras con height/width de rect (gráficas)
  out.svg_rect = [...document.querySelectorAll('svg rect')].filter(r => r.getBoundingClientRect().height > 0).length;
  // texto en español visible (heurística) cuando el idioma no es es
  out.texto = document.body.innerText;
  return out;
};
const ES_PAL = /\b(Registrar|Guardar|Cerrar sesión|Siguiente|Atrás|Volver|Inicio|Ajustes|Semana|Entrenamiento|Alimentación|Cuerpo|Ejercicios|Notificaciones|Cuenta|Planes|Pago|Hoy|Progreso|Tus|Tu|Mi plan|Comidas|Eliminar|Editar|Enviar|Cancelar|Nuevo|Nueva|Sin datos|Aún|más|para|con tu|de la|del|los|las)\b/;

async function revisarPagina(page, url, vista, tema, lang, rol, capturar) {
  const ctxt = () => ({ url, vista, tema, lang, rol });
  const t0 = Date.now();
  let resp; try { resp = await page.goto(B + url, { waitUntil: 'load', timeout: 20000 }); } catch (e) { R.paginas.push({ ...ctxt(), error: String(e).slice(0, 120) }); return; }
  await page.waitForTimeout(450);
  const status = resp ? resp.status() : 0;
  const m = await page.evaluate(medir);
  const htmlLang = await page.evaluate(() => document.documentElement.lang);
  const cookie = (await page.context().cookies()).find(c => c.name === 'idioma');
  const lineas = m.texto.split('\n').map(s => s.trim()).filter(s => s.length > 3);
  let espanol = [];
  if (lang !== 'es') espanol = lineas.filter(s => ES_PAL.test(s) && /[áéíóúñ¿¡]|\b(de la|del|para|con|los|las|tus?)\b/i.test(s) && !/@/.test(s)).slice(0, 8);
  const fallos = [];
  if (status >= 400) fallos.push('HTTP ' + status);
  if (m.desborde_x > 1) fallos.push('desborde horizontal ' + m.desborde_x + 'px');
  if (m.cortados.length) fallos.push('texto cortado');
  for (const b of m.barras) {
    if (b.nominal > 100.5 || b.nominal < 0) fallos.push('barra fuera de rango ' + b.nominal + ' ' + b.el);
    else if (b.sobresale) fallos.push('barra sobresale ' + b.el);
    else if (Math.abs(b.real - b.nominal) > 2 && b.prop === 'width' && b.visible) fallos.push('barra ancho real ' + b.real + ' != ' + b.nominal);
    if (b.concuerda_texto === false) fallos.push('barra ' + b.nominal + '% no coincide con texto ' + JSON.stringify(b.texto_pct) + ' [' + b.texto.slice(0, 40) + ']');
  }
  if (lang !== 'es' && htmlLang && !htmlLang.startsWith(lang)) fallos.push('html lang=' + htmlLang);
  if (lang !== 'es' && cookie && cookie.value !== lang) fallos.push('cookie idioma cambió a ' + cookie.value);
  delete m.texto;
  R.paginas.push({ ...ctxt(), status, ms: Date.now() - t0, fallos, espanol_visible: espanol, ...m, barras: m.barras.filter(b => b.nominal > 100.5 || b.nominal < 0 || b.concuerda_texto === false || Math.abs(b.real - b.nominal) > 2 || b.sobresale), n_barras: m.barras.length });
  if (capturar) await page.screenshot({ path: path.join(CAP, `${slug(url)}_${vista}_${tema}_${lang}.png`), fullPage: false });
}

// ---- idioma al navegar 10 secciones seguidas
async function idiomaNavegando(page, lang, vista, rol) {
  await page.goto(B + '/idioma/' + lang); await page.waitForLoadState('load');
  const rutas = ['/app', '/programa', '/nutricion', '/dieta', '/cuerpo', '/progreso', '/retos', '/planes', '/guia', '/ajustes', '/mis-pagos'];
  const cambios = [];
  for (const r of rutas) {
    await page.goto(B + r, { waitUntil: 'load' }); await page.waitForTimeout(250);
    const c = (await page.context().cookies()).find(x => x.name === 'idioma'); const hl = await page.evaluate(() => document.documentElement.lang);
    if (!c || c.value !== lang || !hl.startsWith(lang)) cambios.push({ ruta: r, cookie: c && c.value, html: hl });
  }
  R.idioma_navegando.push({ lang, vista, rol, rutas: rutas.length, cambios });
}

// ---- flechas y navegación
async function flechas(page, vista, rol) {
  const reg = (nombre, ok, detalle) => R.flechas.push({ vista, rol, nombre, ok, detalle: detalle || '' });
  const urlSin = u => u.replace(B, '');
  // calendario / mes anterior-siguiente
  for (const ruta of ['/habitos', '/progreso', '/diario', '/mediciones', '/menu-semanal', '/app']) {
    await page.goto(B + ruta); await page.waitForTimeout(200);
    const sels = ['a[aria-label*="anterior" i]', 'a[aria-label*="siguiente" i]', 'a:has-text("‹")', 'a:has-text("›")', 'a:has-text("←")', 'a:has-text("→")', 'button[aria-label*="anterior" i]', 'button[aria-label*="siguiente" i]', '.cal-nav a', '.mes-nav a'];
    for (const s of sels) {
      const el = page.locator(s + ':visible').first();
      if (await el.count()) {
        const antes = await page.url(); const txt = (await page.locator('main').first().innerText().catch(() => '')).slice(0, 4000);
        const [resp] = await Promise.all([page.waitForResponse(() => true, { timeout: 3000 }).catch(() => null), el.click({ timeout: 3000 }).catch(e => reg(ruta + ' ' + s, false, String(e).slice(0, 60)))]);
        await page.waitForTimeout(300);
        const despues = await page.url(); const txt2 = (await page.locator('main').first().innerText().catch(() => '')).slice(0, 4000);
        reg(ruta + ' ' + s, antes !== despues || txt !== txt2, urlSin(despues));
        if (antes !== despues) await page.goBack().catch(() => { });
        break;
      }
    }
  }
  // riel lateral (solo escritorio)
  if (vista !== 'cel') {
    await page.goto(B + '/app');
    const rb = page.locator('[data-riel]:visible').first();
    if (await rb.count()) {
      const c0 = await page.evaluate(() => document.body.classList.contains('menu-riel'));
      await rb.click(); await page.waitForTimeout(350);
      const c1 = await page.evaluate(() => document.body.classList.contains('menu-riel'));
      const w1 = await page.evaluate(() => document.querySelector('.side').getBoundingClientRect().width);
      await rb.click(); await page.waitForTimeout(350);
      const c2 = await page.evaluate(() => document.body.classList.contains('menu-riel'));
      reg('riel expandir/contraer', c0 !== c1 && c2 === c0, `riel:${c0}->${c1}->${c2} ancho expandido ${Math.round(w1)}`);
    } else reg('riel [data-riel]', false, 'no visible');
  } else {
    // menú del celular y barra inferior
    await page.goto(B + '/app');
    const bm = page.locator('button[data-menu]:visible').first();
    if (await bm.count()) {
      await bm.click(); await page.waitForTimeout(350);
      const abierto = await page.evaluate(() => { const s = document.querySelector('.side'); const r = s.getBoundingClientRect(); return r.left >= -1 && r.width > 100; });
      const w = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      await page.locator('.side-x:visible').first().click().catch(() => { });
      await page.waitForTimeout(350);
      const cerrado = await page.evaluate(() => { const r = document.querySelector('.side').getBoundingClientRect(); return r.right <= 1; });
      reg('menú celular abrir/cerrar', abierto && cerrado, `abierto:${abierto} cerrado:${cerrado} desborde:${w}`);
    } else reg('menú celular', false, 'sin botón');
    const tabs = await page.locator('.tabbar a:visible, nav.tab a:visible, .tab-i:visible').count();
    reg('barra inferior', tabs >= 3, tabs + ' elementos');
    for (let i = 0; i < Math.min(tabs, 4); i++) {
      const el = page.locator('.tabbar a:visible, nav.tab a:visible').nth(i);
      if (!(await el.count())) break; const h = await el.getAttribute('href'); if (!h) continue;
      await page.goto(B + '/app'); await el.click(); await page.waitForLoadState('load');
      reg('barra inferior → ' + h, page.url().includes(h.split('?')[0]), urlSin(page.url()));
    }
  }
  // guía: recorrido guiado (Siguiente / Atrás / Saltar / Escape)
  await page.goto(B + '/app?guia=1'); await page.waitForTimeout(900);
  const cap = () => page.locator('.guia-caja:visible, .guia-capa').count();
  const paso = async () => (await page.locator('.guia-caja').first().innerText().catch(() => '')).slice(0, 60);
  if (await page.locator('.guia-sig:visible').count()) {
    const p1 = await paso(); await page.locator('.guia-sig').first().click(); await page.waitForTimeout(400); const p2 = await paso();
    reg('guía Siguiente', p1 !== p2, p1 + ' -> ' + p2);
    await page.locator('.guia-sig').first().click(); await page.waitForTimeout(400);
    const atr = page.locator('.guia-ant:visible').first();
    if (await atr.count()) { await atr.click(); await page.waitForTimeout(400); reg('guía Atrás', (await paso()) === p2, ''); } else reg('guía Atrás', false, 'sin botón');
    const sal = page.locator('.guia-saltar').first();
    if (await sal.count()) { await sal.click(); await page.waitForTimeout(400); reg('guía Saltar', (await page.locator('.guia-caja').count()) === 0, ''); } else reg('guía Saltar', false, 'sin botón');
  } else reg('guía recorrido', false, 'no abrió');
  // volver
  for (const ruta of ['/ejercicios', '/articulos', '/recetas', '/ajustes']) {
    await page.goto(B + '/app'); const r = await page.goto(B + ruta).catch(() => null);
    const v = page.locator('a:visible:text-matches("Volver", "i")').first();
    if (await v.count()) { await v.click(); await page.waitForLoadState('load'); reg('Volver desde ' + ruta, true, urlSin(page.url())); }
  }
  // selector mensual/anual en planes
  await page.goto(B + '/planes'); const sw = page.locator('[data-periodo=anual]').first();
  if (await sw.count()) { const t0 = await page.locator('main').innerText(); await sw.click().catch(() => { }); await page.waitForTimeout(250); reg('planes mensual/anual', t0 !== await page.locator('main').innerText() && (await sw.getAttribute('aria-checked')) === 'true', ''); }
  else reg('planes mensual/anual', null, 'no hay selector');
}

// ---- portada: pestañas y carruseles
async function portada(page, vista, lang) {
  const reg = (nombre, ok, detalle) => R.flechas.push({ vista, rol: 'publico-' + lang, nombre, ok, detalle: detalle || '' });
  await page.goto(B + '/'); await page.waitForTimeout(500);
  const sels = ['[role=tab]:visible', '.lp-tab:visible', '[data-disp-tab]:visible', '[data-tab]:visible'];
  for (const s of sels) {
    const n = await page.locator(s).count();
    if (n > 1) {
      let cambia = 0; const antes = await page.locator('body').innerHTML().then(h => h.length);
      for (let i = 0; i < Math.min(n, 6); i++) { const h0 = await page.locator('[aria-selected=true], .on, .act').count(); await page.locator(s).nth(i).click({ timeout: 2000 }).catch(() => { }); await page.waitForTimeout(150); cambia++; }
      reg('portada pestañas ' + s, true, n + ' pestañas');
      break;
    }
  }
  for (const s of ['.lp-prev:visible', '.lp-next:visible', '[data-prev]:visible', '[data-next]:visible', 'button[aria-label*="Siguiente" i]:visible', 'button[aria-label*="next" i]:visible']) {
    if (await page.locator(s).count()) { await page.locator(s).first().click({ timeout: 2000 }).then(() => reg('portada carrusel ' + s, true), e => reg('portada carrusel ' + s, false, String(e).slice(0, 60))); }
  }
  const links = await page.$$eval('a[href]', as => [...new Set(as.map(a => a.getAttribute('href')).filter(h => h && h.startsWith('/') && !h.startsWith('//')))]);
  const rotos = [];
  for (const h of links) { const r = await page.request.get(B + h).catch(() => null); if (!r || r.status() >= 400) rotos.push(h + ' ' + (r && r.status())); }
  reg('enlaces de la portada', rotos.length === 0, rotos.join(', ') || links.length + ' ok');
}

(async () => {
  const br = await chromium.launch();
  let n = 0;
  for (const vista of VIEWS) for (const tema of TEMAS) for (const lang of LANGS) {
    // para acotar tiempo, EN/FR solo en pc/cel claro y oscuro solo en ES salvo RAPIDO desactivado
    if (process.env.RAPIDO !== '0') { if (lang !== 'es' && tema === 'dark') continue; if (lang !== 'es' && vista === 'tab') continue; }
    for (const rol of ['demo', 'coach']) {
      if (rol === 'demo' && false) continue;
      const ctx = await ctxNuevo(br, vista, tema, lang); const page = await ctx.newPage();
      vigilar(page, () => ({ vista, tema, lang, rol }));
      await login(page, rol === 'coach' ? 'coach@fitapp.local' : 'demo@fitapp.local');
      const lista = rol === 'coach' ? PAGINAS_COACH.concat(PAGINAS_USR.slice(0, 6)) : PAGINAS_USR;
      for (const u of lista) { await revisarPagina(page, u, vista, tema, lang, rol, tema === 'light' && lang === 'es' && n++ % 6 === 0); }
      if (tema === 'light' && lang === 'es' && rol === 'coach') await flechas(page, vista, rol);
      if (tema === 'light' && lang !== 'es' && vista !== 'tab' && rol === 'demo') await idiomaNavegando(page, lang, vista, rol);
      await ctx.close(); guardar();
    }
    const ctx = await ctxNuevo(br, vista, tema, lang); const page = await ctx.newPage(); vigilar(page, () => ({ vista, tema, lang, rol: 'publico' }));
    for (const u of PUBLICAS) await revisarPagina(page, u, vista, tema, lang, 'publico', tema === 'light' && lang === 'es');
    if (tema === 'light' && vista !== 'tab') await portada(page, vista, lang);
    await ctx.close(); guardar();
  }
  await br.close();
  const f = R.paginas.filter(p => p.fallos && p.fallos.length);
  R.resumen = { paginas: R.paginas.length, con_fallos: f.length, consola: R.consola.length, flechas_fallidas: R.flechas.filter(x => x.ok === false).length, idioma_cambios: R.idioma_navegando.reduce((a, b) => a + b.cambios.length, 0) };
  guardar(); console.log(JSON.stringify(R.resumen));
})();
