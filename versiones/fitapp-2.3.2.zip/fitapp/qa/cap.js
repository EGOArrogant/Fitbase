const { chromium, devices } = require('playwright');
(async()=>{const [,, url, vista, lang, tema, out, rol]=process.argv;const br=await chromium.launch();
const o=vista==='cel'?devices['iPhone 14 Pro Max']:{viewport:{width:vista==='tab'?1024:1440,height:vista==='tab'?768:900}};
const c=await br.newContext({...o,deviceScaleFactor:1,colorScheme:tema||'light'});await c.addCookies([{name:'idioma',value:lang||'es',url:'http://localhost:5001'}]);
await c.addInitScript(t=>{try{localStorage.setItem('tema',t)}catch(e){}},tema||'light');
const p=await c.newPage();await p.goto('http://localhost:5001/login');await p.fill('form:has([name=password]) [name=email]',rol==='demo'?'demo@fitapp.local':'coach@fitapp.local');await p.fill('form:has([name=password]) [name=password]','demo1234');await Promise.all([p.waitForLoadState('load'),p.click('form:has([name=password]) button')]);await p.waitForTimeout(900);if(await p.locator('.guia-capa').count())await p.keyboard.press('Escape');
await p.goto('http://localhost:5001'+url);await p.waitForTimeout(600);await p.screenshot({path:out,fullPage:process.env.FULL==='1'});await br.close()})()
