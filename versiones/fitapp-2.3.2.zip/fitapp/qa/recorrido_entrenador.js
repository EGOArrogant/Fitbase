// Recorrido QA de FitBase como entrenador + cliente de prueba. Uso: node qa/recorrido_entrenador.js [fase,fase,...]
// Fases: datos, cliente, coach, admin, idioma, pdf, pantallas   (sin argumento: todas)
// Evidencia: qa/salida/2026-11-23/{evidencia.json,texto/,capturas/,pdf/}
const { chromium, devices } = require('playwright');
const fs = require('fs'), path = require('path'), cp = require('child_process');
const B = 'http://localhost:5000';
const FECHA = '2026-11-23';
const D = path.join(__dirname, 'salida', FECHA);
for (const s of ['', 'texto', 'capturas', 'pdf']) fs.mkdirSync(path.join(D, s), { recursive: true });
const EVF = path.join(D, 'evidencia.json');
const ev = fs.existsSync(EVF) ? JSON.parse(fs.readFileSync(EVF)) : { fecha: FECHA, pasos: {}, hallazgos_auto: [], pantallas: [], pdf: [], consola: [] };
const fases = process.argv[2] ? process.argv[2].split(',') : ['datos', 'cliente', 'coach', 'admin', 'idioma', 'pdf', 'pantallas'];
const CL = { email: 'lucia.qa@example.com', pw: 'Lucia2026!', nombre: 'Lucia QA' };
const CO = { email: 'coach@fitapp.local', pw: 'demo1234' };
const slug = u => u.replace(/^\//, '').replace(/[^a-z0-9]+/gi, '_').replace(/_$/, '') || 'inicio';
const guardar = () => fs.writeFileSync(EVF, JSON.stringify(ev, null, 1));
const paso = (k, v) => { ev.pasos[k] = v; guardar(); };
const flashes = h => [...h.matchAll(/<div class="alert ([a-z]+)"[^>]*>([^<]*)</g)].map(m => m[1] + ': ' + m[2].trim());
const dia = n => { const d = new Date(Date.UTC(2026, 10, 23)); d.setUTCDate(d.getUTCDate() - n); return d.toISOString().slice(0, 10); };

async function nuevoCtx(browser, opt = {}) {
  const ctx = await browser.newContext(Object.assign({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, colorScheme: 'light' }, opt));
  await ctx.addInitScript(t => { try { localStorage.setItem('tema', t); } catch (e) { } }, opt._tema || 'light');
  return ctx;
}
async function login(page, u) {
  await page.goto(B + '/login');
  await page.fill('form:has([name=password]) [name=email]', u.email);
  await page.fill('form:has([name=password]) [name=password]', u.pw);
  await Promise.all([page.waitForLoadState('load'), page.click('form:has([name=password]) button')]);
  return page.url();
}
async function post(page, url, form) {
  const r = await page.request.post(B + url, { form });
  const t = await r.text();
  return { s: r.status(), url: r.url(), f: flashes(t) };
}
async function get(page, url) { const r = await page.request.get(B + url); return { s: r.status(), t: await r.text(), ct: r.headers()['content-type'] }; }
const aTexto = h => h.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/g, ' ').replace(/<[^>]+>/g, '\n').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\n\s*\n+/g, '\n');
async function texto(page, url, nombre) {
  const t0 = Date.now();
  const resp = await page.goto(B + url, { waitUntil: 'load' });
  const ms = Date.now() - t0;
  const tx = await page.evaluate(() => document.body.innerText);
  fs.writeFileSync(path.join(D, 'texto', (nombre || slug(url)) + '.txt'), tx);
  return { tx, ms, s: resp && resp.status() };
}
const cid = () => ev.pasos.cliente_id;

// ---------------------------------------------------------------- DATOS: alta del cliente y registros
async function fDatos(br) {
  const hecho = k => ev.pasos[k] && !process.env.REHACER;
  const ctxC = await nuevoCtx(br), pc = await ctxC.newPage();
  let u = await login(pc, CL);
  const coachCtx = await nuevoCtx(br), pco = await coachCtx.newPage();
  await login(pco, CO);
  if (!/\/app|\/mi-plan/.test(u)) {
    // registrar por invitación
    await pco.goto(B + '/coach/invitar');
    await pco.fill('[name=nombre]', CL.nombre); await pco.fill('[name=contacto]', CL.email);
    await pco.click('form:has([name=nombre]) button');
    const href = await pco.evaluate(() => [...document.querySelectorAll('a,input,code')].map(e => e.href || e.value || e.textContent).find(x => /\/unirme\/[A-Za-z0-9]{10,}/.test(x)));
    const tok = href.match(/unirme\/([A-Za-z0-9]+)/)[1];
    await pc.goto(B + '/unirme/' + tok);
    await pc.evaluate(() => {
      const f = document.querySelector('form:has([name=edad])');
      const set = (n, v) => { f.querySelector(`[name=${n}]`).value = v; };
      const chk = (n, v) => f.querySelectorAll(`[name=${n}]`).forEach(e => { if (e.value === v) e.checked = true; });
      set('telefono', '5551234567'); set('password', 'Lucia2026!'); chk('sexo', 'Mujer'); set('edad', '34'); set('peso', '68'); set('talla', '163'); set('cintura', '82');
      chk('objetivo', 'Perder grasa'); set('meta', 'Bajar 6 kg de grasa en 6 meses'); set('motivacion', 'Quiero sentirme con más energía'); chk('experiencia', 'menos6');
      for (let i = 0; i <= 6; i++) chk('parq' + i, 'no'); chk('parq3', 'si');
      chk('condiciones', 'hipertension'); chk('dolor', 'espalda'); chk('actividad', 'Ligero'); chk('lugar', 'Gimnasio completo'); set('dias', '4'); set('duracion', '60'); chk('horario', 'Tarde');
      set('sueno', '6.5'); set('estres', '7'); chk('alcohol', 'Ocasional'); chk('tabaco', 'No'); chk('gusto', 'Caminar'); chk('gusto', 'Nadar'); set('comidas', '4'); chk('cocina', 'A veces');
      chk('dieta_tipo', 'vegetariana'); chk('alergias', 'lacteos'); chk('alergias', 'frutos_secos'); chk('edad_legal', 'mayor');
      ['c_terminos', 'c_datos_salud', 'c_actividad_fisica', 'c_compartir_coach'].forEach(n => f.querySelector(`[name=${n}]`).checked = true);
      set('no_gusta', 'coliflor'); f.querySelector('[name=medicamentos]').value = 'Enalapril 10 mg';
      f.submit();
    });
    await pc.waitForLoadState('load');
    paso('registro', { url: pc.url(), token: tok });
  } else paso('registro', { omitido: 'cliente ya existía' });
  await pco.goto(B + '/coach');
  const h = await pco.evaluate(n => [...document.querySelectorAll('a[href^="/coach/cliente/"]')].map(a => ({ h: a.getAttribute('href'), t: a.textContent.trim() })), 0);
  const mi = h.find(x => /Lucia/.test(x.t));
  ev.pasos.cliente_id = mi ? +mi.h.match(/cliente\/(\d+)/)[1] : null; guardar();

  // ---- sondeo (editar con datos reales) y avanzado
  let r = await get(pc, '/sondeo'); paso('sondeo_get', { s: r.s });
  if (!hecho('sondeo_avanzado_post')) { r = await post(pc, '/sondeo-avanzado', {
    anios: '1', meses: '3', constancia: 'intermitente', disciplina: 'Fitness y salud', split: 'Cuerpo completo', dias_actual: '3', duracion_actual: '55', entrenador_previo: 'no',
    sentadilla_peso: '40', sentadilla_reps: '8', banca_peso: '25', banca_reps: '8', muerto_peso: '50', muerto_reps: '6', militar_peso: '15', militar_reps: '8', remo_peso: '30', remo_reps: '8',
    dominadas_peso: '0', dominadas_reps: '0', hip_thrust_peso: '60', hip_thrust_reps: '10', metas_fuerza: 'Sentadilla 60 kg', compite: 'no', peso: '68', sueno: '6.5', estres: '7',
    lesiones: 'Molestia lumbar leve', analisis: 'no', sustancias: 'no', kcal_actual: '1700', suplementos: 'Proteína en polvo', historial_dietas: 'Dieta de 1200 kcal sin éxito',
    objetivo_detalle: 'Perder grasa conservando músculo', debiles: 'Glúteo', modo: 'completo'
  });
  paso('sondeo_avanzado_post', r); }

  // ---- registro diario 14 días (23 nov = hoy)
  if (!hecho('registro_diario')) {
  const pesos = [68.4, 68.0, 68.6, 67.9, 68.1, 67.8, 67.5, 68.0, 67.4, 67.2, 67.6, 67.0, 66.9, 66.8]; // día 0..13 hacia hoy
  const diario = [];
  for (let i = 13; i >= 0; i--) {
    const idx = 13 - i, f = dia(i);
    const form = { fecha: f, peso: String(pesos[idx]), kcal: String(1650 + (idx % 3) * 60), proteina: String(95 + (idx % 4) * 8), pasos: String(7000 + idx * 250), sueno: String(6 + (idx % 3) * 0.5), entreno: [0, 2, 4, 6, 9, 11].includes(idx) ? 'Sí' : (idx % 7 === 6 ? 'Descanso' : 'No'), energia: String(6 + (idx % 3)), cintura: idx % 7 === 0 ? String(82 - idx * 0.1) : '', notas: idx === 5 ? 'Dormí mal, mucho estrés en el trabajo' : '' };
    const rr = await post(pc, '/habitos?fecha=' + f, form);
    diario.push({ f, form, s: rr.s, fl: rr.f });
  }
  paso('registro_diario', diario); }

  // ---- 6 sesiones de series
  if (!hecho('series')) {
  const sel = await (async () => { await pc.goto(B + '/sesion'); return pc.evaluate(() => [...document.querySelectorAll('form select[name=ejercicio] option')].map(o => o.value)); })();
  paso('sesion_ejercicios_disponibles', sel);
  const pick = re => sel.find(x => re.test(x));
  const ex = [pick(/^Sentadilla/i), pick(/^Press de banca/i), pick(/^Remo/i) || pick(/Jal[oó]n/i), pick(/Peso muerto rumano/i)].filter(Boolean);
  paso('sesion_ejercicios_usados', { ex, faltan: ['Sentadilla', 'Press', 'Remo', 'Peso muerto rumano'].filter((n, i) => !ex[i] || false) });
  const base = [40, 25, 30, 45], fechasSes = [13, 11, 9, 7, 4, 2].map(dia), series = [];
  for (let s = 0; s < 6; s++) for (let e = 0; e < ex.length; e++) for (let k = 0; k < 3; k++) {
    const peso = base[e] + s * 2.5 + (e === 3 ? s * 2.5 : 0), reps = 10 - k - (s > 3 ? 1 : 0);
    const rr = await post(pc, '/sesion', { fecha: fechasSes[s], dia: String(s % 3), ejercicio: ex[e], peso: String(peso), reps: String(reps), rir: String(2 - (k > 1 ? 1 : 0)), nota: '' });
    series.push([fechasSes[s], ex[e], peso, reps, rr.s]);
  }
  paso('series', { total: series.length, fallos: series.filter(x => x[4] >= 400).length, muestra: series.slice(0, 3) }); }

  // ---- comidas con texto (con lácteos a propósito)
  if (!hecho('comidas')) {
  const comidas = [];
  for (const [f, txt] of [[dia(1), 'Desayuno: 2 huevos con frijoles y una tortilla\nComida: ensalada con garbanzos y arroz\nCena: un vaso de leche entera con pan'],
  [dia(0), 'Desayuno: yogur natural con avena y plátano\nComida: quesadilla de queso panela con nopales\nCena: sopa de verduras y tofu']]) {
    const ri = await (await pc.request.post(B + '/registrar/interpretar', { data: { texto: txt } })).json();
    const items = ri.items || [];
    const rg = await (await pc.request.post(B + '/registrar/guardar', { data: { fecha: f, items } })).json();
    comidas.push({ fecha: f, texto: txt, interpretacion: items.map(i => ({ n: i.nombre, g: i.gramos, kcal: i.por100g && i.por100g.kcal, avisos: i.avisos, alergia: i.alergia, tiempo: i.tiempo })), faltan: ri.faltan, guardado: rg });
  }
  paso('comidas', comidas); }

  // ---- suplementación
  if (!hecho('supl_contexto')) {
  r = await post(pc, '/suplementacion', { accion: 'contexto', deporte: 'fuerza', hora: '18:00', renal: 'no', corazon: 'no', ansiedad: 'no', anticoagulantes: 'no', lactancia: 'no', medicamentos: 'si', pescado: 'no', sol: 'si', competidor: 'no' });
  paso('supl_contexto', r);
  let st = await texto(pc, '/suplementacion', 'cliente_suplementacion');
  paso('supl_texto_pantalla', st.tx.slice(0, 6000));
  const claves = await pc.evaluate(() => [...new Set([...document.querySelectorAll('input[name=clave]')].map(i => i.value))]);
  paso('supl_claves_visibles', claves);
  const intento = {};
  for (const k of ['cafeina', 'bicarbonato', 'creatina', 'omega3']) { intento[k] = await post(pc, '/suplementacion', { accion: 'agregar', clave: k, dosis: '1', acepto: '1' }); }
  const st2 = await texto(pc, '/suplementacion', 'cliente_suplementacion_despues');
  intento.en_plan_despues = ['Cafeína', 'Bicarbonato', 'Creatina', 'Omega'].filter(n => new RegExp('(en tu plan|En tu plan|Quitar)[^\\n]{0,40}', 'i').test(st2.tx) && st2.tx.includes(n));
  paso('supl_intentos_agregar', intento); }

  // ---- foto de progreso
  if (!hecho('foto_subida') || !ev.pasos.foto_subida.imgs) {
  cp.execSync(`python3 -c "from PIL import Image,ImageDraw;im=Image.new('RGB',(600,800),(180,200,220));d=ImageDraw.Draw(im);d.ellipse((250,100,350,200),fill=(220,180,150));d.rectangle((230,200,370,500),fill=(90,120,160));d.text((20,20),'QA foto 2026-11-23',fill=(0,0,0));im.save('${D}/foto_qa.jpg')"`);
  await pc.goto(B + '/fotos');
  await pc.fill('form:has([name=fotos]) [name=peso]', '66.8');
  await pc.setInputFiles('[name=fotos]', path.join(D, 'foto_qa.jpg'));
  await pc.fill('form:has([name=fotos]) [name=nota]', 'Foto de prueba QA');
  await pc.click('#btn-subir'); await pc.waitForTimeout(3000); await pc.goto(B + '/fotos');
  paso('foto_subida', { url: pc.url(), flashes: await pc.evaluate(() => [...document.querySelectorAll('.alert')].map(a => a.innerText)), imgs: await pc.evaluate(() => document.querySelectorAll('img[src*="/fotos/archivo/"]').length) }); }

  // ---- mediciones (antropometría básica)
  if (!hecho('mediciones_post')) r = await post(pc, '/mediciones', { tipo: 'basica', fecha: dia(0), peso: '66.8', talla: '163', cintura: '80', cadera: '99', cuello: '32', muneca: '15' });
  if (!hecho('mediciones_post')) paso('mediciones_post', r);

  // ---- retos (el entrenador crea uno antes; el cliente se inscribe)
  if (!hecho('coach_crear_reto')) { r = await post(pco, '/coach/retos', { accion: 'crear', titulo: 'Reto 20 sesiones QA', descripcion: 'Completa 20 sesiones en 4 semanas', tipo: 'sesiones', meta: '20', inicio: dia(14), fin: '2026-12-20', puntos: '150', nivel: 'Todos', cuota: '0', cupo: '', premios: 'Playera' });
  paso('coach_crear_reto', r); }
  await pc.goto(B + '/retos');
  const rid = await pc.evaluate(() => { const a = [...document.querySelectorAll('a[href^="/retos/"]')].filter(a => /Reto 20 sesiones QA/.test(a.closest('article,section,div,li') ? a.closest('article,section,div,li').innerText : a.innerText)).map(a => a.getAttribute('href')).filter(h => /\/retos\/\d+/.test(h)); return a.length ? +a[0].match(/\d+/)[0] : null; });
  ev.pasos.reto_id = rid;
  if (rid && !hecho('cliente_inscribe_reto_ok')) { r = await post(pc, '/retos/' + rid, { accion: 'inscribir' }); paso('cliente_inscribe_reto_ok', r); }

  // ---- feedback, privacidad ARCO, preferencias
  if (!hecho('feedback_post')) { r = await post(pc, '/feedback', { tipo: 'problema', area: 'Nutrición', calificacion: '3', texto: 'QA: el plan del día debería explicar por qué excluye lácteos y frutos secos.', publico: '1' });
  paso('feedback_post', r); }
  if (!hecho('arco_post')) { r = await post(pc, '/mi-privacidad', { accion: 'arco', tipo: 'acceso', descripcion: 'QA: solicito copia de todos mis datos personales.' });
  paso('arco_post', r); }
  paso('notificaciones_cliente', (await texto(pc, '/notificaciones', 'cliente_notificaciones')).tx.slice(0, 3000));
  await ctxC.close(); await coachCtx.close();
}

// ---------------------------------------------------------------- CLIENTE: lecturas de nutrición y controles
const PROHIBIDAS = {
  lacteos: /\b(leche|queso|yogur(t)?|crema|mantequilla|reques[oó]n|lacte[oa]s?|panela|cottage)\b/i,
  frutos_secos: /\b(almendras?|nueces|nuez|pistaches?|avellanas?|pecanas?|anacardos?|mara[nñ][oó]n|castañas?)\b/i,
  carne: /\b(pollo|res|cerdo|carne|at[uú]n|pescado|jam[oó]n|tocino|chorizo|camar[oó]n(es)?|salm[oó]n|pavo|sardinas?|bistec|milanesa|carnitas|filete)\b/i
};
function buscarProhibidas(tx) {
  const out = {};
  const lineas = tx.split('\n');
  for (const [k, re] of Object.entries(PROHIBIDAS)) {
    const hits = lineas.filter(l => re.test(l) && !/\b(sin|evita|evitar|excluye|alergia|aviso|contiene|no incluye|libre)\b/i.test(l)).slice(0, 12).map(l => l.trim().slice(0, 140));
    if (hits.length) out[k] = hits;
  }
  return out;
}
async function fCliente(br) {
  const ctx = await nuevoCtx(br), p = await ctx.newPage();
  await login(p, CL);
  const rev = {};
  for (const u of ['/plan-del-dia', '/menu-semanal', '/nutricion', '/dieta', '/mi-plan', '/recetas', '/diario', '/progreso', '/cuerpo', '/puntaje']) {
    const t = await texto(p, u, 'cliente_' + slug(u));
    rev[u] = { s: t.s, ms: t.ms, prohibidas: buscarProhibidas(t.tx), largo: t.tx.length };
  }
  paso('restricciones_en_pantallas', rev);
  // recetas del plan del día: chequear los enlaces
  await p.goto(B + '/plan-del-dia');
  const rec = await p.evaluate(() => [...document.querySelectorAll('a[href^="/recetas/"]')].map(a => a.getAttribute('href')));
  const rr = [];
  for (const h of [...new Set(rec)].slice(0, 8)) { const t = await texto(p, h, 'cliente_receta_' + slug(h)); rr.push({ h, ms: t.ms, prohibidas: buscarProhibidas(t.tx), titulo: t.tx.split('\n')[0] }); }
  paso('recetas_plan_dia', rr);
  // diario vs registro: totales
  const dj = await texto(p, '/diario?fecha=' + dia(0), 'cliente_diario_hoy');
  paso('diario_hoy_texto', dj.tx.slice(0, 2500));
  const hb = await texto(p, '/habitos?fecha=' + dia(0), 'cliente_habitos_hoy');
  paso('habitos_hoy_texto', hb.tx.slice(0, 1500));
  // API de hoy
  const reg = await (await p.request.get(B + '/api/v1/hoy')).text(); paso('api_hoy', reg.slice(0, 1500));
  const prog = await (await p.request.get(B + '/api/v1/progreso')).text(); paso('api_progreso', prog.slice(0, 2500));
  await ctx.close();
}

// ---------------------------------------------------------------- IDIOMA
const ES = /\b(el|la|los|las|de|del|que|para|con|tu|tus|una|un|por|como|más|sin|hoy|aún|y)\b/gi;
async function fIdioma(br) {
  const ctx = await nuevoCtx(br), p = await ctx.newPage();
  await login(p, CL);
  const res = {};
  const paginas = ['/app', '/mi-plan', '/habitos', '/nutricion', '/plan-del-dia', '/suplementacion', '/progreso', '/retos', '/notificaciones', '/mi-privacidad', '/fotos', '/feedback', '/planes'];
  for (const lang of ['en', 'fr']) {
    await p.goto(B + '/idioma/' + lang);
    res[lang] = {};
    for (const u of paginas) {
      const t = await texto(p, u, `idioma_${lang}_${slug(u)}`);
      const lineas = t.tx.split('\n').map(x => x.trim()).filter(x => x.length > 25);
      const esp = lineas.filter(l => (l.match(ES) || []).length >= 3 && /[áéíóúñ¿¡]|\b(el|la|los|las|para|con|tu)\b/i.test(l)).slice(0, 6);
      res[lang][u] = { htmlLang: await p.evaluate(() => document.documentElement.lang), lineasEnEspanol: esp.length ? esp : undefined, totalLargas: lineas.length, pctEsp: lineas.length ? Math.round(100 * lineas.filter(l => (l.match(ES) || []).length >= 3).length / lineas.length) : 0 };
    }
    await p.screenshot({ path: path.join(D, 'capturas', `idioma_${lang}_app.jpg`), type: 'jpeg', quality: 50 });
  }
  // estabilidad: volver a es y navegar
  await p.goto(B + '/idioma/es');
  const seq = [];
  for (const u of ['/app', '/habitos', '/mi-plan', '/nutricion', '/app']) { await p.goto(B + u); seq.push([u, await p.evaluate(() => document.documentElement.lang)]); }
  res.estabilidad_es = seq;
  // cambio a en y comprobar que se conserva tras cerrar sesión/abrir de nuevo
  await p.goto(B + '/idioma/en'); const c = await ctx.cookies(); res.cookie_idioma = c.filter(x => x.name === 'idioma').map(x => x.value);
  await p.goto(B + '/salir'); await login(p, CL); await p.goto(B + '/app'); res.tras_relogin = await p.evaluate(() => document.documentElement.lang);
  await p.goto(B + '/idioma/es');
  paso('idioma', res); await ctx.close();
}

// ---------------------------------------------------------------- ENTRENADOR
async function fCoach(br) {
  const ctx = await nuevoCtx(br), p = await ctx.newPage();
  await login(p, CO);
  const C = cid(), out = {};
  const t = await texto(p, '/coach', 'coach_panel');
  out.panel = { ms: t.ms, tiene_lucia: /Lucia/.test(t.tx), texto: t.tx.slice(0, 1800) };
  // filtros: clic en chips y contar tarjetas visibles
  const filtros = [];
  const chips = await p.evaluate(() => [...document.querySelectorAll('.cp-chip:not([disabled])')].map(c => ({ g: c.parentElement.dataset.grupo, v: c.dataset.valor, t: c.textContent.trim() })));
  for (const c of chips) {
    await p.click(`.cp-chips[data-grupo=${c.g}] .cp-chip[data-valor="${c.v}"]`);
    const vis = await p.evaluate(() => [...document.querySelectorAll('.cp-card')].filter(x => x.offsetParent !== null).map(x => x.dataset.nombre));
    filtros.push({ grupo: c.g, valor: c.v, chip: c.t, visibles: vis.length, lucia: vis.some(n => /lucia/.test(n)) });
    await p.click(`.cp-chips[data-grupo=${c.g}] .cp-chip[data-valor=""]`);
  }
  out.filtros = filtros;
  const card = await p.evaluate(() => { const a = [...document.querySelectorAll('.cp-card')].find(x => /lucia/.test(x.dataset.nombre)); return a ? { nivel: a.dataset.nivel, objetivo: a.dataset.objetivo, estado: a.dataset.estado, texto: a.innerText.slice(0, 700) } : null; });
  out.tarjeta_lucia = card;
  // actividad en vivo
  const act = await get(p, '/coach/actividad.json'); out.actividad_json = act.t.slice(0, 2500);
  const at = await texto(p, '/coach/actividad', 'coach_actividad'); out.actividad_texto = at.tx.slice(0, 2500);
  // páginas del cliente
  const base = `/coach/cliente/${C}`;
  for (const [k, u] of [['ficha', base], ['dieta', base + '/dieta'], ['diario', base + '/diario'], ['mediciones', base + '/mediciones'], ['fotos', base + '/fotos'], ['expediente', base + '/expediente'], ['suplementacion', base + '/suplementacion'], ['preferencias', base + '/preferencias'], ['sondeo_avanzado', base + '/sondeo-avanzado'], ['menu_semanal', base + '/menu-semanal'], ['puntaje', base + '/puntaje'], ['registrar', base + '/registrar']]) {
    const x = await texto(p, u, 'coach_' + k);
    out[k] = { s: x.s, ms: x.ms, prohibidas: ['dieta', 'menu_semanal'].includes(k) ? buscarProhibidas(x.tx) : undefined, extracto: x.tx.slice(0, 900) };
  }
  // nota de suplementación
  out.nota_supl = await post(p, base + '/suplementacion', { accion: 'nota', nota: 'Con tu presión alta evita cafeína y bicarbonato. Empieza con creatina 3 g y revisa con tu médico. (QA)' });
  out.supl_despues = (await texto(p, base + '/suplementacion', 'coach_suplementacion_despues')).tx.slice(0, 2500);
  // feedback: responder
  const fb = await texto(p, '/coach/feedback', 'coach_feedback'); out.feedback = fb.tx.slice(0, 1500);
  const fid = await p.evaluate(() => { const i = document.querySelector('form input[name=id]'); return i ? i.value : null; });
  if (fid) out.feedback_respuesta = await post(p, '/coach/feedback', { id: fid, estado: 'revision', respuesta: 'Gracias, lo revisamos (QA).' });
  // retos
  out.retos = (await texto(p, '/coach/retos', 'coach_retos')).tx.slice(0, 1500);
  // invitar + QR
  await p.goto(B + '/coach/invitar');
  const svgs = await p.evaluate(() => [...document.querySelectorAll('svg')].filter(s => s.getBoundingClientRect().width > 80).map((s, i) => ({ i, w: s.getBoundingClientRect().width, h: s.getBoundingClientRect().height })));
  out.qr_svgs = svgs;
  const qrs = await p.$$('svg'); let n = 0;
  out.qr_decodificado = [];
  for (const s of qrs) { const bb = await s.boundingBox(); if (bb && bb.width > 80) { const f = path.join(D, 'capturas', `qr_${n}.png`); await s.screenshot({ path: f }); n++;
    try { const r = cp.execSync(`python3 -c "import cv2;im=cv2.imread('${f}');im=cv2.copyMakeBorder(im,40,40,40,40,cv2.BORDER_CONSTANT,value=(255,255,255));print(cv2.QRCodeDetector().detectAndDecode(im)[0])"`).toString().trim(); out.qr_decodificado.push({ f, r }); } catch (e) { out.qr_decodificado.push({ f, error: String(e).slice(0, 100) }); } } }
  out.invitar_texto = (await p.evaluate(() => document.body.innerText)).slice(0, 1800);
  // notificaciones del entrenador
  out.notificaciones = (await texto(p, '/notificaciones', 'coach_notificaciones')).tx.slice(0, 3000);
  out.notif_json = (await get(p, '/notificaciones/estado.json')).t.slice(0, 600);
  paso('coach', out); await ctx.close();
}

// ---------------------------------------------------------------- ADMIN (pagos, legal, idiomas, diagnóstico, IA)
async function fAdmin(br) {
  const cx = await nuevoCtx(br), pc = await cx.newPage(); await login(pc, CL);
  const ca = await nuevoCtx(br), pa = await ca.newPage(); await login(pa, CO);
  const out = {};
  // configurar transferencia (genera pagos.json en la carpeta de la app: dato de ejecución)
  out.config = await post(pa, '/admin/pagos', { accion: 'config', banco: 'Banco QA', beneficiario: 'FitBase QA SA de CV', clabe: '012345678901234567', cuenta: '1234567890', instrucciones: 'Usa tu folio como concepto.', cobro_activo: '1' });
  out.planes = (await texto(pc, '/planes', 'cliente_planes')).tx.slice(0, 1800);
  const pg = await texto(pc, '/pagar/pro?periodo=mensual', 'cliente_pagar_pro'); out.pagar_texto = pg.tx.slice(0, 1800);
  out.pedido = await post(pc, '/pagar/pro', { periodo: 'mensual', nombre: 'Lucia QA Prueba', email: CL.email, telefono: '5551234567', metodo: 'transferencia', terminos: '1' });
  const mp = await texto(pc, '/mis-pagos', 'cliente_mis_pagos'); out.mis_pagos = mp.tx.slice(0, 1500);
  const folio = (mp.tx.match(/\b(FB|FIT|QA)?-?[A-Z0-9]{3,}-?\d{4,}[A-Z0-9-]*\b/) || [])[0];
  const fol = await pc.evaluate(() => { const a = document.querySelector('a[href^="/pago/"]'); return a ? a.getAttribute('href').split('/')[2].split('?')[0] : null; });
  ev.pasos.folio = fol;
  if (fol) {
    const v = await texto(pc, '/pago/' + fol, 'cliente_pago_folio'); out.pago_ver = v.tx.slice(0, 2000);
    const ap = await texto(pa, '/admin/pagos', 'admin_pagos'); out.admin_pagos = ap.tx.slice(0, 2500);
    const pid = await pa.evaluate(() => { const i = document.querySelector('form input[name=id]'); return i ? i.value : null; });
    out.pedido_id = pid;
    if (pid) { out.confirmar = await post(pa, '/admin/pagos', { accion: 'confirmar', id: pid, nota: 'Depósito verificado QA' }); }
    out.pago_despues = (await texto(pc, '/pago/' + fol, 'cliente_pago_folio_pagado')).tx.slice(0, 1500);
    out.mis_pagos_despues = (await texto(pc, '/mis-pagos', 'cliente_mis_pagos_despues')).tx.slice(0, 1200);
    out.planes_despues = (await texto(pc, '/planes', 'cliente_planes_despues')).tx.slice(0, 1200);
  }
  out.legal = (await texto(pa, '/admin/legal', 'admin_legal')).tx.slice(0, 3000);
  out.arco_admin = /QA: solicito copia/.test(out.legal);
  out.idiomas = (await texto(pa, '/admin/idiomas', 'admin_idiomas')).tx.slice(0, 1500);
  out.ia = (await texto(pa, '/admin/ia', 'admin_ia')).tx.slice(0, 1500);
  // diagnóstico
  await pa.goto(B + '/admin/diagnostico');
  out.diag_antes = (await pa.evaluate(() => document.body.innerText)).slice(0, 1200);
  await pa.click('form:has([name=accion][value=ejecutar]) button');
  await pa.waitForLoadState('load');
  let fin = '';
  for (let i = 0; i < 40; i++) { await pa.waitForTimeout(5000); await pa.goto(B + '/admin/diagnostico'); fin = await pa.evaluate(() => document.body.innerText); if (!/en marcha|ejecutando|probando/i.test(fin)) break; }
  fs.writeFileSync(path.join(D, 'texto', 'admin_diagnostico_resultado.txt'), fin);
  out.diag_resultado = fin.slice(0, 3500);
  // notificaciones del entrenador tras todo
  out.coach_notificaciones_final = (await texto(pa, '/notificaciones', 'coach_notificaciones_final')).tx.slice(0, 3500);
  out.cliente_notificaciones_final = (await texto(pc, '/notificaciones', 'cliente_notificaciones_final')).tx.slice(0, 3000);
  paso('admin', out); await cx.close(); await ca.close();
}

// ---------------------------------------------------------------- PDF
async function fPdf(br) {
  const cx = await nuevoCtx(br), pc = await cx.newPage(); await login(pc, CL);
  const ca = await nuevoCtx(br), pa = await ca.newPage(); await login(pa, CO);
  const C = cid();
  await pc.goto(B + '/ejercicios'); const exs = await pc.evaluate(() => [...document.querySelectorAll('a[href^="/ejercicios/"]')].map(a => a.getAttribute('href')).filter(h => h.split('/').length === 3));
  await pc.goto(B + '/articulos'); const arts = await pc.evaluate(() => [...document.querySelectorAll('a[href^="/articulos/"]')].map(a => a.getAttribute('href')).filter(h => h.split('/').length === 3));
  await pc.goto(B + '/recetas'); const recs = await pc.evaluate(() => [...document.querySelectorAll('a[href^="/recetas/"]')].map(a => a.getAttribute('href')).filter(h => /^\/recetas\/[a-z0-9-]+(\?.*)?$/.test(h) && !/nueva|pdf/.test(h)));
  const cli = ['/mi-plan/pdf', '/programa/pdf', '/sesion/pdf', '/entrenar/pdf?m=pectoral&m=dorsal&m=cuadriceps', '/dieta/pdf', '/nutricion/pdf', '/plan-del-dia/pdf', '/menu-semanal/pdf', '/diario/pdf', '/progreso/pdf', '/mediciones/pdf', '/puntaje/pdf', '/mi-expediente.pdf', '/mis-datos.pdf', '/reporte-mensual.pdf', '/sondeo-avanzado/pdf', '/recetas/pdf', '/alimentos/pdf', '/calculadoras/pdf?tipo=calorias&sexo=Mujer&edad=34&peso=66.8&talla=163&actividad=Ligero&objetivo=Perder%20grasa&vista=detalle']
    .concat(exs.slice(0, 1).map(h => h + '/pdf'), arts.slice(0, 1).map(h => h + '/pdf'), recs.slice(0, 1).map(h => h.split('?')[0] + '/pdf'));
  if (ev.pasos.folio) cli.push(`/pago/${ev.pasos.folio}/recibo.pdf`);
  const coach = ['/coach/reporte.pdf', `/coach/cliente/${C}/dieta/pdf`, `/coach/cliente/${C}/mediciones/pdf`, `/coach/cliente/${C}/puntaje/pdf`, `/coach/cliente/${C}/expediente.pdf`, `/coach/cliente/${C}/reporte-mensual.pdf`, `/coach/cliente/${C}/menu-semanal/pdf`, `/coach/cliente/${C}/sondeo-avanzado/pdf`];
  ev.pdf = [];
  for (const [who, pg, lista] of [['cliente', pc, cli], ['coach', pa, coach]]) for (const u of lista) {
    const t0 = Date.now(); let r;
    try { r = await pg.request.get(B + u, { timeout: 60000 }); } catch (e) { ev.pdf.push({ who, u, error: String(e).slice(0, 120) }); continue; }
    const body = await r.body(), ms = Date.now() - t0, ok = r.status() < 400 && /pdf/.test(r.headers()['content-type'] || '');
    const f = `${who}_${slug(u)}.pdf`, fp = path.join(D, 'pdf', f);
    const rec = { who, u, s: r.status(), ct: r.headers()['content-type'], bytes: body.length, ms, file: 'pdf/' + f };
    if (ok) {
      fs.writeFileSync(fp, body);
      try { const tx = cp.execSync(`pdftotext -layout "${fp}" -`).toString(); fs.writeFileSync(path.join(D, 'texto', f.replace(/\.pdf$/, '.pdf.txt')), tx); rec.paginas = +(cp.execSync(`pdfinfo "${fp}" | grep Pages`).toString().match(/\d+/) || [0])[0]; rec.chars = tx.length; rec.sospechosos = [...new Set((tx.match(/\b(None|nan|NaN|undefined|null)\b|\{\{|\}\}|\[object|None%| , |—\s*—/g) || []))].slice(0, 8); rec.vacio = tx.trim().length < 80; } catch (e) { rec.error_texto = String(e).slice(0, 100); }
    }
    ev.pdf.push(rec); guardar();
  }
  await cx.close(); await ca.close();
}

// ---------------------------------------------------------------- PANTALLAS
const PAG_CLIENTE = ['/app', '/mi-plan', '/sondeo', '/sondeo-avanzado', '/programa', '/sesion', '/habitos', '/progreso', '/cuerpo', '/nutricion', '/nutricion/preferencias', '/dieta', '/plan-del-dia', '/menu-semanal', '/registrar', '/diario', '/recetas', '/alimentos', '/ejercicios', '/calculadoras', '/suplementos', '/suplementacion', '/emergencia', '/mitos', '/articulos', '/puntaje', '/fotos', '/retos', '/feedback', '/notificaciones', '/mi-privacidad', '/mediciones', '/mi-expediente', '/mis-pagos', '/planes', '/ajustes', '/guia', '/descargas', '/asistente', '/entrenar', '/privacidad', '/terminos', '/aviso-simplificado', '/consentimiento-informado'];
const PAG_COACH = () => ['/coach', '/coach/actividad', '/coach/invitar', '/coach/retos', '/coach/feedback', `/coach/cliente/${cid()}`, `/coach/cliente/${cid()}/dieta`, `/coach/cliente/${cid()}/diario`, `/coach/cliente/${cid()}/mediciones`, `/coach/cliente/${cid()}/fotos`, `/coach/cliente/${cid()}/expediente`, `/coach/cliente/${cid()}/suplementacion`, `/coach/cliente/${cid()}/preferencias`, `/coach/cliente/${cid()}/sondeo-avanzado`, `/coach/cliente/${cid()}/menu-semanal`, `/coach/cliente/${cid()}/puntaje`, '/admin', '/admin/pagos', '/admin/legal', '/admin/idiomas', '/admin/diagnostico', '/admin/ia', '/terminos-entrenadores', '/actualizaciones'];
async function fPantallas(br) {
  const variantes = [
    ['pc_claro', { viewport: { width: 1440, height: 900 }, _tema: 'light', colorScheme: 'light' }],
    ['pc_oscuro', { viewport: { width: 1440, height: 900 }, _tema: 'dark', colorScheme: 'dark' }],
    ['cel_claro', Object.assign({}, devices['iPhone 14 Pro Max'], { deviceScaleFactor: 1, _tema: 'light', colorScheme: 'light' })],
    ['cel_oscuro', Object.assign({}, devices['iPhone 14 Pro Max'], { deviceScaleFactor: 1, _tema: 'dark', colorScheme: 'dark' })]
  ];
  ev.pantallas = []; ev.consola = [];
  for (const [nom, cuenta, lista] of [['cliente', CL, PAG_CLIENTE], ['coach', CO, PAG_COACH()]]) {
    for (const [vn, vo] of variantes) {
      const ctx = await nuevoCtx(br, vo), p = await ctx.newPage();
      let actual = '';
      p.on('console', m => { if (m.type() === 'error') ev.consola.push({ cuenta: nom, v: vn, u: actual, msg: m.text().slice(0, 200) }); });
      p.on('pageerror', e => ev.consola.push({ cuenta: nom, v: vn, u: actual, msg: 'pageerror: ' + String(e).slice(0, 200) }));
      p.on('response', r => { if (r.status() >= 400 && r.url().startsWith(B)) ev.consola.push({ cuenta: nom, v: vn, u: actual, msg: `HTTP ${r.status()} ${r.url().replace(B, '')}` }); });
      await login(p, cuenta);
      for (const u of lista) {
        actual = u;
        const t0 = Date.now(); let s = null;
        try { const r = await p.goto(B + u, { waitUntil: 'load', timeout: 30000 }); s = r && r.status(); } catch (e) { s = 'ERR ' + String(e).slice(0, 60); }
        const ms = Date.now() - t0;
        const m = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth, t: document.title, h1: (document.querySelector('h1') || {}).innerText, vacio: document.body.innerText.trim().length,
          rotos: [...document.images].filter(i => i.complete && i.naturalWidth === 0).map(i => i.src.slice(-60)).slice(0, 3),
          desborde: [...document.querySelectorAll('body *')].filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.right > window.innerWidth + 2 && getComputedStyle(e).position !== 'fixed' && !e.closest('[class*=scroll],table,pre,.tabla,.tz-tabla,.sc-x'); }).slice(0, 3).map(e => (e.tagName + '.' + (e.className || '')).toString().slice(0, 60)) })).catch(() => ({}));
        const f = `${nom}_${vn}_${slug(u)}.jpg`;
        // muestra: 1 de cada 5 pantallas en jpeg
        const idx = lista.indexOf(u);
        if (idx % 5 === 0 || (m.sw && m.sw > m.iw + 2) || (s && s >= 400)) await p.screenshot({ path: path.join(D, 'capturas', f), type: 'jpeg', quality: 45 }).catch(() => { });
        ev.pantallas.push({ cuenta: nom, v: vn, u, s, ms, sw: m.sw, iw: m.iw, desbordeH: m.sw > m.iw + 2, h1: m.h1, vacio: m.vacio, rotos: m.rotos, desborde: m.desborde, lento: ms > 2000, captura: (idx % 5 === 0 || m.sw > m.iw + 2) ? 'capturas/' + f : undefined });
      }
      guardar(); await ctx.close();
    }
  }
}

(async () => {
  const br = await chromium.launch();
  const mapa = { datos: fDatos, cliente: fCliente, coach: fCoach, admin: fAdmin, idioma: fIdioma, pdf: fPdf, pantallas: fPantallas };
  for (const f of fases) {
    const t0 = Date.now();
    try { await mapa[f](br); ev.pasos['fase_' + f] = { ok: true, seg: Math.round((Date.now() - t0) / 1000) }; }
    catch (e) { ev.pasos['fase_' + f] = { ok: false, error: String(e.stack || e).slice(0, 600) }; console.log('FALLO fase', f, String(e).slice(0, 300)); }
    guardar(); console.log('fase', f, JSON.stringify(ev.pasos['fase_' + f]));
  }
  await br.close();
})();
