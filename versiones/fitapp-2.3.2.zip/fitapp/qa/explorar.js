const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const c=await b.newContext();const p=await c.newPage();
const B='http://localhost:5000';
async function dump(u){await p.goto(B+u);const r=await p.evaluate(()=>[...document.forms].map(f=>({a:f.getAttribute('action'),m:f.method,f:[...f.elements].filter(e=>e.name).map(e=>e.name+':'+e.type+(e.tagName=='SELECT'?'['+[...e.options].map(o=>o.value).slice(0,8).join('|')+']':(e.type=='radio'||e.type=='checkbox')?'='+e.value:'')).join(' ')})));console.log('==',u,p.url());r.forEach(x=>console.log(JSON.stringify(x)))}
await p.goto(B+'/login');await dump('/login');
await p.fill('[name=email]','lucia.qa@example.com');await p.fill('[name=password]','Lucia2026!');await p.click('form button[type=submit], form [type=submit]');
console.log(p.url());
for(const u of process.argv.slice(2))await dump(u);
await b.close()})();
