const { chromium, devices } = require('playwright');
const OUT = process.argv[2], BASE = 'http://127.0.0.1:5003';
const PAGS = [['inicio','/app'],['nutricion','/nutricion'],['menu_semanal','/menu-semanal'],['diario','/diario'],['programa','/programa'],['progreso','/progreso'],['suplementacion','/suplementacion'],['coach_panel','/coach'],['planes','/planes'],['portada','/']];
(async () => {
  const b = await chromium.launch();
  for (const [disp, o] of [['pc', {viewport:{width:1440,height:900}, deviceScaleFactor:1}], ['cel', devices['iPhone 14 Pro Max']]]) {
    for (const tema of ['oscuro','claro']) {
      const c = await b.newContext(o); const p = await c.newPage();
      await p.goto(BASE + '/login');
      await p.evaluate(t => localStorage.setItem('tema', t), tema === 'oscuro' ? 'dark' : 'light');
      await p.fill('input[name=email]', 'coach@fitapp.local'); await p.fill('input[name=password]', 'demo1234');
      await Promise.all([p.waitForNavigation(), p.click('button[type=submit]')]);
      for (const [n, u] of PAGS) {
        if (disp === 'cel' && tema === 'claro' && !['inicio','nutricion','coach_panel'].includes(n)) continue;
        await p.goto(BASE + u, {waitUntil: 'networkidle'}).catch(()=>{});
        await p.evaluate(() => { document.querySelectorAll('.guia-ov,.guia-overlay,[data-guia]').forEach(e=>e.remove()); });
        await p.screenshot({path: `${OUT}/${disp}_${tema}_${n}.jpg`, type: 'jpeg', quality: 72, fullPage: false});
      }
      await c.close();
    }
  }
  await b.close();
})();
