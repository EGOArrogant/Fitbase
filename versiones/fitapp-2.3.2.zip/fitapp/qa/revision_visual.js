// Revisión visual: capturas + medición automática. Uso: node qa/revision_visual.js [tag] [rol] [vistas] [temas] [filtro]
const { chromium, devices } = require('playwright');
const fs = require('fs');
const BASE = 'http://localhost:5002';
const OUT = process.env.OUT || '/home/user/fitapp/qa/salida/visual_todas';
const MODO = process.env.MODO || 'paginas'; // paginas | estados | guia
const [,, TAG = 'antes', ROLFILT = '', VISTAS = 'pc,tab,ios,and', TEMAS = 'claro,oscuro', FILT = ''] = process.argv;
const CUENTAS = {
  lucia: ['lucia.qa@example.com', 'Lucia2026!'], demo: ['demo@fitapp.local', 'demo1234'], coach: ['coach@fitapp.local', 'demo1234'], pub: null };
const PAGS = {
  lucia: ['/app', '/habitos', '/nutricion', '/diario', '/registrar', '/menu-semanal', '/progreso', '/cuerpo', '/puntaje', '/retos', '/suplementacion', '/mi-privacidad', '/ajustes', '/sesion', '/programa', '/dieta', '/alimentos', '/recetas', '/ejercicios', '/mi-plan', '/planes', '/notificaciones', '/asistente', '/guia', '/nutricion/preferencias', '/fotos', '/feedback', '/entrenar'],
  demo: ['/app', '/puntaje', '/progreso'],
  coach: ['/coach', '/coach/cliente/6', '/coach/cliente/6/puntaje', '/coach/retos', '/coach/actividad', '/coach/invitar', '/coach/feedback', '/admin', '/admin/pagos', '/admin/crear', '/admin/idiomas', '/admin/ia', '/admin/legal', '/admin/diagnostico', '/app'],
  pub: ['/', '/planes', '/login', '/registro', '/calculadoras', '/articulos', '/mitos', '/emergencia', '/ejercicios', '/recetas', '/alimentos', '/cuerpo', '/privacidad', '/aviso-simplificado', '/terminos', '/terminos-entrenadores']
};
const VIS = {
  pc: { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 },
  tab: { viewport: { width: 1024, height: 1366 }, deviceScaleFactor: 1 },
  ios: { ...devices['iPhone 14 Pro Max'], deviceScaleFactor: 1 },
  and: { viewport: { width: 360, height: 780 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36' }
};
function medir() {
  const res = { recortes: [], desborde: [], alturas: [], contraste: [], encimados: [], imgs: [], hscroll: document.documentElement.scrollWidth > innerWidth + 1 };
  const sel = el => { let s = el.tagName.toLowerCase(); if (el.id) s += '#' + el.id; if (el.className && typeof el.className === 'string') s += '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.'); return s; };
  const vis = el => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width > 2 && r.height > 2 && cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0'; };
  const all = [...document.querySelectorAll('body *')].filter(el => !['SCRIPT', 'STYLE', 'TEMPLATE', 'PATH', 'SVG', 'CIRCLE', 'LINE', 'RECT', 'G', 'POLYLINE', 'TEXT', 'TSPAN'].includes(el.tagName.toUpperCase()) && vis(el));
  const parse = c => { const m = c.match(/-?[\d.]+(?:e-?\d+)?/g); if (!m) return [0, 0, 0, 1]; const n = m.map(Number); if (/^color\(/.test(c)) return [n[0] * 255, n[1] * 255, n[2] * 255, n.length > 3 ? n[3] : 1]; return n; }; // acepta rgb(), rgba() y color(srgb …) (resultado de color-mix)
  const lum = ([r, g, b]) => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); };
  const over = (f, b) => { const a = f[3] ?? 1; return [0, 1, 2].map(i => f[i] * a + b[i] * (1 - a)).concat(1); };
  const bgEf = el => { const ch = []; let e = el; while (e) { if (getComputedStyle(e).backgroundImage !== 'none' && e !== el) return null; /* degradado o imagen: no se puede medir con fiabilidad */ const c = parse(getComputedStyle(e).backgroundColor); if (c.length < 4) c.push(1); if (c[3] > 0) ch.push(c); if (c[3] >= 1) break; e = e.parentElement; } let b = [255, 255, 255, 1]; if (!ch.length || ch[ch.length - 1][3] < 1) b = [getComputedStyle(document.documentElement).colorScheme === 'dark' ? 0 : 255, 0, 0, 1]; for (let i = ch.length - 1; i >= 0; i--) b = over(ch[i], b); return b; };
  for (const el of all) {
    const cs = getComputedStyle(el), r = el.getBoundingClientRect();
    if (el.closest('.side') && matchMedia('(max-width:900px)').matches && !document.body.classList.contains('menu-abierto')) { /* drawer cerrado */ }
    if (r.right < 0 || r.left > innerWidth + 5 && !el.closest('.tbl, .scroll, table')) { }
    const ovx = cs.overflowX, ovy = cs.overflowY;
    if ((ovx === 'hidden' || ovx === 'clip') && el.scrollWidth > el.clientWidth + 2 && el.clientWidth > 0) res.recortes.push({ el: sel(el), tipo: 'x', sw: el.scrollWidth, cw: el.clientWidth, txt: (el.innerText || '').trim().slice(0, 40) });
    if ((ovy === 'hidden' || ovy === 'clip') && el.scrollHeight > el.clientHeight + 2 && el.clientHeight > 0) res.recortes.push({ el: sel(el), tipo: 'y', sh: el.scrollHeight, ch: el.clientHeight, txt: (el.innerText || '').trim().slice(0, 40) });
    if (el.children.length === 0 && (el.innerText || '').trim() && cs.overflow === 'visible' && el.scrollWidth > el.clientWidth + 2 && cs.display !== 'inline' && !(el.closest('.side') && getComputedStyle(el.closest('.side')).transform !== 'none')) res.desborde.push({ el: sel(el), sw: el.scrollWidth, cw: el.clientWidth, txt: el.innerText.trim().slice(0, 40) });
    if (el.children.length === 0 || [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) {
      const txt = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join('').trim();
      if (txt && !(el.closest('.side') && getComputedStyle(el.closest('.side')).transform !== 'none' && r.left < 0)) {
        const fg = parse(cs.color); if (fg.length < 4) fg.push(1); const bg = bgEf(el); if (!bg) continue; const f = over(fg, bg);
        const L1 = lum(f), L2 = lum(bg), cr = (Math.max(L1, L2) + .05) / (Math.min(L1, L2) + .05);
        const big = parseFloat(cs.fontSize) >= 24 || (parseFloat(cs.fontSize) >= 18.6 && +cs.fontWeight >= 700);
        if (cr < (big ? 3 : 4.5) && !el.disabled && cs.backgroundImage === 'none') res.contraste.push({ el: sel(el), cr: +cr.toFixed(2), txt: txt.slice(0, 30) });
      }
    }
  }
  // alturas distintas en filas de tarjetas
  for (const p of document.querySelectorAll('.grid, .cards, .kpis, .kpi-row, [class*=grid], .flex')) {
    const k = [...p.children].filter(vis); if (k.length < 2) continue;
    const rows = {}; k.forEach(c => { const r = c.getBoundingClientRect(); (rows[Math.round(r.top / 10)] ||= []).push(r); });
    for (const rr of Object.values(rows)) { if (rr.length < 2) continue; const hs = rr.map(x => x.height); const mx = Math.max(...hs), mn = Math.min(...hs); if (mx > 40 && mn / mx < .6 && p.matches('.grid,.cards,.kpis,[class*=grid]')) res.alturas.push({ el: sel(p), min: Math.round(mn), max: Math.round(mx) }); }
  }
  res.casillas = [...document.querySelectorAll('input[type=checkbox],input[type=radio]')].filter(vis).filter(i => { const r = i.getBoundingClientRect(); return r.width > 32 || r.height > 32; }).map(i => ({ el: sel(i), w: Math.round(i.getBoundingClientRect().width), h: Math.round(i.getBoundingClientRect().height), txt: (i.closest('label')?.innerText || '').trim().slice(0, 30) })).slice(0, 10); // casillas/radios gigantes
  res.deformes = [...document.querySelectorAll('button,a,[role=button],[role=tab]')].filter(vis).filter(b => { const r = b.getBoundingClientRect(); return r.width < 32 && r.height >= 2.5 * r.width && !(b.innerText || '').trim(); }).map(b => ({ el: sel(b), w: Math.round(b.getBoundingClientRect().width), h: Math.round(b.getBoundingClientRect().height) })).slice(0, 10); // puntos/íconos estirados por min-height de táctil
  for (const i of document.images) if (i.complete && i.naturalWidth === 0 && i.src) res.imgs.push(i.src.slice(0, 80));
  // elementos de texto que se salen de su tarjeta
  for (const el of all) { if (el.children.length) continue; const p = el.parentElement; if (!p || !(el.innerText || '').trim()) continue; const pc = getComputedStyle(p); if (pc.overflow !== 'visible') continue; const a = el.getBoundingClientRect(), b = p.getBoundingClientRect(); if (a.right > b.right + 3 && b.width > 50 && !el.closest('.side') && getComputedStyle(el).position !== 'absolute') res.encimados.push({ el: sel(el), sobra: Math.round(a.right - b.right) }); }
  const dedup = a => { const m = new Map(); a.forEach(x => { const k = JSON.stringify([x.el, x.txt]); if (!m.has(k)) m.set(k, x); }); return [...m.values()].slice(0, 25); };
  for (const k of ['recortes', 'desborde', 'contraste', 'encimados', 'alturas', 'casillas', 'deformes']) res[k] = dedup(res[k]);
  res.vw = innerWidth; res.sw = document.documentElement.scrollWidth;
  return res;
}

// ---- Contornos recortados y bordes incompletos (se evalúa en la página; recibe el elemento opcional `solo`) ----
function medirContornos(solo) {
  const out = { contornos: [], bordes: [], tapados: [] };
  const sel = el => { let s = el.tagName.toLowerCase(); if (el.id) s += '#' + el.id; if (el.className && typeof el.className === 'string') s += '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.'); return s; };
  const px = v => parseFloat(v) || 0;
  const acc = (() => { const t = document.createElement('i'); t.style.color = 'var(--accent)'; document.body.appendChild(t); const c = getComputedStyle(t).color; t.remove(); return c; })();
  const lista = solo ? [solo] : [...document.querySelectorAll('body *')].filter(e => !/^(SCRIPT|STYLE|PATH|CIRCLE|LINE|RECT|G|POLYLINE|TEXT|TSPAN|svg)$/i.test(e.tagName));
  const clips = el => { // ancestros que recortan: devuelve {el, pad:{l,t,r,b}, x, y, scroll}
    const r = []; let a = el.parentElement;
    while (a && a !== document.documentElement) {
      const cs = getComputedStyle(a); const ox = cs.overflowX !== 'visible', oy = cs.overflowY !== 'visible';
      if (ox || oy) { const b = a.getBoundingClientRect(); r.push({ a, x: ox, y: oy, sx: /auto|scroll/.test(cs.overflowX), sy: /auto|scroll/.test(cs.overflowY), l: b.left + px(cs.borderLeftWidth), t: b.top + px(cs.borderTopWidth), r: b.right - px(cs.borderRightWidth), b: b.bottom - px(cs.borderBottomWidth), a_: a }); }
      a = a.parentElement;
    }
    r.push({ a: document.documentElement, x: true, y: false, sx: false, sy: false, l: 0, t: -1e9, r: document.documentElement.clientWidth, b: 1e9, vp: true });
    return r;
  };
  const T = 0.6;
  for (const el of lista) {
    const cs = getComputedStyle(el); const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2 || cs.visibility === 'hidden' || cs.display === 'none') continue;
    if (el.closest('.side') && getComputedStyle(el.closest('.side')).transform !== 'none') continue;
    // 1) extensión visible por fuera de la caja: outline y sombras exteriores
    let ext = { l: 0, t: 0, r: 0, b: 0 }, motivo = [];
    if (cs.outlineStyle !== 'none' && px(cs.outlineWidth) > 0) { const e = Math.max(0, px(cs.outlineWidth) + px(cs.outlineOffset)); if (e > 0) { ['l', 't', 'r', 'b'].forEach(k => ext[k] = Math.max(ext[k], e)); motivo.push('outline ' + cs.outlineWidth + ' ' + cs.outlineColor); } }
    if (cs.boxShadow !== 'none') { // anillos exteriores (blur 0 y spread > 0); las sombras difusas de elevación son decorativas
      const partes = cs.boxShadow.split(/,(?![^(]*\))/);
      for (const sh of partes) { if (/inset/.test(sh)) continue; const n = sh.replace(/rgba?\([^)]+\)/, '').match(/-?[\d.]+/g); if (!n) continue; const [ox, oy, bl = 0, sp = 0] = n.map(Number); if (bl === 0 && sp > 0) { ext.l = Math.max(ext.l, sp - ox); ext.r = Math.max(ext.r, sp + ox); ext.t = Math.max(ext.t, sp - oy); ext.b = Math.max(ext.b, sp + oy); motivo.push('anillo ' + sh.trim().slice(0, 40)); } }
    }
    // borde del color de acento (hoy, seleccionado, activo): se evalúa como borde completo
    const bordeAcento = ['Top', 'Right', 'Bottom', 'Left'].some(s => px(cs['border' + s + 'Width']) > 0 && cs['border' + s + 'Color'] === acc);
    const tieneBorde = ['Top', 'Right', 'Bottom', 'Left'].map(s => px(cs['border' + s + 'Width']) > 0 && cs['border' + s + 'Style'] !== 'none' && !/rgba\([^)]*,\s*0\)/.test(cs['border' + s + 'Color']));
    const insetAcc = /inset/.test(cs.boxShadow) && cs.boxShadow.includes(acc);
    if (!(ext.l || ext.t || ext.r || ext.b) && !bordeAcento && !insetAcc && !tieneBorde.some(Boolean)) continue;
    for (const c of clips(el)) {
      const sc = c.vp ? { l: 0, r: c.r } : c;
      const sides = [];
      // el elemento debe estar dentro de la zona visible del ancestro para que cuente (si está desplazado fuera, es scroll normal)
      const dentroX = r.right > c.l - T && r.left < c.r + T, dentroY = c.vp ? true : (r.bottom > c.t - T && r.top < c.b + T);
      if (!dentroX || !dentroY) continue;
      if (c.x) { if (r.left - ext.l < c.l - T) sides.push(['izq', c.l - (r.left - ext.l)]); if (r.right + ext.r > c.r + T) sides.push(['der', (r.right + ext.r) - c.r]); }
      if (c.y) { if (r.top - ext.t < c.t - T) sides.push(['arr', c.t - (r.top - ext.t)]); if (r.bottom + ext.b > c.b + T) sides.push(['abj', (r.bottom + ext.b) - c.b]); }
      for (const [lado, mm] of sides) {
        // contorno por fuera de la caja: error aunque sea 1 px. Caja que sola sale del contenedor: borde incompleto, salvo scroll normal.
        const propio = (lado === 'izq' && r.left < c.l - T) || (lado === 'der' && r.right > c.r + T) || (lado === 'arr' && r.top < c.t - T) || (lado === 'abj' && r.bottom > c.b + T);
        if (!propio && (ext.l || ext.t || ext.r || ext.b)) out.contornos.push({ el: sel(el), ancestro: sel(c.a), lado, px: +mm.toFixed(1), motivo: motivo.join('; '), txt: (el.innerText || '').trim().slice(0, 20) });
        else if (!propio && !c.vp && (bordeAcento || insetAcc)) { /* dentro: nada */ }
        else if (propio && !c.vp) {
          const idx = { izq: 3, der: 1, arr: 0, abj: 2 }[lado];
          const rastrea = (lado === 'izq' || lado === 'der') ? c.sx : c.sy;
          if (tieneBorde[idx] && (!rastrea) ) out.bordes.push({ el: sel(el), ancestro: sel(c.a), lado, px: +mm.toFixed(1), txt: (el.innerText || '').trim().slice(0, 20) });
        }
      }
    }
  }
  // 2) bordes tapados por un vecino encimado (solo elementos con borde visible, en la pantalla actual)
  if (!solo) {
    const vistos = new Set();
    const paso = () => {
      for (const el of lista) {
        if (vistos.has(el)) continue; const r = el.getBoundingClientRect(); if (r.width < 8 || r.height < 8 || r.bottom < 0 || r.top > innerHeight || r.left < 0 || r.right > innerWidth) continue;
        const cs = getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0' || cs.pointerEvents === 'none' && false) continue;
        if (!(['Top', 'Right', 'Bottom', 'Left'].some(s => px(cs['border' + s + 'Width']) > 0 && cs['border' + s + 'Style'] !== 'none') || px(cs.borderTopLeftRadius) >= 6 && cs.backgroundColor !== 'rgba(0, 0, 0, 0)')) continue;
        const dt = el.closest('details:not([open])'); if (dt && !el.closest('summary')) continue; // contenido de un <details> cerrado: no se ve
        vistos.add(el);
        const pts = [[r.left + r.width / 2, r.top + 1], [r.left + r.width / 2, r.bottom - 1], [r.left + 1, r.top + r.height / 2], [r.right - 1, r.top + r.height / 2]];
        for (const [x, y] of pts) {
          if (clips(el).some(c => !c.vp && (x < c.l || x > c.r || y < c.t || y > c.b))) continue; // punto fuera del área visible de un contenedor que se desliza
          const t = document.elementFromPoint(x, y); if (!t || t === el || el.contains(t) || t.contains(el)) continue;
          let f = t, fijo = false; while (f && f !== document.body) { const p = getComputedStyle(f).position; if (p === 'fixed' || p === 'sticky') { fijo = true; break; } f = f.parentElement; }
          if (fijo) continue;
          out.tapados.push({ el: sel(el), por: sel(t), txt: (el.innerText || '').trim().slice(0, 20) }); break;
        }
      }
    };
    const H = innerHeight, tot = document.documentElement.scrollHeight;
    for (let y = 0; y < Math.min(tot, 12000); y += H - 80) { window.scrollTo(0, y); paso(); }
    window.scrollTo(0, 0);
  }
  const dedup = a => { const m = new Map(); a.forEach(x => { const k = JSON.stringify([x.el, x.lado, x.por]); if (!m.has(k)) m.set(k, x); }); return [...m.values()].slice(0, 25); };
  for (const k of Object.keys(out)) out[k] = dedup(out[k]);
  return out;
}

// ---- Modo estados: foco (Tab), hover, seleccionado, día de hoy. Mide contornos con el estado aplicado y guarda acercamientos a 2x ----
const PAGS_EST = { lucia: ['/app', '/nutricion', '/registrar', '/progreso', '/diario', '/menu-semanal', '/retos', '/planes', '/ajustes', '/mi-privacidad'], coach: ['/coach', '/coach/cliente/6', '/coach/invitar', '/admin', '/admin/pagos'], pub: ['/', '/planes', '/login'] };
const GRUPOS = { boton: '.btn, .cta, .lp-btn', chip: '.chip, .cp-chip, .fb-chip, .pill', pestana: '.tab, .tabs a, [role=tab]', dia: '.dia', modo: '.rr-modo', nav: '.side a.nav, .tabbar a', campo: 'input:not([type=hidden]), select, textarea', resumen: 'summary' };
const SELECCIONADO = '.on, .sel, .activo, .hoy, [aria-selected=true], [aria-current], input:checked';
async function zoom(p, h, ruta) {
  try {
    await h.scrollIntoViewIfNeeded(); const b = await h.boundingBox(); if (!b) return;
    const vp = p.viewportSize(); const m = 16;
    const x = Math.max(0, b.x - m), y = Math.max(0, b.y - m);
    const w = Math.min(vp.width - x, Math.min(b.width, 520) + 2 * m), hh = Math.min(vp.height - y, Math.min(b.height, 300) + 2 * m);
    if (w < 20 || hh < 20) return;
    await p.screenshot({ path: ruta, clip: { x, y, width: w, height: hh } });
  } catch (e) { }
}
async function estados(br) {
  fs.mkdirSync(OUT + '/estados', { recursive: true });
  const res = {};
  for (const rol of Object.keys(PAGS_EST)) {
    if (ROLFILT && !ROLFILT.split(',').includes(rol)) continue;
    for (const v of VISTAS.split(',')) for (const tema of TEMAS.split(',')) {
      const ctx = await br.newContext({ ...VIS[v], deviceScaleFactor: 2, colorScheme: tema === 'claro' ? 'light' : 'dark' });
      await ctx.addInitScript(t => { try { localStorage.setItem('tema', t); localStorage.setItem('guiaVista', '1'); } catch (e) { } }, tema === 'claro' ? 'light' : 'dark');
      const p = await ctx.newPage();
      if (CUENTAS[rol]) { await p.goto(BASE + '/login'); await p.fill('form:has([name=password]) [name=email]', CUENTAS[rol][0]); await p.fill('form:has([name=password]) [name=password]', CUENTAS[rol][1]); await Promise.all([p.waitForLoadState('load'), p.click('form:has([name=password]) button')]); await p.waitForTimeout(400); }
      for (const url of PAGS_EST[rol]) {
        if (FILT && !url.includes(FILT)) continue;
        const clave = `${rol}_${url.replace(/[^a-z0-9]+/gi, '_').replace(/^_|_$/g, '') || 'raiz'}_${v}_${tema}`;
        const r = { contornos: [], bordes: [], focoInvisible: [], pasos: 0 };
        try {
          await p.goto(BASE + url, { waitUntil: 'load', timeout: 20000 }); await p.waitForTimeout(400);
          const imgs = {}; const firmas = new Set();
          const medirEl = async (h, estado, tomar) => {
            const m = await p.evaluate(medirContornos, h);
            for (const k of ['contornos', 'bordes']) m[k].forEach(x => r[k].push({ estado, ...x }));
            const firma = estado + '|' + await h.evaluate(e => e.tagName + '.' + (typeof e.className === 'string' ? e.className.trim().split(/\s+/).slice(0, 2).join('.') : ''));
            if (tomar && !firmas.has(firma) && (imgs[estado.split('_')[0]] || 0) < 6) { firmas.add(firma); const n = imgs[estado.split('_')[0]] = (imgs[estado.split('_')[0]] || 0) + 1; await zoom(p, h, `${OUT}/estados/${clave}_${estado}_${n}.png`); }
          };
          // foco con teclado
          for (let i = 0; i < 70; i++) {
            await p.keyboard.press('Tab'); r.pasos++;
            const h = await p.evaluateHandle(() => document.activeElement);
            const ok = await h.evaluate(e => e && e !== document.body && e.getBoundingClientRect().width > 0);
            if (!ok) continue;
            const invF = e => { const c = getComputedStyle(e); const sinOutline = c.outlineStyle === 'none' || parseFloat(c.outlineWidth) === 0; return sinOutline && c.boxShadow === 'none' ? (e.tagName + '.' + (e.className || '').toString().slice(0, 30) + '[' + (e.type || '') + ']') : null; };
            let inv = await h.evaluate(invF); if (inv) { await p.waitForTimeout(550); inv = await h.evaluate(invF); } // descarta la transición de 150 ms
            if (inv) r.focoInvisible.push(inv);
            await medirEl(h, 'foco', true);
          }
          await p.evaluate(() => { document.activeElement && document.activeElement.blur(); window.scrollTo(0, 0); });
          // hover
          for (const [g, q] of Object.entries(GRUPOS)) {
            const hs = await p.$$(q.split(',').map(x => x.trim() + ':visible').join(', ')); for (const h of hs.slice(0, 2)) { try { await h.scrollIntoViewIfNeeded(); await h.hover({ timeout: 1500 }); await medirEl(h, 'hover_' + g, true); } catch (e) { } }
          }
          await p.mouse.move(0, 0);
          // seleccionado / día de hoy
          const sh = await p.$$(SELECCIONADO.split(',').map(x => x.trim() + ':visible').join(', '));
          for (const h of sh.slice(0, 40)) await medirEl(h, 'sel', true);
        } catch (e) { r.error = String(e).slice(0, 150); }
        const dd = a => { const m = new Map(); a.forEach(x => { const k = JSON.stringify([x.estado, x.el, x.lado, x.ancestro]); if (!m.has(k)) m.set(k, x); }); return [...m.values()]; };
        r.contornos = dd(r.contornos); r.bordes = dd(r.bordes); r.focoInvisible = [...new Set(r.focoInvisible)];
        res[clave] = r;
      }
      await ctx.close();
    }
  }
  fs.writeFileSync(`${OUT}/estados_${TAG}${ROLFILT ? '_' + ROLFILT.replace(/,/g, '') : ''}_${VISTAS.replace(/,/g, '')}.json`, JSON.stringify(res, null, 1));
}
// ---- Modo guía: abre la guía de uso (modal) y mide/captura cada paso ----
async function guia(br) {
  fs.mkdirSync(OUT + '/guia', { recursive: true }); const res = {};
  for (const v of VISTAS.split(',')) for (const tema of TEMAS.split(',')) {
    const ctx = await br.newContext({ ...VIS[v], deviceScaleFactor: 1, colorScheme: tema === 'claro' ? 'light' : 'dark' });
    await ctx.addInitScript(t => { try { localStorage.setItem('tema', t); localStorage.setItem('guiaVista', '1'); } catch (e) { } }, tema === 'claro' ? 'light' : 'dark');
    const p = await ctx.newPage();
    await p.goto(BASE + '/login'); await p.fill('form:has([name=password]) [name=email]', CUENTAS.lucia[0]); await p.fill('form:has([name=password]) [name=password]', CUENTAS.lucia[1]); await Promise.all([p.waitForLoadState('load'), p.click('form:has([name=password]) button')]); await p.waitForTimeout(400);
    await p.goto(BASE + '/app?guia=1'); await p.waitForTimeout(600);
    if (!(await p.locator('.guia-caja').count())) await p.evaluate(() => window.FBguia && window.FBguia()); await p.waitForTimeout(500);
    const clave = `guia_${v}_${tema}`; res[clave] = [];
    for (let i = 0; i < 12; i++) {
      if (!(await p.locator('.guia-caja').count())) break;
      await p.waitForTimeout(500);
      const m = await p.evaluate(() => {
        const c = document.querySelector('.guia-caja'), f = document.querySelector('.guia-foco'); const r = c.getBoundingClientRect(), fr = f.getBoundingClientRect();
        const bs = [...c.querySelectorAll('button')].map(b => { const q = b.getBoundingClientRect(); return { t: b.innerText.trim(), fuera: q.left < 0 || q.right > innerWidth || q.top < 0 || q.bottom > innerHeight }; });
        const h2 = c.querySelector('h2');
        return { titulo: h2 && h2.innerText, cajaFuera: r.left < -.5 || r.right > innerWidth + .5 || r.top < -.5 || r.bottom > innerHeight + .5, caja: [r.left, r.top, r.right, r.bottom].map(Math.round), focoVisible: +f.style.opacity > 0, botonesFuera: bs.filter(b => b.fuera).map(b => b.t), scrollCaja: c.scrollHeight > c.clientHeight + 2 };
      });
      res[clave].push(m);
      if (i < 3 || m.cajaFuera || m.botonesFuera.length) await p.screenshot({ path: `${OUT}/guia/${clave}_${i + 1}.png` });
      const sig = p.locator('.guia-sig'); if (!(await sig.count())) break; await sig.click();
    }
    await ctx.close();
  }
  fs.writeFileSync(`${OUT}/guia_${TAG}_${VISTAS.replace(/,/g, '')}.json`, JSON.stringify(res, null, 1));
}
module.exports = { medir, medirContornos, VIS, CUENTAS, BASE };
(async () => {
  if (require.main !== module) return;
  const br = await chromium.launch();
  if (MODO === 'estados') { await estados(br); await br.close(); return; }
  if (MODO === 'guia') { await guia(br); await br.close(); return; }
  const resultados = {};
  for (const rol of Object.keys(PAGS)) {
    if (ROLFILT && !ROLFILT.split(',').includes(rol)) continue;
    for (const v of VISTAS.split(',')) for (const tema of TEMAS.split(',')) {
      const ctx = await br.newContext({ ...VIS[v], colorScheme: tema === 'claro' ? 'light' : 'dark' });
      await ctx.addInitScript(t => { try { localStorage.setItem('tema', t); localStorage.setItem('guiaVista', '1'); } catch (e) { } }, tema === 'claro' ? 'light' : 'dark');
      const p = await ctx.newPage();
      if (CUENTAS[rol]) {
        await p.goto(BASE + '/login'); await p.fill('form:has([name=password]) [name=email]', CUENTAS[rol][0]); await p.fill('form:has([name=password]) [name=password]', CUENTAS[rol][1]);
        await Promise.all([p.waitForLoadState('load'), p.click('form:has([name=password]) button')]); await p.waitForTimeout(500);
      }
      for (const url of PAGS[rol]) {
        if (FILT && !url.includes(FILT)) continue;
        try {
          await p.goto(BASE + url, { waitUntil: 'load', timeout: 20000 }); await p.waitForTimeout(450);
          if (await p.locator('.guia-capa').count()) { await p.keyboard.press('Escape'); await p.waitForTimeout(200); }
          const nombre = `${rol}_${url.replace(/[^a-z0-9]+/gi, '_').replace(/^_|_$/g, '') || 'raiz'}_${v}_${tema}_${TAG}`;
          await p.screenshot({ path: `${OUT}/${nombre}.jpg`, type: 'jpeg', quality: 70, fullPage: true });
          const m = await p.evaluate(medir); Object.assign(m, await p.evaluate(medirContornos)); m.status = 'ok'; resultados[nombre] = m;
        } catch (e) { resultados[`${rol}_${url}_${v}_${tema}`] = { error: String(e).slice(0, 120) }; }
      }
      await ctx.close();
    }
  }
  fs.writeFileSync(`${OUT}/medicion_${TAG}${ROLFILT ? '_' + ROLFILT.replace(/,/g, '') : ''}_${VISTAS.replace(/,/g, '')}.json`, JSON.stringify(resultados, null, 1));
  await br.close();
})();
