const { chromium, devices } = require('playwright');
(async () => {
  const b = await chromium.launch();
  for (const [nom, ctxo] of [['pc', {viewport:{width:1440,height:900}}], ['tab', {viewport:{width:1024,height:1366}}], ['cel', devices['iPhone 14 Pro Max']]]) {
    for (const tema of ['dark','light']) {
      const c = await b.newContext({...ctxo, deviceScaleFactor: 2});
      const p = await c.newPage();
      await p.goto('http://127.0.0.1:5002/login');
      await p.evaluate(t => localStorage.setItem('tema', t), tema);
      await p.fill('input[name=email]', 'demo@fitapp.local'); await p.fill('input[name=password]', 'demo1234');
      await Promise.all([p.waitForNavigation(), p.click('button[type=submit]')]);
      await p.goto('http://127.0.0.1:5002/app');
      const el = await p.$('.dia.hoy');
      if (!el) { console.log(nom, tema, 'sin .dia.hoy'); continue; }
      await el.scrollIntoViewIfNeeded();
      const m = await p.evaluate(() => { const d = document.querySelector('.dia.hoy'); const w = d.closest('.tabla-wrap'); const r = d.getBoundingClientRect(), rw = w.getBoundingClientRect(); const cs = getComputedStyle(d);
        return {izq: r.left - rw.left, der: rw.right - r.right, arriba: r.top - rw.top, outline: cs.outlineStyle, sombra: cs.boxShadow}; });
      console.log(nom, tema, JSON.stringify(m));
      const box = await el.boundingBox();
      await p.screenshot({path: `qa/salida/2026-11-23/visual2/hoy_${nom}_${tema}.png`, clip: {x: Math.max(0, box.x - 40), y: Math.max(0, box.y - 40), width: Math.min(box.width + 300, 900), height: box.height + 80}});
      await c.close();
    }
  }
  await b.close();
})();
