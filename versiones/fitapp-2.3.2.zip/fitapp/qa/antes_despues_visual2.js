// Capturas ampliadas (deviceScaleFactor 2) de los componentes corregidos en la segunda pasada visual.
// Uso: node qa/antes_despues_visual2.js antes|despues [filtro]
// «antes» sirve el CSS de la primera pasada (qa/salida/pulido_antes_pasada2.css) en lugar de static/css/pulido.css.
const { chromium, devices } = require('playwright');
const fs = require('fs');
const BASE = 'http://localhost:5002';
const FASE = process.argv[2] || 'despues', FILT = process.argv[3] || '';
const OUT = '/home/user/fitapp/qa/salida/2026-11-23/visual2';
const VIEJO = fs.readFileSync('/home/user/fitapp/qa/salida/pulido_antes_pasada2.css', 'utf8');
const D = {
  pc: { viewport: { width: 1440, height: 900 } },
  tab: { viewport: { width: 1024, height: 1366 } },
  ios: devices['iPhone 14 Pro Max'],
  and: { viewport: { width: 360, height: 780 }, isMobile: true, hasTouch: true }
};
const U = { lucia: ['lucia.qa@example.com', 'Lucia2026!'], coach: ['coach@fitapp.local', 'demo1234'], demo: ['demo@fitapp.local', 'demo1234'], pub: null };
const tabHasta = async (p, fn, max = 80) => { for (let i = 0; i < max; i++) { await p.keyboard.press('Tab'); if (await p.evaluate(fn)) return true; } return false; };
const CASOS = [
  { id: '01_pagos_config_360', rol: 'coach', url: '/admin/pagos', dev: 'and', t: 'claro', prep: async p => { await p.evaluate(() => { const d = document.querySelector('.co-factura'); d && (d.open = true); }); }, sel: '.co-factura', alto: 900 },
  { id: '02_reglas_programa_claro', rol: 'lucia', url: '/programa', dev: 'tab', t: 'claro', sel: '.card.dark' },
  { id: '03_chip_activo_hover', rol: 'coach', url: '/coach', dev: 'pc', t: 'claro', hover: '.cp-chip.on', sel: '.cp-chips' },
  { id: '04_portada_cabecera_360', rol: 'pub', url: '/', dev: 'and', t: 'claro', clip: { x: 0, y: 0, width: 360, height: 220 } },
  { id: '05_foco_menu_publico', rol: 'pub', url: '/login', dev: 'and', t: 'claro', foco: () => /Mapa muscular/.test(document.activeElement.innerText || ''), sel: '.pub-links', pad: 12 },
  { id: '06_foco_dia_menu_semanal', rol: 'lucia', url: '/menu-semanal', dev: 'and', t: 'claro', foco: () => document.activeElement.classList && document.activeElement.classList.contains('ms-dia'), sel: '.ms-dias', pad: 12 },
  { id: '07_kpi_calorias_360', rol: 'lucia', url: '/app', dev: 'and', t: 'claro', selTxt: 'Calorías promedio vs meta', sel: '.tz-kpi:has(.wl)', pad: 10 },
  { id: '08_kpi_calorias_pc', rol: 'lucia', url: '/app', dev: 'pc', t: 'oscuro', sel: '.tz-kpi:has(.wl)', pad: 10 },
  { id: '09_admin_resumen_pc', rol: 'coach', url: '/admin', dev: 'pc', t: 'claro', sel: '.tz-kpis', pad: 10 },
  { id: '10_invitar_enlace_360', rol: 'coach', url: '/coach/invitar', dev: 'and', t: 'claro', sel: '.inv-link', pad: 12 },
  { id: '11_tabla_desliza_resumen_360', rol: 'lucia', url: '/progreso', dev: 'and', t: 'claro', sel: 'section.card:has(h2:text("Resumen semanal")) .tabla-wrap', pad: 10 },
  { id: '12_tabla_desliza_programa_tableta', rol: 'lucia', url: '/programa', dev: 'tab', t: 'oscuro', sel: '.prog-wrap', pad: 10 },
  { id: '13_foco_riel_claro', rol: 'lucia', url: '/app', dev: 'pc', t: 'claro', foco: () => document.activeElement.matches('.side a[href="/app"]'), sel: '.side', clip: { x: 0, y: 0, width: 200, height: 330 } },
  { id: '15_dietas_radio_360', rol: 'lucia', url: '/nutricion/preferencias', dev: 'and', t: 'claro', sel: '.al-dietas', alto: 420, pad: 6 },
  { id: '16_articulos_puntos_360', rol: 'pub', url: '/articulos', dev: 'and', t: 'claro', sel: '.art-slide-txt', alto: 520, pad: 4 },
  { id: '17_coach_kpis_360', rol: 'coach', url: '/coach', dev: 'and', t: 'claro', sel: '.cp-kpis', pad: 8 },
  { id: '18_radar_ficha_pc', rol: 'coach', url: '/coach/cliente/6', dev: 'pc', t: 'claro', sel: '.chart.radar', pad: 14 },
  { id: '19_kpi_texto_largo_360', rol: 'lucia', url: '/nutricion/preferencias', dev: 'and', t: 'claro', sel: '.tz-kpis', pad: 8, alto: 330 },
  { id: '14_hoy_calendario_360', rol: 'demo', url: '/app', dev: 'and', t: 'claro', sel: '.dia.hoy', pad: 24 }
];
(async () => {
  const br = await chromium.launch();
  for (const c of CASOS) {
    if (FILT && !c.id.includes(FILT)) continue;
    const ctx = await br.newContext({ ...D[c.dev], deviceScaleFactor: 2, colorScheme: c.t === 'claro' ? 'light' : 'dark' });
    const tema = c.t === 'claro' ? 'light' : 'dark';
    await ctx.addInitScript(t => { try { localStorage.setItem('tema', t); localStorage.setItem('guiaVista', '1'); } catch (e) { } }, tema);
    if (FASE === 'antes') await ctx.route('**/static/css/pulido.css*', r => r.fulfill({ status: 200, contentType: 'text/css', body: VIEJO }));
    const p = await ctx.newPage();
    try {
      if (U[c.rol]) { await p.goto(BASE + '/login'); await p.fill('form:has([name=password]) [name=email]', U[c.rol][0]); await p.fill('form:has([name=password]) [name=password]', U[c.rol][1]); await Promise.all([p.waitForLoadState('load'), p.click('form:has([name=password]) button')]); }
      await p.goto(BASE + c.url, { waitUntil: 'load' }); await p.waitForTimeout(700);
      if (c.prep) await c.prep(p);
      if (c.foco) await tabHasta(p, c.foco);
      let h = c.sel ? p.locator(c.sel).first() : null;
      if (c.hover) { await p.locator(c.hover).first().hover(); }
      if (h) { await h.scrollIntoViewIfNeeded(); }
      await p.waitForTimeout(350);
      let clip = c.clip;
      if (!clip && h) {
        const b = await h.boundingBox(); const pad = c.pad ?? 8, vp = p.viewportSize();
        const x = Math.max(0, b.x - pad), y = Math.max(0, b.y - pad);
        clip = { x, y, width: Math.min(vp.width - x, b.width + 2 * pad), height: Math.min(vp.height - y, Math.min(b.height, c.alto || 520) + 2 * pad) };
      }
      await p.screenshot({ path: `${OUT}/${c.id}_${FASE}.png`, clip });
      console.log('ok', c.id, FASE);
    } catch (e) { console.log('ERROR', c.id, String(e).slice(0, 160)); }
    await ctx.close();
  }
  await br.close();
})();
