import json,sys,collections
r=json.load(open(sys.argv[1]))
c=collections.Counter()
for p in r['paginas']:
    for f in p.get('fallos',[]):
        import re
        c[(re.sub(r'[\d.]+','N',f)[:90], p['url'] if 'desborde' in f or 'barra' in f or 'cort' in f else '', p['vista'])]+=1
for k,v in c.most_common(45): print(v,k)
print('--consola');
cc=collections.Counter((x['tipo'],x['texto'][:90],x['url']) for x in r['consola'])
for k,v in cc.items(): print(v,k)
print('--flechas')
for x in r['flechas']:
    if x['ok'] is not True: print(x)
print('--esp visible')
es=collections.Counter()
for p in r['paginas']:
    for l in p.get('espanol_visible',[]): es[(p['url'],l[:70])]+=1
print(len(es)); 
for k in list(es)[:25]: print(k)
print('--cortados/sin_nombre')
for p in r['paginas']:
    if p.get('cortados') or p.get('sin_nombre'): print(p['url'],p['vista'],p['cortados'][:2],p['sin_nombre'][:2]); 
