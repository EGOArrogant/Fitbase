const { chromium, devices } = require('playwright');
(async () => {
  const b = await chromium.launch(); const malos=[];
  for (const modo of ['riel','expandido']) for (const w of [1920,1600,1440,1366,1280,1180,1024,900,820,768,600,430,390,360]) {
    const c = await b.newContext({viewport:{width:w,height:900}}); const p = await c.newPage();
    await p.goto('http://127.0.0.1:' + (process.env.PUERTO || 5003) + '/login');
    await p.evaluate(m => { localStorage.setItem('menuModo', m === 'riel' ? 'riel' : 'expandido'); }, modo);
    await p.fill('input[name=email]','coach@fitapp.local'); await p.fill('input[name=password]','demo1234');
    await Promise.all([p.waitForNavigation(), p.click('button[type=submit]')]);
    await p.goto('http://127.0.0.1:' + (process.env.PUERTO || 5003) + '/app');
    const m = await p.evaluate(() => { const w=document.querySelector('.tabla-wrap:has(.tz-cal)'); const hoy=document.querySelector('.dia.hoy'); const r=hoy.getBoundingClientRect(), rw=w.getBoundingClientRect();
      const sem=[...w.querySelectorAll('.tz-cal > *')].pop().getBoundingClientRect();
      return {client:w.clientWidth, scroll:w.scrollWidth, hoyDentro: r.left>=rw.left && r.right<=rw.right, semDer: Math.round(rw.right-sem.right), riel: document.body.classList.contains('menu-riel')}; });
    const ok = m.scroll <= m.client && m.hoyDentro && m.semDer >= 0;
    if (!ok || w===1440 || w===390) console.log(modo, w, JSON.stringify(m), ok?'OK':'MAL');
    if (!ok) malos.push(modo+w);
    if (modo==='expandido' && w===1440) await p.screenshot({path:'qa/salida/cal1440.png', clip:{x:0,y:300,width:1440,height:600}});
    await c.close();
  }
  console.log('malos:', malos.join(' ')||'ninguno'); await b.close();
})();
