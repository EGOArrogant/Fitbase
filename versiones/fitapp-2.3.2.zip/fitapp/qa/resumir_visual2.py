"""Resume los JSON de revision_visual.js: contornos recortados, bordes incompletos, bordes tapados, hscroll, desborde y contraste."""
import json, glob, sys, collections
d = sys.argv[1]; tag = sys.argv[2] if len(sys.argv) > 2 else 'antes'
agg = collections.defaultdict(list)
for f in sorted(glob.glob(f'{d}/medicion_{tag}_*.json')):
    for k, v in json.load(open(f)).items():
        if 'error' in v: agg['ERROR'].append((k, v['error'])); continue
        for c in ('contornos', 'bordes', 'tapados', 'recortes', 'desborde', 'encimados', 'imgs', 'casillas', 'deformes'):
            for x in v.get(c, []): agg[c].append((k, x))
        if v.get('hscroll'): agg['hscroll'].append((k, f"{v['sw']}>{v['vw']}"))
        for x in v.get('contraste', []): agg['contraste'].append((k, x))
for c, l in agg.items():
    print('==', c, len(l))
    seen = collections.OrderedDict()
    for k, x in l:
        kk = json.dumps({a: b for a, b in (x.items() if isinstance(x, dict) else [('x', x)]) if a not in ('px', 'sw', 'cw', 'sh', 'ch', 'cr', 'sobra', 'min', 'max')}, ensure_ascii=False)
        seen.setdefault(kk, []).append(k.split('_', 1)[1] if '_' in k else k)
    for kk, ks in list(seen.items())[:40]: print(' ', kk[:200], '|', len(ks), ks[0], ks[-1])
