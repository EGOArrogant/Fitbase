"""Resume estados_*.json de revision_visual.js (MODO=estados)."""
import json, glob, sys, collections
d = sys.argv[1]; tag = sys.argv[2] if len(sys.argv) > 2 else 'antes'
agg = collections.defaultdict(lambda: collections.defaultdict(list))
for f in sorted(glob.glob(f'{d}/estados_{tag}_*.json')):
    for k, v in json.load(open(f)).items():
        if v.get('error'): agg['ERROR'][v['error'][:80]].append(k)
        for c in ('contornos', 'bordes'):
            for x in v[c]: agg[c][json.dumps({a: b for a, b in x.items() if a not in ('px', 'txt')}, ensure_ascii=False)].append(k + f"({x.get('px')})")
        for x in v['focoInvisible']: agg['focoInvisible'][x].append(k)
for c, m in agg.items():
    print('==', c, sum(len(l) for l in m.values()))
    for kk, l in list(m.items())[:60]: print(' ', kk[:230], '|', len(l), l[0], l[-1])
