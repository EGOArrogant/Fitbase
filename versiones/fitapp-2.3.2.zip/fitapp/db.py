"""Base de datos SQLite (archivo fitapp.db junto a la app) y datos de demostración."""
import json
import os
import random
import shutil
import sqlite3
import datetime as dt
from werkzeug.security import generate_password_hash

from data.contenido import PLANTILLAS, SMAE_EJEMPLO

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("FITAPP_DB") or os.path.join(BASE, "fitapp.db")
BACKUP_DIR = os.path.join(BASE, "respaldos")

SCHEMA = """
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  nombre TEXT NOT NULL,
  password TEXT NOT NULL,
  rol TEXT NOT NULL DEFAULT 'cliente',
  coach_id INTEGER,
  codigo_coach TEXT,
  perfil TEXT,
  programa TEXT,
  checklist TEXT,
  smae TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS series (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  fecha TEXT NOT NULL,
  ejercicio TEXT NOT NULL,
  serie INTEGER,
  peso REAL,
  reps INTEGER,
  rir REAL,
  nota TEXT
);
CREATE TABLE IF NOT EXISTS registros (
  usuario_id INTEGER NOT NULL,
  fecha TEXT NOT NULL,
  peso REAL, kcal REAL, proteina REAL, pasos INTEGER, sueno REAL,
  entreno TEXT, energia INTEGER, cintura REAL, notas TEXT, etiquetas TEXT,
  PRIMARY KEY (usuario_id, fecha)
);
CREATE TABLE IF NOT EXISTS recetas_usuario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  autor_id INTEGER NOT NULL,
  nombre TEXT NOT NULL,
  tipo TEXT NOT NULL,
  tags TEXT,
  ing TEXT NOT NULL,
  pasos TEXT,
  minutos INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS diario_comidas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  fecha TEXT NOT NULL,
  tiempo TEXT NOT NULL,
  alimento TEXT NOT NULL,
  porcion TEXT,
  gramos REAL,
  kcal REAL, prot REAL, carb REAL, grasa REAL
);
CREATE TABLE IF NOT EXISTS mediciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  autor_id INTEGER,
  fecha TEXT NOT NULL,
  tipo TEXT NOT NULL,
  datos TEXT NOT NULL,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS productos (
  codigo TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  marca TEXT,
  kcal REAL, prot REAL, carb REAL, grasa REAL, fibra REAL, azucar REAL, sodio REAL,
  porcion_g REAL,
  porcion_desc TEXT,
  fuente TEXT,
  autor_id INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS fotos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  autor_id INTEGER,
  fecha TEXT NOT NULL,
  angulo TEXT NOT NULL,
  archivo TEXT NOT NULL,
  peso REAL,
  nota TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  tipo TEXT NOT NULL,
  area TEXT,
  calificacion INTEGER,
  texto TEXT NOT NULL,
  publico INTEGER DEFAULT 1,
  estado TEXT DEFAULT 'nuevo',
  respuesta TEXT,
  respondio_id INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  actualizado TEXT
);
CREATE TABLE IF NOT EXISTS feedback_votos (
  feedback_id INTEGER NOT NULL,
  usuario_id INTEGER NOT NULL,
  PRIMARY KEY (feedback_id, usuario_id)
);
CREATE TABLE IF NOT EXISTS retos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  titulo TEXT NOT NULL,
  descripcion TEXT,
  tipo TEXT NOT NULL,
  meta REAL NOT NULL,
  inicio TEXT NOT NULL,
  fin TEXT NOT NULL,
  puntos INTEGER DEFAULT 100,
  nivel TEXT DEFAULT 'Todos',
  cuota REAL DEFAULT 0,
  premios TEXT,
  cupo INTEGER,
  validar INTEGER DEFAULT 0,
  tier_min TEXT,
  creador_id INTEGER,
  activo INTEGER DEFAULT 1,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS retos_inscritos (
  reto_id INTEGER NOT NULL,
  usuario_id INTEGER NOT NULL,
  inscrito TEXT DEFAULT CURRENT_TIMESTAMP,
  pagado INTEGER DEFAULT 0,
  pago_ref TEXT,
  monto REAL,
  progreso_manual REAL,
  completado TEXT,
  validado INTEGER DEFAULT 0,
  puntos INTEGER DEFAULT 0,
  lugar INTEGER,
  PRIMARY KEY (reto_id, usuario_id)
);
CREATE TABLE IF NOT EXISTS invitaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT UNIQUE NOT NULL,
  coach_id INTEGER NOT NULL,
  nombre TEXT,
  contacto TEXT,
  nota TEXT,
  max_usos INTEGER DEFAULT 1,
  usos INTEGER DEFAULT 0,
  expira TEXT,
  cliente_id INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  ultimo_uso TEXT
);
CREATE TABLE IF NOT EXISTS consentimientos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  tipo TEXT NOT NULL, otorgado INTEGER NOT NULL, version TEXT, huella TEXT,
  ip TEXT, agente TEXT, detalle TEXT, creado TEXT
);
CREATE INDEX IF NOT EXISTS idx_consent_usuario ON consentimientos(usuario_id, tipo);
CREATE TABLE IF NOT EXISTS solicitudes_arco (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  folio TEXT UNIQUE, usuario_id INTEGER, nombre TEXT, email TEXT, tipo TEXT, descripcion TEXT,
  estado TEXT DEFAULT 'recibida', respuesta TEXT, creado TEXT, vence TEXT, respondido TEXT
);
CREATE TABLE IF NOT EXISTS errores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ruta TEXT, metodo TEXT, usuario_id INTEGER, tipo TEXT, mensaje TEXT, traza TEXT, veces INTEGER DEFAULT 1,
  creado TEXT, ultimo TEXT, resuelto INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS notificaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  tipo TEXT, titulo TEXT NOT NULL, texto TEXT, url TEXT, actor_id INTEGER,
  leida INTEGER DEFAULT 0,
  creado TEXT
);
CREATE INDEX IF NOT EXISTS idx_notif_usuario ON notificaciones(usuario_id, leida);
CREATE TABLE IF NOT EXISTS actividad (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER NOT NULL,
  coach_id INTEGER NOT NULL,
  tipo TEXT, texto TEXT, url TEXT, detalle TEXT,
  n INTEGER DEFAULT 1,
  creado TEXT
);
CREATE INDEX IF NOT EXISTS idx_actividad_coach ON actividad(coach_id, creado);
CREATE TABLE IF NOT EXISTS pedidos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  folio TEXT UNIQUE NOT NULL,
  usuario_id INTEGER NOT NULL,
  plan TEXT NOT NULL,
  periodo TEXT NOT NULL,
  monto INTEGER NOT NULL,
  moneda TEXT DEFAULT 'MXN',
  metodo TEXT NOT NULL,
  estado TEXT DEFAULT 'pendiente',
  nombre TEXT, email TEXT, telefono TEXT,
  factura TEXT,
  stripe_sesion TEXT,
  referencia TEXT,
  comprobante TEXT,
  nota_admin TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  pagado_en TEXT,
  vigencia_hasta TEXT
);
CREATE INDEX IF NOT EXISTS idx_pedidos_usuario ON pedidos(usuario_id);
CREATE TABLE IF NOT EXISTS api_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hash TEXT UNIQUE NOT NULL,
  usuario_id INTEGER NOT NULL,
  dispositivo TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  ultimo_uso TEXT
);
CREATE TABLE IF NOT EXISTS comentarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  autor_id INTEGER NOT NULL,
  texto TEXT NOT NULL,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


def conectar():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def respaldar(max_copias=10):
    """Copia rotativa del archivo de base de datos al iniciar."""
    if os.environ.get("FITAPP_DB") or not os.path.exists(DB_PATH):
        return
    os.makedirs(BACKUP_DIR, exist_ok=True)
    destino = os.path.join(BACKUP_DIR, f"fitapp-{dt.datetime.now():%Y%m%d-%H%M%S}.db")
    shutil.copy2(DB_PATH, destino)
    copias = sorted(f for f in os.listdir(BACKUP_DIR) if f.endswith(".db"))
    for f in copias[:-max_copias]:
        os.remove(os.path.join(BACKUP_DIR, f))


def perfil_base(**kw):
    p = dict(sexo="Hombre", edad=24, peso=90.0, talla=174.0, nivel="Intermedio", objetivo="Perder grasa", ritmo=0.5,
             actividad="Moderado", dias=4, duracion=60, comidas=4, cuello=40.0, cintura=92.0, cadera=None,
             grasa_medida=None, neat=0.15, cardio_min=30, cardio_ses=3, cardio_met=3.5, ecuacion="",
             parq=[False] * 7, condiciones=[], preferencias=[], equipo="Gimnasio completo",
             inicio=str(dt.date.today()), bienestar=False)
    p.update(kw)
    return p


MIGRACIONES = ["ALTER TABLE diario_comidas ADD COLUMN fibra REAL", "ALTER TABLE diario_comidas ADD COLUMN alimento_id INTEGER",
               "ALTER TABLE diario_comidas ADD COLUMN fuente TEXT",
               "ALTER TABLE usuarios ADD COLUMN es_admin INTEGER DEFAULT 0", "ALTER TABLE usuarios ADD COLUMN plan TEXT DEFAULT 'gratis'",
               "ALTER TABLE usuarios ADD COLUMN plan_vence TEXT", "ALTER TABLE usuarios ADD COLUMN plan_nota TEXT",
               "ALTER TABLE usuarios ADD COLUMN activo INTEGER DEFAULT 1", "ALTER TABLE usuarios ADD COLUMN ultimo_acceso TEXT",
               "ALTER TABLE usuarios ADD COLUMN guia_vista TEXT"]


def init_db(con):
    con.executescript(SCHEMA)
    for m in MIGRACIONES:   # columnas nuevas en bases ya creadas (se ignoran si ya existen)
        try:
            con.execute(m)
        except sqlite3.OperationalError:
            pass
    con.commit()


def crear_usuario(con, email, nombre, password, rol="cliente", coach_id=None, perfil=None, programa_key="torso-pierna-4"):
    codigo = None
    if rol == "entrenador":
        codigo = "".join(random.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6))
    cur = con.execute(
        "INSERT INTO usuarios (email, nombre, password, rol, coach_id, codigo_coach, perfil, programa, checklist, smae) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (email.lower().strip(), nombre, generate_password_hash(password), rol, coach_id, codigo,
         json.dumps(perfil) if perfil else None, json.dumps(PLANTILLAS[programa_key]), json.dumps({}), json.dumps(SMAE_EJEMPLO)))
    con.commit()
    return cur.lastrowid


def _seed_cliente(con, uid, peso0, tendencia_kg, kcal_base, prot_base, adherencia, rng, inicio, prog):
    dias = (dt.date.today() - inicio).days
    peso = peso0
    dias_entreno = {d["dia"] for d in prog["dias"]}
    for i in range(dias + 1):
        f = inicio + dt.timedelta(days=i)
        peso += tendencia_kg / 7
        entreno = "Sí" if f.weekday() in dias_entreno else "Descanso"
        if entreno == "Sí" and rng.random() > adherencia:
            entreno = "No"
        if rng.random() < 0.08 and i != dias:
            continue  # día sin registro
        con.execute("INSERT OR REPLACE INTO registros (usuario_id, fecha, peso, kcal, proteina, pasos, sueno, entreno, energia, cintura, etiquetas) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (uid, str(f), round(peso + rng.uniform(-0.45, 0.45), 1), rng.choice([kcal_base - 60, kcal_base, kcal_base + 30, kcal_base + 80, kcal_base + 450]),
                     rng.choice([prot_base - 20, prot_base - 6, prot_base, prot_base + 7]), rng.randint(6000, 11000),
                     round(rng.uniform(6.2, 8.2), 1), entreno, rng.choice([3, 3, 4, 4, 5]),
                     None, json.dumps(rng.sample(["Dormí poco", "Comí fuera", "Estrés alto", "Buena técnica", "Récord personal"], k=rng.choice([0, 0, 1])))))
        if entreno == "Sí":
            dia = next(d for d in prog["dias"] if d["dia"] == f.weekday())
            semana = i // 7
            for e in dia["ejercicios"][:4]:
                base = {"Press de banca": 80, "Remo con barra": 70, "Press inclinado con mancuernas": 30, "Jalón al pecho": 60,
                        "Sentadilla con barra": 100, "Peso muerto rumano": 90, "Prensa de piernas": 180, "Curl femoral sentado": 45,
                        "Press inclinado con barra": 60, "Remo en polea baja": 60, "Press militar con mancuernas": 22, "Jalón con agarre estrecho": 55,
                        "Peso muerto": 120, "Sentadilla búlgara": 20, "Hip thrust con barra": 100, "Extensión de cuádriceps": 50}.get(e["ex"], 30)
                carga = round(base * (1 + 0.0125 * semana) * 2) / 2
                for s in range(e["series"]):
                    reps = min(e["rmax"], e["rmin"] + 1 + semana - (1 if s == e["series"] - 1 and semana < 2 else 0))
                    rir = max(0, e["rir"] - (1 if s == e["series"] - 1 and semana < 2 else 0))
                    con.execute("INSERT INTO series (usuario_id, fecha, ejercicio, serie, peso, reps, rir) VALUES (?,?,?,?,?,?,?)",
                                (uid, str(f), e["ex"], s + 1, carga, reps, rir))
    con.commit()


def seed_demo(con):
    if con.execute("SELECT 1 FROM usuarios WHERE email='demo@fitapp.local'").fetchone():
        return
    inicio = dt.date.today() - dt.timedelta(days=20)
    coach = crear_usuario(con, "coach@fitapp.local", "Entrenador demo", "demo1234", rol="entrenador",
                          perfil=perfil_base(inicio=str(inicio)))
    rng = random.Random(7)
    demo = crear_usuario(con, "demo@fitapp.local", "Cliente ejemplo", "demo1234", coach_id=coach,
                         perfil=perfil_base(inicio=str(inicio), cardio_min=30, cardio_ses=5))
    _seed_cliente(con, demo, 90.0, -0.45, 2380, 198, 0.95, rng, inicio, PLANTILLAS["torso-pierna-4"])
    extras = [("Cliente 2", "Mujer", 28, 62.0, 165, "Ganar músculo", 0.25, "full-body-3", 0.2, 2150, 120, 0.9),
              ("Cliente 3", "Hombre", 35, 82.0, 178, "Recomposición", 0.25, "torso-pierna-4", -0.1, 2500, 165, 0.75),
              ("Cliente 4", "Mujer", 41, 74.0, 160, "Perder grasa", 0.5, "full-body-3", -0.15, 1800, 120, 0.5)]
    for i, (n, sexo, edad, peso, talla, obj, ritmo, prog, tend, kc, pr, adh) in enumerate(extras):
        uid = crear_usuario(con, f"cliente{i + 2}@fitapp.local", n, "demo1234", coach_id=coach, programa_key=prog,
                            perfil=perfil_base(sexo=sexo, edad=edad, peso=peso, talla=talla, objetivo=obj, ritmo=ritmo,
                                               cintura=75.0 if sexo == "Mujer" else 88.0, cadera=98.0 if sexo == "Mujer" else None,
                                               cuello=33.0 if sexo == "Mujer" else 39.0, dias=PLANTILLAS[prog]["dias_semana"],
                                               nivel="Principiante" if prog == "full-body-3" else "Intermedio", inicio=str(inicio),
                                               parq=[False, False, False, False, False, True, False] if i == 2 else [False] * 7))
        _seed_cliente(con, uid, peso, tend, kc, pr, adh, rng, inicio, PLANTILLAS[prog])
    con.execute("UPDATE usuarios SET plan='coach15', plan_nota='Cuenta de demostración' WHERE id=?", (coach,))
    ahora = dt.datetime.now()
    hace = lambda m: (ahora - dt.timedelta(minutes=m)).isoformat(timespec="seconds")
    ids = [r[0] for r in con.execute("SELECT id FROM usuarios WHERE coach_id=? ORDER BY id", (coach,)).fetchall()]
    url = lambda i: f"/coach/cliente/{i}"
    for actor, tipo, texto, det, n, m in [
            (ids[0], "entreno", "registró series de entrenamiento", ["Sentadilla trasera: 100 kg × 5", "Sentadilla trasera: 100 kg × 5", "Sentadilla trasera: 102.5 kg × 4"], 3, 4),
            (ids[1], "comida", "registró comidas", ["Avena con plátano, Yogur griego"], 1, 22),
            (ids[2], "dia", "registró su día", ["82.6 kg · 8,450 pasos · 7.0 h de sueño"], 1, 55),
            (ids[0], "dia", "registró su día", ["89.1 kg · 11,200 pasos · 7.5 h de sueño · entrenó"], 1, 140),
            (ids[3], "reto", "se inscribió al reto", ["10,000 pasos diarios"], 1, 300),
            (ids[1], "medicion", "registró mediciones corporales", [], 1, 60 * 26)]:
        con.execute("INSERT INTO actividad (actor_id, coach_id, tipo, texto, url, detalle, n, creado) VALUES (?,?,?,?,?,?,?,?)",
                    (actor, coach, tipo, texto, url(actor), json.dumps(det, ensure_ascii=False), n, hace(m)))
    con.execute("INSERT INTO notificaciones (usuario_id, tipo, titulo, texto, url, actor_id, creado) VALUES (?,?,?,?,?,?,?)",
                (demo, "comentario", "Tu entrenador te dejó un comentario", "Vi tu sentadilla del martes: deja la última serie a RIR 2 esta semana.", "/app", coach, hace(180)))
    con.execute("INSERT INTO comentarios (usuario_id, autor_id, texto) VALUES (?,?,?)",
                (demo, coach, "Vi tu sentadilla del martes: deja la última serie a RIR 2 esta semana y cuida la profundidad."))
    con.commit()
