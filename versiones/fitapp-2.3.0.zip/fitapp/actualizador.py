"""Actualizaciones sin reinstalar.

Un paquete de actualización es un ZIP con la carpeta de la app (puede venir dentro de una carpeta "fitapp/") y un
archivo VERSION. Al aplicarlo:
1. Se valida el ZIP (sin rutas peligrosas, con VERSION y app.py) y, si hay manifiesto, su SHA-256.
2. Se respaldan el código actual y la base de datos en respaldos/.
3. Se copian los archivos nuevos SIN tocar los datos del usuario (base de datos, respaldos, clave, videos, modelos, entorno).
4. Al reiniciar, el script de inicio instala dependencias nuevas y la base aplica sus migraciones.

Actualización en línea (opcional): define la variable FITAPP_UPDATE_URL con la dirección de un manifiesto JSON
{"version": "2.1.0", "url": "https://.../fitapp-2.1.0.zip", "sha256": "...", "notas": "..."}.
"""
import datetime as dt
import hashlib
import io
import json
import os
import shutil
import urllib.error
import urllib.request
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
PROTEGIDOS = ("fitapp.db", "fitapp.db-journal", "respaldos/", ".secret_key", "static/videos/", "static/modelos/", "fotos/", ".venv/", "venv/",
              "actualizaciones.json", "pagos.json", "comprobantes/", "idiomas/auto/", "legal.json", "ia.json", "diagnostico/")
CONFIG = os.path.join(BASE, "actualizaciones.json")
REPO_OK = __import__("re").compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")


def leer_config():
    c = {"fuente": "", "repo": "", "url": "", "auto": False, "cada_horas": 6, "ultima_revision": None, "ultimo_error": None}
    try:
        with open(CONFIG, encoding="utf-8") as f:
            c.update(json.load(f))
    except (OSError, ValueError):
        pass
    return c


def guardar_config(c):
    with open(CONFIG + ".tmp", "w", encoding="utf-8") as f:
        json.dump(c, f, ensure_ascii=False, indent=1)
    os.replace(CONFIG + ".tmp", CONFIG)


def url_manifiesto(c=None):
    """Dirección del archivo version.json: variable de entorno > dirección directa > repositorio de GitHub."""
    c = c or leer_config()
    if os.environ.get("FITAPP_UPDATE_URL"):
        return os.environ["FITAPP_UPDATE_URL"]
    if c.get("fuente") == "url" and c.get("url"):
        return c["url"]
    if c.get("fuente") == "github" and REPO_OK.match(c.get("repo") or ""):
        return f"https://github.com/{c['repo']}/releases/latest/download/version.json"
    return None


def version_actual():
    try:
        with open(os.path.join(BASE, "VERSION"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return "0.0.0"


def _tupla(v):
    out = []
    for x in v.strip().split("."):
        try:
            out.append(int(x))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def es_mas_nueva(nueva, actual=None):
    return _tupla(nueva) > _tupla(actual or version_actual())


def _protegido(rel):
    rel = rel.replace("\\", "/")
    return any(rel == p.rstrip("/") or rel.startswith(p) for p in PROTEGIDOS)


def inspeccionar(datos):
    """Valida el ZIP y devuelve (prefijo, version, lista de archivos relativos). Lanza ValueError si no es válido."""
    try:
        z = zipfile.ZipFile(io.BytesIO(datos))
    except zipfile.BadZipFile:
        raise ValueError("El archivo no es un ZIP válido.")
    nombres = [n for n in z.namelist() if not n.endswith("/")]
    prefijo = "fitapp/" if any(n.startswith("fitapp/") for n in nombres) else ""
    if f"{prefijo}VERSION" not in nombres or f"{prefijo}app.py" not in nombres:
        raise ValueError("El paquete no parece una actualización de la app (faltan VERSION o app.py).")
    archivos = []
    for n in nombres:
        if not n.startswith(prefijo):
            continue
        rel = n[len(prefijo):]
        norm = os.path.normpath(rel)
        if rel.startswith(("/", "\\")) or norm.startswith("..") or os.path.isabs(norm) or ":" in rel:
            raise ValueError(f"Ruta no permitida dentro del paquete: {n}")
        archivos.append(rel)
    version = z.read(f"{prefijo}VERSION").decode("utf-8").strip()
    return prefijo, version, archivos


def respaldar_codigo():
    os.makedirs(os.path.join(BASE, "respaldos"), exist_ok=True)
    destino = os.path.join(BASE, "respaldos", f"codigo-{version_actual()}-{dt.datetime.now():%Y%m%d-%H%M%S}.zip")
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for raiz, dirs, files in os.walk(BASE):
            rel_raiz = os.path.relpath(raiz, BASE).replace("\\", "/")
            dirs[:] = [d for d in dirs if d not in ("__pycache__",) and not _protegido((rel_raiz + "/" + d + "/").lstrip("./"))]
            for f in files:
                rel = os.path.relpath(os.path.join(raiz, f), BASE).replace("\\", "/")
                if not _protegido(rel) and not rel.endswith(".pyc"):
                    z.write(os.path.join(raiz, f), rel)
    return destino


def aplicar(datos, sha256=None):
    """Aplica el paquete. Devuelve dict con versión anterior y nueva, archivos copiados y ruta del respaldo."""
    if sha256 and hashlib.sha256(datos).hexdigest().lower() != sha256.lower():
        raise ValueError("La firma SHA-256 del paquete no coincide: descarga incompleta o archivo alterado.")
    prefijo, version, archivos = inspeccionar(datos)
    anterior = version_actual()
    respaldo = respaldar_codigo()
    import db
    db.respaldar()
    z = zipfile.ZipFile(io.BytesIO(datos))
    copiados = 0
    for rel in archivos:
        if _protegido(rel):
            continue
        destino = os.path.join(BASE, rel)
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        with z.open(prefijo + rel) as src, open(destino + ".nuevo", "wb") as dst:
            shutil.copyfileobj(src, dst)
        os.replace(destino + ".nuevo", destino)
        copiados += 1
    with open(os.path.join(BASE, "respaldos", "historial_actualizaciones.log"), "a", encoding="utf-8") as f:
        f.write(f"{dt.datetime.now():%Y-%m-%d %H:%M} {anterior} -> {version} ({copiados} archivos)\n")
    return {"anterior": anterior, "nueva": version, "copiados": copiados, "respaldo": respaldo}


def consultar_en_linea(url=None, timeout=10):
    """Lee el manifiesto remoto. Devuelve dict o None si no hay fuente configurada. Guarda la hora y el resultado."""
    c = leer_config()
    url = url or url_manifiesto(c)
    if not url:
        return None
    candidatos = [url]
    if c.get("fuente") == "github" and REPO_OK.match(c.get("repo") or "") and not os.environ.get("FITAPP_UPDATE_URL"):
        # también se aceptan versiones publicadas como archivos del repositorio (version.json en la rama main)
        candidatos += [f"https://raw.githubusercontent.com/{c['repo']}/{rama}/version.json" for rama in ("main", "master")]
    try:
        m, ultimo = None, None
        for u in candidatos:
            try:
                req = urllib.request.Request(u, headers={"User-Agent": "FitBase-actualizador", "Cache-Control": "no-cache"})
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    m = json.loads(r.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as e:
                ultimo = e
                if e.code != 404:
                    raise
        if m is None:
            raise ultimo
        if not m.get("version") or not m.get("url"):
            raise ValueError("El archivo version.json no trae 'version' y 'url'.")
        m["disponible"] = es_mas_nueva(str(m["version"]))
        c["ultimo_error"] = None
        return m
    except urllib.error.HTTPError as e:
        if e.code == 404 and c.get("repo") and not c.get("url"):
            msg = (f"El repositorio {c['repo']} todavía no tiene versiones publicadas. "
                   "Publica la primera desde la sección GitHub de esta página («Publicar esta versión en GitHub»).")
        else:
            msg = f"El servidor respondió {e.code} al buscar version.json. Revisa la dirección o el repositorio."
        c["ultimo_error"] = msg
        raise RuntimeError(msg) from None
    except Exception as e:  # noqa: BLE001
        c["ultimo_error"] = f"{type(e).__name__}: {e}"[:200]
        raise
    finally:
        c["ultima_revision"] = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
        try:
            guardar_config(c)
        except OSError:
            pass


def descargar(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "FitBase-actualizador"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def instalar_en_linea(m):
    r = aplicar(descargar(m["url"]), m.get("sha256"))
    guardar_novedades(r["nueva"], m.get("notas", ""))
    return r


def guardar_novedades(version, notas):
    os.makedirs(os.path.join(BASE, "respaldos"), exist_ok=True)
    with open(os.path.join(BASE, "respaldos", "ultima_version.json"), "w", encoding="utf-8") as f:
        json.dump({"version": version, "notas": notas, "fecha": dt.datetime.now().strftime("%Y-%m-%d %H:%M")}, f, ensure_ascii=False)


def novedades():
    try:
        with open(os.path.join(BASE, "respaldos", "ultima_version.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def respaldos_codigo():
    carpeta = os.path.join(BASE, "respaldos")
    try:
        xs = sorted((f for f in os.listdir(carpeta) if f.startswith("codigo-") and f.endswith(".zip")),
                    key=lambda f: os.path.getmtime(os.path.join(carpeta, f)), reverse=True)
    except OSError:
        return []
    return xs


def restaurar_anterior():
    """Vuelve al código del respaldo más reciente (los datos no se tocan)."""
    xs = respaldos_codigo()
    if not xs:
        raise ValueError("No hay versiones anteriores guardadas.")
    with open(os.path.join(BASE, "respaldos", xs[0]), "rb") as f:
        datos = f.read()
    r = aplicar(datos)
    os.remove(os.path.join(BASE, "respaldos", xs[0]))   # el respaldo usado ya no hace falta
    return r


def historial():
    try:
        with open(os.path.join(BASE, "respaldos", "historial_actualizaciones.log"), encoding="utf-8") as f:
            return [x.strip() for x in f if x.strip()][-15:][::-1]
    except OSError:
        return []


# ------------------------------------------------------------------ GitHub: probar conexión y publicar versiones desde la página
API_GH = "https://api.github.com"


def _gh(url, token=None, metodo="GET", datos=None, tipo="application/json", timeout=30):
    """Llama a la API de GitHub. Devuelve (código, json|bytes)."""
    h = {"User-Agent": "FitBase-actualizador", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    cuerpo = None
    if datos is not None:
        cuerpo = datos if isinstance(datos, (bytes, bytearray)) else json.dumps(datos).encode()
        h["Content-Type"] = tipo
    req = urllib.request.Request(url, data=cuerpo, headers=h, method=metodo)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw[:1] in (b"{", b"[") else raw)
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw)
        except ValueError:
            return e.code, {"message": raw.decode(errors="ignore")[:200]}


def github_estado(repo, token=None):
    """Revisa repositorio, visibilidad y la última versión publicada."""
    out = {"repo": repo, "pasos": [], "ok": False}
    if not REPO_OK.match(repo or ""):
        out["pasos"].append((False, "Escribe el repositorio como usuario/nombre."))
        return out
    try:
        cod, r = _gh(f"{API_GH}/repos/{repo}", token)
    except Exception as e:  # noqa: BLE001
        out["pasos"].append((False, f"No hay conexión con GitHub ({type(e).__name__}). Revisa tu internet."))
        return out
    if cod == 404:
        out["pasos"].append((False, "No encontramos ese repositorio. Revisa el nombre o, si es privado, hazlo público o agrega un token."))
        return out
    if cod >= 400:
        out["pasos"].append((False, f"GitHub respondió {cod}: {r.get('message', '')}"))
        return out
    out["pasos"].append((True, f"Repositorio encontrado: {r.get('full_name', repo)}"))
    out["privado"] = bool(r.get("private"))
    out["pasos"].append((not out["privado"], "Es público: las computadoras pueden descargar las versiones." if not out["privado"]
                         else "Es privado: las computadoras no podrán descargar las versiones. Cámbialo a público en Settings → Danger Zone."))
    cod, rel = _gh(f"{API_GH}/repos/{repo}/releases/latest", token)
    if cod == 404:
        out["pasos"].append((False, "Todavía no hay versiones publicadas. Usa «Publicar esta versión en GitHub»."))
        out["ok"] = not out["privado"]
        return out
    nombres = [a.get("name") for a in rel.get("assets", [])]
    out["ultima"] = {"tag": rel.get("tag_name"), "fecha": (rel.get("published_at") or "")[:10], "assets": nombres}
    out["pasos"].append((True, f"Última versión publicada: {rel.get('tag_name')} ({out['ultima']['fecha']})"))
    tiene = "version.json" in nombres and any(n.endswith(".zip") for n in nombres)
    out["pasos"].append((tiene, "Incluye el paquete .zip y el archivo version.json." if tiene else "A esa versión le falta el .zip o el version.json."))
    out["ok"] = tiene and not out["privado"]
    return out


def construir_paquete(version):
    """Crea en memoria el ZIP de la versión (sin datos del usuario) y su manifiesto."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for raiz, dirs, files in os.walk(BASE):
            rel_raiz = os.path.relpath(raiz, BASE).replace("\\", "/")
            dirs[:] = [d for d in dirs if d not in ("__pycache__", "dist", ".git", "fotos") and not _protegido((rel_raiz + "/" + d + "/").lstrip("./"))]
            for fn in files:
                rel = os.path.relpath(os.path.join(raiz, fn), BASE).replace("\\", "/")
                if rel == "VERSION" or _protegido(rel) or rel.endswith((".pyc", ".tmp", ".nuevo")):
                    continue
                z.write(os.path.join(raiz, fn), "fitapp/" + rel)
        z.writestr("fitapp/VERSION", version + "\n")
    return buf.getvalue()


def github_publicar(repo, token, version, notas=""):
    """Publica la versión actual como Release de GitHub con el .zip y el version.json. Devuelve la URL del release."""
    if not REPO_OK.match(repo or ""):
        raise ValueError("Configura primero el repositorio (usuario/nombre).")
    if not token:
        raise ValueError("Falta el token de GitHub.")
    if not __import__("re").fullmatch(r"\d+\.\d+\.\d+", version or ""):
        raise ValueError("La versión debe tener el formato 2.1.0")
    cod, r = _gh(f"{API_GH}/repos/{repo}", token)
    if cod >= 400:
        raise ValueError("No se pudo abrir el repositorio con ese token. Revisa que tenga permiso «Contents: Read and write».")
    cod, _ = _gh(f"{API_GH}/repos/{repo}/commits?per_page=1", token)
    if cod == 409:   # repositorio vacío: GitHub necesita al menos un archivo para crear la etiqueta
        import base64
        texto = "# FitBase\n\nVersiones de FitBase para actualización automática. Descarga desde la sección Releases.\n"
        cod, r2 = _gh(f"{API_GH}/repos/{repo}/contents/README.md", token, "PUT",
                      {"message": "Inicio del repositorio de versiones", "content": base64.b64encode(texto.encode()).decode()})
        if cod >= 400:
            raise ValueError(f"No se pudo preparar el repositorio vacío: {r2.get('message', cod)}")
    paquete = construir_paquete(version)
    sha = hashlib.sha256(paquete).hexdigest()
    nombre = f"fitapp-{version}.zip"
    manifiesto = {"version": version, "url": f"https://github.com/{repo}/releases/download/v{version}/{nombre}", "sha256": sha, "notas": notas}
    cod, rel = _gh(f"{API_GH}/repos/{repo}/releases", token, "POST",
                   {"tag_name": f"v{version}", "name": f"FitBase {version}", "body": notas or f"FitBase {version}", "draft": False, "prerelease": False})
    if cod == 422:
        raise ValueError(f"Ya existe una versión v{version} en GitHub. Usa un número más alto.")
    if cod >= 400:
        raise ValueError(f"GitHub no permitió crear la versión: {rel.get('message', cod)}")
    subir = f"https://uploads.github.com/repos/{repo}/releases/{rel['id']}/assets"
    for nom, datos, tipo in ((nombre, paquete, "application/zip"),
                             ("version.json", json.dumps(manifiesto, ensure_ascii=False, indent=2).encode(), "application/json")):
        cod, a = _gh(f"{subir}?name={nom}", token, "POST", datos, tipo, timeout=180)
        if cod >= 400:
            raise ValueError(f"No se pudo subir {nom}: {a.get('message', cod) if isinstance(a, dict) else cod}")
    with open(os.path.join(BASE, "VERSION"), "w", encoding="utf-8") as f:   # esta computadora ya tiene esa versión
        f.write(version + "\n")
    with open(os.path.join(BASE, "respaldos", "historial_actualizaciones.log") if os.path.isdir(os.path.join(BASE, "respaldos")) else os.devnull, "a", encoding="utf-8") as f:
        f.write(f"{dt.datetime.now():%Y-%m-%d %H:%M} publicada en GitHub {repo} v{version}\n")
    return rel.get("html_url") or f"https://github.com/{repo}/releases/tag/v{version}", len(paquete)


def siguiente_version(v=None):
    t = _tupla(v or version_actual())
    return f"{t[0]}.{t[1]}.{t[2] + 1}"
