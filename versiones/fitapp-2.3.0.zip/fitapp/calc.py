"""Cálculos basados en evidencia (mismas fórmulas verificadas del Excel v3)."""
import math
import datetime as dt
from data.ejercicios import EJERCICIOS, GRUPOS
from data.contenido import NIVEL_SERIES

FACTOR_ACTIVIDAD = {"Sedentario": 1.2, "Ligero": 1.375, "Moderado": 1.55, "Activo": 1.725, "Muy activo": 1.9}


def num(v, default=None):
    try:
        if v is None or v == "":
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


# ---------------- Composición corporal ----------------
def imc(peso, talla):
    return peso / (talla / 100) ** 2


def imc_clase(v):
    return "Bajo peso" if v < 18.5 else "Normal" if v < 25 else "Sobrepeso" if v < 30 else "Obesidad"


def grasa_navy(sexo, talla, cuello, cintura, cadera=None):
    """Hodgdon y Beckett 1984, versión métrica (cm). Devuelve fracción."""
    try:
        if sexo == "Hombre":
            if not (cuello and cintura) or cintura <= cuello:
                return None
            return (495 / (1.0324 - 0.19077 * math.log10(cintura - cuello) + 0.15456 * math.log10(talla)) - 450) / 100
        if not (cuello and cintura and cadera):
            return None
        return (495 / (1.29579 - 0.35004 * math.log10(cintura + cadera - cuello) + 0.221 * math.log10(talla)) - 450) / 100
    except ValueError:
        return None


def composicion(p):
    peso, talla = p["peso"], p["talla"]
    medido = num(p.get("grasa_medida"))
    navy = grasa_navy(p["sexo"], talla, num(p.get("cuello")), num(p.get("cintura")), num(p.get("cadera")))
    grasa = medido / 100 if medido else navy
    mlg = peso * (1 - grasa) if grasa else None
    out = {"imc": imc(peso, talla), "navy": navy, "grasa": grasa, "metodo": "Medido" if medido else ("Marina EE. UU." if navy else None),
           "mlg": mlg, "masa_grasa": peso * grasa if grasa else None}
    out["imc_clase"] = imc_clase(out["imc"])
    cint = num(p.get("cintura"))
    out["ice"] = cint / talla if cint else None
    if mlg:
        out["ffmi"] = mlg / (talla / 100) ** 2
        out["ffmi_norm"] = out["ffmi"] + 6.1 * (1.8 - talla / 100)
    return out


# ---------------- Energía ----------------
def ecuaciones_ger(p, mlg):
    w, h, a = p["peso"], p["talla"], p["edad"]
    s = 1 if p["sexo"] == "Hombre" else 0
    eq = {
        "Mifflin-St Jeor (1990)": 10 * w + 6.25 * h - 5 * a + (5 if s else -161),
        "Harris-Benedict revisada (1984)": (88.362 + 13.397 * w + 4.799 * h - 5.677 * a) if s else (447.593 + 9.247 * w + 3.098 * h - 4.330 * a),
        "Harris-Benedict original (1919)": (66.473 + 13.7516 * w + 5.0033 * h - 6.755 * a) if s else (655.0955 + 9.5634 * w + 1.8496 * h - 4.6756 * a),
        "ten Haaf y Weijs (2014)": (49.94 * w + 2459.053 * (h / 100) - 34.014 * a + 799.257 * s + 122.502) / 4.184,
        "Tinsley 2019 (peso)": 24.8 * w + 10,
    }
    if mlg:
        eq["Cunningham (1980)"] = 500 + 22 * mlg
        eq["Katch-McArdle"] = 370 + 21.6 * mlg
        eq["Tinsley 2019 (MLG)"] = 25.9 * mlg + 284
    return eq


def ecuacion_recomendada(mlg, nivel):
    if mlg:
        return "Cunningham (1980)"
    return "Mifflin-St Jeor (1990)" if nivel == "Principiante" else "ten Haaf y Weijs (2014)"


def kcal_met(met, peso, minutos, sesiones):
    """kcal netas por día: (MET − 1) × kg × h × sesiones / 7 (evita contar dos veces el reposo)."""
    return max(0.0, (met - 1) * peso * (minutos / 60) * sesiones / 7)


def energia(p, comp):
    eqs = ecuaciones_ger(p, comp["mlg"])
    rec = ecuacion_recomendada(comp["mlg"], p["nivel"])
    usada = p.get("ecuacion") if p.get("ecuacion") in eqs else rec
    ger = eqs[usada]
    eat = kcal_met(3.5, p["peso"], p["duracion"], p["dias"]) + kcal_met(p.get("cardio_met", 3.5), p["peso"], p.get("cardio_min", 0), p.get("cardio_ses", 0))
    neat = ger * p.get("neat", 0.15)
    get_fact = (ger + neat + eat) / 0.9
    get_pal = ger * FACTOR_ACTIVIDAD.get(p.get("actividad", "Moderado"), 1.55)
    get = get_fact
    signo = {"Perder grasa": -1, "Recomposición": -1, "Ganar músculo": 1}.get(p["objetivo"], 0)
    ajuste = signo * p["ritmo"] / 100 * p["peso"] * 7700 / 7
    objetivo = round((get + ajuste) / 10) * 10
    ea = (objetivo - eat) / comp["mlg"] if comp["mlg"] else None
    return {"ecuaciones": eqs, "recomendada": rec, "usada": usada, "ger": ger, "neat": neat, "eat": eat,
            "eta": get_fact * 0.1, "gasto_total": get, "get_pal": get_pal, "ajuste": ajuste, "objetivo": objetivo,
            "cambio_semana": signo * p["ritmo"] / 100 * p["peso"], "ea": ea,
            "ea_estado": None if ea is None else ("riesgo" if ea < 30 else "adecuada" if ea < 45 else "optima")}


def macros(p, en, comp):
    peso, kcal = p["peso"], en["objetivo"]
    deficit = p["objetivo"] in ("Perder grasa", "Recomposición")
    gkg = p.get("prot_gkg") or (2.2 if deficit else 1.8)
    prot = gkg * peso
    grasa = max(p.get("grasa_pct", 0.25) * kcal / 9, 0.5 * peso)
    carb = max(0.0, (kcal - prot * 4 - grasa * 9) / 4)
    nota_dieta = None
    try:
        import restricciones
        grasa, carb, nota_dieta = restricciones.ajustar_macros(p, kcal, prot, grasa, carb)
    except ImportError:
        pass
    comidas = max(1, int(p.get("comidas", 4)))
    return {"kcal": kcal, "prot": prot, "grasa": grasa, "carb": carb, "prot_gkg": gkg, "nota_dieta": nota_dieta,
            "carb_gkg": carb / peso, "grasa_pct": grasa * 9 / kcal, "prot_comida": prot / comidas,
            "prot_comida_gkg": prot / comidas / peso, "fibra": 14 * kcal / 1000, "agua": 0.035 * peso,
            "prot_mlg": prot / comp["mlg"] if comp["mlg"] else None}


# ---------------- Entrenamiento ----------------
def e1rm(peso, reps, rir=0):
    """Epley ajustado por RIR: peso × (1 + (reps + RIR)/30)."""
    if not peso or not reps:
        return None
    return round(peso * (1 + (reps + (rir or 0)) / 30), 1)


def sugerencia(peso, reps, rir, rmin, rmax, rir_obj, inc):
    if reps >= rmax and (rir is None or rir >= rir_obj):
        nuevo = max(peso + 1, round(peso * (1 + inc) * 2) / 2)
        return "subir", f"Sube a {nuevo:g} kg"
    if reps < rmin:
        return "bajar", "Baja ~5 % o revisa sueño y fatiga"
    return "mantener", "Mantén la carga y busca +1 repetición"


def volumen_programa(programa, nivel="Intermedio"):
    vmin, vmax = NIVEL_SERIES.get(nivel, (10, 20))
    tot = {g: {"directas": 0.0, "indirectas": 0.0, "dias": set(), "max_sesion": 0.0} for g in GRUPOS}
    for i, dia in enumerate(programa.get("dias", [])):
        sesion = {g: 0.0 for g in GRUPOS}
        for e in dia["ejercicios"]:
            info = EJERCICIOS.get(e["ex"])
            if not info or info["tipo"] in ("Cardio", "Movilidad"):
                continue
            s = float(e.get("series", 0))
            g = info["grupo"]
            if g in tot:
                tot[g]["directas"] += s
                tot[g]["dias"].add(i)
                sesion[g] += s
            for sg in info["secundarios"]:
                tot[sg]["indirectas"] += 0.5 * s
                sesion[sg] += 0.5 * s
        for g in GRUPOS:
            tot[g]["max_sesion"] = max(tot[g]["max_sesion"], sesion[g])
    filas = []
    for g in GRUPOS:
        t = tot[g]
        ef = t["directas"] + t["indirectas"]
        if t["directas"] == 0:
            estado, nivel_e = "Sin series directas", "bajo"
        elif ef < vmin:
            estado, nivel_e = "Bajo", "bajo"
        elif ef > vmax:
            estado, nivel_e = "Alto: vigila la recuperación", "alto"
        elif t["max_sesion"] > 10:
            estado, nivel_e = ">10 series en una sesión", "alto"
        elif len(t["dias"]) < 2:
            estado, nivel_e = "Frecuencia <2/sem", "medio"
        else:
            estado, nivel_e = "Óptimo", "ok"
        filas.append({"grupo": g, "directas": t["directas"], "indirectas": t["indirectas"], "efectivas": ef,
                      "frecuencia": len(t["dias"]), "max_sesion": t["max_sesion"], "estado": estado, "nivel": nivel_e})
    return {"filas": filas, "min": vmin, "max": vmax}


def volumen_por_musculo(sets):
    """Series fraccionadas por músculo del mapa (principal 1, otros 0.5) para mapa de calor."""
    out = {}
    for s in sets:
        info = EJERCICIOS.get(s["ejercicio"])
        if not info or info["tipo"] in ("Cardio", "Movilidad"):
            continue
        for i, t in enumerate(info["targets"]):
            out[t] = out.get(t, 0) + (1 if i == 0 else 0.5)
    return out


def duracion_sesion(dia):
    return round(sum(e["series"] * (e["descanso"] + 45) for e in dia["ejercicios"]) / 60 + 10)


# ---------------- Seguimiento ----------------
def tendencia(valores, alfa=0.1):
    out, t = [], None
    for v in valores:
        if v is not None:
            t = v if t is None else t + alfa * (v - t)
        out.append(t)
    return out


def get_adaptativo(logs):
    pesos = [(l["fecha"], l["peso"]) for l in logs if l["peso"]]
    kc = [l["kcal"] for l in logs if l["kcal"]]
    if len(pesos) < 14 or len(kc) < 10:
        return None
    tr = tendencia([p for _, p in pesos])
    dias = (pesos[-1][0] - pesos[0][0]).days or 1
    return sum(kc) / len(kc) - (tr[-1] - tr[0]) * 7700 / dias


def puntaje_dia(l, kcal_obj, prot_obj):
    comps = []
    if l.get("kcal"):
        comps.append(1 if abs(l["kcal"] - kcal_obj) <= kcal_obj * 0.1 else 0)
    if l.get("proteina"):
        comps.append(1 if l["proteina"] >= prot_obj * 0.9 else 0)
    if l.get("sueno"):
        comps.append(1 if l["sueno"] >= 7 else 0)
    if l.get("entreno"):
        comps.append(0 if l["entreno"] == "No" else 1)
    return round(100 * sum(comps) / len(comps)) if comps else None


def fitness_score(logs, dias_semana, kcal_obj, prot_obj, cambio_e1rm, ritmo_real, ritmo_obj, checklist_pct):
    n = len(logs) or 1
    hechos = sum(1 for l in logs if l.get("entreno") == "Sí")
    plan = dias_semana * max(1, n / 7)
    def pct(f):
        vals = [f(l) for l in logs]
        vals = [v for v in vals if v is not None]
        return 100 * sum(vals) / len(vals) if vals else 0
    comps = [
        ("Consistencia", min(100, 100 * hechos / plan) if logs else 0, 0.25),
        ("Proteína", pct(lambda l: None if not l.get("proteina") else (1 if l["proteina"] >= prot_obj * 0.9 else 0)), 0.15),
        ("Calorías", pct(lambda l: None if not l.get("kcal") else (1 if abs(l["kcal"] - kcal_obj) <= kcal_obj * 0.1 else 0)), 0.15),
        ("Sueño", pct(lambda l: None if not l.get("sueno") else (1 if l["sueno"] >= 7 else 0)), 0.15),
        ("Fuerza", max(0, min(100, 50 + 1000 * cambio_e1rm)) if cambio_e1rm is not None else 50, 0.15),
        ("Ritmo de peso", max(0, min(100, 100 - 10000 * abs(ritmo_real - ritmo_obj))) if ritmo_real is not None else 50, 0.10),
        ("Checklist", 100 * checklist_pct if checklist_pct is not None else 50, 0.05),
    ]
    total = sum(v * w for _, v, w in comps) / sum(w for _, _, w in comps)
    etiqueta = "Excelente" if total >= 85 else "Bueno" if total >= 70 else "Regular" if total >= 50 else "Por mejorar"
    return {"componentes": [(n_, round(v)) for n_, v, _ in comps], "pesos": [(n_, w) for n_, _, w in comps],
            "total": round(total, 1), "etiqueta": etiqueta}


# ---------------- Calculadoras extra ----------------
def zonas_fc(edad, fc_reposo):
    fcmax = 208 - 0.7 * edad  # Tanaka 2001
    res = fcmax - fc_reposo
    zonas = [("Ligera (ACSM 30–39 %)", 0.30, 0.39), ("Moderada (ACSM 40–59 %)", 0.40, 0.59),
             ("Vigorosa (ACSM 60–89 %)", 0.60, 0.89), ("Casi máxima (≥90 %)", 0.90, 1.0)]
    return fcmax, [(n, round(fc_reposo + a * res), round(fc_reposo + b * res)) for n, a, b in zonas]


def rockport(peso_kg, edad, sexo, tiempo_min, fc_final):
    """Kline et al. 1987 (caminata de 1 milla)."""
    lb = peso_kg * 2.20462
    return 132.853 - 0.0769 * lb - 0.3877 * edad + 6.315 * (1 if sexo == "Hombre" else 0) - 3.2649 * tiempo_min - 0.1565 * fc_final


def cooper(distancia_m):
    """Cooper 1968: VO2máx = (d − 504.9) / 44.73 (corrige la versión del curso, que sobreestima)."""
    return (distancia_m - 504.9) / 44.73


def discos(objetivo, barra=20, disponibles=(25, 20, 15, 10, 5, 2.5, 1.25)):
    lado = (objetivo - barra) / 2
    out = []
    for d in disponibles:
        while lado >= d - 1e-9:
            out.append(d)
            lado -= d
    return out, round(lado * 2, 2)


def calentamiento(peso_trabajo):
    pasos = [(0.4, 8), (0.6, 5), (0.75, 3), (0.85, 1)]
    return [(max(20, round(peso_trabajo * f / 2.5) * 2.5), r) for f, r in pasos]


def hoy():
    return dt.date.today()


def energia_ajustada(p, comp, en, gasto):
    """Recalcula la meta con el gasto real medido (gasto adaptativo), limitado a ±20 % del estimado por fórmula."""
    base = en["gasto_total"]
    gasto = max(base * 0.8, min(base * 1.2, gasto))
    signo = {"Perder grasa": -1, "Recomposición": -1, "Ganar músculo": 1}.get(p["objetivo"], 0)
    ajuste = signo * p["ritmo"] / 100 * p["peso"] * 7700 / 7
    objetivo = round((gasto + ajuste) / 10) * 10
    ea = (objetivo - en["eat"]) / comp["mlg"] if comp["mlg"] else None
    return {**en, "gasto_total": gasto, "gasto_estimado": base, "objetivo": objetivo, "ajuste": ajuste, "adaptado": True, "ea": ea,
            "ea_estado": None if ea is None else ("riesgo" if ea < 30 else "adecuada" if ea < 45 else "optima")}
