"""Registro rápido de comidas: texto libre, voz (se transcribe en el navegador), foto y código de barras.

- Texto/voz: intérprete local en español ("2 huevos, una rebanada de pan y una taza de leche") que reconoce
  cantidades, medidas caseras y alimentos de la base. Si algo no se reconoce y hay clave de Claude, la IA lo estima.
- Foto: Claude (visión) identifica los alimentos y estima los gramos; los valores se toman de nuestra base cuando hay
  coincidencia y, si no, de la estimación de la IA. Siempre se muestran para revisar antes de guardar.
- Código de barras: se busca en la base local de productos y, si no está, en Open Food Facts (base abierta, ODbL).
  El producto se guarda en la base local para la próxima vez. Si no existe, se puede capturar de la etiqueta.
"""
import base64
import difflib
import json
import os
import re
import unicodedata
import urllib.request

import alimentos as alim
import asistente

# ------------------------------------------------------------------ utilidades
def norm(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9/., ]+", " ", s)


def singular(w):
    if len(w) > 4 and w.endswith("es") and w[-3] not in "aeiou":
        return w[:-2]
    if len(w) > 3 and w.endswith("s"):
        return w[:-1]
    return w


NUMEROS = {"un": 1, "uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7, "ocho": 8,
           "nueve": 9, "diez": 10, "doce": 12, "medio": .5, "media": .5, "cuarto": .25, "par": 2, "docena": 12}
# unidad -> (palabras que la nombran, palabras a buscar en las porciones del alimento, gramos por defecto)
UNIDADES = {
    "g": (("g", "gr", "grs", "gramo", "gramos"), (), 1),
    "kg": (("kg", "kilo", "kilos"), (), 1000),
    "ml": (("ml", "mililitro", "mililitros"), (), 1),
    "l": (("litro", "litros"), (), 1000),
    "taza": (("taza", "tazas"), ("taza",), 240),
    "vaso": (("vaso", "vasos"), ("vaso", "taza"), 240),
    "cucharada": (("cucharada", "cucharadas", "cda", "cdas"), ("cucharada", "cda"), 15),
    "cucharadita": (("cucharadita", "cucharaditas", "cdita", "cditas"), ("cucharadita", "cdita"), 5),
    "rebanada": (("rebanada", "rebanadas", "rodaja", "rodajas"), ("rebanada",), 30),
    "pieza": (("pieza", "piezas", "pza", "pzas", "unidad", "unidades"), ("pieza", "mediano", "mediana", "1 "), None),
    "filete": (("filete", "filetes"), ("filete",), 120),
    "lata": (("lata", "latas"), ("lata",), 140),
    "plato": (("plato", "platos", "porcion", "porciones", "racion"), ("plato", "porcion", "racion"), None),
    "puno": (("puno", "punos", "punado", "punados"), ("puno", "punado"), 30),
    "scoop": (("scoop", "scoops", "medida", "medidas"), ("scoop", "medida"), 30),
    "orden": (("orden", "ordenes"), ("orden",), None),
    "copa": (("copa", "copas"), ("copa",), 150),
    "caballito": (("caballito", "caballitos", "shot", "shots"), ("caballito",), 44),
    "bolsa": (("bolsa", "bolsita", "bolsas"), ("bolsa",), 28),
    "barra": (("barra", "barras", "barrita", "barritas"), ("barra", "barrita"), 25),
    "botella": (("botella", "botellas"), ("botella", "lata"), 355),
    "rebanada_pizza": ((), ("rebanada",), 110),
}
PALABRA_UNIDAD = {w: u for u, (ws, _, _) in UNIDADES.items() for w in ws}
VACIAS = {"de", "del", "con", "la", "el", "los", "las", "y", "a", "al", "en", "mi", "me", "comi", "desayune", "cene", "tome",
          "almorce", "bebi", "aprox", "aproximadamente", "como", "unos", "unas", "algo", "poco", "poquito", "sin", "e"}
# preferencias cuando la palabra es genérica (lo más común en México)
PREFERIDO = {"huevo": "Huevo entero (crudo o cocido)", "huevos": "Huevo entero (crudo o cocido)", "pan": "Pan blanco de caja",
             "leche": "Leche semidescremada", "arroz": "Arroz blanco cocido", "frijol": "Frijol negro cocido (sin caldo)",
             "frijoles": "Frijol negro cocido (sin caldo)", "pollo": "Pechuga de pollo cocida (sin piel)",
             "pechuga": "Pechuga de pollo cocida (sin piel)", "tortilla": "Tortilla de maíz", "tortillas": "Tortilla de maíz",
             "avena": "Avena en hojuelas cruda", "atun": "Atún en agua (escurrido)", "yogur": "Yogur natural descremado (sin azúcar)",
             "yogurt": "Yogur natural descremado (sin azúcar)", "queso": "Queso panela", "aguacate": "Aguacate hass",
             "platano": "Plátano", "manzana": "Manzana", "cafe": "Café negro", "refresco": "Refresco de cola",
             "coca": "Refresco de cola", "carne": "Bistec de res cocido (magro)", "bistec": "Bistec de res cocido (magro)",
             "pasta": "Pasta cocida", "papa": "Papa cocida (sin cáscara)", "papas": "Papa cocida (sin cáscara)",
             "salmon": "Salmón cocido (de granja)", "brocoli": "Brócoli cocido", "proteina": "Proteína whey concentrada",
             "whey": "Proteína whey concentrada", "jamon": "Jamón de pavo", "mango": "Mango ataulfo", "cereal": "Cereal de hojuelas de maíz (natural)",
             "granola": "Granola comercial", "nueces": "Nuez", "almendras": "Almendra", "cacahuates": "Cacahuate natural",
             "aceite": "Aceite de oliva", "mantequilla": "Mantequilla", "jugo": "Jugo de naranja natural", "fresas": "Fresa",
             "camote": "Camote cocido (sin cáscara)", "lentejas": "Lenteja cocida", "garbanzos": "Garbanzo cocido",
             "tofu": "Tofu firme", "camaron": "Camarón cocido (sin cáscara)", "camarones": "Camarón cocido (sin cáscara)",
             "ensalada": "Lechuga romana", "cerveza": "Cerveza clara", "tacos": "Taco de bistec", "taco": "Taco de bistec",
             "pizza": "Pizza de pepperoni (rebanada)", "hamburguesa": "Hamburguesa sencilla"}


def _cantidad(tokens):
    """Lee la cantidad al inicio. Devuelve (cantidad, tokens restantes)."""
    total, i = None, 0
    while i < len(tokens):
        t = tokens[i]
        if re.fullmatch(r"\d+([.,]\d+)?", t):
            total = (total or 0) + float(t.replace(",", "."))
        elif re.fullmatch(r"\d+/\d+", t):
            a, b = t.split("/"); total = (total or 0) + float(a) / max(float(b), 1)
        elif t in NUMEROS and not (t in ("un", "una") and total):
            v = NUMEROS[t]
            total = (total or 0) + v if not (total and t in ("docena",)) else total * v
        elif t in ("y",) and total and i + 1 < len(tokens) and tokens[i + 1] in ("medio", "media", "cuarto"):
            pass
        else:
            break
        i += 1
    return (total if total else 1), tokens[i:]


def _num_pegado(tokens):
    """'200g' -> ['200', 'g']"""
    out = []
    for t in tokens:
        m = re.fullmatch(r"(\d+(?:[.,]\d+)?)(g|gr|grs|ml|kg)", t)
        out.extend([m.group(1), m.group(2)] if m else [t])
    return out


def _tiene_porciones(a):
    return any(not p["desc"].startswith(("100 g", "1 equivalente")) for p in a.get("porciones", []))


def buscar_alimento(texto, extra=None):
    """Devuelve (alimento, confianza 0-1) para un texto como 'pechuga de pollo asada'."""
    crudas = [w for w in norm(texto).split() if w not in VACIAS]
    palabras = [singular(w) for w in crudas]
    if not palabras:
        return None, 0
    clave = " ".join(palabras)
    pref = PREFERIDO.get(crudas[0]) or PREFERIDO.get(palabras[0])
    mejor, puntos = None, 0
    for a in list(alim.ALIMENTOS) + list(extra or []):
        nom = [singular(w) for w in norm(a["nombre"]).split() if w not in VACIAS]
        if not nom:
            continue
        coincide = [p for p in palabras if any(p == n or (len(p) > 3 and (n.startswith(p) or p.startswith(n))) for n in nom)]
        if not coincide:
            continue
        cobertura = len(coincide) / len(palabras)
        if palabras[0] not in coincide and cobertura < .67:
            continue                                   # la palabra principal tiene que aparecer
        precision = len(coincide) / len(nom)
        s = cobertura * .7 + precision * .25 + (.05 if nom[0] == palabras[0] else 0)
        s = max(s, difflib.SequenceMatcher(None, clave, " ".join(nom)).ratio() * .9)
        s += .06 if _tiene_porciones(a) else 0
        s -= .1 if a.get("categoria") == "Ingredientes de recetas" else 0
        if pref and a["nombre"] == pref:
            s += .12 if cobertura < 1 else .2
        if s > puntos:
            mejor, puntos = a, s
    return (mejor, round(min(puntos, 1), 2)) if puntos >= .5 else (None, 0)


def _fraccion(desc):
    m = re.match(r"\s*(\d+)\s*/\s*(\d+)", desc)
    if m:
        return int(m.group(1)) / max(int(m.group(2)), 1)
    m = re.match(r"\s*(\d+(?:[.,]\d+)?)", desc)
    if m:
        return float(m.group(1).replace(",", "."))
    return {"½": .5, "¼": .25, "¾": .75}.get(desc.strip()[:1], 1)


def _porcion(a, unidad, cant):
    """Gramos para 'cant' unidades de 'unidad' del alimento a. Devuelve (gramos, descripción)."""
    porciones = [p for p in a.get("porciones", []) if p.get("g") and not p["desc"].startswith(("100 g", "1 equivalente"))]
    if unidad in ("g", "kg", "ml", "l"):
        g = cant * UNIDADES[unidad][2]
        return g, f"{g:g} {'ml' if unidad in ('ml', 'l') else 'g'}"
    if unidad:
        _, buscar, defecto = UNIDADES[unidad]
        opciones = [p for p in porciones if any(b in norm(p["desc"]) for b in buscar)]
        if opciones:
            p = min(opciones, key=lambda p: abs(_fraccion(p["desc"]) - 1))
            por_unidad = p["g"] / (_fraccion(p["desc"]) or 1)
            g = cant * por_unidad
            return g, (f"{cant:g} × {p['desc']}" if _fraccion(p["desc"]) == 1 else f"{cant:g} {unidad}{'s' if cant != 1 else ''} (~{por_unidad:.0f} g c/u)")
        if defecto:
            return cant * defecto, f"{cant:g} {unidad}{'s' if cant != 1 else ''} (~{defecto} g c/u)"
    if porciones:
        p = porciones[0]
        return cant * p["g"], f"{cant:g} × {p['desc']}"
    return cant * 100, f"{cant * 100:g} g"


def _item(texto, a, gramos, desc, confianza, fuente="base"):
    m = alim.macros(a, gramos)
    return {"texto": texto, "alimento_id": a.get("id"), "nombre": a["nombre"], "gramos": round(gramos), "porcion": desc,
            "por100g": {k: a["por100g"].get(k) or 0 for k in ("kcal", "prot", "carb", "grasa", "fibra")},
            "confianza": confianza, "fuente": fuente, **m}


def partir(texto):
    t = re.sub(r"\s+(e|mas|más|con)\s+(?=(\d|un|una|uno|dos|tres|cuatro|cinco|seis|medio|media)\b)", ",", texto, flags=re.I)
    t = re.sub(r"\s+y\s+(?!medi[oa]\b)", ",", t, flags=re.I)
    return [x.strip(" .;") for x in re.split(r"[,\n;+]|\s-\s", t) if x.strip(" .;")]


COMBOS = {"cafe con leche": "1 taza de café negro, 1/4 taza de leche", "huevos con jamon": "2 huevos, 1 rebanada de jamón de pavo",
          "pan tostado": "1 rebanada de pan blanco de caja", "pan con mantequilla": "1 rebanada de pan blanco de caja, 1 cucharadita de mantequilla"}


def _previo(texto):
    t = " " + norm(texto) + " "
    for k, v in COMBOS.items():
        t = t.replace(" " + k + " ", " " + v + " ")
    # "una taza y media de arroz" -> "1.5 taza de arroz"
    t = re.sub(r"\b(un|una|uno|\d+)\s+(\w+)\s+y\s+(media|medio)\b",
               lambda m: f"{(NUMEROS.get(m.group(1)) or float(m.group(1))) + .5:g} {m.group(2)}", t)
    return t.strip()


def _uno(parte, extra):
    tok = _num_pegado(norm(parte).split())
    cant, resto = _cantidad(tok)
    unidad = None
    if resto and resto[0] in PALABRA_UNIDAD and resto[0] not in ("g", "gr", "grs", "kg", "ml"):
        a0, c0 = buscar_alimento(" ".join(resto), extra)          # "barra de proteína", "taza de café": la unidad es parte del nombre
        if a0 and singular(resto[0]) in norm(a0["nombre"]).split()[0:1]:
            gramos, desc = _porcion(a0, None, cant)
            return _item(parte, a0, gramos, desc, c0)
    if resto and resto[0] in PALABRA_UNIDAD:
        unidad = PALABRA_UNIDAD[resto[0]]; resto = resto[1:]
        if resto and resto[0] == "de":
            resto = resto[1:]
    if not resto:
        return None
    a, conf = buscar_alimento(" ".join(resto), extra)
    if not a:
        return None
    if unidad in (None, "rebanada") and "pizza" in norm(a["nombre"]):
        unidad = "rebanada_pizza"
    gramos, desc = _porcion(a, unidad, cant)
    return _item(parte, a, gramos, desc, conf)


TIEMPO_PALABRA = {"desayuno": "Desayuno", "almuerzo": "Colación AM", "colacion": "Colación AM", "snack": "Colación PM",
                  "merienda": "Colación PM", "comida": "Comida", "cena": "Cena", "postentreno": "Colación PM",
                  "colacionam": "Colación AM", "colacionpm": "Colación PM", "almuerzoam": "Colación AM"}


def interpretar_texto(texto, extra=None, tiempo=None):
    """Devuelve lista de renglones reconocidos y lista de textos no reconocidos.
    Si el texto trae encabezados ("Desayuno: ...", "Comida"), cada renglón lleva su tiempo de comida."""
    items, faltan = [], []
    actual = tiempo
    for linea in [x for x in re.split(r"\n", texto or "") if x.strip()] or [texto or ""]:
        m = re.match(r"\s*([A-Za-zÁÉÍÓÚáéíóúñ\- ]+?)\s*:\s*(.*)$", linea)
        cab = norm(m.group(1)).replace(" ", "").replace("-", "") if m else norm(linea).strip().replace(" ", "").replace("-", "")
        if m and cab in TIEMPO_PALABRA:
            actual, linea = TIEMPO_PALABRA[cab], m.group(2)
        elif cab in TIEMPO_PALABRA:
            actual = TIEMPO_PALABRA[cab]; continue
        it, fa = _interpretar_linea(linea, extra)
        for x in it:
            x["tiempo"] = actual
        items += it; faltan += fa
    return items, faltan


def _interpretar_linea(texto, extra=None):
    items, faltan = [], []
    for parte in partir(_previo(texto)):
        entero = _uno(parte, extra)
        if " con " in f" {parte} " and (not entero or entero["confianza"] < .85):
            trozos = [x for x in re.split(r"\s+con\s+", parte) if x.strip()]
            sub = [_uno(x, extra) for x in trozos]
            if all(sub) and (not entero or sum(x["confianza"] for x in sub) / len(sub) > entero["confianza"]):
                items.extend(sub); continue
        if entero:
            items.append(entero)
        else:
            faltan.append(parte)
    return items, faltan


# ------------------------------------------------------------------ IA (opcional)
ESQUEMA = {
    "type": "object",
    "properties": {
        "alimentos": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "nombre": {"type": "string", "description": "Nombre del alimento en español de México, genérico (ej. 'Arroz blanco cocido')"},
                "porcion_casera": {"type": "string"},
                "gramos": {"type": "number"},
                "kcal": {"type": "number"}, "prot": {"type": "number"}, "carb": {"type": "number"}, "grasa": {"type": "number"},
            },
            "required": ["nombre", "porcion_casera", "gramos", "kcal", "prot", "carb", "grasa"],
            "additionalProperties": False}},
        "nota": {"type": "string", "description": "Advertencia breve sobre incertidumbre (aceite oculto, salsas, tamaño)."},
    },
    "required": ["alimentos", "nota"],
    "additionalProperties": False,
}
INSTRUCCION = ("Eres un nutriólogo que estima porciones. Identifica cada alimento y estima los gramos de la porción como se "
               "come (cocido). Da kcal y macros de esa porción con valores de referencia USDA/SMAE. Separa los componentes "
               "(ej. tacos: tortilla, carne y salsa por separado solo si es útil; si es un platillo típico, úsalo entero). "
               "Si no hay comida en la imagen, devuelve la lista vacía y explícalo en la nota.")


def _ia(contenido):
    if not asistente.hay_credenciales():
        return None, "Para fotos (y para alimentos que la base no reconoce) se necesita la clave de Claude: revisa el LEEME."
    try:
        import anthropic
    except ImportError:
        return None, "Falta la librería anthropic (se instala al abrir la app)."
    try:
        r = anthropic.Anthropic().messages.create(
            model=asistente.MODELO, max_tokens=3000, output_config={"effort": "low", "format": {"type": "json_schema", "schema": ESQUEMA}},
            system=INSTRUCCION, messages=[{"role": "user", "content": contenido}])
    except Exception as e:  # noqa: BLE001
        return None, f"No se pudo consultar la IA: {type(e).__name__}."
    if r.stop_reason == "refusal":
        return None, "La IA no pudo analizar esta solicitud."
    texto = next((b.text for b in r.content if b.type == "text"), "{}")
    try:
        return json.loads(texto), None
    except ValueError:
        return None, "La IA respondió en un formato inesperado."


def _desde_ia(datos, origen):
    items = []
    for x in datos.get("alimentos", []):
        a, conf = buscar_alimento(x["nombre"])
        if a and conf >= .7:
            it = _item(x["nombre"], a, x["gramos"], f"{x['porcion_casera']} (~{x['gramos']:.0f} g)", round(conf * .9, 2), origen)
        else:
            g = max(x["gramos"], 1)
            it = {"texto": x["nombre"], "alimento_id": None, "nombre": x["nombre"], "gramos": round(g),
                  "porcion": f"{x['porcion_casera']} (~{g:.0f} g)", "kcal": round(x["kcal"]), "prot": round(x["prot"], 1),
                  "carb": round(x["carb"], 1), "grasa": round(x["grasa"], 1), "confianza": .5, "fuente": origen + " (estimación IA)",
                  "por100g": {k: round(x[k] / g * 100, 1) for k in ("kcal", "prot", "carb", "grasa")}}
        items.append(it)
    return items


def interpretar_con_ia(textos):
    datos, error = _ia("Estima estos alimentos (México): " + "; ".join(textos))
    return (_desde_ia(datos, "texto"), datos.get("nota", "")) if datos else ([], error)


def analizar_foto(contenido_bytes, media_type):
    if media_type not in ("image/jpeg", "image/png", "image/webp", "image/gif"):
        return [], "Formato de imagen no compatible (usa JPG o PNG)."
    datos, error = _ia([{"type": "image", "source": {"type": "base64", "media_type": media_type,
                                                    "data": base64.standard_b64encode(contenido_bytes).decode()}},
                        {"type": "text", "text": "¿Qué alimentos hay en este plato y cuánto pesa cada porción?"}])
    if not datos:
        return [], error
    return _desde_ia(datos, "foto"), datos.get("nota", "")


# ------------------------------------------------------------------ código de barras
def decodificar_imagen(contenido_bytes):
    """Lee un código de barras de una foto. Requiere los paquetes opcionales zxing-cpp y Pillow."""
    try:
        import io
        import zxingcpp
        from PIL import Image
    except ImportError:
        return None
    try:
        img = Image.open(io.BytesIO(contenido_bytes)).convert("L")
        img.thumbnail((1600, 1600))
        for r in zxingcpp.read_barcodes(img):
            if r.text and r.text.isdigit():
                return r.text
    except Exception:  # noqa: BLE001
        return None
    return None


def valido_ean(codigo):
    """Dígito verificador GTIN (EAN-8, UPC-A, EAN-13, GTIN-14)."""
    if not codigo.isdigit() or len(codigo) not in (8, 12, 13, 14):
        return False
    d = [int(x) for x in codigo]
    s = sum(x * (3 if i % 2 == 0 else 1) for i, x in enumerate(reversed(d[:-1])))
    return (10 - s % 10) % 10 == d[-1]


def producto_local(con, codigo):
    r = con.execute("SELECT * FROM productos WHERE codigo=?", (codigo,)).fetchone()
    return dict(r) if r else None


def open_food_facts(codigo, timeout=8):
    url = (f"https://world.openfoodfacts.org/api/v2/product/{codigo}.json"
           "?fields=product_name,product_name_es,brands,nutriments,serving_quantity,serving_size,quantity")
    req = urllib.request.Request(url, headers={"User-Agent": "FitBase/2 (app de nutricion local)"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        d = json.loads(r.read().decode("utf-8"))
    if d.get("status") != 1:
        return None
    p, n = d["product"], d["product"].get("nutriments", {})
    kcal = n.get("energy-kcal_100g")
    if kcal is None and n.get("energy_100g"):
        kcal = n["energy_100g"] / 4.184
    if kcal is None:
        return None
    return {"codigo": codigo, "nombre": (p.get("product_name_es") or p.get("product_name") or "Producto").strip(),
            "marca": (p.get("brands") or "").split(",")[0].strip(), "kcal": round(kcal, 1),
            "prot": round(n.get("proteins_100g") or 0, 1), "carb": round(n.get("carbohydrates_100g") or 0, 1),
            "grasa": round(n.get("fat_100g") or 0, 1), "fibra": n.get("fiber_100g"), "azucar": n.get("sugars_100g"),
            "sodio": round(n["sodium_100g"] * 1000) if n.get("sodium_100g") is not None else None,
            "porcion_g": float(p["serving_quantity"]) if str(p.get("serving_quantity") or "").replace(".", "", 1).isdigit() else None,
            "porcion_desc": p.get("serving_size") or "", "fuente": "Open Food Facts (ODbL)"}


def guardar_producto(con, d, autor_id=None):
    con.execute("""INSERT OR REPLACE INTO productos (codigo, nombre, marca, kcal, prot, carb, grasa, fibra, azucar, sodio, porcion_g,
                   porcion_desc, fuente, autor_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (d["codigo"], d["nombre"], d.get("marca"), d["kcal"], d["prot"], d["carb"], d["grasa"], d.get("fibra"), d.get("azucar"),
                 d.get("sodio"), d.get("porcion_g"), d.get("porcion_desc"), d.get("fuente", "Etiqueta"), autor_id))
    con.commit()


def buscar_producto(con, codigo):
    """Devuelve (producto, origen, error)."""
    codigo = re.sub(r"\D", "", codigo or "")
    if not codigo:
        return None, None, "Escribe o escanea un código."
    p = producto_local(con, codigo)
    if p:
        return p, "local", None
    try:
        p = open_food_facts(codigo)
    except Exception:  # noqa: BLE001
        return None, None, "Sin conexión con Open Food Facts. Puedes capturar el producto con los datos de su etiqueta."
    if not p:
        return None, None, "Producto no encontrado. Captúralo una vez con los datos de su etiqueta y quedará guardado."
    guardar_producto(con, p)
    return producto_local(con, codigo), "Open Food Facts", None


def item_producto(p, gramos):
    a = {"id": None, "nombre": (p["nombre"] + (f" · {p['marca']}" if p.get("marca") else "")),
         "por100g": {"kcal": p["kcal"], "prot": p["prot"], "carb": p["carb"], "grasa": p["grasa"], "fibra": p.get("fibra")}}
    desc = f"{gramos:g} g" + (f" ({p['porcion_desc']})" if p.get("porcion_desc") and p.get("porcion_g") == gramos else "")
    return _item(p["codigo"], a, gramos, desc, 1, "código de barras")
