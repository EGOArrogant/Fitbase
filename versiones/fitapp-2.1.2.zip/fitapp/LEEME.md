# FitBase · plataforma de entrenamiento y nutrición basada en evidencia

Aplicación web en Python (Flask + SQLite) para usar en tu PC como servidor. Se puede abrir desde cualquier celular o computadora conectada a tu misma red wifi.

## Instalación (una sola vez)

1. Instala **Python 3.10 o superior** desde python.org. En Windows, marca la casilla **"Add python.exe to PATH"** en la primera pantalla del instalador.
2. Descomprime `fitapp.zip` en una carpeta fija, por ejemplo `Documentos\FitBase`. No la dejes en Descargas ni dentro del ZIP.
3. Ejecuta el instalador:
   - **Windows:** doble clic en `instalar_windows.bat`.
   - **Mac / Linux:** abre una terminal en la carpeta y ejecuta `bash instalar_mac_linux.sh`.

   El instalador revisa Python, crea un entorno aislado (`.venv`), instala Flask, Waitress y ReportLab (PDF) y la librería de Claude, y crea un acceso directo **FitBase** en el escritorio. En Windows también te pregunta si quieres que arranque al encender la computadora.

## Uso diario

- Abre **FitBase** desde el escritorio. Se abre una ventana negra (el servidor, no la cierres) y el navegador entra solo a `http://localhost:5000`.
- Desde tu celular o tablet en la misma red wifi, usa la dirección `http://192.168.x.x:5000` que aparece en la ventana negra. Si Windows pregunta por el firewall, permite **redes privadas**.
- Para apagarla, cierra la ventana negra.

### Funciones que necesitan algo extra

- **Foto del plato** y alimentos que la base no reconoce: necesitan activar el Coach IA (ver abajo).
- **Código de barras en línea**: la búsqueda en Open Food Facts necesita internet. Sin internet, los productos se capturan desde la etiqueta y quedan guardados.
- **Cámara y micrófono en el celular**: los navegadores solo los permiten en `localhost` o con HTTPS. En la red local (`http://192.168…`) usa "Foto del código" y el micrófono del teclado del celular para dictar; funcionan igual.
- **Leer un código desde una foto** en el servidor usa los paquetes opcionales de `requirements-opcional.txt`. Se instalan solos; si fallan, lo demás funciona.

### Enlaces de invitación

Mientras la app está en tu computadora, los enlaces usan la dirección de tu red local (`http://192.168…`) y solo abren en celulares conectados a tu mismo wifi. Cuando publiques FitBase en internet, define la variable `FITAPP_URL_PUBLICA` con tu dominio (por ejemplo `https://app.tudominio.com`) para que los enlaces funcionen desde cualquier lugar.

## Usarla en el celular

La app se adapta sola al teléfono: barra superior, menú deslizable (botón ☰ o «Más») y barra inferior con Inicio, Entrenar, **Registrar** (botón central), Comida y Más. Las tablas largas se convierten en tarjetas.

Para tenerla como app en el teléfono:
1. Abre en el navegador del celular la dirección `http://192.168.x.x:5000` que aparece en la ventana del servidor (celular y computadora en la misma red wifi).
2. **Android (Chrome):** menú ⋮ → «Agregar a la pantalla principal».
3. **iPhone (Safari):** botón Compartir → «Agregar a inicio».

Queda un ícono de FitBase que abre la app a pantalla completa. La computadora con el servidor debe estar encendida.

## Actualizaciones sin reinstalar

Abre **Actualizaciones** en el menú, desde la computadora donde corre el servidor.

- **Automática (recomendada):** escribe una sola vez el repositorio de GitHub donde se publican las versiones (por ejemplo `tuusuario/fitbase`) y activa **«Instalar las versiones nuevas automáticamente»**. FitBase revisa cada 1, 6, 12 o 24 horas. Cuando hay versión nueva la descarga y verifica su firma. Antes de instalar guarda una copia del código y de la base de datos. Después se reinicia sola cuando nadie la está usando: dos minutos sin actividad, o al encender la computadora. Si prefieres decidir tú, deja el interruptor apagado: verás el aviso y la instalas con un clic.
- **Desde archivo:** si te mandan un `fitapp-x.y.z.zip`, súbelo y la app se instala y se reinicia sola.
- **Volver atrás:** el botón **«Volver a la versión anterior»** restaura la copia más reciente del código.
- **Nunca se tocan** tu base de datos, fotos, respaldos, videos ni la configuración de actualizaciones.

**Cómo publicar una versión nueva** (lo hace quien mantiene FitBase):
1. Ejecuta `python scripts/crear_paquete.py 2.1.0 "Qué trae" --github tuusuario/fitbase`. Se crean `dist/fitapp-2.1.0.zip` y `dist/version.json`.
2. En GitHub: Releases → Draft a new release → etiqueta `v2.1.0` → sube los dos archivos → Publish.
3. Todas las computadoras con ese repositorio configurado la detectan solas.

Las dependencias nuevas se instalan solas al abrir FitBase y la base de datos se migra sola al arrancar.

## Tu cuenta de administrador (todo desbloqueado, sin costo)

La primera vez que abras FitBase en tu computadora, la pantalla de inicio de sesión te ofrece **«Crear administrador»**. También puedes entrar directo a `http://localhost:5000/admin/crear`. Escribe tu nombre, tu correo y una contraseña de al menos 10 caracteres. Esa cuenta:

- tiene **todo desbloqueado**: funciones de cliente, Pro y entrenador, sin cobro;
- abre el panel **★ Administración**, donde ves todos los usuarios y estadísticas, das planes **Pro o Coach de cortesía** (con fecha de fin o para siempre), cambias roles, asignas entrenadores, restableces contraseñas, desactivas cuentas y nombras a otros administradores.

Por seguridad, el administrador solo se crea desde la computadora donde está instalada la app y no existe una contraseña predeterminada. Si ya tienes cuenta de entrenador, usa ese mismo correo y su contraseña: se convierte en administrador sin perder a tus clientes. Si olvidas la contraseña, con la app cerrada ejecuta en la carpeta de FitBase:

- **Windows:** `.venv\Scripts\python.exe scripts\crear_admin.py`
- **Mac / Linux:** `.venv/bin/python scripts/crear_admin.py`

## Cuentas de demostración

| Cuenta | Correo | Contraseña |
|---|---|---|
| Cliente con 3 semanas de datos | demo@fitapp.local | demo1234 |
| Entrenador con 4 clientes | coach@fitapp.local | demo1234 |

También puedes entrar desde los botones "Ver demo" y "Demo para entrenadores" de la portada.

### Para empezar desde cero

Detén el servidor y borra el archivo `fitapp.db`. Al iniciar se crea una base nueva, con las cuentas demo incluidas.

## Qué incluye

| Sección | Qué hace |
|---|---|
| Evaluación inicial | Datos y objetivo, medidas, % de grasa (Marina EE. UU. o medido), PAR-Q+, FC en reposo, presión arterial y condiciones de salud (embarazo, hipertensión, diabetes, lesión, osteoporosis). Las alertas se basan en la evidencia. |
| Inicio (dashboard) | Calendario de adherencia por colores, Fitness Score en radar con pesos visibles, KPI, peso con tendencia, gasto adaptativo, racha semanal con comodín, alertas y mensajes del entrenador. |
| Mi programa | 4 plantillas. Editor de series, repeticiones, RIR y descansos. Volumen semanal por músculo con conteo fraccionado y semáforo, frecuencia, máximo por sesión, duración estimada y sustitución de ejercicios. |
| Sesión de hoy | Sugerencia de doble progresión, calentamiento, temporizador de descanso, registro de series con e1RM y tonelaje. |
| Mapa muscular | Cuerpo masculino y femenino, frente y espalda. Al tocar un músculo muestra función, ejercicios, volumen, movilidad y lesiones. Modo "mi volumen esta semana" como mapa de calor. |
| Ejercicios | 72 ejercicios con claves técnicas, músculos implicados, alternativas y tu historial de e1RM. |
| Nutrición | Calorías y macros con ecuaciones validadas en deportistas, disponibilidad energética y recetas sugeridas por tiempo de comida. |
| Dieta por equivalentes (dietocálculo) | Equivalentes SMAE calculados automáticamente desde las metas, reparto en 6 tiempos de comida, % de adecuación 90–110 %, menú y receta por tiempo, notas, versión imprimible y progreso del cliente con sugerencia de ajuste calórico. |
| Recetas | 73 recetas mexicanas con macros por ingrediente, porciones escaladas a tus calorías, plan del día automático, lista de compras y recetas propias (las del entrenador se comparten con sus clientes). |
| Progreso | Peso y tendencia, e1RM por ejercicio, tonelaje semanal, resumen semanal con gasto adaptativo y etiquetas del día (al estilo de los "errores" de un diario de trading). |
| Registro diario y hábitos | Peso, kcal, proteína, pasos, sueño, entrenamiento, energía, cintura, etiquetas y checklist del playbook. |
| Modo entrenador | Código para vincular clientes. Panel con score, adherencia, fuerza y alertas; detalle de cada cliente, comentarios y dietocálculo. |
| Calculadoras | Calorías y macros, 1RM con tabla de cargas, discos y calentamiento (kg/lb), zonas de FC (ACSM y Tanaka), Rockport y Cooper (versión corregida). |
| Contenido | Suplementos por nivel de evidencia, mitos vs evidencia y protocolo de emergencia (AHA 2025). |
| Tus datos | Exportación a JSON o CSV, respaldo automático de la base en `respaldos/` (últimas 10 copias), modo oscuro, modo bienestar que oculta los números y aviso de privacidad (borrador LFPDPPP). |

## Novedades de esta versión (2.1)

| Sección | Qué hace |
|---|---|
| Diseño y fluidez | Estética común en todas las secciones. El modo claro tiene tonos tipo papel que cansan menos la vista. Las tipografías vienen dentro de la app, así que funcionan sin internet. Las páginas cambian con transiciones suaves y la siguiente se carga por adelantado al pasar el ratón. Hay una barra de carga discreta y el menú recuerda dónde ibas. |
| Planes y cobro | **Gratis** incluye todo el contenido y la personalización. **Pro** cuesta $99 al mes o $799 al año. **Coach** empieza gratis con hasta 3 clientes; después hay Coach 15 ($349), Coach 40 ($699) y Coach 100 ($1,290) al mes, con 2 a 4 meses de regalo si pagas el año. Todos los niveles de Coach traen todas las funciones y sus clientes reciben Pro incluido. Al cambiar de plan, los días pagados que te quedan se convierten en días del plan nuevo. |
| Pantalla de pago | Pide nombre, correo, teléfono, factura (RFC, razón social, régimen y uso del CFDI) y forma de pago. **Tarjeta** y **OXXO** se pagan en la página segura de Stripe; FitBase nunca ve ni guarda los números de la tarjeta. El pago anual con tarjeta permite meses sin intereses. **Transferencia o depósito SPEI** muestra la CLABE y una referencia; el cliente sube su comprobante y tú lo confirmas. Cada pedido tiene folio y recibo en PDF, y el cliente ve todo en *Mis pagos*. |
| Funciones Pro | Puedes exigir el plan para usarlas desde *Administración → Pagos*, con el interruptor «Activar cobro». Mientras esté apagado, todo sigue abierto. |
| Notificaciones | La campana tiene contador en vivo y aparecen avisos emergentes. Si el usuario lo permite, también llegan avisos del navegador aunque la pestaña esté cerrada. Se avisa de comentarios del entrenador, cambios en tu dieta o rutina, retos nuevos, respuestas a tu opinión, pagos confirmados o rechazados y planes por vencer. |
| Actividad en vivo (coach) | Muestra al momento lo que hace cada cliente: series con peso y repeticiones, comidas, peso, pasos y sueño, mediciones, fotos, retos y cambios de perfil. Las acciones seguidas se agrupan, por ejemplo «×3 series». También ves quién está en línea. Se actualiza cada 5 segundos y puedes filtrar por cliente o por tipo. |
| Panel de clientes | Usa tarjetas con **filtros inteligentes** que responden al instante: por nivel (novato, principiante, intermedio, avanzado o élite, según el sondeo avanzado o el inicial), por objetivo y por estado (necesitan atención, alerta de salud, 3 días o más sin registrar, van muy bien, nuevos, en línea, sin evaluación). Hay buscador y 6 formas de ordenar. Cada tarjeta muestra el programa, la sesión de hoy con ejercicios, series, repeticiones y RIR, la última sesión registrada, la meta de calorías y macros frente al promedio real de 7 días, el ritmo de peso, la racha y la última actividad. |
| Guía de uso | La primera vez que entras aparece un recorrido paso a paso que resalta cada apartado. Funciona en computadora y en celular; en celular abre el menú y señala la barra inferior. Hay una versión para cliente, para coach y para administrador. Puedes repetirlo cuando quieras desde **🧭 Guía de uso**, donde también hay un manual con buscador. La futura app móvil recibe los mismos pasos en `/api/v1/guia`. |
| Idiomas | Hay **español de Latinoamérica, inglés y francés**. Se eligen en el menú, en la portada o en *Ajustes*. Están traducidos el menú, la portada, el acceso, los planes, la pantalla de pago, la guía, las notificaciones y el panel del coach. Lo que aún no tiene traducción se muestra en español y queda anotado. En *Administración → Idiomas* lo traduces con IA en un clic usando tu clave de Claude, o a mano en `idiomas/fuente_ui.txt` (formato: español ||| inglés ||| francés). |
| Portada | Nueva sección **«Úsala donde estés»**. Muestra la app en un celular grande (440 × 956), una tableta de 13″ (1032 × 1376) y una laptop de 15″ (1440 × 900), con proporciones reales. El botón **«Pruébala aquí mismo»** abre la demo funcionando dentro del dispositivo elegido y a su tamaño real. |
| GitHub | En *Actualizaciones → GitHub*: **Probar conexión** revisa el repositorio paso a paso y **Publicar esta versión** crea el release con el paquete y `version.json` sin salir de la app. Necesitas un token de acceso con permiso *Contents: Read and write*. El token solo se guarda en esta computadora si eliges recordarlo. |

### Configurar el cobro (Administración → Pagos)
1. **Tarjeta y OXXO:** crea una cuenta en stripe.com (México) y activa OXXO en *Settings → Payment methods*. Copia tu **clave secreta** (`sk_test_…` para probar o `sk_live_…` para cobrar) y pégala en *Administración → Pagos*. También puedes ponerla en la variable de entorno `STRIPE_SECRET_KEY`. Con **«Probar conexión con Stripe»** confirmas que funciona.
2. **Transferencia:** escribe banco, beneficiario y CLABE de 18 dígitos. Cuando un cliente suba su comprobante lo verás en *Por revisar*. Pulsa **Confirmar pago** y su plan se activa solo.
3. **Confirmación de pagos con tarjeta u OXXO:** se hace sola cuando el cliente regresa de pagar, cuando abre *Mis pagos* y cuando tú abres *Pagos*. Si tu servidor está publicado en internet, agrega además el webhook que se indica en esa página para que se confirmen al instante.
4. Cuando todo esté listo, activa **«Activar cobro»**.
5. Las claves se guardan solo en `pagos.json`, en esta computadora. Ese archivo nunca entra en paquetes ni actualizaciones.

## Novedades de esta versión (2.0)

| Sección | Qué hace |
|---|---|
| Funciones Pro | **Ajuste semanal automático de calorías:** se activa en *Mi plan* y revisa cada semana tu peso real y lo que comes. Recalcula tu gasto real, con un límite de ±20 % respecto a la fórmula, y te avisa del cambio. **Semanas de descarga automáticas:** la sesión te avisa cuando toca, por calendario según tu nivel o porque tu fuerza lleva 3 semanas sin subir; al activarla quedan la mitad de series, 2 repeticiones más en reserva y cargas al 90 %. **Tendencias de mediciones:** peso, masa magra, músculo, % de grasa y cintura en el tiempo. **Reporte del mes en PDF:** lo que salió bien y qué mejorar, en lenguaje sencillo. Disponible en *Mis descargas* y en *Progreso*, y el entrenador lo descarga por cliente. En la versión local todo está abierto. |
| API para la app móvil | En `/api/v1`, con documentación en `/api`. Inicio de sesión con token por dispositivo, que se puede revocar en *Ajustes → Dispositivos conectados*. Incluye perfil y metas, entrenamiento y comida del día, registro de comidas por texto, peso, pasos y sueño, series, progreso, retos y la lista de clientes para entrenadores. La futura app de iPhone y Android usa las mismas cuentas y los mismos datos. |
| Portada nueva | Página de inicio de marketing en lenguaje sencillo, pensada para dos públicos: quien entrena por su cuenta y entrenadores. Tiene animaciones al desplazarse: textos que aparecen, cifras que suben, palabras que rotan, un celular fijo que cambia de pantalla en cada paso, tarjetas con efecto 3D, marquesina de niveles, preguntas frecuentes y botón fijo en celular. Muestra capturas reales de la app (`static/landing/`). Respeta la opción del sistema de «reducir movimiento». |
| Invitar clientes (entrenador) | En **Invitar clientes** el entrenador crea un enlace personal (de un solo uso y con vigencia) o usa su enlace general. Puede enviarlo por WhatsApp o correo, o compartir su código QR. El cliente abre el enlace en su celular y llena su **ficha de ingreso** en 7 pasos: cuenta, datos, objetivo y motivación, salud (PAR-Q+, condiciones, molestias, medicamentos y lesiones), rutina diaria (trabajo, dónde y cuándo entrena, sueño, estrés, alcohol y tabaco), alimentación (comidas, si cocina, alergias, lo que no le gusta) y consentimiento. Al terminar, el cliente queda vinculado con su plan y programa listos y aparece en el panel con la etiqueta «Nuevo». Su ficha se ve en el expediente y en el PDF. Si el cliente ya tiene cuenta, el enlace le ofrece vincularse. |
| Sondeo avanzado | Tiempo entrenando, constancia, disciplina, rutina actual, **los pesos que ya cargas** (mejor serie en 7 ejercicios), competencia (federación, categoría, fecha, peso en tarima), composición (peso, % de grasa, masa magra y método), sueño, estrés, lesiones, análisis, suplementos, metas, puntos débiles y cómo prefieres ver la app (sencillo, completo o atleta). Calcula tu fuerza relativa y tu nivel: **Novato, Principiante, Intermedio, Avanzado o Élite**, incluido el competidor amateur o profesional (IFBB Pro). Con eso propone volumen, esfuerzo, progresión, programa y la fase de preparación con cuenta regresiva. Calcula también las cargas para tu primera sesión. El entrenador la ve en el expediente y en el PDF. |
| Fotos de progreso | Frente, perfil, espalda o pose, con fecha y peso. Se comparan lado a lado. Son privadas: solo las ven la persona y su entrenador. Se guardan en la carpeta `fotos/` de la computadora, no se suben a internet y las actualizaciones no las tocan. |
| Retos y niveles | Retos con inscripción cuyo avance se mide solo con tus registros: entrenamientos, días con comidas, proteína, pasos, series, tonelaje y % de peso perdido (cuenta máximo 1 % por semana). Hay tabla de posiciones e insignias. Los niveles (tiers) Bronce → Plata → Oro → Platino → Diamante → Leyenda dan beneficios como descuentos en retos de pago y acceso anticipado. |
| Retos con premios | El entrenador crea retos con cuota, cupo y premios, confirma pagos, valida resultados y asigna lugares. En esta versión el pago se registra a mano (transferencia o efectivo). Al publicar la app en línea se conecta una pasarela de pago. |
| Feedback | Los clientes envían ideas, errores y calificaciones y votan las ideas de la comunidad. El entrenador responde, cambia el estado (en revisión, planeado, hecho) y ve un resumen. |
| Versión para celular | Barra superior, menú deslizable, barra inferior con accesos rápidos, tablas convertidas en tarjetas, textos y botones del tamaño del dedo, y se puede agregar a la pantalla de inicio como app. |
| Mis descargas (PDF) | Página que reúne todos los PDF: plan de alimentación, dieta por equivalentes, plan del día, menú semanal, diario, puntaje nutricional, recetario, tabla de alimentos, programa, hoja de la sesión para el gimnasio (con casillas para anotar peso y repeticiones), plan inteligente, ficha de cada ejercicio, progreso, mediciones con proporcionalidad, expediente y mis datos. Cada sección tiene además su propio botón «PDF». |
| Registrar comida | Cuatro formas de registrar: **texto** libre ("2 huevos, pan y una taza de leche", con encabezados como "Comida:"), **voz** (dictado del navegador o del teclado del celular), **foto** del plato (la IA identifica alimentos y gramos; requiere la clave de Claude) y **código de barras** (cámara, foto o números). Siempre se revisan las porciones antes de guardar. Los productos se buscan en tu base local y en Open Food Facts; si no existen, se capturan una vez desde la etiqueta. |
| Puntaje nutricional | Calificación diaria de 0 a 100 con proteína, energía, fibra, frutas y verduras, azúcares y ultraprocesados, y variedad. "Lo que te falta" dice cuánto te falta de cada cosa, con alimentos concretos y cambios sugeridos. Incluye una gráfica de 7 días. El entrenador la ve por cliente. |
| Menú semanal | 7 días de recetas ajustadas a tus calorías y macros, sin repetir de más. Lista de compras agrupada por pasillo y PDF. |
| Proporcionalidad | Con envergadura y talla sentado (medibles en casa) o con longitudes y diámetros ISAK, la app dice si tus brazos, piernas, tronco, hombros y caderas son largos, medios o cortos, o anchos, medios o estrechos. Calcula los índices córmico, esquélico, de envergadura relativa y acromio-ilíaco; la composición por zonas (área muscular del brazo, perímetros corregidos, distribución de la grasa); el perfil frente al humano de referencia Phantom (Ross & Wilson); y los deportes donde tus proporciones dan ventaja. También sale en el expediente PDF. |
| Cuerpo 3D continuo | El maniquí ahora es una sola malla esculpida con piel, como una figura de arcilla, que se dobla en las articulaciones. Se genera con `scripts/generar_cuerpo3d.py` (archivos en `static/cuerpo3d/`). Puedes cambiar entre hombre y mujer en cada ejercicio. |
| Base de alimentos | 414 alimentos (77 nuevos de USDA FoodData Central), más los productos que escanees o captures. |
| Cuerpo 3D esculpido | El maniquí ahora tiene músculos modelados (pectoral, deltoides, bíceps, cuádriceps, glúteo, etc.), material tipo arcilla y sombras. Hay versión de hombre y de mujer. El músculo principal se ve en morado y los secundarios en tono intermedio. El cuerpo se ajusta a tu % de grasa y somatotipo medidos. La postura respeta la biomecánica: pies apoyados y barra sobre el medio pie. |
| Mediciones corporales | **Básica** (cinta métrica: cintura, cadera, cuello, muñeca) y **avanzada ISAK** (8 pliegues, perímetros y diámetros óseos). Calcula % de grasa por 5 métodos (Durnin-Womersley, Jackson-Pollock, Yuhasz-Carter, Marina EE. UU., bioimpedancia), masa magra, FFMI, músculo esquelético (Lee 2000), fraccionamiento de De Rose, complexión, riesgo por cintura, ICE e ICC, y somatotipo Heath-Carter con somatocarta. El entrenador puede capturarlas por cliente y salen en el expediente y su PDF. |
| Actualizaciones | Instala versiones nuevas desde un archivo o en línea, sin reinstalar ni perder datos, con respaldo automático y opción de volver atrás. |
| Instalador | `instalar_windows.bat` / `instalar_mac_linux.sh`: revisan Python, instalan todo, crean el acceso directo y (en Windows) el arranque automático opcional. |
| Planes | **Gratis** incluye todo el contenido y la personalización: plan, rutina, dieta, recetas, 3D, mediciones y PDF. **Pro** ($79/mes) automatiza y analiza: ajuste semanal de calorías, periodización, menú semanal con lista de compras, tendencias, reporte mensual, más Coach IA y respaldo en la nube. **Coach** ($449/mes) es administración: clientes, alertas, asignación, expedientes y marca propia. En esta versión local todo está abierto y los cobros no están conectados. |
| Expediente del cliente | El entrenador ve en una sola página la salud (PAR-Q+, condiciones, FC, presión), composición, plan inteligente, programa, fuerza, dieta, diario, registro completo y comentarios, y descarga el historial completo en PDF. El cliente también puede ver y descargar el suyo. Hay además un reporte PDF de todos los clientes. |
| Iconos de artículos | Portadas con iconos minimalistas propios por categoría. |
| Sondeo inicial | Las personas nuevas responden edad, peso, estatura, experiencia, objetivo, equipo disponible, molestias (rodilla, espalda, hombro, cadera), condiciones de salud y si pueden bajar al suelo o caminar 10 min. |
| Mi plan inteligente | Con el sondeo, la app recomienda y deja para después ejercicios con reglas basadas en guías (OARSI, Cochrane, NSCA, OMS, ADA, ACOG/guía canadiense, Too Fit To Fracture, ACSM). Ejemplo: con 150 kg o dolor de rodilla, el cardio es bicicleta, elíptica o agua en lugar de correr. Cada decisión muestra su motivo y su fuente. |
| Equipo | 17 tipos de equipo con iconos propios (barra, mancuernas, máquina, polea, kettlebell, peso corporal, disco, balón medicinal, banda, TRX, bosu, Smith, cardio, estiramientos, yoga, pilates, recuperación). Filtro en Entrenar hoy y en la biblioteca. |
| Ejercicios | 150 ejercicios (antes 72), incluidos cardio, movilidad y recuperación. La ficha muestra los músculos principales y secundarios sobre el cuerpo y tiene espacio para video: el entrenador sube un MP4/WebM o pega un enlace de YouTube. |
| Cuerpo de mujer | Dibujo de mujer proporcionado por el dueño del proyecto, vectorizado igual que el de hombre. Ambos con peinado redibujado. |
| Recetas | 312 recetas: platillos mexicanos y variantes de bowls, tacos, ensaladas, sopas, pastas, salteados, fajitas, tostadas, ceviches, guisos, desayunos, colaciones y licuados, con medidas caseras, pasos y tips. |
| Artículos | 260 artículos: 69 de investigación (con referencias verificadas en PubMed, PMC o DOI) y 191 guías prácticas (técnica de cada ejercicio, guía por músculo, equipo, suplementos, mitos y condiciones de salud). |
| Mapa muscular y Entrenar hoy | Usa el dibujo del cuerpo proporcionado por el dueño del proyecto, vectorizado: cada zona gris es un músculo seleccionable y las líneas se conservan. La versión de mujer ajusta las proporciones del mismo dibujo. Deltoides lateral y aductores se eligen con botones porque no tienen zona propia en el dibujo. Usa los colores de la página (gris neutro, morado al seleccionar) en modo claro y oscuro. |
| Calculadoras | Energía con barra de balance (reposo, actividad y déficit o superávit) y comparación de objetivos; nutrientes con gráfica de dona y tabla por comida; fuerza con curva carga–repeticiones y tabla de cargas por objetivo. Tienen dos vistas: **Vista cliente** y **Vista entrenador** (comparación de ecuaciones, desglose factorial, disponibilidad energética, g/kg, tabla de cargas por RIR y todas las fórmulas de 1RM). Cada calculadora explica qué significa cada número. |
| Descargas en PDF | Todo lo que descarga el cliente sale en PDF: resultados de calculadoras, dieta por equivalentes, plan del día con lista de compras, recetas, programa, reporte de progreso, diario de comidas, artículos y "Mis datos". La copia técnica en JSON queda en Ajustes para quien la necesite. |
| Dashboard | Estilo de diario de trading en modo oscuro. Incluye: progreso neto de fuerza, factor de adherencia (anillo), sesiones cumplidas (medidor), calorías promedio vs meta, calendario por colores con resumen semanal, Fitness Score con barra de gradiente, tonelaje acumulado, reporte diario, sesiones recientes, checklist y acceso al Coach IA. |
| Coach IA | Asistente con criterio de entrenador veterano (gimnasio, resistencia, deportes de equipo y combate). Responde con los datos reales del cliente y tiene límites de seguridad: no diagnostica, deriva al médico ante señales de alarma y no da dosis de sustancias prohibidas. |
| Diario de comidas | Registro por porciones caseras o gramos con buscador de alimentos. Muestra proteína y grasa mínimas por cliente, lo que falta o sobra y un análisis de 7 días, y pasa los totales al registro diario. El entrenador puede verlo y editarlo. |
| Tabla de alimentos | 318 alimentos (USDA FoodData Central, SMAE y etiquetas mexicanas). Valores por 100 g, porciones caseras (pieza, taza, cucharada) en gramos y equivalente SMAE. |

## Activar el Coach IA (opcional)

Sin configuración, el Coach responde en **modo básico** con reglas y los datos del cliente. Para respuestas completas con IA:

1. Crea una clave de API en https://console.anthropic.com (el uso tiene costo por consulta).
2. Antes de iniciar la app, define la variable de entorno:
   - **Windows:** abre "Símbolo del sistema" y ejecuta `setx ANTHROPIC_API_KEY "tu-clave"` una sola vez. Cierra y vuelve a abrir FitBase. La clave queda guardada solo en tu PC.
   - **Mac / Linux:** `export ANTHROPIC_API_KEY="tu-clave"` y luego `./iniciar_mac_linux.sh`.
3. El modelo es `claude-opus-5-5`, con esfuerzo bajo para que las respuestas de chat sean rápidas. Se cambia con la variable `FITAPP_MODELO`.

Si la API rechaza una consulta por seguridad, el servidor reintenta automáticamente con otro modelo (fallback del servidor). No compartas la clave: queda solo en tu PC.

## Personalizar

- **Nombre de la marca:** variable de entorno `FITAPP_NOMBRE`, o edita `APP_NOMBRE` en `app.py`.
- **Puerto:** variable de entorno `PORT`.
- **Ingredientes y recetas:** `data/recetas.py` y `data/recetas_extra.json`. Las recetas propias también se pueden crear desde la web.
- **Alimentos:** `data/alimentos_a.json` y `data/alimentos_b.json`. Cada alimento lleva `nombre`, `categoria`, `smae`, `por100g` (`kcal`, `prot`, `carb`, `grasa`, `fibra`), `porciones` (`desc`, `g`), `eq_smae_g` y `fuente`.
- **Artículos:** `data/articulos.py` (originales), `data/articulos_inv1.py` y `data/articulos_inv2.py` (investigación) y `data/articulos_guias.py` (guías generadas a partir de los datos de la app).
- **Recetas generadas por familias:** `data/recetas_variantes.py`.
- **Animaciones 3D:** poses en `static/js/visor3d.js` y asignación de ejercicios en `data/animaciones.py`.
- **Planes y precios:** `PLANES` y `TABLA` en `app.py`.
- **Reglas del plan inteligente:** `seleccion.py`. **Equipo e iconos:** `data/equipo.py`.
- **Videos de técnica:** `static/videos/<slug-del-ejercicio>.mp4` o desde la ficha del ejercicio (cuenta de entrenador).
- **Ejercicios:** `data/ejercicios.py`.
- **Información de músculos:** `data/musculos.py`.
- **Dibujo del cuerpo:** `scripts/cuerpo_base.png`. Si lo cambias (o agregas una versión de mujer), regenera `data/cuerpo_svg.json` con `python scripts/vectorizar_cuerpo.py scripts/cuerpo_base.png data/cuerpo_svg.json` (requiere `pip install opencv-python-headless`; la app no lo necesita para funcionar).
- **Plantillas, checklist, suplementos y emergencias:** `data/contenido.py`.
- **Fórmulas:** `calc.py`, que usa las mismas del Excel v3 verificado. Las calculadoras interactivas repiten esas fórmulas en `templates/calculadoras.html`.
- **Diseño de los PDF:** `pdf.py` (usa la tipografía libre DejaVu incluida en `static/fonts`).
- **Dietocálculo:** `dieta.py`.

## Seguridad y alcance

- Es una herramienta educativa: no sustituye la valoración médica ni la de un nutriólogo con cédula.
- Úsala solo en tu red local. Para publicarla en internet necesitas HTTPS, un dominio y revisar el aviso de privacidad con un abogado.
- Las contraseñas se guardan cifradas (hash). La clave de sesión se genera sola en `.secret_key`.
