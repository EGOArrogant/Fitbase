"""Generador de PDF para todo lo que el cliente descarga (ReportLab + tipografía DejaVu incluida).

Uso: generar(titulo, bloques, subtitulo) -> bytes
Bloques (tuplas):
  ("h", texto)                       subtítulo de sección
  ("p", texto)                       párrafo (admite <b> e <i>)
  ("nota", texto)                    texto pequeño gris
  ("lista", [textos])                viñetas
  ("kv", [(etiqueta, valor), ...])   tabla de dos columnas
  ("tabla", encabezados, filas[, anchos_relativos])
  ("metricas", [(etiqueta, valor, unidad), ...])   tarjetas grandes en una fila
  ("aviso", texto)                   recuadro destacado
  ("salto",)                         salto de página
"""
import datetime as dt
import io
import os
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (KeepTogether, ListFlowable, ListItem, PageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

_FUENTES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "fonts")
try:
    pdfmetrics.registerFont(TTFont("DV", os.path.join(_FUENTES, "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DVB", os.path.join(_FUENTES, "DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFontFamily("DV", normal="DV", bold="DVB", italic="DV", boldItalic="DVB")
    F, FB = "DV", "DVB"
except Exception:  # si faltara la tipografía, Helvetica (sin algunos símbolos)
    F, FB = "Helvetica", "Helvetica-Bold"

ACENTO = colors.HexColor("#6D4AE6")
TINTA = colors.HexColor("#16122B")
GRIS = colors.HexColor("#5B5872")
LINEA = colors.HexColor("#E6E3F0")
SUAVE = colors.HexColor("#F4F2FB")
AVISO = colors.HexColor("#FFF6DB")

S = {
    "h": ParagraphStyle("h", fontName=FB, fontSize=13, leading=17, textColor=TINTA, spaceBefore=10, spaceAfter=5),
    "p": ParagraphStyle("p", fontName=F, fontSize=10, leading=14.5, textColor=TINTA, spaceAfter=5),
    "nota": ParagraphStyle("nota", fontName=F, fontSize=8, leading=11, textColor=GRIS, spaceAfter=4),
    "celda": ParagraphStyle("celda", fontName=F, fontSize=9, leading=12, textColor=TINTA),
    "celdab": ParagraphStyle("celdab", fontName=FB, fontSize=9, leading=12, textColor=TINTA),
    "cab": ParagraphStyle("cab", fontName=FB, fontSize=8.5, leading=11, textColor=GRIS),
    "met_v": ParagraphStyle("met_v", fontName=FB, fontSize=18, leading=22, textColor=TINTA, alignment=TA_CENTER),
    "met_l": ParagraphStyle("met_l", fontName=F, fontSize=8, leading=10, textColor=GRIS, alignment=TA_CENTER),
}


def _t(x):
    """Texto seguro para Paragraph: escapa todo salvo <b>, <i> y <br/> que ponemos nosotros."""
    s = escape("" if x is None else str(x))
    for tag in ("b", "i"):
        s = s.replace(f"&lt;{tag}&gt;", f"<{tag}>").replace(f"&lt;/{tag}&gt;", f"</{tag}>")
    return s.replace("&lt;br/&gt;", "<br/>")


def _tabla(enc, filas, anchos, total):
    data = []
    if enc:
        data.append([Paragraph(_t(c), S["cab"]) for c in enc])
    for f in filas:
        data.append([Paragraph(_t(c), S["celda"]) for c in f])
    n = len(data[0]) if data else 1
    anchos = anchos or [1] * n
    suma = float(sum(anchos))
    t = Table(data, colWidths=[total * a / suma for a in anchos], repeatRows=1 if enc else 0)
    estilo = [("LINEBELOW", (0, 0), (-1, -1), 0.4, LINEA), ("VALIGN", (0, 0), (-1, -1), "TOP"),
              ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
    if enc:
        estilo += [("BACKGROUND", (0, 0), (-1, 0), SUAVE), ("LINEBELOW", (0, 0), (-1, 0), 0.8, ACENTO)]
    t.setStyle(TableStyle(estilo))
    return t


def generar(titulo, bloques, subtitulo="", app="FitBase"):
    buf = io.BytesIO()
    margen = 16 * mm
    doc = SimpleDocTemplate(buf, pagesize=letter, leftMargin=margen, rightMargin=margen, topMargin=26 * mm,
                            bottomMargin=18 * mm, title=titulo, author=app)
    ancho = letter[0] - 2 * margen
    fecha = dt.date.today().strftime("%d/%m/%Y")

    def marco(c, d):
        c.saveState()
        c.setFillColor(ACENTO)
        c.rect(0, letter[1] - 16 * mm, letter[0], 16 * mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont(FB, 13)
        c.drawString(margen, letter[1] - 10.5 * mm, app)
        c.setFont(F, 9)
        c.drawRightString(letter[0] - margen, letter[1] - 10.5 * mm, f"{titulo[:70]} · {fecha}")
        c.setFillColor(GRIS)
        c.setFont(F, 7.5)
        c.drawString(margen, 10 * mm, "Herramienta educativa: no sustituye la valoración de un médico o nutriólogo con cédula.")
        c.drawRightString(letter[0] - margen, 10 * mm, f"Página {d.page}")
        c.restoreState()

    story = [Paragraph(_t(titulo), ParagraphStyle("tit", fontName=FB, fontSize=20, leading=24, textColor=TINTA, spaceAfter=2))]
    if subtitulo:
        story.append(Paragraph(_t(subtitulo), ParagraphStyle("sub", fontName=F, fontSize=10, leading=14, textColor=GRIS, spaceAfter=8)))
    for b in bloques:
        k = b[0]
        if k in ("kv", "lista") and not b[1]:
            continue
        if k == "tabla" and not b[2]:
            continue
        if k == "h":
            story.append(Paragraph(_t(b[1]), S["h"]))
        elif k == "p":
            story.append(Paragraph(_t(b[1]), S["p"]))
        elif k == "nota":
            story.append(Paragraph(_t(b[1]), S["nota"]))
        elif k == "lista":
            story.append(ListFlowable([ListItem(Paragraph(_t(x), S["p"]), leftIndent=10) for x in b[1]],
                                      bulletType="bullet", start="•", leftIndent=12, bulletFontName=F))
        elif k == "kv":
            filas = [[Paragraph(_t(a), S["celda"]), Paragraph(_t(v), S["celdab"])] for a, v in b[1]]
            t = Table(filas, colWidths=[ancho * 0.6, ancho * 0.4])
            t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.4, LINEA), ("TOPPADDING", (0, 0), (-1, -1), 4),
                                   ("BOTTOMPADDING", (0, 0), (-1, -1), 4), ("ALIGN", (1, 0), (1, -1), "RIGHT")]))
            story.append(t)
        elif k == "tabla":
            story.append(_tabla(b[1], b[2], b[3] if len(b) > 3 else None, ancho))
            story.append(Spacer(1, 4))
        elif k == "metricas":
            celdas = [[Paragraph(_t(v) + (f' <font size="9" color="#5B5872">{_t(u)}</font>' if u else ""), S["met_v"]),
                       Paragraph(_t(l), S["met_l"])] for l, v, u in b[1]]
            fila = [Table([[c[0]], [c[1]]], colWidths=[ancho / len(celdas) - 8]) for c in celdas]
            t = Table([fila], colWidths=[ancho / len(celdas)] * len(celdas))
            t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, LINEA), ("INNERGRID", (0, 0), (-1, -1), 0.6, LINEA),
                                   ("BACKGROUND", (0, 0), (-1, -1), SUAVE), ("TOPPADDING", (0, 0), (-1, -1), 8),
                                   ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
            story.append(KeepTogether([t, Spacer(1, 8)]))
        elif k == "aviso":
            t = Table([[Paragraph(_t(b[1]), S["p"])]], colWidths=[ancho])
            t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), AVISO), ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#EBCF7A")),
                                   ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                                   ("LEFTPADDING", (0, 0), (-1, -1), 8)]))
            story.append(Spacer(1, 4))
            story.append(t)
            story.append(Spacer(1, 4))
        elif k == "salto":
            story.append(PageBreak())
    doc.build(story, onFirstPage=marco, onLaterPages=marco)
    return buf.getvalue()


def nombre_archivo(texto):
    import re
    import unicodedata
    s = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode().lower()
    return (re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "documento")[:60] + ".pdf"
