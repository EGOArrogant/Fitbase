"""FitBase · plataforma de entrenamiento y nutrición basada en evidencia.

Ejecutar:  python app.py      (abre http://localhost:5000; en tu red: http://IP-DE-TU-PC:5000)
"""
import csv
import io
import json
import math
import re
import os
import secrets
import socket
import datetime as dt
from functools import wraps

from flask import (Flask, Response, abort, flash, g, jsonify, redirect, render_template, request, send_file, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import calc
import charts
from bodymap import SIN_ZONA, body_svg
from data.contenido import (ACTIVIDADES_MET, ALERTAS_CONDICION, CHECKLIST, CONDICIONES, EMERGENCIA, MITOS, PARQ,
                            PLANTILLAS, SMAE, SUPLEMENTOS)
from data.ejercicios import EJERCICIOS, EQUIPOS, GRUPOS, POR_SLUG, sustitutos
from data.musculos import MUSCULOS
from data.articulos import ARTICULOS, CATEGORIAS as CAT_ART, POR_SLUG as ART_POR_SLUG, enlace as art_enlace
from data.recetas import ING, POR_ID, RECETAS, TIPOS, macros_receta
import db
import dieta as dietamod
import asistente
import alimentos as alim
import seleccion as selmod
from data.animaciones import animacion as animacion_de
from data.equipo import NOMBRES as EQUIPO_NOMBRES, PERFILES_EQUIPO, icono as icono_equipo, ATRIBUTOS
import pdf as pdfmod
import antropometria as antro
import actualizador
import pagos as pagosmod
import notificaciones as notif
import guia as guiamod
import i18n
import registro_rapido as rr
import puntaje as pnt
import proporcionalidad as prop
import perfil_avanzado as pa
import retos as rt

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024  # videos de técnica


def _secret():
    path = os.path.join(BASE, ".secret_key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
    return open(path).read().strip()


app.secret_key = os.environ.get("FITAPP_SECRET") or _secret()
APP_NOMBRE = os.environ.get("FITAPP_NOMBRE", "FitBase")
DIAS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


# ------------------------------------------------------------------ utilidades
def get_db():
    if "db" not in g:
        g.db = db.conectar()
    return g.db


@app.teardown_appcontext
def _close(exc):
    con = g.pop("db", None)
    if con is not None:
        con.close()


ULTIMA_ACTIVIDAD = [0.0]


@app.before_request
def _cargar_usuario():
    if not request.path.startswith("/static/"):
        ULTIMA_ACTIVIDAD[0] = __import__("time").time()
    g.user = None
    uid = session.get("uid")
    if uid:
        row = get_db().execute("SELECT * FROM usuarios WHERE id=?", (uid,)).fetchone()
        if row and row["activo"] != 0:
            g.user = dict(row)
            ahora = dt.datetime.now()
            if not row["ultimo_acceso"] or row["ultimo_acceso"] < (ahora - dt.timedelta(seconds=60)).isoformat(timespec="seconds"):
                get_db().execute("UPDATE usuarios SET ultimo_acceso=? WHERE id=?", (ahora.isoformat(timespec="seconds"), uid))
                get_db().commit()


@app.context_processor
def _ctx():
    u = g.get("user")
    if u and u.get("perfil") and request.method == "GET":
        _avisos_del_dia(get_db(), u)
    lang = idioma_actual()
    return {"APP": APP_NOMBRE, "usuario": u, "hoy": dt.date.today(), "DIAS": DIAS, "plan_usuario": plan_de(u),
            "idioma": lang, "IDIOMAS": i18n.IDIOMAS, "html_lang": i18n.IDIOMAS[lang][1],
            "js_trad": {x: i18n.t(x, lang) for x in JS_TEXTOS} if lang != "es" else None,
            "notif_no_leidas": notif.no_leidas(get_db(), u["id"]) if u else 0,
            "guia_auto": bool(u and u.get("perfil") and not u.get("guia_vista") and request.endpoint == "dashboard"),
            "guia_pasos": guiamod.pasos(u, url_for, tr) if u and u.get("perfil") and (request.args.get("guia") or (not u.get("guia_vista") and request.endpoint == "dashboard")) else None,
            "sin_admin": request.endpoint in ("login", "inicio") and es_local() and not hay_admin(),
            "bienestar": bool(g.get("user") and perfil(g.user).get("bienestar"))}


@app.template_filter("n")
def _fmt_num(v, dec=0):
    if v is None or v == "":
        return "—"
    try:
        return f"{float(v):,.{dec}f}"
    except (TypeError, ValueError):
        return v


@app.template_filter("slug")
def _f_slug(v):
    from data.ejercicios import _slug
    return _slug(v)


@app.template_filter("pct")
def _fmt_pct(v, dec=0):
    return "—" if v is None else f"{v * 100:.{dec}f} %"


# ------------------------------------------------------------------ planes efectivos y límites
PLANES_CLAVE = {"gratis": "Gratis", "pro": "Pro", "coach15": "Coach 15", "coach40": "Coach 40", "coach100": "Coach 100",
                "coach": "Coach sin límite (cortesía)"}


def plan_de(u):
    """Plan efectivo: admin = todo; plan pagado/asignado vigente; entrenador sin pago = Coach Inicial (3 clientes);
    cliente de un entrenador = Pro incluido; si no, Gratis."""
    if not u:
        return {"clave": "gratis", "nombre": "Gratis", "motivo": "", "clientes": 0}
    if u.get("es_admin"):
        return {"clave": "admin", "nombre": "Administrador · todo desbloqueado", "motivo": "Cuenta de administrador", "clientes": None}
    asignado = u.get("plan") or "gratis"
    vigente = not u.get("plan_vence") or u["plan_vence"] >= str(dt.date.today())
    if asignado != "gratis" and asignado in PLANES_CLAVE and vigente:
        cat = pagosmod.CATALOGO.get(asignado, {})
        es_coach = asignado.startswith("coach")
        if not es_coach or u.get("rol") == "entrenador":
            return {"clave": asignado, "nombre": PLANES_CLAVE[asignado], "motivo": u.get("plan_nota") or "Asignado por el administrador",
                    "vence": u.get("plan_vence"), "clientes": cat.get("clientes") if es_coach else 0, "pagable": asignado in pagosmod.CATALOGO}
    if u.get("rol") == "entrenador":
        return {"clave": "coach_inicial", "nombre": "Coach Inicial", "motivo": f"Gratis hasta {pagosmod.COACH_GRATIS} clientes",
                "clientes": pagosmod.COACH_GRATIS}
    if u.get("coach_id"):
        return {"clave": "pro", "nombre": "Pro", "motivo": "Incluido por tu entrenador", "clientes": 0}
    return {"clave": "gratis", "nombre": "Gratis", "motivo": "", "clientes": 0}


def tiene_pro(u):
    return plan_de(u)["clave"] != "gratis"


def cupo_clientes(coach):
    """(puede_sumar, usados, limite) para un entrenador. limite None = sin límite."""
    coach = dict(coach)
    limite = plan_de(coach).get("clientes")
    usados = get_db().execute("SELECT COUNT(*) FROM usuarios WHERE coach_id=? AND activo=1", (coach["id"],)).fetchone()[0]
    return (limite is None or usados < limite), usados, limite


MSG_CUPO = "Tu entrenador ya alcanzó el máximo de clientes de su plan. Avísale para que amplíe su plan y vuelve a abrir el enlace."


def cobro_activo():
    return bool(pagosmod.leer_config().get("cobro_activo"))


def pro_required(f):
    """Funciones de automatización: abiertas mientras el cobro no esté activado por el administrador."""
    @wraps(f)
    def w(*a, **k):
        if g.user and cobro_activo() and not tiene_pro(g.user):
            if request.method == "POST":
                flash("Esta función es parte de Pro. Puedes activarlo desde $" + str(pagosmod.CATALOGO["pro"]["mensual"] // 100) + " al mes.", "info")
                return redirect(url_for("planes") + "#pro")
            return render_template("pro_requerido.html", funcion=request.endpoint), 402
        return f(*a, **k)
    return w


def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user:
            return redirect(url_for("login", siguiente=request.path))
        if not g.user.get("perfil") and request.endpoint not in ("evaluacion", "sondeo"):
            return redirect(url_for("sondeo"))
        return f(*a, **k)
    return w


def perfil(u):
    p = db.perfil_base()
    if u and u.get("perfil"):
        p.update(json.loads(u["perfil"]))
    for k in ("edad", "peso", "talla", "ritmo", "dias", "duracion", "comidas", "neat", "cardio_min", "cardio_ses", "cardio_met"):
        p[k] = calc.num(p.get(k), db.perfil_base()[k]) or 0
    p["dias"], p["comidas"] = int(p["dias"]), int(p["comidas"])
    return p


def programa(u):
    return json.loads(u["programa"]) if u.get("programa") else PLANTILLAS["torso-pierna-4"]


def guardar(u, campo, valor):
    get_db().execute(f"UPDATE usuarios SET {campo}=? WHERE id=?", (json.dumps(valor), u["id"]))
    get_db().commit()


def registros(uid, desde=None):
    q = "SELECT * FROM registros WHERE usuario_id=?" + (" AND fecha>=?" if desde else "") + " ORDER BY fecha"
    rows = get_db().execute(q, (uid, str(desde)) if desde else (uid,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["fecha"] = dt.date.fromisoformat(d["fecha"])
        d["etiquetas"] = json.loads(d["etiquetas"]) if d.get("etiquetas") else []
        out.append(d)
    return out


def series_de(uid, desde=None, ejercicio=None):
    q, args = "SELECT * FROM series WHERE usuario_id=?", [uid]
    if desde:
        q += " AND fecha>=?"; args.append(str(desde))
    if ejercicio:
        q += " AND ejercicio=?"; args.append(ejercicio)
    return [dict(r) for r in get_db().execute(q + " ORDER BY fecha, id", args).fetchall()]


def calcular(u):
    p = perfil(u)
    comp = calc.composicion(p)
    en = calc.energia(p, comp)
    aj = p.get("kcal_ajuste") or {}
    if p.get("auto_kcal") and aj.get("gasto"):
        en = calc.energia_ajustada(p, comp, en, aj["gasto"])
    mac = calc.macros(p, en, comp)
    return p, comp, en, mac


def progreso_fuerza(uid):
    """Por ejercicio: e1RM inicial (primera sesión), mejor e1RM, última sesión."""
    res = {}
    for s in series_de(uid):
        e = calc.e1rm(s["peso"], s["reps"], s["rir"])
        if e is None:
            continue
        r = res.setdefault(s["ejercicio"], {"ejercicio": s["ejercicio"], "primera_fecha": s["fecha"], "inicial": e, "mejor": e,
                                            "fecha_mejor": s["fecha"], "series": 0, "ultima": s, "historial": {}})
        if s["fecha"] == r["primera_fecha"]:
            r["inicial"] = max(r["inicial"], e)
        if e > r["mejor"]:
            r["mejor"], r["fecha_mejor"] = e, s["fecha"]
        r["series"] += 1
        r["ultima"] = s
        r["historial"][s["fecha"]] = max(r["historial"].get(s["fecha"], 0), e)
    for r in res.values():
        r["cambio"] = r["mejor"] / r["inicial"] - 1 if r["inicial"] else 0
    return res


def ajuste_semanal(u):
    """Pro: una vez por semana recalcula el gasto real con el peso y las calorías registradas. Devuelve (usuario, mensaje)."""
    p = perfil(u)
    if not p.get("auto_kcal"):
        return u, None
    hoy = dt.date.today()
    semana = f"{hoy.isocalendar()[0]}-{hoy.isocalendar()[1]:02d}"
    aj = p.get("kcal_ajuste") or {}
    if aj.get("semana") == semana:
        return u, None
    adapt = calc.get_adaptativo(registros(u["id"], hoy - dt.timedelta(days=42)))
    if not adapt:
        aj.update(semana=semana, falta=True)
        p["kcal_ajuste"] = aj
        guardar(u, "perfil", p)
        return (dict(get_db().execute("SELECT * FROM usuarios WHERE id=?", (u["id"],)).fetchone()),
                "Ajuste automático activo: necesitamos 14 días con peso y 10 con calorías registradas para calcular tu gasto real.")
    _, comp, en_antes, mac_antes = calcular(u)
    p["kcal_ajuste"] = {"semana": semana, "gasto": round(adapt), "fecha": str(hoy), "antes": mac_antes["kcal"]}
    guardar(u, "perfil", p)
    u2 = dict(get_db().execute("SELECT * FROM usuarios WHERE id=?", (u["id"],)).fetchone())
    nueva = calcular(u2)[3]["kcal"]
    msg = None
    if abs(nueva - mac_antes["kcal"]) >= 20:
        msg = f"Ajuste semanal: tus calorías pasan de {mac_antes['kcal']:,.0f} a {nueva:,.0f} kcal según tu peso real de las últimas semanas."
    return u2, msg


def resumen_usuario(u):
    """Todo lo que necesitan el dashboard y el panel del entrenador."""
    u, msg_ajuste = ajuste_semanal(u)
    p, comp, en, mac = calcular(u)
    hoy = dt.date.today()
    logs = registros(u["id"], hoy - dt.timedelta(days=90))
    ult28 = [l for l in logs if l["fecha"] >= hoy - dt.timedelta(days=27)]
    for l in logs:
        l["puntaje"] = calc.puntaje_dia(l, mac["kcal"], mac["prot"])
    pesos = [l["peso"] for l in logs]
    trend = calc.tendencia(pesos)
    pf = progreso_fuerza(u["id"])
    cambios = [r["cambio"] for r in pf.values() if r["series"] >= 4]
    cambio_e1rm = sum(cambios) / len(cambios) if cambios else None
    tr_val = [t for t in trend if t is not None]
    ritmo_real = None
    if len(tr_val) >= 2 and len(logs) >= 7:
        semanas = max((logs[-1]["fecha"] - logs[0]["fecha"]).days / 7, 1)
        ritmo_real = (tr_val[-1] / tr_val[0] - 1) / semanas
    signo = {"Perder grasa": -1, "Recomposición": -1, "Ganar músculo": 1}.get(p["objetivo"], 0)
    chk = json.loads(u["checklist"]) if u.get("checklist") else {}
    chk_pct = (sum(1 for v in chk.values() if v) / len(chk)) if chk else None
    score = calc.fitness_score(ult28, p["dias"], mac["kcal"], mac["prot"], cambio_e1rm, ritmo_real, signo * p["ritmo"] / 100, chk_pct)
    adapt = calc.get_adaptativo(logs)
    # alertas
    alertas = []
    if any(p.get("parq", [])):
        alertas.append(("riesgo", "PAR-Q+ con respuesta «Sí»: consultar a un médico antes de aumentar la intensidad."))
    for c in p.get("condiciones", []):
        if c in ALERTAS_CONDICION:
            alertas.append(("aviso", ALERTAS_CONDICION[c]))
    fcr, pas, pad = calc.num(p.get("fc_reposo")), calc.num(p.get("pas")), calc.num(p.get("pad"))
    if fcr and fcr > 100:
        alertas.append(("riesgo", f"Frecuencia cardiaca en reposo de {fcr:.0f} lpm (>100 = taquicardia en reposo): vuelve a medirla en calma y consulta a un médico antes de ejercicio intenso."))
    if (pas and pas >= 160) or (pad and pad >= 100):
        alertas.append(("riesgo", f"Presión arterial {pas or '—'}/{pad or '—'} mmHg: no inicies ejercicio intenso sin autorización médica (umbral orientativo; verificar con tu médico)."))
    elif (pas and pas >= 130) or (pad and pad >= 80):
        alertas.append(("aviso", f"Presión arterial {pas or '—'}/{pad or '—'} mmHg: elevada según AHA/ACC. El ejercicio aeróbico y de fuerza ayuda a reducirla; vigílala con tu médico."))
    if en["ea"] is not None and en["ea"] < 30:
        alertas.append(("riesgo", f"Disponibilidad energética de {en['ea']:.0f} kcal/kg de masa libre de grasa: por debajo de 30 (zona de riesgo según el COI 2023). Revisa calorías y carga de cardio."))
    if msg_ajuste:
        alertas.append(("info", msg_ajuste))
    if adapt and abs(adapt - en["gasto_total"]) > 150 and not p.get("auto_kcal"):
        alertas.append(("aviso", f"Tu gasto adaptativo ({adapt:,.0f} kcal) difiere {adapt - en['gasto_total']:+,.0f} kcal del estimado. Considera ajustar tus calorías."))
    vol = calc.volumen_programa(programa(u), p["nivel"])
    sin_directas = [f["grupo"] for f in vol["filas"] if f["directas"] == 0]
    if sin_directas:
        alertas.append(("info", "Músculos sin series directas en tu programa: " + ", ".join(sin_directas) + "."))
    sesiones = sum(1 for l in ult28 if l.get("entreno") == "Sí")
    plan = p["dias"] * max(1, len(ult28) / 7)
    adherencia = min(1, sesiones / plan) if ult28 else None
    # racha semanal (semanas completas con ≥75 % de sesiones; 1 comodín cada 4 semanas)
    racha, comodines, semana = 0, 1, hoy - dt.timedelta(days=hoy.weekday() + 7)
    while True:
        ses = sum(1 for l in logs if semana <= l["fecha"] < semana + dt.timedelta(days=7) and l.get("entreno") == "Sí")
        if ses >= max(1, round(p["dias"] * 0.75)):
            racha += 1
        elif comodines and racha:
            comodines -= 1
        else:
            break
        semana -= dt.timedelta(days=7)
        if semana < hoy - dt.timedelta(days=90):
            break
    return dict(p=p, comp=comp, en=en, mac=mac, logs=logs, trend=trend, pf=pf, score=score, adapt=adapt, alertas=alertas,
                adherencia=adherencia, sesiones=sesiones, ritmo_real=ritmo_real, cambio_e1rm=cambio_e1rm, vol=vol, racha=racha)


# ------------------------------------------------------------------ público
@app.route("/")
def inicio():
    from data.recetas import RECETAS as _R
    cifras = {"ejercicios": len(EJERCICIOS), "recetas": len(_R), "articulos": len(ARTICULOS), "alimentos": len(alim.ALIMENTOS)}
    return render_template("landing.html", PLANES=PLANES, cifras=cifras, publico_forzado=True)


def _bienvenida(con, uid, rol, coach_id, nombre, via="con tu código"):
    notif.avisar(con, uid, "guia", f"¡Bienvenido a {APP_NOMBRE}!", "Te mostramos cada apartado en un recorrido corto. Puedes repetirlo cuando quieras desde «Guía de uso».",
                 url_for("guia"))
    if rol == "entrenador":
        notif.avisar(con, uid, "cliente", "Invita a tus primeros clientes", "Comparte tu enlace o tu código y verás aquí todo lo que registren.",
                     url_for("coach_invitar"))
    if coach_id:
        notif.avisar(con, coach_id, "cliente", f"{nombre} se unió como tu cliente", f"Se registró {via}.", url_for("coach_cliente", cid=uid), uid)
        con.execute("INSERT INTO actividad (actor_id, coach_id, tipo, texto, url, detalle, creado) VALUES (?,?,?,?,?,?,?)",
                    (uid, coach_id, "cliente", "se unió como tu cliente", url_for("coach_cliente", cid=uid), "[]", notif.ahora()))


@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        f = request.form
        email, nombre, pw = f.get("email", "").strip().lower(), f.get("nombre", "").strip(), f.get("password", "")
        if not email or not nombre or len(pw) < 8:
            flash("Completa nombre, correo y una contraseña de al menos 8 caracteres.", "error")
            return render_template("auth.html", modo="registro")
        con = get_db()
        if con.execute("SELECT 1 FROM usuarios WHERE email=?", (email,)).fetchone():
            flash("Ese correo ya está registrado.", "error")
            return render_template("auth.html", modo="registro")
        coach_id = None
        codigo = f.get("codigo", "").strip().upper()
        if codigo:
            c = con.execute("SELECT * FROM usuarios WHERE codigo_coach=? AND rol='entrenador'", (codigo,)).fetchone()
            if not c:
                flash("Código de entrenador no válido.", "error")
                return render_template("auth.html", modo="registro")
            coach_id = c["id"]
            if not cupo_clientes(c)[0]:
                flash(MSG_CUPO, "error")
                return render_template("auth.html", modo="registro")
        if not f.get("consentimiento"):
            flash("Para usar la plataforma necesitamos tu consentimiento expreso para tratar datos de salud (LFPDPPP).", "error")
            return render_template("auth.html", modo="registro")
        rol = "entrenador" if f.get("rol") == "entrenador" else "cliente"
        uid = db.crear_usuario(con, email, nombre, pw, rol=rol, coach_id=coach_id)
        con.execute("UPDATE usuarios SET perfil=NULL WHERE id=?", (uid,))
        _bienvenida(con, uid, rol, coach_id, nombre)
        con.commit()
        session["uid"] = uid
        return redirect(url_for("sondeo"))
    return render_template("auth.html", modo="registro")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = get_db().execute("SELECT * FROM usuarios WHERE email=?", (request.form.get("email", "").strip().lower(),)).fetchone()
        if u and check_password_hash(u["password"], request.form.get("password", "")):
            if "activo" in u.keys() and u["activo"] == 0:
                flash("Esta cuenta está desactivada. Contacta al administrador.", "error")
                return render_template("auth.html", modo="login")
            session["uid"] = u["id"]
            sig = request.args.get("siguiente")
            return redirect(sig if sig and sig.startswith("/") else url_for("dashboard"))
        flash("Correo o contraseña incorrectos.", "error")
    return render_template("auth.html", modo="login")


@app.route("/demo")
def demo():
    u = get_db().execute("SELECT id FROM usuarios WHERE email=?", ("coach@fitapp.local" if request.args.get("rol") == "entrenador" else "demo@fitapp.local",)).fetchone()
    session["uid"] = u["id"]
    return redirect(url_for("coach" if request.args.get("rol") == "entrenador" else "dashboard"))


@app.route("/salir")
def salir():
    session.clear()
    return redirect(url_for("inicio"))


# ------------------------------------------------------------------ evaluación
@app.route("/evaluacion", methods=["GET", "POST"])
def evaluacion():
    if not g.user:
        return redirect(url_for("login"))
    p = perfil(g.user)
    if request.method == "POST":
        f = request.form
        for k in ("sexo", "nivel", "objetivo", "actividad", "ecuacion", "equipo"):
            p[k] = f.get(k, p.get(k))
        for k in ("edad", "peso", "talla", "ritmo", "dias", "duracion", "comidas", "cuello", "cintura", "cadera", "grasa_medida", "cardio_min", "cardio_ses", "fc_reposo", "pas", "pad"):
            p[k] = calc.num(f.get(k))
        p["neat"] = (calc.num(f.get("neat"), 15) or 15) / 100
        p["parq"] = [f.get(f"parq{i}") == "si" for i in range(len(PARQ))]
        p["condiciones"] = f.getlist("condiciones")
        p["preferencias"] = f.getlist("preferencias")
        if not g.user.get("perfil"):
            p["inicio"] = str(dt.date.today())
        if not all([p["edad"], p["peso"], p["talla"]]):
            flash("Edad, peso y estatura son obligatorios.", "error")
        else:
            guardar(g.user, "perfil", p)
            if f.get("plantilla") in PLANTILLAS:
                guardar(g.user, "programa", PLANTILLAS[f["plantilla"]])
            flash("Evaluación guardada. Tu plan se recalculó.", "ok")
            return redirect(url_for("dashboard"))
    comp = calc.composicion(p) if p.get("peso") and p.get("talla") else None
    en = calc.energia(p, comp) if comp else None
    return render_template("evaluacion.html", p=p, PARQ=PARQ, CONDICIONES=CONDICIONES, PLANTILLAS=PLANTILLAS, comp=comp, en=en,
                           nuevo=not g.user.get("perfil"), EQUIPOS=["Gimnasio completo", "Casa con mancuernas", "Solo peso corporal"])


# ------------------------------------------------------------------ sondeo inicial y plan inteligente
EXPERIENCIA = [("nunca", "Nunca he entrenado con pesas", "Principiante"), ("menos6", "Menos de 6 meses", "Principiante"),
               ("6a24", "Entre 6 meses y 2 años", "Intermedio"), ("mas2", "Más de 2 años constante", "Avanzado")]
DOLORES = [("rodilla", "Rodilla"), ("espalda", "Espalda baja"), ("hombro", "Hombro"), ("cadera", "Cadera")]
CARDIO_GUSTO = ["Caminar", "Bicicleta", "Nadar", "Elíptica", "Correr", "Clases o baile", "Deportes de equipo"]


@app.route("/sondeo", methods=["GET", "POST"])
def sondeo():
    if not g.user:
        return redirect(url_for("login"))
    p = perfil(g.user) if g.user.get("perfil") else db.perfil_base(inicio=str(dt.date.today()))
    s = dict(p.get("sondeo") or {})
    if request.method == "POST":
        f = request.form
        for k in ("edad", "peso", "talla"):
            p[k] = calc.num(f.get(k))
        p["sexo"] = "Mujer" if f.get("sexo") == "Mujer" else "Hombre"
        exp = f.get("experiencia", "nunca")
        p["nivel"] = next((n for k, _, n in EXPERIENCIA if k == exp), "Principiante")
        p["objetivo"] = f.get("objetivo") if f.get("objetivo") in ("Perder grasa", "Mantener", "Recomposición", "Ganar músculo") else "Mantener"
        p["dias"] = int(calc.num(f.get("dias"), 3) or 3)
        p["duracion"] = int(calc.num(f.get("duracion"), 45) or 45)
        p["condiciones"] = f.getlist("condiciones")
        s.update(experiencia=exp, dolor=f.getlist("dolor"), suelo=f.get("suelo", "si"), camina10=f.get("camina10", "si"),
                 equipo=[e for e in f.getlist("eq") if e in EQUIPO_NOMBRES] or sorted(PERFILES_EQUIPO["Gimnasio completo"]),
                 gusto=f.getlist("gusto"), lugar=f.get("lugar", "Gimnasio completo"))
        p["equipo"] = s["lugar"] if s["lugar"] in PERFILES_EQUIPO else "Gimnasio completo"
        p["sondeo"] = s
        if not all([p["edad"], p["peso"], p["talla"]]):
            flash("Edad, peso y estatura son obligatorios.", "error")
        else:
            nuevo = not g.user.get("perfil")
            guardar(g.user, "perfil", p)
            if nuevo:
                guardar(g.user, "programa", PLANTILLAS["full-body-3"] if p["nivel"] == "Principiante" else PLANTILLAS["torso-pierna-4"])
            flash("¡Listo! Armamos tu plan con base en tus respuestas. Si ya entrenas, haz el sondeo avanzado (tus pesos, tiempo en el gym y fotos) para afinarlo aún más.", "ok")
            return redirect(url_for("plan_inteligente"))
    return render_template("sondeo.html", p=p, s=s, EXPERIENCIA=EXPERIENCIA, DOLORES=DOLORES, CONDICIONES=CONDICIONES,
                           EQ_NOMBRES=EQUIPO_NOMBRES, icono=icono_equipo, PERFILES_EQUIPO={k: sorted(v) for k, v in PERFILES_EQUIPO.items()},
                           CARDIO_GUSTO=CARDIO_GUSTO, nuevo=not g.user.get("perfil"))


def datos_plan_inteligente(p):
    ev = selmod.evaluar(p)
    equipo = selmod.equipo_disponible(p)
    por_grupo, evitados = {}, []
    for e in EJERCICIOS.values():
        if e["tipo"] not in ("Compuesto", "Aislamiento"):
            continue
        ok, motivo = selmod.permitido(e["nombre"], ev)
        if e["equipo"] not in equipo:
            continue
        if ok:
            por_grupo.setdefault(e["grupo"], []).append(e)
        else:
            evitados.append((e, motivo))
    for gname, lst in por_grupo.items():
        orden_eq = {"Barra": 0, "Mancuernas": 1, "Máquina": 2, "Polea": 3, "Máquina Smith": 4, "Peso corporal": 5}
        lst.sort(key=lambda e: (not ATRIBUTOS[e["nombre"]]["guiado"] if "guiado" in ev["prefer"] else False,
                                PREFERIDOS.get(e["targets"][0], []).index(e["nombre"]) if e["nombre"] in PREFERIDOS.get(e["targets"][0], []) else 99,
                                e["tipo"] != "Compuesto", orden_eq.get(e["equipo"], 9), e["nombre"]))
    movilidad = [e for e in EJERCICIOS.values() if e["tipo"] == "Movilidad" and e["equipo"] in equipo and selmod.permitido(e["nombre"], ev)[0]][:6]
    return dict(p=p, ev=ev, por_grupo=por_grupo, evitados=evitados, movilidad=movilidad, equipo=sorted(equipo), imc=ev["imc"])


@app.route("/mi-plan")
@login_required
def plan_inteligente():
    return render_template("plan_inteligente.html", GRUPOS=GRUPOS + ["Otros"], icono=icono_equipo, **datos_plan_inteligente(perfil(g.user)))


# ------------------------------------------------------------------ dashboard
def calendario_mes(logs, anio, mes):
    primero = dt.date(anio, mes, 1)
    sig = dt.date(anio + (mes == 12), mes % 12 + 1, 1)
    por_fecha = {l["fecha"]: l for l in logs}
    semanas, semana = [], [None] * primero.weekday()
    d = primero
    while d < sig:
        l = por_fecha.get(d)
        semana.append({"fecha": d, "puntaje": l.get("puntaje") if l else None, "entreno": l.get("entreno") if l else None, "hoy": d == dt.date.today()})
        if len(semana) == 7:
            semanas.append(semana); semana = []
        d += dt.timedelta(days=1)
    if semana:
        semanas.append(semana + [None] * (7 - len(semana)))
    filas = []
    for s in semanas:
        vals = [c["puntaje"] for c in s if c and c["puntaje"] is not None]
        filas.append({"dias": s, "prom": round(sum(vals) / len(vals)) if vals else None, "n": len(vals)})
    return filas


@app.route("/app")
@login_required
def dashboard():
    r = resumen_usuario(g.user)
    hoy = dt.date.today()
    anio, mes = int(request.args.get("a", hoy.year)), int(request.args.get("m", hoy.month))
    cal = calendario_mes(r["logs"], anio, mes)
    por_fecha = {l["fecha"]: l for l in r["logs"]}
    for f in cal:
        for c in f["dias"]:
            if c:
                l = por_fecha.get(c["fecha"], {})
                c["kcal"], c["prot"] = l.get("kcal"), l.get("proteina")
    vals_mes = [c["puntaje"] for f in cal for c in f["dias"] if c and c["puntaje"] is not None]
    prev = (dt.date(anio, mes, 1) - dt.timedelta(days=1))
    nxt = (dt.date(anio, mes, 28) + dt.timedelta(days=5))
    ult28 = [l for l in r["logs"] if l["fecha"] >= hoy - dt.timedelta(days=27)]
    ok = sum(1 for l in ult28 if l.get("entreno") == "Sí")
    desc = sum(1 for l in ult28 if l.get("entreno") == "Descanso")
    falta = sum(1 for l in ult28 if l.get("entreno") == "No")
    kc_dias = [l for l in ult28 if l.get("kcal")]
    en_rango = sum(1 for l in kc_dias if abs(l["kcal"] - r["mac"]["kcal"]) <= r["mac"]["kcal"] * 0.1)
    kc_prom = sum(l["kcal"] for l in kc_dias) / len(kc_dias) if kc_dias else None
    # tonelaje acumulado
    ser = series_de(g.user["id"], desde=hoy - dt.timedelta(days=90))
    ton = {}
    for s in ser:
        ton[s["fecha"]] = ton.get(s["fecha"], 0) + (s["peso"] or 0) * s["reps"]
    fechas = sorted(ton)
    acum, t = [], 0
    for f in fechas:
        t += ton[f]; acum.append(t)
    graf_acum = charts.area(acum, [f[8:10] + "/" + f[5:7] for f in fechas], titulo="Tonelaje acumulado (kg)")
    # sesiones recientes
    prog = programa(g.user)
    recientes = []
    for f in reversed(fechas[-6:]):
        ss = [s for s in ser if s["fecha"] == f]
        fd = dt.date.fromisoformat(f)
        nombre = next((d["nombre"] for d in prog["dias"] if d["dia"] == fd.weekday()), "Sesión libre")
        top = max(ss, key=lambda s: calc.e1rm(s["peso"], s["reps"], s["rir"]) or 0)
        recientes.append({"fecha": f, "nombre": nombre, "series": len(ss), "ton": ton[f], "ej": len({s["ejercicio"] for s in ss}),
                          "top": top["ejercicio"], "e1rm": calc.e1rm(top["peso"], top["reps"], top["rir"])})
    rep = r["logs"][-14:]
    graf_rep = charts.barras([l["puntaje"] or 0 for l in rep], [f"{l['fecha'].day}" for l in rep], alto=150, titulo="Puntaje diario",
                             clases=["bar" if (l["puntaje"] or 0) >= 50 else "bar2" for l in rep])
    dia_hoy = next((i for i, d in enumerate(prog["dias"]) if d["dia"] == hoy.weekday()), None)
    comentarios = get_db().execute("SELECT c.*, u.nombre FROM comentarios c JOIN usuarios u ON u.id=c.autor_id WHERE usuario_id=? ORDER BY c.id DESC LIMIT 3", (g.user["id"],)).fetchall()
    chk = json.loads(g.user["checklist"]) if g.user.get("checklist") else {}
    total_chk = sum(len(i) for _, i in CHECKLIST)
    ultimo = r["logs"][-1]["fecha"] if r["logs"] else None
    return render_template("dashboard.html", avz=datos_avanzado(r["p"]), modo_app=pa.modo(r["p"]), r=r, cal=cal, mes_nombre=f"{MESES[mes - 1].capitalize()} {anio}",
                           prom_mes=round(sum(vals_mes) / len(vals_mes)) if vals_mes else None, dias_mes=len(vals_mes),
                           prev=prev, nxt=nxt, radar=charts.radar(r["score"]["componentes"]), graf_acum=graf_acum, graf_rep=graf_rep,
                           ok=ok, desc=desc, falta=falta, en_rango=en_rango, fuera=len(kc_dias) - en_rango, kc_prom=kc_prom,
                           anillo=charts.anillo(r["adherencia"] or 0), medidor=charts.medidor(ok, desc, falta),
                           recientes=recientes, prog=prog, dia_hoy=dia_hoy, comentarios=comentarios,
                           chk_hechos=sum(1 for v in chk.values() if v), total_chk=total_chk, ultimo=ultimo, sesiones90=len(fechas))


# ------------------------------------------------------------------ asistente
@app.route("/asistente")
@login_required
def asistente_view():
    return render_template("asistente.html", ia=asistente.hay_credenciales(), q=request.args.get("q", ""))


@app.route("/api/asistente", methods=["POST"])
@login_required
def asistente_api():
    data = request.get_json(silent=True) or {}
    hist = [m for m in data.get("mensajes", []) if m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str) and m["content"].strip()][-12:]
    if not hist or hist[-1]["role"] != "user":
        return jsonify({"error": "Falta la pregunta."}), 400
    for m in hist:
        m["content"] = m["content"][:4000]
    while hist and hist[0]["role"] != "user":
        hist.pop(0)
    r = resumen_usuario(g.user)
    texto, modo = None, "basico"
    if asistente.hay_credenciales():
        texto, modo = asistente.responder_ia(hist, asistente.contexto_cliente(r, programa(g.user), g.user["nombre"]), APP_NOMBRE)
    if texto is None:
        aviso = {"auth": "(La clave de la API de Claude no es válida; respondo en modo básico.)\n\n",
                 "sin_conexion": "(No hay conexión con la IA; respondo en modo básico.)\n\n"}.get(modo, "")
        texto, modo = aviso + asistente.responder_basico(hist[-1]["content"], r), "basico"
    return jsonify({"respuesta": texto, "modo": modo})


# ------------------------------------------------------------------ programa
@app.route("/programa", methods=["GET", "POST"])
@login_required
def programa_view():
    prog, p = programa(g.user), perfil(g.user)
    if request.method == "POST":
        a = request.form.get("accion")
        if a == "plantilla" and request.form.get("plantilla") in PLANTILLAS:
            prog = PLANTILLAS[request.form["plantilla"]]
            flash(f"Programa cambiado a «{prog['nombre']}».", "ok")
        elif a == "agregar":
            i = int(request.form["dia"])
            ex = request.form.get("ejercicio")
            if ex in EJERCICIOS:
                prog["dias"][i]["ejercicios"].append({"ex": ex, "series": int(request.form.get("series", 3)), "rmin": int(request.form.get("rmin", 8)),
                                                     "rmax": int(request.form.get("rmax", 12)), "rir": int(request.form.get("rir", 2)),
                                                     "descanso": int(request.form.get("descanso", 120))})
        elif a == "eliminar":
            i, j = int(request.form["dia"]), int(request.form["idx"])
            prog["dias"][i]["ejercicios"].pop(j)
        elif a == "sustituir":
            i, j = int(request.form["dia"]), int(request.form["idx"])
            if request.form.get("nuevo") in EJERCICIOS:
                prog["dias"][i]["ejercicios"][j]["ex"] = request.form["nuevo"]
        elif a == "actualizar":
            for i, d in enumerate(prog["dias"]):
                d["nombre"] = request.form.get(f"n{i}", d["nombre"])
                d["dia"] = int(request.form.get(f"w{i}", d["dia"]))
                for j, e in enumerate(d["ejercicios"]):
                    for k in ("series", "rmin", "rmax", "rir", "descanso"):
                        v = request.form.get(f"d{i}e{j}{k}")
                        if v not in (None, ""):
                            e[k] = int(float(v))
            flash("Programa actualizado.", "ok")
        elif a == "nuevo_dia":
            prog["dias"].append({"nombre": f"Día {len(prog['dias']) + 1}", "dia": 5, "ejercicios": []})
        elif a == "borrar_dia":
            prog["dias"].pop(int(request.form["dia"]))
        prog["nombre"] = request.form.get("nombre_programa", prog.get("nombre"))
        guardar(g.user, "programa", prog)
        return redirect(url_for("programa_view") + (f"#dia{request.form.get('dia')}" if request.form.get("dia") else ""))
    vol = calc.volumen_programa(prog, p["nivel"])
    for d in prog["dias"]:
        d["duracion"] = calc.duracion_sesion(d)
        d["series_total"] = sum(e["series"] for e in d["ejercicios"])
    pref_equipo = {"Casa con mancuernas": {"Mancuernas", "Peso corporal"}, "Solo peso corporal": {"Peso corporal"}}.get(p.get("equipo"))
    return render_template("programa.html", prog=prog, vol=vol, PLANTILLAS=PLANTILLAS, EJERCICIOS=EJERCICIOS, GRUPOS=GRUPOS,
                           sustitutos=sustitutos, pref_equipo=pref_equipo, p=p)


# ------------------------------------------------------------------ sesión
def datos_sesion(prog, fecha, fobj, di):
    if di not in (None, ""):
        di = int(di)
    else:
        di = next((i for i, d in enumerate(prog["dias"]) if d["dia"] == fobj.weekday()), 0)
    dia = prog["dias"][di] if prog["dias"] else {"nombre": "Libre", "ejercicios": []}
    hoy_series = series_de(g.user["id"], desde=fobj)
    hoy_series = [s for s in hoy_series if s["fecha"] == fecha]
    planes = []
    des = descarga_estado(g.user)
    for e in dia["ejercicios"]:
        if des.get("activa"):   # semana de descarga: mitad de series y 2 repeticiones más en reserva
            e = dict(e, series=max(1, round(e["series"] * 0.5)), rir=min(5, (e.get("rir") or 0) + 2))
        info = EJERCICIOS.get(e["ex"], {})
        previas = [s for s in series_de(g.user["id"], ejercicio=e["ex"]) if s["fecha"] < fecha]
        ultima_fecha = previas[-1]["fecha"] if previas else None
        ult = [s for s in previas if s["fecha"] == ultima_fecha]
        sug = None
        if ult:
            top = max(ult, key=lambda s: (s["peso"], s["reps"]))
            todas_tope = all(s["reps"] >= e["rmax"] and (s["rir"] is None or s["rir"] >= e["rir"]) for s in ult)
            if todas_tope:
                sug = ("subir", f"Llegaste al tope del rango con el RIR objetivo: sube a {max(top['peso'] + 1, round(top['peso'] * (1 + info.get('incremento', 0.025)) * 2) / 2):g} kg.")
            else:
                sug = calc.sugerencia(top["peso"], min(s["reps"] for s in ult), top["rir"], e["rmin"], e["rmax"], e["rir"], info.get("incremento", 0.025))
        if not ult:
            kg = pa.carga_inicial(perfil(g.user), e["ex"], e["rmin"], e["rmax"], e["rir"])
            if kg:
                sug = ("info", f"Primera vez en la app: empieza con ~{kg:g} kg (calculado con tus marcas del sondeo avanzado) y ajusta según el RIR.")
        if des.get("activa") and ult:
            top = max(ult, key=lambda s: (s["peso"], s["reps"]))
            sug = ("info", f"Semana de descarga: usa ~{round(top['peso'] * 0.9 / 2.5) * 2.5:g} kg (90 % de tu última carga), {e['series']} series, sin llegar al fallo.")
        hechas = [s for s in hoy_series if s["ejercicio"] == e["ex"]]
        planes.append({"e": e, "info": info, "ultima": ult, "ultima_fecha": ultima_fecha, "sug": sug, "hechas": hechas,
                       "calent": calc.calentamiento(max((s["peso"] for s in ult), default=0)) if info.get("tipo") == "Compuesto" and ult else None})
    for s in hoy_series:
        s["e1rm"] = calc.e1rm(s["peso"], s["reps"], s["rir"])
    tonelaje = sum((s["peso"] or 0) * s["reps"] for s in hoy_series)
    return dict(prog=prog, dia=dia, di=di, fecha=fecha, fobj=fobj, planes=planes, hoy_series=hoy_series, tonelaje=tonelaje, descarga=des)


@app.route("/sesion", methods=["GET", "POST"])
@login_required
def sesion_view():
    prog = programa(g.user)
    fecha = request.values.get("fecha") or str(dt.date.today())
    try:
        fobj = dt.date.fromisoformat(fecha)
    except ValueError:
        fobj = dt.date.today(); fecha = str(fobj)
    con = get_db()
    if request.method == "POST":
        if request.form.get("accion") == "borrar":
            con.execute("DELETE FROM series WHERE id=? AND usuario_id=?", (request.form["id"], g.user["id"]))
        else:
            ex = request.form.get("ejercicio")
            peso, reps = calc.num(request.form.get("peso")), calc.num(request.form.get("reps"))
            if ex in EJERCICIOS and reps:
                n = con.execute("SELECT COUNT(*) FROM series WHERE usuario_id=? AND fecha=? AND ejercicio=?", (g.user["id"], fecha, ex)).fetchone()[0]
                con.execute("INSERT INTO series (usuario_id, fecha, ejercicio, serie, peso, reps, rir, nota) VALUES (?,?,?,?,?,?,?,?)",
                            (g.user["id"], fecha, ex, n + 1, peso or 0, int(reps), calc.num(request.form.get("rir")), request.form.get("nota") or None))
                r = con.execute("SELECT entreno FROM registros WHERE usuario_id=? AND fecha=?", (g.user["id"], fecha)).fetchone()
                if not r:
                    con.execute("INSERT INTO registros (usuario_id, fecha, entreno) VALUES (?,?,?)", (g.user["id"], fecha, "Sí"))
                elif r["entreno"] != "Sí":
                    con.execute("UPDATE registros SET entreno='Sí' WHERE usuario_id=? AND fecha=?", (g.user["id"], fecha))
            else:
                flash("Elige un ejercicio y escribe las repeticiones.", "error")
        con.commit()
        return redirect(url_for("sesion_view", fecha=fecha, dia=request.form.get("dia", "")) + "#registro")
    return render_template("sesion.html", EJERCICIOS=EJERCICIOS, **datos_sesion(prog, fecha, fobj, request.args.get("dia")))


# ------------------------------------------------------------------ hábitos / registro diario
@app.route("/habitos", methods=["GET", "POST"])
@login_required
def habitos():
    con = get_db()
    fecha = request.values.get("fecha") or str(dt.date.today())
    if request.method == "POST":
        if request.form.get("accion") == "checklist":
            chk = {item: bool(request.form.get(f"c{i}-{j}")) for i, (_, items) in enumerate(CHECKLIST) for j, item in enumerate(items)}
            guardar(g.user, "checklist", chk)
            flash("Checklist guardado.", "ok")
        else:
            f = request.form
            con.execute("INSERT OR REPLACE INTO registros (usuario_id, fecha, peso, kcal, proteina, pasos, sueno, entreno, energia, cintura, notas, etiquetas) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        (g.user["id"], fecha, calc.num(f.get("peso")), calc.num(f.get("kcal")), calc.num(f.get("proteina")),
                         calc.num(f.get("pasos")), calc.num(f.get("sueno")), f.get("entreno") or None, calc.num(f.get("energia")),
                         calc.num(f.get("cintura")), f.get("notas") or None, json.dumps(f.getlist("etiquetas"))))
            con.commit()
            flash("Registro del día guardado.", "ok")
        return redirect(url_for("habitos", fecha=fecha))
    r = resumen_usuario(g.user)
    actual = next((l for l in r["logs"] if str(l["fecha"]) == fecha), {})
    chk = json.loads(g.user["checklist"]) if g.user.get("checklist") else {}
    return render_template("habitos.html", r=r, fecha=fecha, actual=actual, CHECKLIST=CHECKLIST, chk=chk,
                           ETIQUETAS=["Dormí poco", "Comí fuera", "Estrés alto", "Entrené en ayunas", "Buena técnica", "Récord personal", "Dolor o molestia", "Ciclo menstrual (contexto)"])


# ------------------------------------------------------------------ progreso
@app.route("/progreso")
@login_required
def progreso():
    r = resumen_usuario(g.user)
    logs = r["logs"]
    graf_peso = charts.linea([("Peso diario", [l["peso"] for l in logs], "s2", True), ("Tendencia", r["trend"], "s1", False)],
                             [f"{l['fecha'].day}/{l['fecha'].month}" for l in logs], titulo="Peso y tendencia")
    # semanas
    semanas = []
    if logs:
        ini = logs[0]["fecha"] - dt.timedelta(days=logs[0]["fecha"].weekday())
        while ini <= dt.date.today():
            sem = [(l, t) for l, t in zip(logs, r["trend"]) if ini <= l["fecha"] < ini + dt.timedelta(days=7)]
            if sem:
                pesos = [l["peso"] for l, _ in sem if l["peso"]]
                kcs = [l["kcal"] for l, _ in sem if l["kcal"]]
                tr = [t for _, t in sem if t is not None]
                semanas.append({"inicio": ini, "peso": sum(pesos) / len(pesos) if pesos else None, "tendencia": tr[-1] if tr else None,
                                "kcal": sum(kcs) / len(kcs) if kcs else None, "sesiones": sum(1 for l, _ in sem if l.get("entreno") == "Sí"),
                                "sueno": (lambda v: sum(v) / len(v) if v else None)([l["sueno"] for l, _ in sem if l["sueno"]])})
            ini += dt.timedelta(days=7)
    for i, s in enumerate(semanas):
        prev = semanas[i - 1]["tendencia"] if i else None
        s["cambio"] = (s["tendencia"] / prev - 1) if prev and s["tendencia"] else None
        s["gasto"] = (s["kcal"] - (s["tendencia"] - prev) * 7700 / 7) if prev and s["kcal"] and s["tendencia"] else None
    # tonelaje semanal
    ser = series_de(g.user["id"])
    ton = {}
    for s in ser:
        f = dt.date.fromisoformat(s["fecha"]); k = f - dt.timedelta(days=f.weekday())
        ton[k] = ton.get(k, 0) + (s["peso"] or 0) * s["reps"]
    tk = sorted(ton)
    graf_ton = charts.barras([ton[k] for k in tk], [f"{k.day}/{k.month}" for k in tk], titulo="Tonelaje semanal (kg)")
    pf = sorted(r["pf"].values(), key=lambda x: -x["series"])
    ej = request.args.get("ej") or (pf[0]["ejercicio"] if pf else None)
    graf_e1rm = ""
    if ej and ej in r["pf"]:
        h = r["pf"][ej]["historial"]
        fechas = sorted(h)
        graf_e1rm = charts.linea([("e1RM", [h[f] for f in fechas], "s1", False)], [f[8:10] + "/" + f[5:7] for f in fechas], titulo=f"e1RM {ej}")
    etiquetas = {}
    for l in logs:
        for t in l["etiquetas"]:
            etiquetas.setdefault(t, []).append(l.get("puntaje"))
    etq = sorted(((t, len(v), round(sum(x for x in v if x is not None) / max(1, len([x for x in v if x is not None])))) for t, v in etiquetas.items()), key=lambda x: -x[1])
    return render_template("progreso.html", r=r, graf_peso=graf_peso, semanas=semanas, graf_ton=graf_ton, pf=pf, ej=ej,
                           graf_e1rm=graf_e1rm, etq=etq)


# ------------------------------------------------------------------ nutrición y recetas
REPARTO = {3: [("desayuno", .3), ("comida", .4), ("cena", .3)],
           4: [("desayuno", .25), ("comida", .35), ("colacion", .15), ("cena", .25)],
           5: [("desayuno", .25), ("colacion", .1), ("comida", .3), ("postentreno", .12), ("cena", .23)],
           6: [("desayuno", .2), ("colacion", .1), ("comida", .3), ("colacion", .1), ("postentreno", .1), ("cena", .2)]}


def reparto(n):
    return REPARTO.get(max(3, min(6, n)), REPARTO[4])


def escalar(rec, kcal_obj):
    f = max(0.5, min(2.5, kcal_obj / max(rec["base"]["kcal"], 1)))
    f = round(f * 4) / 4
    return f, macros_receta(rec, f), [(n, round(gr * f)) for n, gr in rec["ing"]]


def recetas_propias(u):
    """Recetas creadas por el usuario o por su entrenador (mismo formato que las integradas)."""
    if not u:
        return []
    ids = [u["id"]] + ([u["coach_id"]] if u.get("coach_id") else [])
    rows = get_db().execute(f"SELECT r.*, us.nombre AS autor FROM recetas_usuario r JOIN usuarios us ON us.id=r.autor_id WHERE autor_id IN ({','.join('?' * len(ids))})", ids).fetchall()
    out = []
    for r in rows:
        rec = {"id": f"u{r['id']}", "nombre": r["nombre"], "tipo": r["tipo"], "minutos": r["minutos"] or 0,
               "tags": json.loads(r["tags"] or "[]") + ["propia"], "ing": [tuple(x) for x in json.loads(r["ing"])],
               "pasos": [x for x in (r["pasos"] or "").split("\n") if x.strip()], "autor": r["autor"], "autor_id": r["autor_id"], "db_id": r["id"]}
        rec["base"] = macros_receta(rec)
        rec["densidad_prot"] = round(rec["base"]["prot"] / max(rec["base"]["kcal"], 1) * 100, 1)
        out.append(rec)
    return out


def todas_recetas(u=None):
    return RECETAS + recetas_propias(u or g.get("user"))


def buscar_receta(rid):
    return POR_ID.get(rid) or next((r for r in recetas_propias(g.get("user")) if r["id"] == rid), None)


def candidatas(tipo, prefs, objetivo):
    tipos = {"colacion": ["colacion"], "postentreno": ["postentreno", "colacion"], "desayuno": ["desayuno"], "comida": ["comida"], "cena": ["cena", "comida"]}[tipo]
    rs = [r for r in todas_recetas() if r["tipo"] in tipos]
    if "vegetariana" in prefs:
        rs = [r for r in rs if "vegetariana" in r["tags"] or "vegana" in r["tags"]] or rs
    if "vegana" in prefs:
        rs = [r for r in rs if "vegana" in r["tags"]] or rs
    clave = (lambda r: -r["densidad_prot"]) if objetivo in ("Perder grasa", "Recomposición") else (lambda r: -r["base"]["prot"])
    return sorted(rs, key=clave)


def datos_nutricion(u):
    p, comp, en, mac = calcular(u)
    d = dietamod.normalizar(json.loads(u["smae"]) if u.get("smae") else None)
    an = dietamod.analizar(d, metas_de(d, mac))
    slots = [(t, s, round(mac["kcal"] * s)) for t, s in reparto(p["comidas"])]
    sugerencias = []
    for tipo, share, kc in slots:
        c = candidatas(tipo, p.get("preferencias", []), p["objetivo"])[:3]
        sugerencias.append((TIPOS[tipo], kc, [(r, *escalar(r, kc)) for r in c]))
    return dict(p=p, comp=comp, en=en, mac=mac, d=d, an=an, sugerencias=sugerencias)


@app.route("/nutricion")
@login_required
def nutricion():
    return render_template("nutricion.html", **datos_nutricion(g.user))


def metas_de(d, mac):
    m = d.get("metas") or {}
    return {"kcal": m.get("kcal") or mac["kcal"], "prot": m.get("prot") or mac["prot"],
            "grasa": m.get("grasa") or mac["grasa"], "carb": m.get("carb") or mac["carb"]}


def editor_dieta(target, editable, url_self, titulo):
    p, comp, en, mac = calcular(target)
    d = dietamod.normalizar(json.loads(target["smae"]) if target.get("smae") else None)
    metas = metas_de(d, mac)
    n = len(d["tiempos"])
    if request.method == "POST" and editable:
        f = request.form
        a = f.get("accion", "guardar")
        mt = {k: calc.num(f.get(f"meta_{k}")) for k in ("kcal", "prot", "grasa", "carb")}
        d["metas"] = mt if any(mt.values()) else None
        metas = metas_de(d, mac)
        if a == "auto_eq":
            d["dist"] = dietamod.distribuir(dietamod.calcular_equivalentes(metas, metas["kcal"]), n)
            flash("Equivalentes calculados y repartidos automáticamente. Ajústalos a tu criterio.", "ok")
        else:
            for gi, gname in enumerate(dietamod.GRUPOS):
                d["dist"][gname] = [calc.num(f.get(f"q_{gi}_{ti}"), 0) or 0 for ti in range(n)]
            if a == "auto_dist":
                d["dist"] = dietamod.distribuir(dietamod.totales_por_grupo(d), n)
                flash("Equivalentes redistribuidos entre los tiempos de comida.", "ok")
            else:
                flash("Dieta guardada.", "ok")
            d["menu"] = {t: f.get(f"menu_{ti}", "") for ti, t in enumerate(d["tiempos"])}
            d["recetas"] = {t: f.get(f"receta_{ti}", "") for ti, t in enumerate(d["tiempos"]) if f.get(f"receta_{ti}")}
            d["notas"] = f.get("notas", "")
        dietamod.sello(d, g.user["nombre"])
        get_db().execute("UPDATE usuarios SET smae=? WHERE id=?", (json.dumps(d), target["id"]))
        get_db().commit()
        return redirect(url_self)
    an = dietamod.analizar(d, metas)
    tipos_tiempo = ["desayuno", "colacion", "comida", "colacion", "postentreno", "cena"]
    opciones = []
    for ti, t in enumerate(d["tiempos"]):
        tipo = tipos_tiempo[ti] if ti < len(tipos_tiempo) else "comida"
        kc = round(an["por_tiempo"][ti][0])
        sel = d["recetas"].get(t)
        rec = buscar_receta(sel) if sel else None
        opciones.append({"tiempo": t, "kcal": kc, "candidatas": candidatas(tipo, p.get("preferencias", []), p["objetivo"]),
                         "sel": sel, "rec": (rec, *escalar(rec, kc)) if rec and kc else None})
    logs = registros(target["id"], dt.date.today() - dt.timedelta(days=60))
    tr = calc.tendencia([l["peso"] for l in logs])
    graf = charts.linea([("Peso", [l["peso"] for l in logs], "s2", True), ("Tendencia", tr, "s1", False)],
                        [f"{l['fecha'].day}/{l['fecha'].month}" for l in logs], titulo="Peso", alto=170)
    adapt = calc.get_adaptativo(logs)
    kc_dias = [l for l in logs if l.get("kcal")]
    adher = (sum(1 for l in kc_dias if abs(l["kcal"] - metas["kcal"]) <= metas["kcal"] * 0.1) / len(kc_dias)) if kc_dias else None
    sug = None
    if adapt:
        signo = {"Perder grasa": -1, "Recomposición": -1, "Ganar músculo": 1}.get(p["objetivo"], 0)
        ideal = round((adapt + signo * p["ritmo"] / 100 * p["peso"] * 7700 / 7) / 10) * 10
        if abs(ideal - metas["kcal"]) > 100:
            sug = ideal
    return render_template("dieta.html", target=target, p=p, mac=mac, en=en, d=d, an=an, metas=metas, editable=editable,
                           GRUPOS=dietamod.GRUPOS, VAL=dietamod.VAL, opciones=opciones, graf=graf, adapt=adapt,
                           adher=adher, sug=sug, titulo=titulo, url_self=url_self, TIPOS=TIPOS)


@app.route("/dieta", methods=["GET", "POST"])
@login_required
def dieta_propia():
    editable = not g.user.get("coach_id")
    return editor_dieta(g.user, editable or request.args.get("editar") == "1", url_for("dieta_propia"), "Mi dieta por equivalentes")


@app.route("/coach/cliente/<int:cid>/dieta", methods=["GET", "POST"])
@login_required
def coach_dieta(cid):
    c = get_db().execute("SELECT * FROM usuarios WHERE id=? AND coach_id=?", (cid, g.user["id"])).fetchone()
    if not c or g.user["rol"] != "entrenador":
        abort(404)
    c = dict(c)
    if not c.get("perfil"):
        flash("El cliente aún no completa su evaluación.", "error")
        return redirect(url_for("coach"))
    return editor_dieta(c, True, url_for("coach_dieta", cid=cid), f"Dietocálculo · {c['nombre']}")


@app.route("/recetas/nueva", methods=["GET", "POST"])
@login_required
def receta_nueva():
    if request.method == "POST":
        f = request.form
        ing = [(n, calc.num(gr)) for n, gr in zip(f.getlist("ing"), f.getlist("gramos")) if n in ING and calc.num(gr)]
        if not f.get("nombre") or not ing:
            flash("Escribe un nombre y al menos un ingrediente con gramos.", "error")
        else:
            get_db().execute("INSERT INTO recetas_usuario (autor_id, nombre, tipo, tags, ing, pasos, minutos) VALUES (?,?,?,?,?,?,?)",
                             (g.user["id"], f["nombre"].strip(), f.get("tipo", "comida"), json.dumps(f.getlist("tags")),
                              json.dumps(ing), f.get("pasos", ""), int(calc.num(f.get("minutos"), 0) or 0)))
            get_db().commit()
            flash("Receta guardada" + (" y compartida con tus clientes." if g.user["rol"] == "entrenador" else "."), "ok")
            return redirect(url_for("recetas"))
    return render_template("receta_nueva.html", ING=ING, TIPOS=TIPOS, TAGS=sorted({t for r in RECETAS for t in r["tags"]}))


@app.route("/recetas/<rid>/borrar", methods=["POST"])
@login_required
def receta_borrar(rid):
    if rid.startswith("u") and rid[1:].isdigit():
        get_db().execute("DELETE FROM recetas_usuario WHERE id=? AND autor_id=?", (int(rid[1:]), g.user["id"]))
        get_db().commit()
        flash("Receta eliminada.", "ok")
    return redirect(url_for("recetas"))


@app.route("/recetas")
def recetas():
    tipo, tag, q = request.args.get("tipo", ""), request.args.get("tag", ""), request.args.get("q", "").lower()
    kcal_obj = None
    if g.user and g.user.get("perfil"):
        p, comp, en, mac = calcular(g.user)
        meta = dict(reparto(p["comidas"]))
        if tipo and tipo in meta:
            kcal_obj = round(mac["kcal"] * meta[tipo])
    rs = [r for r in todas_recetas() if (not tipo or r["tipo"] == tipo) and (not tag or tag in r["tags"]) and (not q or q in r["nombre"].lower())]
    items = [(r, *escalar(r, kcal_obj)) if kcal_obj else (r, 1.0, r["base"], r["ing"]) for r in rs]
    tags = sorted({t for r in todas_recetas() for t in r["tags"]})
    return render_template("recetas.html", items=items, TIPOS=TIPOS, tags=tags, tipo=tipo, tag=tag, q=q, kcal_obj=kcal_obj)


@app.route("/recetas/<rid>")
def receta(rid):
    r = buscar_receta(rid) or abort(404)
    kcal = calc.num(request.args.get("kcal"))
    f, m, ing = escalar(r, kcal) if kcal else (1.0, r["base"], r["ing"])
    detalle = [(n, gr, ING[n]) for n, gr in ing]
    return render_template("receta.html", r=r, f=f, m=m, detalle=detalle, kcal=kcal, TIPOS=TIPOS)


def datos_plan_dia(variar=0):
    p, comp, en, mac = calcular(g.user)
    plan, usadas = [], set()
    for tipo, share in reparto(p["comidas"]):
        kc = round(mac["kcal"] * share)
        c = [r for r in candidatas(tipo, p.get("preferencias", []), p["objetivo"]) if r["id"] not in usadas]
        r = c[(variar + len(plan)) % len(c)] if c else None
        if r:
            usadas.add(r["id"])
            plan.append((TIPOS[tipo], kc, r, *escalar(r, kc)))
    tot = {k: sum(x[4][k] for x in plan) for k in ("kcal", "prot", "carb", "grasa")}
    compras = {}
    for *_a, ing in plan:
        for n, gr in ing:
            compras[n] = compras.get(n, 0) + gr
    return plan, tot, mac, sorted(compras.items())


@app.route("/plan-del-dia")
@login_required
def plan_dia():
    variar = int(request.args.get("variar", 0))
    plan, tot, mac, compras = datos_plan_dia(variar)
    return render_template("plan_dia.html", plan=plan, tot=tot, mac=mac, compras=compras, variar=variar)


# ------------------------------------------------------------------ cuerpo y ejercicios
@app.route("/cuerpo")
def cuerpo():
    sexo = "Mujer" if request.args.get("sexo") == "Mujer" else ("Hombre" if request.args.get("sexo") == "Hombre" else
                                                             (perfil(g.user)["sexo"] if g.user and g.user.get("perfil") else "Hombre"))
    datos = {}
    for mid, m in MUSCULOS.items():
        prim = [e for e in EJERCICIOS.values() if e["targets"][0] == mid]
        sec = [e for e in EJERCICIOS.values() if mid in e["targets"][1:]]
        datos[mid] = dict(m, id=mid, principales=[(e["nombre"], e["slug"], e["equipo"]) for e in prim],
                          secundarios=[(e["nombre"], e["slug"]) for e in sec][:8])
    vol = {}
    if g.user and g.user.get("perfil"):
        lunes = dt.date.today() - dt.timedelta(days=dt.date.today().weekday())
        vol = calc.volumen_por_musculo(series_de(g.user["id"], desde=lunes))
    return render_template("cuerpo.html", sexo=sexo, frente=body_svg(sexo, "frente"), espalda=body_svg(sexo, "espalda"),
                           datos=json.dumps(datos, ensure_ascii=False), vol=json.dumps(vol),
                           otros=[(m, MUSCULOS[m]["nombre"].split(" (")[0]) for m in SIN_ZONA])


EQUIPO_PERFIL = {k: v for k, v in PERFILES_EQUIPO.items()}
PREFERIDOS = {
    "pectoral": ["Press de banca", "Press inclinado con mancuernas", "Aperturas en polea (cruce de poleas)"],
    "gluteo": ["Hip thrust con barra", "Sentadilla búlgara", "Abducción de cadera en máquina"],
    "isquios": ["Peso muerto rumano", "Curl femoral sentado"],
    "cuadriceps": ["Sentadilla con barra", "Prensa de piernas", "Extensión de cuádriceps"],
    "dorsal": ["Jalón al pecho", "Remo con barra", "Dominadas"],
    "romboides": ["Remo en máquina con apoyo de pecho", "Remo en polea baja"],
    "biceps": ["Curl con barra EZ", "Curl inclinado con mancuernas"],
    "triceps": ["Press cerrado en banca", "Extensión con cuerda sobre la cabeza", "Extensión de tríceps en polea"],
    "deltoide_lat": ["Elevaciones laterales en polea", "Elevaciones laterales con mancuernas"],
    "deltoide_ant": ["Press militar con mancuernas"],
    "deltoide_post": ["Deltoide posterior en máquina", "Face pulls"],
    "pantorrilla": ["Elevación de talones de pie", "Elevación de talones sentado"],
    "abdomen": ["Crunch en polea", "Elevación de piernas colgado"],
}


def generar_sesion(musculos, minutos, equipo, ev=None):
    """equipo: conjunto de categorías disponibles. ev: resultado de seleccion.evaluar (reglas del perfil)."""
    permitido = set(equipo) if equipo else None
    presupuesto = max(6, int(minutos / 2.9))  # series totales que caben (descanso + ejecución)
    por_musculo = max(2, presupuesto // max(1, len(musculos)))
    plan = []
    for mid in musculos:
        base = [e for e in EJERCICIOS.values() if e["targets"][0] == mid and e["tipo"] in ("Compuesto", "Aislamiento")
                and (permitido is None or e["equipo"] in permitido)]
        cands = [e for e in base if not ev or selmod.permitido(e["nombre"], ev)[0]] or base
        orden_eq = {"Barra": 0, "Mancuernas": 1, "Máquina": 2, "Polea": 3, "Peso corporal": 4}
        pref = PREFERIDOS.get(mid, [])
        guiar = bool(ev and "guiado" in ev["prefer"])
        cands.sort(key=lambda e: (not ATRIBUTOS[e["nombre"]]["guiado"] if guiar else False,
                                  pref.index(e["nombre"]) if e["nombre"] in pref else 99, e["tipo"] != "Compuesto", orden_eq.get(e["equipo"], 5), len(e["nombre"])))
        n_ej = 1 if por_musculo <= 3 or len(cands) < 2 else 2
        elegidos = cands[:1]
        if n_ej == 2:
            resto = [c for c in cands[1:] if c["tipo"] != elegidos[0]["tipo"] or elegidos[0]["tipo"] == "Aislamiento"]
            if resto:
                elegidos.append(resto[0])
        series_c = max(2, min(4, round(por_musculo / max(1, len(elegidos)))))
        for e in elegidos:
            comp = e["tipo"] == "Compuesto"
            plan.append({"ex": e["nombre"], "slug": e["slug"], "musculo": mid, "series": series_c, "rmin": 6 if comp else 10,
                         "rmax": 10 if comp else 15, "rir": 2 if comp else 1, "descanso": 150 if comp else 75})
    plan.sort(key=lambda x: EJERCICIOS[x["ex"]]["tipo"] != "Compuesto")
    return plan


@app.route("/entrenar", methods=["GET", "POST"])
@login_required
def entrenar():
    p = perfil(g.user)
    sexo = request.values.get("sexo") or p["sexo"]
    musculos = [m for m in request.values.getlist("m") if m in MUSCULOS]
    minutos = int(calc.num(request.values.get("min"), p["duracion"]) or 60)
    ev = selmod.evaluar(p)
    eq_sel = [e for e in request.values.getlist("eq") if e in EQUIPO_NOMBRES]
    equipo = set(eq_sel) if eq_sel else selmod.equipo_disponible(p)
    plan = generar_sesion(musculos, minutos, equipo, ev) if musculos else []
    if request.method == "POST" and plan:
        prog = programa(g.user)
        prog["dias"].append({"nombre": "Sesión: " + ", ".join(MUSCULOS[m]["nombre"].split(" (")[0] for m in musculos[:3]),
                             "dia": dt.date.today().weekday(),
                             "ejercicios": [{k: e[k] for k in ("ex", "series", "rmin", "rmax", "rir", "descanso")} for e in plan]})
        guardar(g.user, "programa", prog)
        flash("Sesión agregada a tu programa como un día nuevo.", "ok")
        return redirect(url_for("sesion_view", dia=len(prog["dias"]) - 1))
    hoy = dt.date.today()
    lunes = hoy - dt.timedelta(days=hoy.weekday())
    vol = calc.volumen_por_musculo(series_de(g.user["id"], desde=lunes))
    # recuperación estimada (heurística transparente): horas desde la última vez como músculo principal / 72 h
    ultima = {}
    for s in series_de(g.user["id"], desde=hoy - dt.timedelta(days=10)):
        info = EJERCICIOS.get(s["ejercicio"])
        if info:
            ultima[info["targets"][0]] = max(ultima.get(info["targets"][0], ""), s["fecha"])
    recup = {}
    for mid in MUSCULOS:
        if mid in ultima:
            horas = (dt.datetime.now() - dt.datetime.fromisoformat(ultima[mid] + "T18:00")).total_seconds() / 3600
            recup[mid] = max(0, min(100, round(horas / 72 * 100)))
        else:
            recup[mid] = 100
    duracion = round(sum(e["series"] * (e["descanso"] + 45) for e in plan) / 60 + 10) if plan else 0
    return render_template("entrenar.html", sexo=sexo, frente=body_svg(sexo, "frente"), espalda=body_svg(sexo, "espalda"),
                           MUSCULOS=MUSCULOS, musculos=musculos, plan=plan, minutos=minutos, equipo=equipo, vol=vol, recup=recup,
                           duracion=duracion, EQ_NOMBRES=EQUIPO_NOMBRES, icono=icono_equipo, ev=ev, letras="ABCDEFGH")


TIEMPOS_COMIDA = ["Desayuno", "Colación AM", "Comida", "Colación PM", "Cena"]


@app.route("/alimentos")
def alimentos_view():
    q, cat = request.args.get("q", ""), request.args.get("cat", "")
    lista = alim.buscar(q, cat)
    return render_template("alimentos.html", lista=lista[:60], total=len(lista), q=q, cat=cat, CATEGORIAS=alim.CATEGORIAS, macros=alim.macros)


def minimos(p, mac):
    return {"prot_min": round(1.6 * p["peso"]), "grasa_min": round(max(0.5 * p["peso"], 0.2 * mac["kcal"] / 9)),
            "fibra": round(14 * mac["kcal"] / 1000)}


def sincronizar_registro(con, uid, fecha):
    """Pasa los totales del diario de comidas al registro diario."""
    tot = con.execute("SELECT SUM(kcal), SUM(prot) FROM diario_comidas WHERE usuario_id=? AND fecha=?", (uid, fecha)).fetchone()
    if con.execute("SELECT 1 FROM registros WHERE usuario_id=? AND fecha=?", (uid, fecha)).fetchone():
        con.execute("UPDATE registros SET kcal=?, proteina=? WHERE usuario_id=? AND fecha=?", (tot[0], tot[1], uid, fecha))
    else:
        con.execute("INSERT INTO registros (usuario_id, fecha, kcal, proteina) VALUES (?,?,?,?)", (uid, fecha, tot[0], tot[1]))
    con.commit()


def vista_diario(target, editable, url_base):
    p, comp, en, mac = calcular(target)
    con = get_db()
    fecha = request.values.get("fecha") or str(dt.date.today())
    if request.method == "POST" and editable:
        f = request.form
        if f.get("accion") == "borrar":
            con.execute("DELETE FROM diario_comidas WHERE id=? AND usuario_id=?", (f.get("id"), target["id"]))
        elif f.get("accion") == "receta":
            rec = buscar_receta(f.get("receta"))
            factor = calc.num(f.get("factor"), 1) or 1
            if rec:
                m = macros_receta(rec, factor)
                con.execute("INSERT INTO diario_comidas (usuario_id, fecha, tiempo, alimento, porcion, gramos, kcal, prot, carb, grasa) VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (target["id"], fecha, f.get("tiempo", "Comida"), "Receta: " + rec["nombre"], f"porción ×{factor:g}", None, m["kcal"], m["prot"], m["carb"], m["grasa"]))
        else:
            a = alim.POR_ID.get(int(calc.num(f.get("alimento_id"), -1) or -1)) if f.get("alimento_id") else None
            gr_porcion = calc.num(f.get("porcion_g"), 100) or 100
            cant = calc.num(f.get("cantidad"), 1) or 1
            if a:
                gramos = gr_porcion * cant
                m = alim.macros(a, gramos)
                fib = round((a["por100g"].get("fibra") or 0) * gramos / 100, 1) if a["por100g"].get("fibra") is not None else None
                con.execute("INSERT INTO diario_comidas (usuario_id, fecha, tiempo, alimento, porcion, gramos, kcal, prot, carb, grasa, fibra, alimento_id, fuente) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (target["id"], fecha, f.get("tiempo", "Comida"), a["nombre"], f"{cant:g} × {f.get('porcion_desc') or str(gr_porcion) + ' g'}", gramos,
                             m["kcal"], m["prot"], m["carb"], m["grasa"], fib, a["id"], "manual"))
            else:
                flash("Elige un alimento de la lista.", "error")
        sincronizar_registro(con, target["id"], fecha)
        return redirect(url_base + "?fecha=" + fecha + "#agregar")
    filas = [dict(x) for x in con.execute("SELECT * FROM diario_comidas WHERE usuario_id=? AND fecha=? ORDER BY id", (target["id"], fecha)).fetchall()]
    tot = {k: sum((x[k] or 0) for x in filas) for k in ("kcal", "prot", "carb", "grasa")}
    por_tiempo = {t: [x for x in filas if x["tiempo"] == t] for t in TIEMPOS_COMIDA}
    mins = minimos(p, mac)
    # análisis 7 días
    desde = dt.date.fromisoformat(fecha) - dt.timedelta(days=6)
    sem = con.execute("SELECT fecha, SUM(kcal) k, SUM(prot) p, SUM(grasa) g, SUM(carb) c FROM diario_comidas WHERE usuario_id=? AND fecha BETWEEN ? AND ? GROUP BY fecha ORDER BY fecha",
                      (target["id"], str(desde), fecha)).fetchall()
    graf = charts.barras([x["k"] or 0 for x in sem], [x["fecha"][8:10] + "/" + x["fecha"][5:7] for x in sem], alto=160, titulo="kcal por día",
                         clases=["bar" if abs((x["k"] or 0) - mac["kcal"]) <= mac["kcal"] * 0.1 else "bar2" for x in sem], referencia=mac["kcal"]) if sem else ""
    analisis = None
    if sem:
        n = len(sem)
        analisis = {"dias": n, "kcal": sum(x["k"] or 0 for x in sem) / n, "prot": sum(x["p"] or 0 for x in sem) / n,
                    "grasa": sum(x["g"] or 0 for x in sem) / n, "carb": sum(x["c"] or 0 for x in sem) / n,
                    "dias_prot": sum(1 for x in sem if (x["p"] or 0) >= mins["prot_min"]),
                    "dias_grasa": sum(1 for x in sem if (x["g"] or 0) >= mins["grasa_min"])}
    return render_template("diario.html", target=target, editable=editable, url_base=url_base, fecha=fecha, filas=filas, tot=tot,
                           por_tiempo=por_tiempo, mac=mac, p=p, mins=mins, graf=graf, analisis=analisis, TIEMPOS=TIEMPOS_COMIDA,
                           datos_js=json.dumps(alim.para_js(), ensure_ascii=False), recetas=todas_recetas(target))


@app.route("/diario", methods=["GET", "POST"])
@login_required
def diario():
    return vista_diario(g.user, True, url_for("diario"))


@app.route("/coach/cliente/<int:cid>/diario", methods=["GET", "POST"])
@login_required
def coach_diario(cid):
    c = get_db().execute("SELECT * FROM usuarios WHERE id=? AND coach_id=?", (cid, g.user["id"])).fetchone()
    if not c or g.user["rol"] != "entrenador":
        abort(404)
    return vista_diario(dict(c), True, url_for("coach_diario", cid=cid))


@app.route("/ejercicios")
def ejercicios():
    grupo, q, tipo = request.args.get("grupo", ""), request.args.get("q", "").lower(), request.args.get("tipo", "")
    eqs = [e for e in request.args.getlist("eq") if e in EQUIPO_NOMBRES]
    lista = [e for e in EJERCICIOS.values() if (not grupo or e["grupo"] == grupo) and (not eqs or e["equipo"] in eqs)
             and (not tipo or e["tipo"] == tipo) and (not q or q in e["nombre"].lower())]
    ev = selmod.evaluar(perfil(g.user)) if g.get("user") and g.user.get("perfil") else None
    aviso = {e["nombre"]: selmod.permitido(e["nombre"], ev)[1] for e in lista} if ev else {}
    return render_template("ejercicios.html", lista=lista, GRUPOS=GRUPOS + ["Otros"], grupo=grupo, eqs=eqs, q=q, tipo=tipo,
                           EQ_NOMBRES=EQUIPO_NOMBRES, icono=icono_equipo, MUSCULOS=MUSCULOS, aviso=aviso, total=len(EJERCICIOS))


@app.route("/ejercicios/<slug>")
def ejercicio(slug):
    e = POR_SLUG.get(slug) or abort(404)
    graf, hist = "", []
    if g.user and g.user.get("perfil"):
        pf = progreso_fuerza(g.user["id"]).get(e["nombre"])
        if pf:
            fechas = sorted(pf["historial"])
            graf = charts.linea([("e1RM", [pf["historial"][f] for f in fechas], "s1", False)], [f[8:10] + "/" + f[5:7] for f in fechas], titulo="e1RM")
            hist = pf
    sexo = request.args.get("sexo") if request.args.get("sexo") in ("Hombre", "Mujer") else (
        perfil(g.user)["sexo"] if g.get("user") and g.user.get("perfil") else "Hombre")
    aviso = ""
    if g.get("user") and g.user.get("perfil"):
        ok, aviso = selmod.permitido(e["nombre"], selmod.evaluar(perfil(g.user)))
    return render_template("ejercicio.html", e=e, subs=sustitutos(e["nombre"])[:8], MUSCULOS=MUSCULOS, graf=graf, hist=hist,
                           frente=body_svg(sexo, "frente"), espalda=body_svg(sexo, "espalda"), video=video_de(e["slug"]),
                           icono=icono_equipo, aviso=aviso, anim=animacion_de(e["nombre"]), cuerpo=cuerpo_3d(sexo))


def cuerpo_3d(sexo):
    """Complexión del maniquí 3D: sexo, % de grasa y mesomorfia del usuario (si los tiene)."""
    c = {"sexo": sexo}
    if g.get("user") and g.user.get("perfil"):
        p = perfil(g.user)
        comp = calc.composicion(p)
        if comp.get("grasa"):
            c["grasa"] = round(comp["grasa"] * 100, 1)
        if (p.get("somatotipo") or {}).get("meso"):
            c["meso"] = round(p["somatotipo"]["meso"], 1)
    return c


VIDEO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "videos")
VIDEO_LINKS = os.path.join(VIDEO_DIR, "enlaces.json")


def video_de(slug):
    """Video del ejercicio: archivo local (static/videos/<slug>.mp4|webm) o enlace de YouTube guardado por el entrenador."""
    for ext in ("mp4", "webm"):
        if os.path.exists(os.path.join(VIDEO_DIR, f"{slug}.{ext}")):
            return {"tipo": "archivo", "url": url_for("static", filename=f"videos/{slug}.{ext}")}
    try:
        with open(VIDEO_LINKS, encoding="utf-8") as fh:
            yt = json.load(fh).get(slug)
    except (OSError, ValueError):
        yt = None
    if yt:
        return {"tipo": "youtube", "url": f"https://www.youtube-nocookie.com/embed/{yt}"}
    return None


@app.route("/ejercicios/<slug>/video", methods=["POST"])
@login_required
def ejercicio_video(slug):
    import re
    e = POR_SLUG.get(slug) or abort(404)
    if g.user["rol"] != "entrenador":
        abort(403)
    os.makedirs(VIDEO_DIR, exist_ok=True)
    arch = request.files.get("archivo")
    enlace = (request.form.get("enlace") or "").strip()
    if arch and arch.filename:
        ext = arch.filename.rsplit(".", 1)[-1].lower()
        if ext not in ("mp4", "webm"):
            flash("Sube un video MP4 o WebM.", "error")
            return redirect(url_for("ejercicio", slug=slug))
        for old in ("mp4", "webm"):
            try:
                os.remove(os.path.join(VIDEO_DIR, f"{slug}.{old}"))
            except OSError:
                pass
        arch.save(os.path.join(VIDEO_DIR, f"{slug}.{ext}"))
        flash("Video guardado.", "ok")
    elif enlace:
        m = re.search(r"(?:youtu\.be/|v=|embed/|shorts/)([A-Za-z0-9_-]{11})", enlace)
        if not m:
            flash("No reconocí el enlace de YouTube.", "error")
            return redirect(url_for("ejercicio", slug=slug))
        try:
            with open(VIDEO_LINKS, encoding="utf-8") as fh:
                d = json.load(fh)
        except (OSError, ValueError):
            d = {}
        d[slug] = m.group(1)
        with open(VIDEO_LINKS, "w", encoding="utf-8") as fh:
            json.dump(d, fh)
        flash("Enlace de video guardado.", "ok")
    return redirect(url_for("ejercicio", slug=slug))


# ------------------------------------------------------------------ calculadoras y contenido
@app.route("/calculadoras")
def calculadoras():
    a = request.args
    res = {}
    if a.get("calc") == "energia":
        p = db.perfil_base(sexo=a.get("sexo", "Hombre"), edad=calc.num(a.get("edad"), 30), peso=calc.num(a.get("peso"), 70), talla=calc.num(a.get("talla"), 170),
                           objetivo=a.get("objetivo", "Mantener"), ritmo=calc.num(a.get("ritmo"), 0.5), dias=int(calc.num(a.get("dias"), 3)),
                           duracion=calc.num(a.get("duracion"), 60), cuello=calc.num(a.get("cuello")), cintura=calc.num(a.get("cintura")),
                           cadera=calc.num(a.get("cadera")), nivel=a.get("nivel", "Principiante"), cardio_min=0, cardio_ses=0)
        comp = calc.composicion(p); en = calc.energia(p, comp)
        res["energia"] = (comp, en, calc.macros(p, en, comp))
    if a.get("calc") == "1rm" and a.get("peso") and a.get("reps"):
        w, rp, rir = calc.num(a["peso"]), int(calc.num(a["reps"])), calc.num(a.get("rir"), 0)
        e = calc.e1rm(w, rp, rir)
        res["1rm"] = (e, [(r, round(e / (1 + r / 30), 1)) for r in (1, 2, 3, 5, 6, 8, 10, 12, 15)])
    if a.get("calc") == "fc" and a.get("edad"):
        res["fc"] = calc.zonas_fc(calc.num(a["edad"]), calc.num(a.get("reposo"), 65))
    if a.get("calc") == "rockport" and a.get("tiempo"):
        res["rockport"] = calc.rockport(calc.num(a["peso"]), calc.num(a["edad"]), a.get("sexo", "Hombre"), calc.num(a["tiempo"]), calc.num(a["fc"]))
    if a.get("calc") == "cooper" and a.get("distancia"):
        res["cooper"] = calc.cooper(calc.num(a["distancia"]))
    if a.get("calc") == "discos" and a.get("objetivo"):
        obj = calc.num(a["objetivo"]); unidad = a.get("unidad", "kg")
        disp = (25, 20, 15, 10, 5, 2.5, 1.25) if unidad == "kg" else (45, 35, 25, 10, 5, 2.5)
        res["discos"] = (*calc.discos(obj, calc.num(a.get("barra"), 20 if unidad == "kg" else 45), disp), unidad, calc.calentamiento(obj))
    pre, vista = {}, "simple"
    if g.get("user") and g.user.get("perfil"):
        pf = perfil(g.user)
        pre = {k: pf.get(k) for k in ("sexo", "edad", "talla", "peso", "actividad", "dias", "duracion", "comidas") if pf.get(k) is not None}
        pre["objetivo"] = pf.get("objetivo") if pf.get("objetivo") in ("Perder grasa", "Ganar músculo") else "Mantener"
        if pf.get("grasa_medida"):
            pre["grasa"] = pf["grasa_medida"]
        vista = "detalle" if g.user["rol"] == "entrenador" else "simple"
    tab_inicial = "mas" if a.get("calc") in ("fc", "rockport", "cooper", "discos") else ""
    return render_template("calculadoras.html", res=res, a=a, pre=pre, vista=vista, tab_inicial=tab_inicial)


@app.route("/privacidad")
def privacidad():
    return render_template("privacidad.html")


@app.route("/suplementos")
def suplementos():
    return render_template("suplementos.html", SUPLEMENTOS=SUPLEMENTOS)


@app.route("/emergencia")
def emergencia():
    return render_template("emergencia.html", EMERGENCIA=EMERGENCIA)


@app.route("/mitos")
def mitos():
    return render_template("mitos.html", MITOS=MITOS)


# ------------------------------------------------------------------ artículos
@app.route("/articulos")
def articulos():
    cat, q, tipo = request.args.get("cat", ""), request.args.get("q", "").strip().lower(), request.args.get("tipo", "")
    if not (cat or q or tipo):
        tipo = "investigacion"
    lista = [a for a in ARTICULOS if (not cat or a["categoria"] == cat) and (not tipo or a["tipo"] == tipo) and
             (not q or q in (a["titulo"] + " " + a["resumen"] + " " + " ".join(a["claves"])).lower())]
    destacados = [a for a in ARTICULOS if a.get("destacado")]
    conteo = {c: sum(1 for a in ARTICULOS if a["categoria"] == c) for c in CAT_ART}
    n_inv = sum(1 for a in ARTICULOS if a["tipo"] == "investigacion")
    return render_template("articulos.html", lista=lista, destacados=destacados, CATS=CAT_ART, conteo=conteo, cat=cat, q=q,
                           total=len(ARTICULOS), tipo=tipo, n_inv=n_inv, n_guia=len(ARTICULOS) - n_inv,
                           inicio=not (request.args.get("cat") or request.args.get("q") or request.args.get("tipo")))


@app.route("/articulos/<slug>")
def articulo(slug):
    a = ART_POR_SLUG.get(slug) or abort(404)
    rel = [x for x in ARTICULOS if x["categoria"] == a["categoria"] and x["slug"] != slug][:3]
    return render_template("articulo.html", a=a, rel=rel, enlace=art_enlace)


@app.route("/articulos/<slug>/pdf")
def articulo_pdf(slug):
    a = ART_POR_SLUG.get(slug) or abort(404)
    b = [("h", "En 30 segundos"), ("lista", a["claves"])]
    for titulo, parrafos in a["secciones"]:
        b.append(("h", titulo))
        b += [("p", x) for x in parrafos]
    b += [("h", "Cómo aplicarlo"), ("lista", a["aplicar"]), ("h", "Referencias")]
    b += [("nota", f"{c} {art_enlace(d)}" + (" (acceso libre)" if libre else "")) for c, d, libre in a["refs"]]
    return pdf_resp(a["titulo"], b, f"{a['categoria']} · {a['minutos']} min de lectura")




# ------------------------------------------------------------------ puntaje nutricional
def filas_dia(uid, fecha):
    return [dict(x) for x in get_db().execute("SELECT * FROM diario_comidas WHERE usuario_id=? AND fecha=? ORDER BY id", (uid, fecha)).fetchall()]


def puntaje_de(target, fecha):
    p, comp, en, mac = calcular(target)
    return pnt.analizar(filas_dia(target["id"], fecha), mac, minimos(p, mac), p["peso"])


def anillo_svg(valor, etiqueta, tam=168):
    r, c = 64, 2 * math.pi * 64
    color = "var(--ok-fg, #1a9b5f)" if valor >= 70 else "#d18b0f" if valor >= 50 else "var(--neg, #e5484d)"
    return (f'<svg viewBox="0 0 160 160" width="{tam}" height="{tam}" role="img" aria-label="Puntaje {valor} de 100, {etiqueta}">'
            f'<circle cx="80" cy="80" r="{r}" fill="none" stroke="var(--border)" stroke-width="12"/>'
            f'<circle cx="80" cy="80" r="{r}" fill="none" stroke="{color}" stroke-width="12" stroke-linecap="round" '
            f'stroke-dasharray="{c * valor / 100:.1f} {c:.1f}" transform="rotate(-90 80 80)"/>'
            f'<text x="80" y="80" text-anchor="middle" font-size="40" font-weight="700" fill="var(--text)">{valor}</text>'
            f'<text x="80" y="106" text-anchor="middle" font-size="14" font-weight="600" fill="{color}">{etiqueta}</text></svg>')


def vista_puntaje(target, es_coach):
    fecha = request.args.get("fecha") or str(dt.date.today())
    try:
        dia = dt.date.fromisoformat(fecha)
    except ValueError:
        dia = dt.date.today(); fecha = str(dia)
    a = puntaje_de(target, fecha)
    semana = []
    for i in range(6, -1, -1):
        d = dia - dt.timedelta(days=i)
        x = puntaje_de(target, str(d)) if i else a
        semana.append((d, x["total"] if x["n"] else 0, x["n"]))
    graf = charts.barras([v for _, v, _ in semana], [d.strftime("%d/%m") for d, _, _ in semana], alto=150, titulo="Puntaje por día",
                         clases=["bar" if v >= 70 else "bar2" for _, v, _ in semana], referencia=70)
    con_datos = [v for _, v, n in semana if n]
    return render_template("puntaje.html", target=target, es_coach=es_coach, fecha=fecha, a=a, anillo=anillo_svg(a["total"], a["etiqueta"]),
                           graf=graf, promedio=round(sum(con_datos) / len(con_datos)) if con_datos else None,
                           registrar=url_for("registrar", cid=target["id"]) if es_coach else url_for("registrar"))


@app.route("/puntaje")
@login_required
def puntaje_nutricional():
    return vista_puntaje(g.user, False)


@app.route("/coach/cliente/<int:cid>/puntaje")
@login_required
def coach_puntaje(cid):
    return vista_puntaje(_cliente_de_coach(cid), True)


# ------------------------------------------------------------------ menú semanal
PASILLOS = {"Frutas": "Frutas y verduras", "Verduras": "Frutas y verduras", "Proteínas animales": "Carnes, pescados y huevo",
            "Lácteos": "Lácteos y huevo", "Cereales y tubérculos": "Cereales, pan y tortillas", "Leguminosas": "Leguminosas",
            "Grasas y semillas": "Aceites, semillas y nueces", "Salsas y condimentos": "Salsas y condimentos", "Suplementos": "Suplementos",
            "Azúcares y bebidas": "Otros", "Platillos mexicanos": "Otros", "Comida rápida": "Otros"}
ORDEN_PASILLOS = ["Frutas y verduras", "Carnes, pescados y huevo", "Lácteos y huevo", "Cereales, pan y tortillas", "Leguminosas",
                  "Aceites, semillas y nueces", "Salsas y condimentos", "Suplementos", "Otros"]
DIAS_SEMANA = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]


PASILLO_PALABRAS = [(("ajo", "cilantro", "limon", "elote", "frutos rojos", "cebolla", "jitomate", "chile", "pimiento", "lechuga", "espinaca",
                      "nopal", "calabac", "zanahoria", "pepino", "aguacate", "fresa", "platano", "manzana", "mango", "brocoli", "ejote",
                      "champinon", "verdolaga", "pina", "papaya", "melon", "tomate", "apio", "betabel", "jicama", "col"), "Frutas y verduras"),
                    (("proteina", "whey", "caseina", "colageno"), "Suplementos"),
                    (("pavo", "pollo", "res", "cerdo", "atun", "salmon", "camaron", "pescado", "tilapia", "sardina", "carne"), "Carnes, pescados y huevo"),
                    (("queso", "yogur", "leche", "huevo", "clara", "requeson"), "Lácteos y huevo"),
                    (("amaranto", "maiz", "avena", "arroz", "pan ", "pan", "tortilla", "pasta", "quinoa", "tostada", "galleta", "papa", "camote"), "Cereales, pan y tortillas"),
                    (("frijol", "lenteja", "garbanzo", "soya", "edamame", "haba", "chicharo"), "Leguminosas"),
                    (("aceite", "nuez", "almendra", "cacahuate", "chia", "linaza", "pepita", "ajonjoli"), "Aceites, semillas y nueces")]


def pasillo(nombre):
    n = pnt._n(nombre)
    for claves, ps in PASILLO_PALABRAS:
        if any(n.startswith(c) or f" {c}" in f" {n}" for c in claves):
            return ps
    a = pnt.POR_NOMBRE.get(nombre)
    if not a or a.get("categoria") == "Ingredientes de recetas":
        b, conf = rr.buscar_alimento(nombre)
        a = b if b and b.get("categoria") != "Ingredientes de recetas" else a
    if "huevo" in nombre.lower() or "clara" in nombre.lower():
        return "Lácteos y huevo"
    return PASILLOS.get((a or {}).get("categoria"), "Otros")


def datos_menu_semana(target, semilla=0):
    p, comp, en, mac = calcular(target)
    usos, dias, compras = {}, [], {}
    for d in range(7):
        plan, usadas = [], set()
        for tipo, share in reparto(p["comidas"]):
            kc = round(mac["kcal"] * share)
            c = [r for r in candidatas(tipo, p.get("preferencias", []), p["objetivo"]) if r["id"] not in usadas]
            if not c:
                continue
            k = (semilla * 5 + d * 3 + len(plan)) % len(c)
            r = min(c[k:] + c[:k], key=lambda r: usos.get(r["id"], 0))
            usadas.add(r["id"]); usos[r["id"]] = usos.get(r["id"], 0) + 1
            f, m, ing = escalar(r, kc)
            plan.append({"tiempo": TIPOS[tipo], "kc": kc, "r": r, "f": f, "m": m, "ing": ing})
            for n, gr in ing:
                compras[n] = compras.get(n, 0) + gr
        tot = {k: sum(x["m"][k] for x in plan) for k in ("kcal", "prot", "carb", "grasa")}
        dias.append({"nombre": DIAS_SEMANA[d], "plan": plan, "tot": tot})
    por_pasillo = {}
    for n, gr in sorted(compras.items()):
        por_pasillo.setdefault(pasillo(n), []).append((n, gr))
    lista = [(ps, por_pasillo[ps]) for ps in ORDEN_PASILLOS if ps in por_pasillo]
    return dias, mac, lista


@app.route("/menu-semanal")
@app.route("/coach/cliente/<int:cid>/menu-semanal")
@login_required
@pro_required
def menu_semanal(cid=None):
    target = _cliente_de_coach(cid) if cid else g.user
    semilla = int(calc.num(request.args.get("variar"), 0) or 0)
    dias, mac, lista = datos_menu_semana(target, semilla)
    return render_template("menu_semanal.html", target=target, es_coach=cid is not None, dias=dias, mac=mac, lista=lista, variar=semilla,
                           hoy=dt.date.today().weekday())


@app.route("/menu-semanal/pdf")
@app.route("/coach/cliente/<int:cid>/menu-semanal/pdf")
@login_required
@pro_required
def menu_semanal_pdf(cid=None):
    target = _cliente_de_coach(cid) if cid else g.user
    dias, mac, lista = datos_menu_semana(target, int(calc.num(request.args.get("variar"), 0) or 0))
    b = [("metricas", [("Meta diaria", _f(mac["kcal"]), "kcal"), ("Proteína", _f(mac["prot"]), "g"), ("Carbohidratos", _f(mac["carb"]), "g"), ("Grasas", _f(mac["grasa"]), "g")])]
    for d in dias:
        b += [("h", f"{d['nombre']} · {_f(d['tot']['kcal'])} kcal · P {_f(d['tot']['prot'])} g"),
              ("tabla", ["Tiempo", "Receta", "kcal", "Proteína"], [[x["tiempo"], x["r"]["nombre"] + (f" (×{x['f']:g})" if x["f"] != 1 else ""), _f(x["m"]["kcal"]), f"{_f(x['m']['prot'])} g"] for x in d["plan"]], [1.4, 4, 1, 1.1])]
    b.append(("salto",))
    b.append(("h", "Lista de compras de la semana"))
    for ps, items in lista:
        b += [("h", ps), ("tabla", ["Ingrediente", "Cantidad", "✓"], [[n, (f"{gr / 1000:.1f} kg" if gr >= 1000 else f"{gr:g} g"), "☐"] for n, gr in items], [4, 1.5, .5])]
    b.append(("nota", "Las cantidades son de ingredientes en el estado en que se pesan en cada receta (cocidos o crudos según se indica)."))
    return pdf_resp(f"Menú semanal · {target['nombre']}", b, "Recetas ajustadas a tus calorías y macros, con lista de compras por pasillo")


# ------------------------------------------------------------------ registro rápido (foto, voz, texto, código)
def _target_registro(cid):
    if cid is None:
        return g.user
    return _cliente_de_coach(cid)


def _hora_tiempo():
    h = dt.datetime.now().hour
    return "Desayuno" if h < 11 else "Colación AM" if h < 13 else "Comida" if h < 17 else "Colación PM" if h < 19 else "Cena"


@app.route("/registrar")
@app.route("/coach/cliente/<int:cid>/registrar")
@login_required
def registrar(cid=None):
    target = _target_registro(cid)
    base = url_for("registrar", cid=cid) if cid else url_for("registrar")
    return render_template("registrar.html", target=target, es_coach=cid is not None, base=base, TIEMPOS=TIEMPOS_COMIDA,
                           tiempo=_hora_tiempo(), hoy=str(dt.date.today()), ia=asistente.hay_credenciales(),
                           diario=url_for("coach_diario", cid=cid) if cid else url_for("diario"))


@app.route("/registrar/interpretar", methods=["POST"])
@login_required
def registrar_interpretar():
    d = request.get_json(silent=True) or {}
    texto = (d.get("texto") or "").strip()[:2000]
    if not texto:
        return jsonify(items=[], faltan=[], nota="Escribe o dicta lo que comiste.")
    items, faltan = rr.interpretar_texto(texto, tiempo=d.get("tiempo"))
    nota = ""
    if faltan and asistente.hay_credenciales():
        extra, nota = rr.interpretar_con_ia(faltan)
        for x in extra:
            x["tiempo"] = d.get("tiempo")
        items += extra
        faltan = [] if extra else faltan
    return jsonify(items=items, faltan=faltan, nota=nota or "")


@app.route("/registrar/foto", methods=["POST"])
@login_required
def registrar_foto():
    f = request.files.get("foto")
    if not f:
        return jsonify(items=[], nota="Toma o elige una foto."), 400
    datos = f.read()
    if len(datos) > 8 * 1024 * 1024:
        return jsonify(items=[], nota="La foto es muy grande (máximo 8 MB)."), 400
    items, nota = rr.analizar_foto(datos, f.mimetype or "image/jpeg")
    for x in items:
        x["tiempo"] = request.form.get("tiempo")
    return jsonify(items=items, nota=nota or "")


@app.route("/registrar/codigo", methods=["POST"])
@login_required
def registrar_codigo():
    codigo = request.form.get("codigo", "")
    if not codigo and request.files.get("foto"):
        codigo = rr.decodificar_imagen(request.files["foto"].read()) or ""
        if not codigo:
            return jsonify(ok=False, nota="No se encontró un código en la foto. Acércate, enfoca bien o escribe los números.")
    p, origen, error = rr.buscar_producto(get_db(), codigo)
    if not p:
        return jsonify(ok=False, codigo=re.sub(r"\D", "", codigo), nota=error, capturar=True)
    gramos = p.get("porcion_g") or 100
    item = rr.item_producto(p, gramos)
    item["tiempo"] = request.form.get("tiempo")
    return jsonify(ok=True, producto=p, origen=origen, items=[item])


@app.route("/registrar/producto", methods=["POST"])
@login_required
def registrar_producto():
    f = request.form
    codigo = re.sub(r"\D", "", f.get("codigo", ""))
    if not codigo or not f.get("nombre") or calc.num(f.get("kcal")) is None:
        return jsonify(ok=False, nota="Faltan datos: código, nombre y kcal por 100 g."), 400
    d = {"codigo": codigo, "nombre": f["nombre"].strip()[:120], "marca": f.get("marca", "").strip()[:60]}
    for k in ("kcal", "prot", "carb", "grasa", "fibra", "azucar", "sodio", "porcion_g"):
        d[k] = calc.num(f.get(k))
    for k in ("prot", "carb", "grasa"):
        d[k] = d[k] or 0
    d.update(porcion_desc=f.get("porcion_desc", "")[:60], fuente="Etiqueta capturada")
    rr.guardar_producto(get_db(), d, g.user["id"])
    p = rr.producto_local(get_db(), codigo)
    item = rr.item_producto(p, p.get("porcion_g") or 100)
    item["tiempo"] = f.get("tiempo")
    return jsonify(ok=True, producto=p, items=[item])


@app.route("/registrar/guardar", methods=["POST"])
@app.route("/coach/cliente/<int:cid>/registrar/guardar", methods=["POST"])
@login_required
def registrar_guardar(cid=None):
    target = _target_registro(cid)
    d = request.get_json(silent=True) or {}
    fecha = d.get("fecha") or str(dt.date.today())
    try:
        dt.date.fromisoformat(fecha)
    except ValueError:
        fecha = str(dt.date.today())
    con = get_db()
    n = 0
    for x in (d.get("items") or [])[:40]:
        nombre = str(x.get("nombre") or "").strip()[:120]
        gramos = calc.num(x.get("gramos"))
        if not nombre or not gramos or gramos <= 0:
            continue
        p100 = x.get("por100g") or {}
        val = {k: round((calc.num(p100.get(k)) or 0) * gramos / 100, 1) for k in ("kcal", "prot", "carb", "grasa")}
        fib = round(calc.num(p100.get("fibra")) * gramos / 100, 1) if calc.num(p100.get("fibra")) is not None else None
        tiempo = x.get("tiempo") if x.get("tiempo") in TIEMPOS_COMIDA else d.get("tiempo") if d.get("tiempo") in TIEMPOS_COMIDA else "Comida"
        con.execute("INSERT INTO diario_comidas (usuario_id, fecha, tiempo, alimento, porcion, gramos, kcal, prot, carb, grasa, fibra, alimento_id, fuente) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (target["id"], fecha, tiempo, nombre, str(x.get("porcion") or f"{gramos:g} g")[:120], gramos, round(val["kcal"]), val["prot"], val["carb"], val["grasa"],
                     fib, x.get("alimento_id") if isinstance(x.get("alimento_id"), int) else None, str(x.get("fuente") or "registro rápido")[:40]))
        n += 1
    sincronizar_registro(con, target["id"], fecha)
    return jsonify(ok=True, guardados=n)


# ------------------------------------------------------------------ administración (dueño de la plataforma)
def hay_admin():
    return bool(get_db().execute("SELECT 1 FROM usuarios WHERE es_admin=1 AND activo=1").fetchone())


def admin_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user:
            return redirect(url_for("login", siguiente=request.path))
        if not g.user.get("es_admin"):
            abort(403)
        return f(*a, **k)
    return w


@app.route("/admin/crear", methods=["GET", "POST"])
def admin_crear():
    """Primera configuración: crea (o promueve) la cuenta de administrador. Solo desde la computadora del servidor."""
    if not es_local():
        abort(403)
    if hay_admin() and not (g.user and g.user.get("es_admin")):
        flash("Ya existe una cuenta de administrador. Inicia sesión con ella.", "info")
        return redirect(url_for("login", siguiente=url_for("admin_panel")))
    if request.method == "POST":
        f = request.form
        nombre, email, pw = (f.get("nombre") or "").strip(), (f.get("email") or "").strip().lower(), f.get("password") or ""
        if not nombre or "@" not in email:
            flash("Escribe tu nombre y un correo válido.", "error")
        elif len(pw) < 10 or pw != f.get("password2"):
            flash("La contraseña debe tener al menos 10 caracteres y coincidir en los dos campos.", "error")
        else:
            con = get_db()
            u = con.execute("SELECT * FROM usuarios WHERE email=?", (email,)).fetchone()
            if u:
                if not check_password_hash(u["password"], pw):
                    flash("Ese correo ya tiene cuenta: escribe su contraseña actual para convertirla en administrador.", "error")
                    return render_template("admin_crear.html")
                con.execute("UPDATE usuarios SET es_admin=1, rol='entrenador', activo=1, codigo_coach=COALESCE(codigo_coach, ?) WHERE id=?",
                            ("".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6)), u["id"]))
                uid = u["id"]
            else:
                uid = db.crear_usuario(con, email, nombre, pw, rol="entrenador", perfil=db.perfil_base(inicio=str(dt.date.today())))
                con.execute("UPDATE usuarios SET es_admin=1 WHERE id=?", (uid,))
            con.commit()
            session["uid"] = uid
            flash("¡Listo! Tu cuenta de administrador tiene todo desbloqueado, sin costo.", "ok")
            return redirect(url_for("admin_panel"))
    return render_template("admin_crear.html")


@app.route("/admin", methods=["GET", "POST"])
@admin_required
def admin_panel():
    con = get_db()
    if request.method == "POST":
        f, uid = request.form, request.form.get("id")
        u = con.execute("SELECT * FROM usuarios WHERE id=?", (uid,)).fetchone()
        if not u:
            abort(404)
        acc = f.get("accion")
        if acc == "plan":
            plan = f.get("plan") if f.get("plan") in PLANES_CLAVE else "gratis"
            con.execute("UPDATE usuarios SET plan=?, plan_vence=?, plan_nota=? WHERE id=?",
                        (plan, f.get("vence") or None, (f.get("nota") or ("Cortesía" if plan != "gratis" else ""))[:120], uid))
            flash(f"{u['nombre']}: plan {PLANES_CLAVE[plan]}{' hasta ' + f['vence'] if f.get('vence') else ''}, sin costo.", "ok")
        elif acc == "rol":
            rol = "entrenador" if f.get("rol") == "entrenador" else "cliente"
            codigo = u["codigo_coach"] or "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6))
            con.execute("UPDATE usuarios SET rol=?, codigo_coach=? WHERE id=?", (rol, codigo if rol == "entrenador" else u["codigo_coach"], uid))
            flash(f"{u['nombre']} ahora es {rol}.", "ok")
        elif acc == "admin":
            if int(uid) == g.user["id"]:
                flash("No puedes quitarte a ti mismo el acceso de administrador.", "error")
            else:
                nuevo = 0 if u["es_admin"] else 1
                con.execute("UPDATE usuarios SET es_admin=?, rol=CASE WHEN ?=1 THEN 'entrenador' ELSE rol END WHERE id=?", (nuevo, nuevo, uid))
                flash(f"{u['nombre']} {'ahora es' if nuevo else 'ya no es'} administrador.", "ok")
        elif acc == "activo":
            if int(uid) == g.user["id"]:
                flash("No puedes desactivar tu propia cuenta.", "error")
            else:
                con.execute("UPDATE usuarios SET activo=? WHERE id=?", (0 if u["activo"] else 1, uid))
                flash(f"Cuenta de {u['nombre']} {'desactivada' if u['activo'] else 'activada'}.", "ok")
        elif acc == "coach":
            cid = f.get("coach_id") or None
            if cid and not con.execute("SELECT 1 FROM usuarios WHERE id=? AND rol='entrenador'", (cid,)).fetchone():
                cid = None
            con.execute("UPDATE usuarios SET coach_id=? WHERE id=?", (cid, uid))
            flash("Entrenador actualizado.", "ok")
        elif acc == "clave":
            temporal = secrets.token_urlsafe(8)
            con.execute("UPDATE usuarios SET password=? WHERE id=?", (generate_password_hash(temporal), uid))
            flash(f"Contraseña temporal de {u['nombre']}: {temporal}  — compártela en privado y pídele que la cambie.", "ok")
        con.commit()
        return redirect(url_for("admin_panel", q=request.args.get("q", ""), filtro=request.args.get("filtro", "")) + f"#u{uid}")
    q, filtro = request.args.get("q", "").strip().lower(), request.args.get("filtro", "")
    usuarios = [dict(x) for x in con.execute("SELECT * FROM usuarios ORDER BY es_admin DESC, rol DESC, nombre").fetchall()]
    coaches = [u for u in usuarios if u["rol"] == "entrenador"]
    nombres = {u["id"]: u["nombre"] for u in usuarios}
    for u in usuarios:
        u["plan_ef"] = plan_de(u)
        u["coach_nombre"] = nombres.get(u["coach_id"])
        u["clientes"] = sum(1 for x in usuarios if x["coach_id"] == u["id"])
    lista = [u for u in usuarios if (not q or q in u["nombre"].lower() or q in u["email"])
             and (not filtro or (filtro == "entrenador" and u["rol"] == "entrenador") or (filtro == "cliente" and u["rol"] == "cliente")
                  or (filtro == "pro" and u["plan_ef"]["clave"] in ("pro", "coach", "admin")) or (filtro == "inactivo" and not u["activo"]))]
    hace7 = str(dt.date.today() - dt.timedelta(days=7))
    stats = {"usuarios": len(usuarios), "entrenadores": len(coaches), "clientes": sum(1 for u in usuarios if u["rol"] == "cliente"),
             "activos7": con.execute("SELECT COUNT(DISTINCT usuario_id) FROM registros WHERE fecha>=?", (hace7,)).fetchone()[0],
             "nuevos7": sum(1 for u in usuarios if (u.get("creado") or "")[:10] >= hace7),
             "feedback": con.execute("SELECT COUNT(*) FROM feedback WHERE estado='nuevo'").fetchone()[0],
             "recaudado": con.execute("SELECT COALESCE(SUM(monto),0) FROM retos_inscritos WHERE pagado=1").fetchone()[0],
             "cortesias": sum(1 for u in usuarios if (u.get("plan") or "gratis") != "gratis")}
    return render_template("admin.html", lista=lista, coaches=coaches, stats=stats, q=q, filtro=filtro, PLANES_CLAVE=PLANES_CLAVE, hoy=str(dt.date.today()))


# ------------------------------------------------------------------ invitaciones del entrenador y ficha de ingreso
HORARIOS = ["Mañana (antes de las 10)", "Mediodía", "Tarde", "Noche", "Varía"]
TRABAJOS = [("Sedentario", "Casi todo el día sentado (oficina, escuela, manejar)"), ("Ligero", "Sentado pero camino seguido"),
            ("Moderado", "De pie buena parte del día"), ("Activo", "Trabajo físico (cargar, construir, repartir)"),
            ("Muy activo", "Trabajo muy pesado o entreno doble")]


def url_publica():
    """Dirección que funciona desde el celular del cliente (no 'localhost')."""
    base = os.environ.get("FITAPP_URL_PUBLICA")
    if base:
        return base.rstrip("/")
    host = request.host
    if host.split(":")[0] in ("localhost", "127.0.0.1", "::1", "[::1]"):
        puerto = host.rsplit(":", 1)[1] if ":" in host else ""
        return f"http://{ip_local()}" + (f":{puerto}" if puerto and puerto != "80" else "")
    return request.host_url.rstrip("/")


def qr_svg(texto, escala=5):
    try:
        import io as _io
        import segno
    except ImportError:
        return ""
    b = _io.BytesIO()
    segno.make(texto, error="m").save(b, kind="svg", scale=escala, dark="#16122B", light="#FFFFFF", xmldecl=False, border=2)
    return b.getvalue().decode()


def _invitacion(token):
    """Devuelve (coach, invitación|None, error). El token puede ser una invitación o el código general del entrenador."""
    con = get_db()
    inv = con.execute("SELECT * FROM invitaciones WHERE token=?", (token,)).fetchone()
    if inv:
        coach = con.execute("SELECT * FROM usuarios WHERE id=? AND rol='entrenador'", (inv["coach_id"],)).fetchone()
        if inv["expira"] and inv["expira"] < str(dt.date.today()):
            return coach, inv, "Esta invitación ya venció. Pídele a tu entrenador un enlace nuevo."
        if inv["max_usos"] and inv["usos"] >= inv["max_usos"]:
            return coach, inv, "Esta invitación ya se usó. Si ya tienes cuenta, inicia sesión."
        return coach, inv, None
    coach = con.execute("SELECT * FROM usuarios WHERE codigo_coach=? AND rol='entrenador'", (token.upper(),)).fetchone()
    return coach, None, (None if coach else "El enlace no es válido.")


@app.route("/coach/invitar", methods=["GET", "POST"])
@login_required
def coach_invitar():
    if g.user["rol"] != "entrenador":
        abort(403)
    con = get_db()
    if request.method == "POST":
        f = request.form
        if f.get("accion") == "cancelar":
            con.execute("UPDATE invitaciones SET expira=? WHERE id=? AND coach_id=?", (str(dt.date.today() - dt.timedelta(days=1)), f.get("id"), g.user["id"]))
            con.commit(); flash("Invitación cancelada.", "ok")
            return redirect(url_for("coach_invitar"))
        token = secrets.token_urlsafe(9)
        dias = int(calc.num(f.get("dias"), 14) or 14)
        con.execute("INSERT INTO invitaciones (token, coach_id, nombre, contacto, nota, max_usos, expira) VALUES (?,?,?,?,?,?,?)",
                    (token, g.user["id"], (f.get("nombre") or "").strip()[:80], (f.get("contacto") or "").strip()[:120], (f.get("nota") or "").strip()[:500],
                     1, str(dt.date.today() + dt.timedelta(days=max(1, min(dias, 90))))))
        con.commit()
        flash("Invitación creada. Copia el enlace o envíalo por WhatsApp.", "ok")
        return redirect(url_for("coach_invitar", nueva=token))
    base = url_publica()
    invs = []
    for x in con.execute("SELECT i.*, u.nombre AS cliente FROM invitaciones i LEFT JOIN usuarios u ON u.id=i.cliente_id WHERE i.coach_id=? ORDER BY i.id DESC LIMIT 40",
                         (g.user["id"],)).fetchall():
        d = dict(x)
        d["url"] = f"{base}/unirme/{d['token']}"
        d["estado"] = "Registrado" if d["cliente_id"] else ("Vencida" if d["expira"] and d["expira"] < str(dt.date.today()) else "Pendiente")
        invs.append(d)
    general = f"{base}/unirme/{g.user['codigo_coach']}"
    nueva = next((i for i in invs if i["token"] == request.args.get("nueva")), None)
    return render_template("coach_invitar.html", invs=invs, general=general, qr_general=qr_svg(general), nueva=nueva,
                           qr_nueva=qr_svg(nueva["url"]) if nueva else "", local=base.startswith("http://"))


def _perfil_ingreso(f):
    lugar = f.get("lugar") if f.get("lugar") in PERFILES_EQUIPO else "Gimnasio completo"
    exp = f.get("experiencia") if f.get("experiencia") in [k for k, _, _ in EXPERIENCIA] else "nunca"
    objetivo = f.get("objetivo") if f.get("objetivo") in ("Perder grasa", "Mantener", "Recomposición", "Ganar músculo") else "Mantener"
    p = db.perfil_base(inicio=str(dt.date.today()))
    p.update(sexo="Mujer" if f.get("sexo") == "Mujer" else "Hombre", edad=calc.num(f.get("edad")), peso=calc.num(f.get("peso")), talla=calc.num(f.get("talla")),
             cintura=calc.num(f.get("cintura")), cuello=None, nivel=next((n for k, _, n in EXPERIENCIA if k == exp), "Principiante"), objetivo=objetivo,
             ritmo={"Perder grasa": .5, "Ganar músculo": .25}.get(objetivo, 0), dias=int(calc.num(f.get("dias"), 3) or 3),
             duracion=int(calc.num(f.get("duracion"), 60) or 60), comidas=int(calc.num(f.get("comidas"), 4) or 4),
             actividad=f.get("actividad") if f.get("actividad") in dict(TRABAJOS) else "Ligero",
             parq=[f.get(f"parq{i}") == "si" for i in range(len(PARQ))], condiciones=[c for c in f.getlist("condiciones") if c in dict(CONDICIONES)],
             preferencias=[x for x in f.getlist("preferencias") if x in ("vegetariana", "vegana")], equipo=lugar)
    p["sondeo"] = {"experiencia": exp, "dolor": [d for d in f.getlist("dolor") if d in dict(DOLORES)], "suelo": "si", "camina10": "si",
                   "lugar": lugar, "equipo": sorted(PERFILES_EQUIPO[lugar]), "gusto": f.getlist("gusto")}
    p["ingreso"] = {k: (f.get(k) or "").strip()[:500] for k in ("telefono", "meta", "fecha_meta", "motivacion", "horario", "medicamentos", "lesiones",
                                                                "alcohol", "tabaco", "alergias", "no_gusta", "cocina", "experiencia_previa")}
    p["ingreso"].update(compromiso=int(calc.num(f.get("compromiso"), 0) or 0) or None, sueno=calc.num(f.get("sueno")), estres=int(calc.num(f.get("estres"), 0) or 0) or None,
                        fecha=str(dt.date.today()))
    return p


@app.route("/unirme/<token>", methods=["GET", "POST"])
def unirme(token):
    coach, inv, error = _invitacion(token)
    if error and not (g.user and coach and g.user.get("coach_id") == coach["id"]):
        return render_template("unirme.html", error=error, coach=coach, inv=None, token=token), 404 if not coach else 410
    # ya tiene cuenta y sesión iniciada
    if g.user:
        if g.user["id"] == coach["id"]:
            flash("Este es tu propio enlace de invitación: compártelo con tus clientes.", "info")
            return redirect(url_for("coach_invitar"))
        if g.user.get("coach_id") == coach["id"]:
            return redirect(url_for("dashboard"))
        if request.method == "POST" and request.form.get("accion") == "vincular":
            if not cupo_clientes(coach)[0]:
                flash(MSG_CUPO, "error")
                return render_template("unirme.html", coach=coach, inv=inv, token=token, vincular=True)
            get_db().execute("UPDATE usuarios SET coach_id=? WHERE id=?", (coach["id"], g.user["id"]))
            notif.avisar(get_db(), coach["id"], "cliente", f"{g.user['nombre']} se vinculó contigo", "Ya puedes ver su información.",
                         url_for("coach_cliente", cid=g.user["id"]), g.user["id"])
            get_db().execute("INSERT INTO actividad (actor_id, coach_id, tipo, texto, url, detalle, creado) VALUES (?,?,?,?,?,?,?)",
                             (g.user["id"], coach["id"], "cliente", "se vinculó contigo", url_for("coach_cliente", cid=g.user["id"]), "[]", notif.ahora()))
            if inv:
                get_db().execute("UPDATE invitaciones SET usos=usos+1, cliente_id=?, ultimo_uso=? WHERE id=?", (g.user["id"], str(dt.date.today()), inv["id"]))
            get_db().commit()
            flash(f"Listo: {coach['nombre']} ya es tu entrenador y puede ver tu información.", "ok")
            return redirect(url_for("dashboard"))
        return render_template("unirme.html", coach=coach, inv=inv, token=token, vincular=True)
    if request.method == "POST":
        f = request.form
        email, nombre, pw = (f.get("email") or "").strip().lower(), (f.get("nombre") or "").strip(), f.get("password") or ""
        faltan = [n for n, v in (("nombre", nombre), ("correo", email), ("edad", calc.num(f.get("edad"))), ("peso", calc.num(f.get("peso"))),
                                 ("estatura", calc.num(f.get("talla")))) if not v]
        error = None
        if faltan:
            error = "Falta: " + ", ".join(faltan) + "."
        elif len(pw) < 8:
            error = "La contraseña debe tener al menos 8 caracteres."
        elif not f.get("consentimiento") or not f.get("compartir"):
            error = "Para continuar acepta el aviso de privacidad y compartir tu información con tu entrenador."
        elif get_db().execute("SELECT 1 FROM usuarios WHERE email=?", (email,)).fetchone():
            error = "Ese correo ya tiene cuenta. Inicia sesión y vuelve a abrir este enlace para vincularte."
        elif not cupo_clientes(coach)[0]:
            error = MSG_CUPO
        if error:
            flash(error, "error")
            return render_template("unirme.html", coach=coach, inv=inv, token=token, f=f, P=PARQ, C=CONDICIONES, D=DOLORES, E=EXPERIENCIA,
                                   LUGARES=list(PERFILES_EQUIPO), H=HORARIOS, T=TRABAJOS, CG=CARDIO_GUSTO)
        p = _perfil_ingreso(f)
        p["ingreso"]["via"] = "invitación personal" if inv else "enlace general del entrenador"
        con = get_db()
        uid = db.crear_usuario(con, email, nombre, pw, rol="cliente", coach_id=coach["id"])
        plantilla = "casa-2" if p["equipo"] in ("Casa con mancuernas", "Solo peso corporal") and "casa-2" in PLANTILLAS else (
            "full-body-3" if p["nivel"] == "Principiante" else "torso-pierna-4")
        con.execute("UPDATE usuarios SET perfil=?, programa=? WHERE id=?", (json.dumps(p), json.dumps(PLANTILLAS[plantilla]), uid))
        if inv:
            con.execute("UPDATE invitaciones SET usos=usos+1, cliente_id=?, ultimo_uso=? WHERE id=?", (uid, str(dt.date.today()), inv["id"]))
        _bienvenida(con, uid, "cliente", coach["id"], nombre, "con tu enlace y llenó su ficha de ingreso")
        if p.get("peso"):
            con.execute("INSERT OR IGNORE INTO registros (usuario_id, fecha, peso, cintura) VALUES (?,?,?,?)", (uid, str(dt.date.today()), p["peso"], p.get("cintura")))
        con.commit()
        session["uid"] = uid
        msg = f"¡Bienvenido! {coach['nombre']} ya tiene tu información y armamos tu primer plan."
        if any(p["parq"]):
            msg += " Como respondiste «Sí» en alguna pregunta de salud, consulta a tu médico antes de entrenar fuerte."
        flash(msg, "ok")
        return redirect(url_for("plan_inteligente"))
    return render_template("unirme.html", coach=coach, inv=inv, token=token, f={}, P=PARQ, C=CONDICIONES, D=DOLORES, E=EXPERIENCIA,
                           LUGARES=list(PERFILES_EQUIPO), H=HORARIOS, T=TRABAJOS, CG=CARDIO_GUSTO)


# ------------------------------------------------------------------ retos y niveles (tiers)
def _corto(nombre):
    partes = (nombre or "").split()
    return (partes[0] + (f" {partes[1][0]}." if len(partes) > 1 else "")) if partes else "—"


def puntos_usuario(uid):
    con = get_db()
    retos_pts = con.execute("SELECT COALESCE(SUM(puntos),0) FROM retos_inscritos WHERE usuario_id=? AND completado IS NOT NULL AND (validado=1 OR puntos>0)", (uid,)).fetchone()[0]
    sesiones = con.execute("SELECT COUNT(*) FROM registros WHERE usuario_id=? AND entreno='Sí'", (uid,)).fetchone()[0]
    dias = con.execute("SELECT COUNT(DISTINCT fecha) FROM diario_comidas WHERE usuario_id=?", (uid,)).fetchone()[0]
    return {"retos": retos_pts, "constancia": sesiones * 5 + dias * 2, "total": retos_pts + sesiones * 5 + dias * 2, "sesiones": sesiones, "dias": dias}


def _prot_min(u):
    p, comp, en, mac = calcular(u)
    return minimos(p, mac)["prot_min"]


def _actualizar_reto(reto, ins, u):
    """Calcula el progreso y marca el reto como completado cuando llega a la meta."""
    con = get_db()
    valor = rt.progreso(con, reto, u["id"], _prot_min(u) if reto["tipo"] == "dias_proteina" else None)
    if ins and not ins["completado"] and valor >= reto["meta"] and (not reto["cuota"] or ins["pagado"]):
        hoy = str(dt.date.today())
        if reto["validar"]:
            con.execute("UPDATE retos_inscritos SET completado=? WHERE reto_id=? AND usuario_id=?", (hoy, reto["id"], u["id"]))
        else:
            con.execute("UPDATE retos_inscritos SET completado=?, validado=1, puntos=? WHERE reto_id=? AND usuario_id=?", (hoy, reto["puntos"], reto["id"], u["id"]))
        con.commit()
    return valor


def _reto_dict(r, u, ins=None):
    d = dict(r)
    d["estado"] = rt.estado_reto(d)
    d["tipo_txt"], d["unidad"] = rt.TIPOS_META.get(d["tipo"], (d["tipo"], ""))
    d["inscritos"] = get_db().execute("SELECT COUNT(*) FROM retos_inscritos WHERE reto_id=?", (d["id"],)).fetchone()[0]
    d["ins"] = dict(ins) if ins else None
    if ins:
        d["valor"] = _actualizar_reto(d, ins, u)
        d["ins"] = dict(get_db().execute("SELECT * FROM retos_inscritos WHERE reto_id=? AND usuario_id=?", (d["id"], u["id"])).fetchone())
        d["pct"] = min(100, round(d["valor"] / d["meta"] * 100)) if d["meta"] else 0
    return d


@app.route("/retos")
@login_required
def retos_view():
    con, u = get_db(), g.user
    pts = puntos_usuario(u["id"])
    tier = rt.tier_de(pts["total"])
    mis = {r["reto_id"]: r for r in con.execute("SELECT * FROM retos_inscritos WHERE usuario_id=?", (u["id"],)).fetchall()}
    todos = [_reto_dict(r, u, mis.get(r["id"])) for r in con.execute("SELECT * FROM retos WHERE activo=1 ORDER BY cuota>0, fin").fetchall()]
    for r in todos:
        r["precio"] = round(r["cuota"] * (1 - tier["descuento"] / 100)) if r["cuota"] else 0
    insignias = [r for r in todos if r["ins"] and r["ins"]["completado"] and r["ins"]["validado"]]
    return render_template("retos.html", pts=pts, tier=tier, TIERS=rt.TIERS, todos=todos, insignias=insignias,
                           mios=[r for r in todos if r["ins"]], disponibles=[r for r in todos if not r["ins"] and r["estado"] != "terminado"])


@app.route("/retos/<int:rid>", methods=["GET", "POST"])
@login_required
def reto_detalle(rid):
    con, u = get_db(), g.user
    r = con.execute("SELECT * FROM retos WHERE id=?", (rid,)).fetchone() or abort(404)
    ins = con.execute("SELECT * FROM retos_inscritos WHERE reto_id=? AND usuario_id=?", (rid, u["id"])).fetchone()
    tier = rt.tier_de(puntos_usuario(u["id"])["total"])
    if request.method == "POST":
        acc = request.form.get("accion")
        if acc == "inscribir" and not ins:
            n = con.execute("SELECT COUNT(*) FROM retos_inscritos WHERE reto_id=?", (rid,)).fetchone()[0]
            if r["cupo"] and n >= r["cupo"]:
                flash("El reto ya no tiene lugares.", "error")
            elif rt.estado_reto(r) == "terminado":
                flash("Este reto ya terminó.", "error")
            else:
                precio = round(r["cuota"] * (1 - tier["descuento"] / 100)) if r["cuota"] else 0
                con.execute("INSERT INTO retos_inscritos (reto_id, usuario_id, pagado, monto) VALUES (?,?,?,?)", (rid, u["id"], 0 if precio else 1, precio))
                con.commit()
                flash("¡Inscrito! Tu avance se cuenta solo con lo que registras en la app." if not precio else
                      f"Lugar apartado. Paga ${precio:,.0f} al organizador para activar tu participación.", "ok")
        elif acc == "salir" and ins and not ins["completado"]:
            if r["cuota"] and ins["pagado"]:
                flash("Ya pagaste este reto: pide la baja al organizador.", "error")
            else:
                con.execute("DELETE FROM retos_inscritos WHERE reto_id=? AND usuario_id=?", (rid, u["id"])); con.commit()
                flash("Saliste del reto.", "ok")
        elif acc == "avance" and ins and r["tipo"] == "manual":
            v = calc.num(request.form.get("valor")) or 0
            con.execute("UPDATE retos_inscritos SET progreso_manual=COALESCE(progreso_manual,0)+? WHERE reto_id=? AND usuario_id=?", (max(0, v), rid, u["id"]))
            con.commit()
        return redirect(url_for("reto_detalle", rid=rid))
    d = _reto_dict(r, u, ins)
    d["precio"] = round(d["cuota"] * (1 - tier["descuento"] / 100)) if d["cuota"] else 0
    tabla = []
    for x in con.execute("SELECT ri.*, us.nombre, us.perfil FROM retos_inscritos ri JOIN usuarios us ON us.id=ri.usuario_id WHERE reto_id=?", (rid,)).fetchall():
        if d["cuota"] and not x["pagado"]:
            continue
        uu = dict(x); uu["id"] = x["usuario_id"]
        val = rt.progreso(con, d, x["usuario_id"], _prot_min(uu) if d["tipo"] == "dias_proteina" and x["perfil"] else 0)
        tabla.append({"nombre": _corto(x["nombre"]), "valor": val, "pct": min(100, round(val / d["meta"] * 100)) if d["meta"] else 0,
                      "completado": x["completado"], "lugar": x["lugar"], "yo": x["usuario_id"] == u["id"]})
    tabla.sort(key=lambda t: (t["lugar"] or 999, -t["valor"]))
    return render_template("reto.html", r=d, tabla=tabla[:30], tier=tier)


@app.route("/coach/retos", methods=["GET", "POST"])
@login_required
def coach_retos():
    if g.user["rol"] != "entrenador":
        abort(403)
    con = get_db()
    if request.method == "POST":
        f, acc = request.form, request.form.get("accion")
        if acc == "crear":
            tipo = f.get("tipo") if f.get("tipo") in rt.TIPOS_META else "manual"
            inicio = f.get("inicio") or str(dt.date.today())
            try:
                fin = f.get("fin") or str(dt.date.fromisoformat(inicio) + dt.timedelta(days=28))
                dt.date.fromisoformat(fin)
            except ValueError:
                flash("Revisa las fechas.", "error"); return redirect(url_for("coach_retos"))
            if not f.get("titulo") or not calc.num(f.get("meta")):
                flash("Escribe un título y una meta.", "error"); return redirect(url_for("coach_retos"))
            con.execute("""INSERT INTO retos (titulo, descripcion, tipo, meta, inicio, fin, puntos, nivel, cuota, premios, cupo, validar, creador_id)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (f["titulo"][:120], (f.get("descripcion") or "")[:1500], tipo, calc.num(f.get("meta")), inicio, fin, int(calc.num(f.get("puntos")) or 100),
                         f.get("nivel") or "Todos", calc.num(f.get("cuota")) or 0, (f.get("premios") or "")[:800], int(calc.num(f.get("cupo")) or 0) or None,
                         1 if f.get("validar") else 0, g.user["id"]))
            flash("Reto publicado.", "ok")
        else:
            rid, uid = f.get("reto"), f.get("usuario")
            if acc == "pagado":
                con.execute("UPDATE retos_inscritos SET pagado=1, pago_ref=? WHERE reto_id=? AND usuario_id=?", ((f.get("ref") or "")[:80], rid, uid))
            elif acc == "validar":
                pts = con.execute("SELECT puntos FROM retos WHERE id=?", (rid,)).fetchone()[0]
                con.execute("UPDATE retos_inscritos SET validado=1, puntos=?, completado=COALESCE(completado, ?) WHERE reto_id=? AND usuario_id=?",
                            (pts, str(dt.date.today()), rid, uid))
            elif acc == "lugar":
                con.execute("UPDATE retos_inscritos SET lugar=? WHERE reto_id=? AND usuario_id=?", (int(calc.num(f.get("lugar")) or 0) or None, rid, uid))
            elif acc == "baja":
                con.execute("DELETE FROM retos_inscritos WHERE reto_id=? AND usuario_id=?", (rid, uid))
            elif acc == "archivar":
                con.execute("UPDATE retos SET activo=0 WHERE id=?", (rid,))
            flash("Cambios guardados.", "ok")
        con.commit()
        return redirect(url_for("coach_retos") + (f"#r{f.get('reto')}" if f.get("reto") else ""))
    lista = []
    for r in con.execute("SELECT * FROM retos WHERE activo=1 ORDER BY inicio DESC").fetchall():
        d = dict(r); d["estado"] = rt.estado_reto(d); d["tipo_txt"], d["unidad"] = rt.TIPOS_META.get(d["tipo"], (d["tipo"], ""))
        d["gente"] = []
        for x in con.execute("SELECT ri.*, us.nombre, us.email FROM retos_inscritos ri JOIN usuarios us ON us.id=ri.usuario_id WHERE reto_id=?", (r["id"],)).fetchall():
            uu = dict(x); uu["id"] = x["usuario_id"]
            val = rt.progreso(con, d, x["usuario_id"], 0)
            d["gente"].append(dict(x) | {"valor": val, "pct": min(100, round(val / d["meta"] * 100)) if d["meta"] else 0})
        d["gente"].sort(key=lambda x: -x["valor"])
        d["recaudado"] = sum((x["monto"] or 0) for x in d["gente"] if x["pagado"])
        lista.append(d)
    return render_template("coach_retos.html", lista=lista, TIPOS=rt.TIPOS_META, hoy=str(dt.date.today()),
                           fin=str(dt.date.today() + dt.timedelta(days=28)))


# ------------------------------------------------------------------ feedback
@app.route("/feedback", methods=["GET", "POST"])
@login_required
def feedback_view():
    con, u = get_db(), g.user
    if request.method == "POST":
        f = request.form
        if f.get("accion") == "votar":
            try:
                con.execute("INSERT INTO feedback_votos (feedback_id, usuario_id) VALUES (?,?)", (f.get("id"), u["id"]))
            except Exception:  # noqa: BLE001 - ya votó: quitar el voto
                con.execute("DELETE FROM feedback_votos WHERE feedback_id=? AND usuario_id=?", (f.get("id"), u["id"]))
            con.commit()
            return redirect(url_for("feedback_view") + "#comunidad")
        texto = (f.get("texto") or "").strip()
        if len(texto) < 5:
            flash("Cuéntanos un poco más (mínimo 5 letras).", "error")
            return redirect(url_for("feedback_view"))
        tipo = f.get("tipo") if f.get("tipo") in dict(rt.FEEDBACK_TIPOS) else "otro"
        con.execute("INSERT INTO feedback (usuario_id, tipo, area, calificacion, texto, publico) VALUES (?,?,?,?,?,?)",
                    (u["id"], tipo, f.get("area") if f.get("area") in rt.FEEDBACK_AREAS else "Otra", int(calc.num(f.get("calificacion")) or 0) or None,
                     texto[:2000], 1 if f.get("publico") and tipo in ("idea", "contenido") else 0))
        con.commit()
        flash("¡Gracias! Leemos cada mensaje y te respondemos aquí mismo.", "ok")
        return redirect(url_for("feedback_view"))
    mios = [dict(x) for x in con.execute("SELECT * FROM feedback WHERE usuario_id=? ORDER BY id DESC", (u["id"],)).fetchall()]
    comunidad = [dict(x) for x in con.execute("""SELECT f.*, (SELECT COUNT(*) FROM feedback_votos v WHERE v.feedback_id=f.id) votos,
        (SELECT COUNT(*) FROM feedback_votos v WHERE v.feedback_id=f.id AND v.usuario_id=?) yo FROM feedback f
        WHERE publico=1 AND estado!='descartado' ORDER BY votos DESC, id DESC LIMIT 40""", (u["id"],)).fetchall()]
    return render_template("feedback.html", mios=mios, comunidad=comunidad, TIPOS=rt.FEEDBACK_TIPOS, AREAS=rt.FEEDBACK_AREAS,
                           ESTADOS=dict(rt.FEEDBACK_ESTADOS))


@app.route("/coach/feedback", methods=["GET", "POST"])
@login_required
def coach_feedback():
    if g.user["rol"] != "entrenador":
        abort(403)
    con = get_db()
    if request.method == "POST":
        f = request.form
        con.execute("UPDATE feedback SET estado=?, respuesta=?, respondio_id=?, actualizado=? WHERE id=?",
                    (f.get("estado") if f.get("estado") in dict(rt.FEEDBACK_ESTADOS) else "revision", (f.get("respuesta") or "").strip()[:1500] or None,
                     g.user["id"], str(dt.date.today()), f.get("id")))
        con.commit()
        flash("Respuesta guardada: la persona la verá en su sección de feedback.", "ok")
        return redirect(url_for("coach_feedback", estado=request.args.get("estado", "")) + f"#f{f.get('id')}")
    est = request.args.get("estado", "")
    filas = [dict(x) for x in con.execute(f"""SELECT f.*, u.nombre, (SELECT COUNT(*) FROM feedback_votos v WHERE v.feedback_id=f.id) votos
        FROM feedback f JOIN usuarios u ON u.id=f.usuario_id {"WHERE f.estado=?" if est else ""} ORDER BY f.estado='nuevo' DESC, votos DESC, f.id DESC""",
                                              (est,) if est else ()).fetchall()]
    cal = [x["calificacion"] for x in con.execute("SELECT calificacion FROM feedback WHERE calificacion IS NOT NULL").fetchall()]
    resumen = {"total": con.execute("SELECT COUNT(*) FROM feedback").fetchone()[0],
               "nuevos": con.execute("SELECT COUNT(*) FROM feedback WHERE estado='nuevo'").fetchone()[0],
               "promedio": round(sum(cal) / len(cal), 1) if cal else None,
               "por_tipo": dict(con.execute("SELECT tipo, COUNT(*) FROM feedback GROUP BY tipo").fetchall())}
    return render_template("coach_feedback.html", filas=filas, resumen=resumen, TIPOS=dict(rt.FEEDBACK_TIPOS), ESTADOS=rt.FEEDBACK_ESTADOS, est=est)


# ------------------------------------------------------------------ sondeo avanzado
def _num(v):
    return calc.num(v)


def datos_avanzado(p):
    av = p.get("avanzado") or {}
    filas, total = pa.fuerza(p.get("sexo", "Hombre"), p.get("peso"), av.get("marcas") or {})
    nivel, _ = pa.clasificar(av, filas) if av else (None, None)
    rec = pa.recomendaciones(nivel, av, p) if nivel else None
    return dict(av=av, filas=filas, total=total, nivel_det=nivel, rec=rec, semanas=pa.semanas_para(av.get("fecha_comp")))


def vista_sondeo_avanzado(target, es_coach, url_self):
    p = perfil(target)
    if request.method == "POST":
        f = request.form
        av = dict(p.get("avanzado") or {})
        for k in ("anios", "meses", "dias_actual", "duracion_actual", "sueno", "estres", "kcal_actual", "peso_tarima", "peso_offseason",
                  "peso", "grasa", "mlg"):
            av[k] = _num(f.get(k))
        for k in ("constancia", "split", "disciplina", "compite", "federacion", "categoria", "fecha_comp", "metodo_comp", "lesiones",
                  "analisis", "fecha_analisis", "sustancias", "historial_dietas", "objetivo_detalle", "metas_fuerza", "modo", "entrenador_previo"):
            av[k] = (f.get(k) or "").strip()[:600]
        av["suplementos"] = [s for s in f.getlist("suplementos") if s in pa.SUPLEMENTOS]
        av["debiles"] = [s for s in f.getlist("debiles") if s in pa.MUSCULOS_DEBILES]
        av["marcas"] = {k: {"peso": _num(f.get(f"{k}_peso")), "reps": int(_num(f.get(f"{k}_reps")) or 0) or None}
                        for k, _, _ in pa.LEVANTAMIENTOS if _num(f.get(f"{k}_reps"))}
        av["actualizado"] = str(dt.date.today())
        av["autor"] = g.user["nombre"]
        if av.get("modo") not in [m for m, _, _ in pa.MODOS]:
            av["modo"] = "completo"
        # composición: actualiza el perfil
        if av.get("peso"):
            p["peso"] = av["peso"]
        if av.get("grasa"):
            p["grasa_medida"] = round(av["grasa"], 1)
        elif av.get("mlg") and av.get("peso") and av["mlg"] < av["peso"]:
            p["grasa_medida"] = round((1 - av["mlg"] / av["peso"]) * 100, 1)
        filas, _ = pa.fuerza(p.get("sexo", "Hombre"), p.get("peso"), av["marcas"])
        av["nivel"], p["nivel"] = pa.clasificar(av, filas)
        p["avanzado"] = av
        guardar(target, "perfil", p)
        flash(f"Sondeo avanzado guardado. Tu nivel: {av['nivel']}. Ajustamos recomendaciones, volumen y cargas iniciales.", "ok")
        return redirect(url_self + "#resultado")
    d = datos_avanzado(p)
    from data.contenido import PLANTILLAS as PL
    plantilla = PL.get(pa.ENFOQUE[d["nivel_det"]]["plantilla"]) if d["nivel_det"] else None
    n_fotos = get_db().execute("SELECT COUNT(*) FROM fotos WHERE usuario_id=?", (target["id"],)).fetchone()[0]
    return render_template("sondeo_avanzado.html", target=target, es_coach=es_coach, p=p, PA=pa, plantilla=plantilla, n_fotos=n_fotos,
                           url_self=url_self, hoy=str(dt.date.today()), **d)


@app.route("/sondeo-avanzado", methods=["GET", "POST"])
@login_required
def sondeo_avanzado():
    return vista_sondeo_avanzado(g.user, False, url_for("sondeo_avanzado"))


@app.route("/coach/cliente/<int:cid>/sondeo-avanzado", methods=["GET", "POST"])
@login_required
def coach_sondeo_avanzado(cid):
    return vista_sondeo_avanzado(_cliente_de_coach(cid), True, url_for("coach_sondeo_avanzado", cid=cid))


@app.route("/sondeo-avanzado/aplicar-programa", methods=["POST"])
@login_required
def aplicar_programa_nivel():
    p = perfil(g.user)
    d = datos_avanzado(p)
    if d["nivel_det"]:
        from data.contenido import PLANTILLAS as PL
        clave = pa.ENFOQUE[d["nivel_det"]]["plantilla"]
        guardar(g.user, "programa", PL[clave])
        flash(f"Programa «{PL[clave]['nombre']}» aplicado. Las cargas iniciales salen de tus marcas.", "ok")
    return redirect(url_for("programa_view"))


@app.route("/sondeo-avanzado/pdf")
@app.route("/coach/cliente/<int:cid>/sondeo-avanzado/pdf")
@login_required
def sondeo_avanzado_pdf(cid=None):
    target = _cliente_de_coach(cid) if cid else g.user
    p = perfil(target)
    d = datos_avanzado(p)
    return pdf_resp("Perfil avanzado", _bloques_avanzado(p, d), f"{target['nombre']} · nivel {d['nivel_det'] or '—'}")


def _bloques_avanzado(p, d):
    av = d["av"]
    if not av:
        return [("p", "Todavía no se ha llenado el sondeo avanzado.")]
    comp_txt = dict(pa.COMPETENCIA).get(av.get("compite"), "—")
    b = [("metricas", [("Nivel", d["nivel_det"] or "—", ""), ("Años entrenando", _f((av.get("anios") or 0) + (av.get("meses") or 0) / 12, 1), ""),
                       ("Total SBD (e1RM)", _f(d["total"]) if d["total"] else "—", "kg"), ("Peso", _f(p.get("peso"), 1), "kg")]),
         ("h", "Experiencia y entrenamiento"),
         ("kv", [(k, v) for k, v in [("Disciplina", av.get("disciplina")), ("Constancia", av.get("constancia")), ("Rutina actual", av.get("split")),
                                     ("Días por semana", _f(av.get("dias_actual"))), ("Duración de la sesión", f"{_f(av.get('duracion_actual'))} min" if av.get("duracion_actual") else None),
                                     ("Competencia", comp_txt), ("Federación / categoría", " · ".join(x for x in (av.get("federacion"), av.get("categoria")) if x)),
                                     ("Próxima competencia", f"{av.get('fecha_comp')} ({d['semanas']:g} semanas)" if d["semanas"] is not None else av.get("fecha_comp")),
                                     ("Peso en tarima / fuera de temporada", " / ".join(f"{x:g} kg" for x in (av.get("peso_tarima"), av.get("peso_offseason")) if x))] if v])]
    if d["filas"]:
        b += [("h", "Marcas de fuerza"),
              ("tabla", ["Ejercicio", "Serie", "1RM estimado", "× peso corporal", "Nivel", "Para el siguiente nivel"],
               [[f["nombre"], f"{f['peso'] or 0:g} kg × {f['reps']}", f"{f['e1rm']:.0f} kg", f"{f['relativo']:.2f}", f["nivel"],
                 f"{f['siguiente']:.0f} kg ({f['siguiente_nivel']})" if f["siguiente"] else "—"] for f in d["filas"]], [2.4, 1.2, 1.1, 1, 1, 1.6])]
    b += [("h", "Composición y salud"),
          ("kv", [(k, v) for k, v in [("% de grasa", f"{av['grasa']:g} % ({av.get('metodo_comp') or 'método no indicado'})" if av.get("grasa") else None),
                                      ("Masa magra", f"{av['mlg']:g} kg" if av.get("mlg") else None), ("Sueño", f"{av['sueno']:g} h" if av.get("sueno") else None),
                                      ("Estrés (1-5)", _f(av.get("estres"))), ("Lesiones", av.get("lesiones")),
                                      ("Análisis de sangre", f"{av.get('analisis')} {av.get('fecha_analisis') or ''}".strip()),
                                      ("Sustancias para el rendimiento", {"no": "No", "si": "Sí (requiere seguimiento médico)", "nd": "Prefiere no decir"}.get(av.get("sustancias"))),
                                      ("Calorías actuales", f"{_f(av.get('kcal_actual'))} kcal" if av.get("kcal_actual") else None),
                                      ("Suplementos", ", ".join(av.get("suplementos") or [])), ("Historial de dietas", av.get("historial_dietas"))] if v])]
    b += [("h", "Objetivos"), ("kv", [(k, v) for k, v in [("Objetivo", av.get("objetivo_detalle")), ("Metas de fuerza", av.get("metas_fuerza")),
                                                          ("Puntos débiles", ", ".join(av.get("debiles") or []))] if v])]
    if d["rec"]:
        r = d["rec"]
        b += [("h", f"Enfoque recomendado · {d['nivel_det']}" + (f" · {r['fase']}" if r.get("fase") else "")),
              ("kv", [("Días", r["dias"]), ("Volumen", r["volumen"]), ("Esfuerzo", r["esfuerzo"]), ("Progresión", r["progresion"]), ("Prioridad", r["prioridad"])])]
        if r["extra"]:
            b.append(("lista", r["extra"]))
    b.append(("nota", "Estándares de fuerza orientativos. Volumen: Schoenfeld 2017. Preparación: Helms 2014; fuera de temporada: Iraki 2019; semana pico: Escalante 2021."))
    return b


# ------------------------------------------------------------------ fotos de progreso (privadas)
FOTOS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fotos")
ANGULOS = ["Frente", "Perfil", "Espalda", "Pose libre"]
FIRMAS = {b"\xff\xd8\xff": ".jpg", b"\x89PNG": ".png"}


def _ext_imagen(datos):
    for firma, ext in FIRMAS.items():
        if datos.startswith(firma):
            return ext
    if datos[:4] == b"RIFF" and datos[8:12] == b"WEBP":
        return ".webp"
    return None


def _puede_ver_fotos(uid):
    if g.user["id"] == uid:
        return True
    u = get_db().execute("SELECT coach_id FROM usuarios WHERE id=?", (uid,)).fetchone()
    return bool(u and u["coach_id"] == g.user["id"] and g.user["rol"] == "entrenador")


def vista_fotos(target, es_coach, url_self):
    con = get_db()
    if request.method == "POST":
        if request.form.get("accion") == "borrar":
            f = con.execute("SELECT * FROM fotos WHERE id=? AND usuario_id=?", (request.form.get("id"), target["id"])).fetchone()
            if f:
                try:
                    os.remove(os.path.join(FOTOS_DIR, f["archivo"]))
                except OSError:
                    pass
                con.execute("DELETE FROM fotos WHERE id=?", (f["id"],)); con.commit()
                flash("Foto eliminada.", "ok")
            return redirect(url_self)
        fecha = request.form.get("fecha") or str(dt.date.today())
        try:
            dt.date.fromisoformat(fecha)
        except ValueError:
            fecha = str(dt.date.today())
        angulo = request.form.get("angulo") if request.form.get("angulo") in ANGULOS else "Pose libre"
        n = 0
        for archivo in request.files.getlist("fotos")[:6]:
            datos = archivo.read(15 * 1024 * 1024 + 1)
            ext = _ext_imagen(datos)
            if not ext or len(datos) > 15 * 1024 * 1024:
                flash(f"«{archivo.filename}» no es una imagen JPG, PNG o WEBP válida (máximo 15 MB).", "error")
                continue
            carpeta = os.path.join(FOTOS_DIR, str(target["id"]))
            os.makedirs(carpeta, exist_ok=True)
            nombre = f"{target['id']}/{fecha}-{secrets.token_hex(8)}{ext}"
            with open(os.path.join(FOTOS_DIR, nombre), "wb") as fh:
                fh.write(datos)
            con.execute("INSERT INTO fotos (usuario_id, autor_id, fecha, angulo, archivo, peso, nota) VALUES (?,?,?,?,?,?,?)",
                        (target["id"], g.user["id"], fecha, angulo, nombre, calc.num(request.form.get("peso")), (request.form.get("nota") or "")[:300]))
            n += 1
        con.commit()
        if n:
            flash(f"{n} foto{'s' if n > 1 else ''} guardada{'s' if n > 1 else ''}. Solo tú{' y tu entrenador' if target.get('coach_id') else ''} pueden verlas.", "ok")
        return redirect(url_self)
    fotos = [dict(x) for x in con.execute("SELECT * FROM fotos WHERE usuario_id=? ORDER BY fecha DESC, id DESC", (target["id"],)).fetchall()]
    fechas = sorted({f["fecha"] for f in fotos}, reverse=True)
    por_fecha = {fe: [f for f in fotos if f["fecha"] == fe] for fe in fechas}
    return render_template("fotos.html", target=target, es_coach=es_coach, fotos=fotos, fechas=fechas, por_fecha=por_fecha, ANGULOS=ANGULOS,
                           url_self=url_self, hoy=str(dt.date.today()), peso=perfil(target).get("peso"))


@app.route("/fotos", methods=["GET", "POST"])
@login_required
def fotos_progreso():
    return vista_fotos(g.user, False, url_for("fotos_progreso"))


@app.route("/coach/cliente/<int:cid>/fotos", methods=["GET", "POST"])
@login_required
def coach_fotos(cid):
    return vista_fotos(_cliente_de_coach(cid), True, url_for("coach_fotos", cid=cid))


@app.route("/fotos/archivo/<int:fid>")
@login_required
def foto_archivo(fid):
    f = get_db().execute("SELECT * FROM fotos WHERE id=?", (fid,)).fetchone()
    if not f or not _puede_ver_fotos(f["usuario_id"]):
        abort(404)
    ruta = os.path.realpath(os.path.join(FOTOS_DIR, f["archivo"]))
    if not ruta.startswith(os.path.realpath(FOTOS_DIR) + os.sep) or not os.path.exists(ruta):
        abort(404)
    resp = send_file(ruta, max_age=0)
    resp.headers["Cache-Control"] = "private, no-store"
    return resp



# ------------------------------------------------------------------ Pro: ajuste automático y descargas
@app.route("/nutricion/auto-kcal", methods=["POST"])
@login_required
@pro_required
def auto_kcal():
    p = perfil(g.user)
    p["auto_kcal"] = bool(request.form.get("activar"))
    p.pop("kcal_ajuste", None)
    guardar(g.user, "perfil", p)
    flash("Ajuste semanal automático activado: cada semana revisamos tu peso real y ajustamos tus calorías." if p["auto_kcal"]
          else "Ajuste automático desactivado: tus calorías vuelven al cálculo por fórmula.", "ok")
    return redirect(url_for("dashboard") if p["auto_kcal"] else url_for("nutricion"))


INTERVALO_DESCARGA = {"Novato": 10, "Principiante": 8, "Intermedio": 6, "Avanzado": 5, "Élite": 4}


def descarga_estado(u, p=None):
    """Periodización automática: ¿toca semana de descarga? Por calendario según nivel o por estancamiento de la fuerza."""
    p = p or perfil(u)
    hoy = dt.date.today()
    if p.get("descarga_hasta") and p["descarga_hasta"] >= str(hoy):
        return {"activa": True, "hasta": p["descarga_hasta"]}
    nivel = (p.get("avanzado") or {}).get("nivel") or p.get("nivel", "Intermedio")
    cada = INTERVALO_DESCARGA.get(nivel, 6)
    try:
        desde = dt.date.fromisoformat(p.get("ultima_descarga") or p.get("inicio") or str(hoy))
    except ValueError:
        desde = hoy
    semanas = (hoy - desde).days / 7
    pf = progreso_fuerza(u["id"])
    recientes = [r for r in pf.values() if r["series"] >= 6 and str(r["ultima"]["fecha"]) >= str(hoy - dt.timedelta(days=10))]
    estancados = [r["ejercicio"] for r in recientes if str(r["fecha_mejor"]) < str(hoy - dt.timedelta(days=21))]
    motivo = None
    if semanas >= cada:
        motivo = f"Llevas {semanas:.0f} semanas entrenando desde tu última descarga (para nivel {nivel.lower()} se recomienda cada {cada})."
    elif semanas >= 3 and recientes and len(estancados) >= max(2, len(recientes) / 2):
        motivo = f"Tu fuerza no ha subido en 3 semanas en {', '.join(estancados[:3])}: una semana ligera suele destrabarla."
    return {"activa": False, "recomendada": bool(motivo), "motivo": motivo, "semanas": round(semanas, 1), "cada": cada}


@app.route("/descarga", methods=["POST"])
@login_required
@pro_required
def descarga():
    p = perfil(g.user)
    if request.form.get("accion") == "activar":
        p["descarga_hasta"] = str(dt.date.today() + dt.timedelta(days=6))
        p["ultima_descarga"] = str(dt.date.today())
        flash("Semana de descarga activada: mitad de series y 2 repeticiones más en reserva por 7 días. Tu cuerpo lo agradecerá.", "ok")
    elif request.form.get("accion") == "posponer":
        p["ultima_descarga"] = str(dt.date.today() - dt.timedelta(days=7 * max(0, INTERVALO_DESCARGA.get(p.get("nivel"), 6) - 1)))
        flash("Listo, te lo recordamos la próxima semana.", "ok")
    else:
        p.pop("descarga_hasta", None)
        flash("Semana de descarga terminada.", "ok")
    guardar(g.user, "perfil", p)
    return redirect(url_for("sesion_view"))



@app.route("/reporte-mensual.pdf")
@app.route("/coach/cliente/<int:cid>/reporte-mensual.pdf")
@login_required
@pro_required
def reporte_mensual_pdf(cid=None):
    """Pro: resumen del mes en lenguaje sencillo, para la persona, su médico o su entrenador."""
    u = _cliente_de_coach(cid) if cid else g.user
    hoy = dt.date.today()
    try:
        anio, mes = map(int, (request.args.get("mes") or hoy.strftime("%Y-%m")).split("-"))
        ini = dt.date(anio, mes, 1)
    except ValueError:
        ini = hoy.replace(day=1)
    fin = (ini + dt.timedelta(days=32)).replace(day=1) - dt.timedelta(days=1)
    fin_real = min(fin, hoy)
    p, comp, en, mac = calcular(u)
    logs = [l for l in registros(u["id"], ini) if l["fecha"] <= fin]
    ses = sum(1 for l in logs if l.get("entreno") == "Sí")
    semanas = max(1, ((fin_real - ini).days + 1) / 7)
    plan = p["dias"] * semanas
    pesos = [l["peso"] for l in logs if l["peso"]]
    tr = [t for t in calc.tendencia(pesos) if t is not None]
    kc = [l["kcal"] for l in logs if l.get("kcal")]
    pr_ = [l["proteina"] for l in logs if l.get("proteina")]
    sueno = [l["sueno"] for l in logs if l.get("sueno")]
    pasos = [l["pasos"] for l in logs if l.get("pasos")]
    pts = []
    d = ini
    while d <= fin_real:
        a = puntaje_de(u, str(d))
        if a["n"]:
            pts.append(a["total"])
        d += dt.timedelta(days=1)
    ser = series_de(u["id"], desde=ini)
    ser = [s for s in ser if s["fecha"] <= str(fin)]
    ton = sum((s["peso"] or 0) * s["reps"] for s in ser)
    mejores = {}
    for s in ser:
        e = calc.e1rm(s["peso"], s["reps"], s["rir"])
        if e:
            mejores.setdefault(s["ejercicio"], []).append((s["fecha"], e))
    cambios = []
    for ej, xs in mejores.items():
        xs.sort()
        if len(xs) >= 3:
            ini_e, fin_e = max(e for f, e in xs[:max(1, len(xs) // 3)]), max(e for f, e in xs[-max(1, len(xs) // 3):])
            cambios.append((ej, ini_e, fin_e, (fin_e / ini_e - 1) * 100 if ini_e else 0))
    cambios.sort(key=lambda x: -x[3])
    retos_ok = get_db().execute("SELECT r.titulo FROM retos_inscritos ri JOIN retos r ON r.id=ri.reto_id WHERE ri.usuario_id=? AND ri.completado BETWEEN ? AND ?",
                                (u["id"], str(ini), str(fin))).fetchall()
    cambio_peso = (tr[-1] - tr[0]) if len(tr) >= 2 else None
    # mensajes sencillos
    logros, mejorar = [], []
    adh = ses / plan if plan else 0
    (logros if adh >= .75 else mejorar).append(f"Entrenaste {ses} veces de {plan:.0f} planeadas ({adh * 100:.0f} %)." + ("" if adh >= .75 else " Meta para el próximo mes: no faltar más de 1 vez por semana."))
    if cambio_peso is not None:
        obj = p["objetivo"]
        bien = (obj in ("Perder grasa", "Recomposición") and cambio_peso < 0) or (obj == "Ganar músculo" and cambio_peso > 0) or (obj == "Mantener" and abs(cambio_peso) < 1)
        (logros if bien else mejorar).append(f"Tu peso promedio cambió {cambio_peso:+.1f} kg en el mes (objetivo: {obj.lower()}).")
    if pr_:
        prom = sum(pr_) / len(pr_)
        (logros if prom >= mac["prot"] * .9 else mejorar).append(f"Proteína promedio: {prom:.0f} g al día (tu meta: {mac['prot']:.0f} g).")
    if sueno:
        sp = sum(sueno) / len(sueno)
        (logros if sp >= 7 else mejorar).append(f"Dormiste en promedio {sp:.1f} horas." + ("" if sp >= 7 else " Dormir 7 o más horas mejora la recuperación y el apetito."))
    if cambios and cambios[0][3] > 0:
        logros.append(f"Tu mayor avance de fuerza: {cambios[0][0]} (+{cambios[0][3]:.0f} %).")
    if not logs:
        mejorar.append("No hubo registros este mes: registra tu peso y tus entrenamientos para ver tu avance.")
    b = [("metricas", [("Entrenamientos", str(ses), f"de {plan:.0f}"), ("Cambio de peso", f"{cambio_peso:+.1f}" if cambio_peso is not None else "—", "kg"),
                       ("Puntaje nutricional", str(round(sum(pts) / len(pts))) if pts else "—", "promedio"), ("Kilos levantados", f"{ton / 1000:,.1f}", "toneladas")]),
         ("h", "Lo que salió bien"), ("lista", logros or ["Este mes es tu punto de partida: lo importante es registrar."]),
         ("h", "Para el próximo mes"), ("lista", mejorar or ["Sigue igual: vas por buen camino. Sube un poco las cargas cuando completes todas las repeticiones."]),
         ("h", "Tus números"),
         ("kv", [("Registros del mes", str(len(logs)))] + [(k, v) for k, v in [("Peso al inicio / al final (tendencia)", f"{tr[0]:.1f} → {tr[-1]:.1f} kg" if len(tr) >= 2 else None),
                                     ("Calorías promedio", f"{sum(kc) / len(kc):,.0f} kcal (meta {mac['kcal']:,.0f})" if kc else None),
                                     ("Proteína promedio", f"{sum(pr_) / len(pr_):.0f} g (meta {mac['prot']:.0f} g)" if pr_ else None),
                                     ("Pasos promedio", f"{sum(pasos) / len(pasos):,.0f} al día" if pasos else None),
                                     ("Sueño promedio", f"{sum(sueno) / len(sueno):.1f} h" if sueno else None),
                                     ("Días con comidas registradas", str(len(pts)) if pts else None),
                                     ("Retos completados", ", ".join(r["titulo"] for r in retos_ok) if retos_ok else None)] if v])]
    if cambios:
        b += [("h", "Fuerza (máximo estimado)"), ("tabla", ["Ejercicio", "Inicio del mes", "Final del mes", "Cambio"],
                                                 [[e, f"{a:.0f} kg", f"{z:.0f} kg", f"{c:+.0f} %"] for e, a, z, c in cambios[:8]], [3, 1.2, 1.2, 1])]
    meds = [m for m in lista_mediciones(u["id"]) if str(ini) <= m["fecha"] <= str(fin)]
    if meds:
        filas = []
        for m in meds:
            r = antro.calcular(p, m["datos"])
            filas.append([m["fecha"], _f(r["peso"], 1), _f(r.get("grasa"), 1), _f(r.get("mlg"), 1), _f(m["datos"].get("cintura"), 1)])
        b += [("h", "Mediciones del mes"), ("tabla", ["Fecha", "Peso", "% grasa", "Masa magra", "Cintura"], filas, [1.3, 1, 1, 1, 1])]
    if pts:
        b.append(("p", "Puntaje nutricional: 70 o más es un día bueno. Revisa «Lo que te falta» en la app para subirlo."))
    b.append(("nota", "Reporte educativo generado con tus registros. Compártelo con tu médico, nutriólogo o entrenador si lo necesitas."))
    meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    return pdf_resp(f"Reporte de {meses[ini.month - 1]} {ini.year}", b, f"{u['nombre']} · {p['objetivo']}")


# ------------------------------------------------------------------ API para la app móvil (v1)
import hashlib as _hashlib

API_INTENTOS = {}   # ip -> [marcas de tiempo] (freno a intentos de contraseña)


def _api_err(msg, codigo=400):
    return jsonify(ok=False, error=msg), codigo


def _hash_token(t):
    return _hashlib.sha256(t.encode()).hexdigest()


def api_auth(rol=None):
    """Autentica con 'Authorization: Bearer <token>'. Pone el usuario en g.user."""
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            h = request.headers.get("Authorization", "")
            if not h.startswith("Bearer "):
                return _api_err("Falta el token (Authorization: Bearer …).", 401)
            con = get_db()
            t = con.execute("SELECT * FROM api_tokens WHERE hash=?", (_hash_token(h[7:].strip()),)).fetchone()
            u = con.execute("SELECT * FROM usuarios WHERE id=?", (t["usuario_id"],)).fetchone() if t else None
            if not u or u["activo"] == 0:
                return _api_err("Token inválido o revocado.", 401)
            con.execute("UPDATE api_tokens SET ultimo_uso=? WHERE id=?", (dt.datetime.now().strftime("%Y-%m-%d %H:%M"), t["id"])); con.commit()
            g.user = dict(u)
            if rol == "entrenador" and g.user["rol"] != "entrenador":
                return _api_err("Solo para entrenadores.", 403)
            if not g.user.get("perfil") and request.endpoint not in ("api_yo",):
                return _api_err("Completa tu perfil (sondeo) antes de usar esta función.", 409)
            return f(*a, **k)
        return w
    return deco


def _usuario_json(u):
    p = perfil(u) if u.get("perfil") else {}
    return {"id": u["id"], "nombre": u["nombre"], "email": u["email"], "rol": u["rol"], "es_admin": bool(u.get("es_admin")),
            "plan": plan_de(u), "coach_id": u.get("coach_id"), "codigo_coach": u.get("codigo_coach") if u["rol"] == "entrenador" else None,
            "perfil_completo": bool(u.get("perfil")), "objetivo": p.get("objetivo"), "nivel": p.get("nivel"), "sexo": p.get("sexo"),
            "peso": p.get("peso"), "talla": p.get("talla")}


@app.route("/api/v1/login", methods=["POST"])
def api_login():
    import time
    ip, ahora = request.remote_addr or "?", time.time()
    API_INTENTOS[ip] = [x for x in API_INTENTOS.get(ip, []) if ahora - x < 300]
    if len(API_INTENTOS[ip]) >= 8:
        return _api_err("Demasiados intentos. Espera 5 minutos.", 429)
    d = request.get_json(silent=True) or {}
    u = get_db().execute("SELECT * FROM usuarios WHERE email=?", ((d.get("email") or "").strip().lower(),)).fetchone()
    if not u or not check_password_hash(u["password"], d.get("password") or ""):
        API_INTENTOS[ip].append(ahora)
        return _api_err("Correo o contraseña incorrectos.", 401)
    if u["activo"] == 0:
        return _api_err("Cuenta desactivada.", 403)
    token = secrets.token_urlsafe(32)
    get_db().execute("INSERT INTO api_tokens (hash, usuario_id, dispositivo) VALUES (?,?,?)", (_hash_token(token), u["id"], (d.get("dispositivo") or "App móvil")[:80]))
    get_db().commit()
    return jsonify(ok=True, token=token, usuario=_usuario_json(dict(u)))


@app.route("/api/v1/logout", methods=["POST"])
@api_auth()
def api_logout():
    get_db().execute("DELETE FROM api_tokens WHERE hash=?", (_hash_token(request.headers["Authorization"][7:].strip()),)); get_db().commit()
    return jsonify(ok=True)


@app.route("/api/v1/yo")
@api_auth()
def api_yo():
    out = _usuario_json(g.user)
    if g.user.get("perfil"):
        p, comp, en, mac = calcular(g.user)
        out["metas"] = {k: round(mac[k]) for k in ("kcal", "prot", "carb", "grasa")} | {"fibra": round(mac["fibra"]), "agua_l": round(mac["agua"], 1),
                                                                                       "ajuste_automatico": bool(p.get("auto_kcal"))}
        out["composicion"] = {"grasa_pct": round(comp["grasa"] * 100, 1) if comp.get("grasa") else None, "masa_magra": round(comp["mlg"], 1) if comp.get("mlg") else None}
    return jsonify(ok=True, usuario=out)


@app.route("/api/v1/hoy")
@api_auth()
def api_hoy():
    hoy = dt.date.today()
    x = datos_sesion(programa(g.user), str(hoy), hoy, request.args.get("dia"))
    p, comp, en, mac = calcular(g.user)
    filas = filas_dia(g.user["id"], str(hoy))
    a = pnt.analizar(filas, mac, minimos(p, mac), p["peso"])
    return jsonify(ok=True, fecha=str(hoy), entrenamiento={
        "dia": x["dia"]["nombre"], "descarga": x["descarga"],
        "ejercicios": [{"ejercicio": pl["e"]["ex"], "slug": pl["info"].get("slug"), "series": pl["e"]["series"], "reps": [pl["e"]["rmin"], pl["e"]["rmax"]],
                        "rir": pl["e"]["rir"], "descanso_s": pl["e"]["descanso"], "sugerencia": pl["sug"][1] if pl["sug"] else None,
                        "hechas": [{"peso": s["peso"], "reps": s["reps"], "rir": s["rir"]} for s in pl["hechas"]]} for pl in x["planes"]]},
        nutricion={"metas": {k: round(mac[k]) for k in ("kcal", "prot", "carb", "grasa")}, "consumido": {k: round(a["tot"][k]) for k in ("kcal", "prot", "carb", "grasa")},
                   "puntaje": a["total"] if a["n"] else None, "etiqueta": a["etiqueta"] if a["n"] else None,
                   "te_falta": [{"titulo": s_["titulo"], "nivel": s_["nivel"], "texto": s_["texto"]} for s_ in a["sugerencias"]]})


@app.route("/api/v1/comidas/interpretar", methods=["POST"])
@api_auth()
def api_comidas_interpretar():
    d = request.get_json(silent=True) or {}
    items, faltan = rr.interpretar_texto((d.get("texto") or "")[:2000], tiempo=d.get("tiempo"))
    return jsonify(ok=True, items=items, no_reconocidos=faltan)


@app.route("/api/v1/comidas", methods=["GET", "POST"])
@api_auth()
def api_comidas():
    if request.method == "POST":
        return registrar_guardar()          # mismo formato: {fecha, tiempo, items:[{nombre, gramos, por100g, tiempo, porcion}]}
    fecha = request.args.get("fecha") or str(dt.date.today())
    filas = filas_dia(g.user["id"], fecha)
    return jsonify(ok=True, fecha=fecha, comidas=[{k: f[k] for k in ("id", "tiempo", "alimento", "porcion", "gramos", "kcal", "prot", "carb", "grasa")} for f in filas],
                   totales={k: round(sum((f[k] or 0) for f in filas), 1) for k in ("kcal", "prot", "carb", "grasa")})


@app.route("/api/v1/registro", methods=["POST"])
@api_auth()
def api_registro():
    """Peso, pasos, sueño y si entrenó hoy (o en 'fecha'). Solo actualiza los campos enviados."""
    d = request.get_json(silent=True) or {}
    fecha = d.get("fecha") or str(dt.date.today())
    try:
        dt.date.fromisoformat(fecha)
    except ValueError:
        return _api_err("Fecha inválida (AAAA-MM-DD).")
    con = get_db()
    if not con.execute("SELECT 1 FROM registros WHERE usuario_id=? AND fecha=?", (g.user["id"], fecha)).fetchone():
        con.execute("INSERT INTO registros (usuario_id, fecha) VALUES (?,?)", (g.user["id"], fecha))
    for k in ("peso", "pasos", "sueno", "cintura", "energia"):
        if d.get(k) is not None and calc.num(d.get(k)) is not None:
            con.execute(f"UPDATE registros SET {k}=? WHERE usuario_id=? AND fecha=?", (calc.num(d[k]), g.user["id"], fecha))
    if d.get("entreno") in ("Sí", "No", "Descanso"):
        con.execute("UPDATE registros SET entreno=? WHERE usuario_id=? AND fecha=?", (d["entreno"], g.user["id"], fecha))
    con.commit()
    return jsonify(ok=True, fecha=fecha)


@app.route("/api/v1/series", methods=["POST"])
@api_auth()
def api_series():
    d = request.get_json(silent=True) or {}
    ex, reps = d.get("ejercicio"), int(calc.num(d.get("reps"), 0) or 0)
    if ex not in EJERCICIOS or reps <= 0:
        return _api_err("Ejercicio desconocido o repeticiones inválidas.")
    fecha = d.get("fecha") or str(dt.date.today())
    con = get_db()
    n = con.execute("SELECT COUNT(*) FROM series WHERE usuario_id=? AND fecha=? AND ejercicio=?", (g.user["id"], fecha, ex)).fetchone()[0]
    con.execute("INSERT INTO series (usuario_id, fecha, ejercicio, serie, peso, reps, rir, nota) VALUES (?,?,?,?,?,?,?,?)",
                (g.user["id"], fecha, ex, n + 1, calc.num(d.get("peso")) or 0, reps, calc.num(d.get("rir")), (d.get("nota") or None)))
    if not con.execute("SELECT 1 FROM registros WHERE usuario_id=? AND fecha=?", (g.user["id"], fecha)).fetchone():
        con.execute("INSERT INTO registros (usuario_id, fecha, entreno) VALUES (?,?,'Sí')", (g.user["id"], fecha))
    else:
        con.execute("UPDATE registros SET entreno='Sí' WHERE usuario_id=? AND fecha=?", (g.user["id"], fecha))
    con.commit()
    return jsonify(ok=True, serie=n + 1, e1rm=calc.e1rm(calc.num(d.get("peso")) or 0, reps, calc.num(d.get("rir"))))


@app.route("/api/v1/progreso")
@api_auth()
def api_progreso():
    r = resumen_usuario(g.user)
    return jsonify(ok=True, peso=[{"fecha": str(l["fecha"]), "peso": l["peso"], "tendencia": round(t, 2) if t else None} for l, t in zip(r["logs"], r["trend"]) if l["peso"]],
                   fuerza=sorted([{"ejercicio": v["ejercicio"], "inicial": round(v["inicial"], 1), "mejor": round(v["mejor"], 1), "cambio_pct": round(v["cambio"] * 100, 1)}
                                  for v in r["pf"].values() if v["series"] >= 3], key=lambda x: -x["cambio_pct"])[:12],
                   adherencia=r["adherencia"], racha_semanas=r["racha"], fitness_score=r["score"]["total"],
                   alertas=[{"nivel": n, "texto": t} for n, t in r["alertas"]])


@app.route("/api/v1/retos")
@api_auth()
def api_retos():
    con, u = get_db(), g.user
    mis = {r["reto_id"]: r for r in con.execute("SELECT * FROM retos_inscritos WHERE usuario_id=?", (u["id"],)).fetchall()}
    pts = puntos_usuario(u["id"])
    out = []
    for r in con.execute("SELECT * FROM retos WHERE activo=1 ORDER BY fin").fetchall():
        d = _reto_dict(r, u, mis.get(r["id"]))
        out.append({k: d.get(k) for k in ("id", "titulo", "descripcion", "tipo_txt", "unidad", "meta", "inicio", "fin", "puntos", "cuota", "premios", "estado", "valor", "pct")}
                   | {"inscrito": bool(d["ins"]), "completado": bool(d["ins"] and d["ins"]["completado"])})
    return jsonify(ok=True, puntos=pts, nivel=rt.tier_de(pts["total"]), retos=out)


@app.route("/api/v1/notificaciones", methods=["GET", "POST"])
@api_auth()
def api_notificaciones():
    """GET ?desde=<id> → nuevas (para sondear cada 15-30 s o al abrir la app). POST {"leidas": true} → marca todas como leídas."""
    con = get_db()
    if request.method == "POST":
        con.execute("UPDATE notificaciones SET leida=1 WHERE usuario_id=?", (g.user["id"],))
        con.commit()
        return jsonify(ok=True)
    desde = int(calc.num(request.args.get("desde"), 0) or 0)
    return jsonify(ok=True, no_leidas=notif.no_leidas(con, g.user["id"]), notificaciones=notif.ultimas(con, g.user["id"], 50, desde))


@app.route("/api/v1/coach/actividad")
@api_auth("entrenador")
def api_coach_actividad():
    """Actividad de clientes. ?desde=<marca 'ahora' de la respuesta anterior> para recibir solo lo nuevo; ?cliente=<id>; ?tipo=<tipo>."""
    con = get_db()
    cliente = int(calc.num(request.args.get("cliente"), 0) or 0) or None
    tipo = request.args.get("tipo") if request.args.get("tipo") in notif.TIPOS else None
    return jsonify(ok=True, ahora=notif.ahora(), actividad=notif.feed_coach(con, g.user["id"], desde=request.args.get("desde"), cliente=cliente, tipo=tipo),
                   en_linea=_clientes_en_linea(con, g.user["id"]))


@app.route("/api/v1/guia", methods=["GET", "POST"])
@api_auth()
def api_guia():
    """Pasos del recorrido (cada uno con 'pantalla' para que la app lo muestre en su pantalla) y el manual por secciones.
    POST {"estado": "completa"|"omitida"} para no volver a mostrarlo automáticamente."""
    if request.method == "POST":
        estado = "completa" if (request.get_json(silent=True) or {}).get("estado") == "completa" else "omitida"
        get_db().execute("UPDATE usuarios SET guia_vista=? WHERE id=?", (f"{estado} {dt.date.today()}", g.user["id"]))
        get_db().commit()
        return jsonify(ok=True)
    pasos = [{k: v for k, v in x.items() if k in ("titulo", "texto", "pantalla")} for x in guiamod.pasos(g.user, url_for, tr)]
    return jsonify(ok=True, mostrar=not g.user.get("guia_vista"), pasos=pasos,
                   secciones=[{"grupo": gr, "apartados": [{k: v for k, v in it.items()} for it in items]} for gr, items in guiamod.secciones_para(g.user)])


@app.route("/api/v1/coach/clientes")
@api_auth("entrenador")
def api_coach_clientes():
    out = []
    for c in get_db().execute("SELECT * FROM usuarios WHERE coach_id=? ORDER BY nombre", (g.user["id"],)).fetchall():
        c = dict(c)
        if not c.get("perfil"):
            out.append({"id": c["id"], "nombre": c["nombre"], "perfil_completo": False}); continue
        r = resumen_usuario(c)
        ult = r["logs"][-1]["fecha"] if r["logs"] else None
        out.append({"id": c["id"], "nombre": c["nombre"], "perfil_completo": True, "objetivo": r["p"]["objetivo"], "fitness_score": r["score"]["total"],
                    "adherencia": r["adherencia"], "ultimo_registro": str(ult) if ult else None,
                    "alertas": [t for n, t in r["alertas"] if n in ("riesgo", "aviso")]})
    return jsonify(ok=True, clientes=out)


@app.route("/api/v1/ejercicios")
def api_ejercicios():
    return jsonify(ok=True, ejercicios=[{"nombre": e["nombre"], "slug": e["slug"], "grupo": e["grupo"], "equipo": e["equipo"], "tipo": e["tipo"],
                                         "musculos": e["targets"], "tecnica": e.get("claves")} for e in EJERCICIOS.values()])


@app.route("/api/v1")
@app.route("/api")
def api_docs():
    return render_template("api.html", base=url_publica())


@app.route("/dispositivos", methods=["POST"])
@login_required
def dispositivos():
    get_db().execute("DELETE FROM api_tokens WHERE id=? AND usuario_id=?", (request.form.get("id"), g.user["id"])); get_db().commit()
    flash("Dispositivo desconectado.", "ok")
    return redirect(url_for("ajustes") + "#dispositivos")


# ------------------------------------------------------------------ más descargas en PDF
@app.route("/nutricion/pdf")
@login_required
def nutricion_pdf():
    x = datos_nutricion(g.user)
    p, en, mac = x["p"], x["en"], x["mac"]
    mins = minimos(p, mac)
    b = [("metricas", [("Calorías", _f(mac["kcal"]), "kcal/día"), ("Proteína", _f(mac["prot"]), "g"), ("Carbohidratos", _f(mac["carb"]), "g"), ("Grasas", _f(mac["grasa"]), "g")]),
         ("h", "Tus metas y por qué"),
         ("kv", [("Gasto total estimado", f"{_f(en['gasto_total'])} kcal"), ("Ajuste por objetivo", f"{_f(en['ajuste'])} kcal ({p['objetivo']})"),
                 ("Proteína", f"{mac['prot_gkg']} g por kg de peso"), ("Carbohidratos", f"{_f(mac['carb_gkg'], 1)} g por kg"),
                 ("Grasas", f"{_f(mac['grasa_pct'] * 100)} % de las calorías"), ("Proteína por comida", f"{_f(mac['prot_comida'])} g en cada una de tus {p['comidas']} comidas"),
                 ("Fibra", f"{_f(mac['fibra'])} g al día"), ("Agua", f"{_f(mac['agua'], 1)} L al día + 0.5-1 L por hora de ejercicio"),
                 ("Mínimos diarios", f"proteína {mins['prot_min']} g · grasa {mins['grasa_min']} g")]),
         ("h", "Calorías por tiempo de comida")]
    b.append(("tabla", ["Tiempo", "kcal", "Proteína aprox."], [[t, _f(kc), f"{_f(mac['prot_comida'])} g"] for t, kc, _ in x["sugerencias"]], [2, 1, 1.4]))
    b.append(("h", "Ideas de recetas para cada tiempo"))
    for t, kc, recs in x["sugerencias"]:
        b.append(("tabla", [f"{t} (~{_f(kc)} kcal)", "Porción", "kcal", "Proteína"],
                  [[r["nombre"], f"×{f:g}", _f(m["kcal"]), f"{_f(m['prot'])} g"] for r, f, m, ing in recs], [4, .8, .8, 1]))
    b += [("h", "Hábitos que más ayudan"),
          ("lista", ["Proteína en cada comida (palma de la mano o más).", "Medio plato de verduras en comida y cena.",
                     "Agua como bebida principal; refresco y jugo solo ocasionalmente.", "Pésate 3-4 veces por semana y mira el promedio, no un día aislado.",
                     "Después de 2-3 semanas ajusta con tu gasto real (la app lo calcula con tus registros)."]),
          ("nota", "Basado en Morton 2018, Helms 2014, Schoenfeld y Aragon 2018, OMS 2015 y Guías Alimentarias 2020-2025.")]
    return pdf_resp("Mi plan de alimentación", b, f"{g.user['nombre']} · {p['objetivo']} · {p['peso']} kg")


def _puntaje_bloques(target, fecha):
    a = puntaje_de(target, fecha)
    b = [("metricas", [("Puntaje", str(a["total"]), a["etiqueta"]), ("Calorías", _f(a["tot"]["kcal"]), "kcal"), ("Proteína", _f(a["tot"]["prot"]), "g"),
                       ("Fibra", _f(a["fibra"]), "g")]),
         ("h", "Cómo se calculó"),
         ("tabla", ["Componente", "Puntos", "Tu día", "Meta", "Nivel"], [[c["nombre"], f"{c['puntos']:.0f}/{c['max']}", c["valor"], c["meta"], c["nivel"]] for c in a["componentes"]],
          [1.8, .8, 1.3, 2.2, .9])]
    if a["sugerencias"]:
        b.append(("h", "Lo que te falta"))
        for sg in a["sugerencias"]:
            b.append(("p", f"<b>{sg['titulo']} ({sg['nivel']}).</b> {sg['texto']}"))
            if sg["ideas"]:
                b.append(("lista", sg["ideas"]))
    dia = dt.date.fromisoformat(fecha)
    sem = []
    for i in range(6, -1, -1):
        d = dia - dt.timedelta(days=i)
        x = puntaje_de(target, str(d))
        sem.append([d.strftime("%d/%m"), str(x["total"]) if x["n"] else "—", x["etiqueta"] if x["n"] else "sin registros", _f(x["tot"]["kcal"]) if x["n"] else "—"])
    b += [("h", "Últimos 7 días"), ("tabla", ["Día", "Puntaje", "Nivel", "kcal"], sem, [1, 1, 2, 1]),
          ("nota", "Proteína 1.6 g/kg (Morton 2018) · fibra 14 g/1000 kcal · ≥400 g de frutas y verduras (OMS) · azúcares libres <10 % de la energía (OMS 2015).")]
    return b


@app.route("/puntaje/pdf")
@app.route("/coach/cliente/<int:cid>/puntaje/pdf")
@login_required
def puntaje_pdf(cid=None):
    target = _cliente_de_coach(cid) if cid else g.user
    fecha = request.args.get("fecha") or str(dt.date.today())
    try:
        dt.date.fromisoformat(fecha)
    except ValueError:
        fecha = str(dt.date.today())
    return pdf_resp("Puntaje nutricional", _puntaje_bloques(target, fecha), f"{target['nombre']} · {fecha}")


@app.route("/mediciones/pdf")
@app.route("/coach/cliente/<int:cid>/mediciones/pdf")
@login_required
def mediciones_pdf(cid=None):
    target = _cliente_de_coach(cid) if cid else g.user
    p = perfil(target)
    res = [(m, antro.calcular(p, m["datos"])) for m in lista_mediciones(target["id"])]
    if not res:
        b = [("p", "Todavía no hay mediciones registradas.")]
        return pdf_resp("Mediciones corporales", b, target["nombre"])
    m, r = res[-1]
    so = r.get("somatotipo")
    b = [("metricas", [("% de grasa", _f(r.get("grasa"), 1), r.get("grasa_metodo") or ""), ("Masa magra", _f(r.get("mlg"), 1), "kg"),
                       ("Músculo", _f(r.get("smm"), 1), "kg"), ("Somatotipo", f"{so['endo']:.1f}-{so['meso']:.1f}-{so['ecto']:.1f}" if so else "—", so["categoria"] if so else "")]),
         ("h", f"Resultados del {m['fecha']}"),
         ("kv", [(k, v) for k, v in [("IMC", f"{_f(r['imc'], 1)} · {r['imc_clase']}" if r.get("imc") else None),
                                     ("Cintura / estatura", _f(r.get("ice"), 2) + (" · riesgo" if r.get("ice") and r["ice"] >= .5 else "") if r.get("ice") else None),
                                     ("Cintura / cadera", _f(r.get("icc"), 2) + (" · riesgo" if r.get("riesgo_icc") else "") if r.get("icc") else None),
                                     ("Complexión", f"{r['complexion']} (r = {_f(r['complexion_r'], 1)})" if r.get("complexion") else None),
                                     ("Masa ósea (Rocha)", f"{_f(r.get('osea'), 1)} kg" if r.get("osea") else None),
                                     ("Masa muscular por diferencia", f"{_f(r.get('muscular_derose'), 1)} kg" if r.get("muscular_derose") else None)] if v])]
    metodos = [(n, r.get(k)) for k, n in (("grasa_dw", "Durnin-Womersley"), ("grasa_jp3", "Jackson-Pollock 3"), ("grasa_carter", "Yuhasz-Carter"),
                                          ("grasa_bia", "Bioimpedancia"), ("grasa_navy", "Marina EE. UU.")) if r.get(k)]
    if metodos:
        b += [("h", "% de grasa por método"), ("tabla", ["Método", "% grasa"], [[n, f"{v:.1f} %"] for n, v in metodos], [3, 1])]
    pr = None
    for mm, rr_ in reversed(res):
        pr = prop.calcular(p, mm["datos"], rr_.get("somatotipo"))
        if pr and (pr["indices"] or pr["rasgos"]):
            break
        pr = None
    if pr:
        b.append(("h", "Proporcionalidad"))
        if pr["rasgos"]:
            b.append(("p", " · ".join(f"<b>{n}</b>: {v}" for n, v in pr["rasgos"])))
        if pr["indices"]:
            b.append(("tabla", ["Índice", "Valor", "Interpretación"], [[n, v, c] for n, v, c, _ in pr["indices"]], [1.6, .7, 3]))
        if pr["zonas"]:
            b.append(("tabla", ["Zona", "Perímetro corregido", "Detalle"], [list(z) for z in pr["zonas"]], [1, 1.2, 3]))
        if pr.get("grasa_distribucion"):
            b.append(("p", f"Distribución de la grasa: {pr['grasa_distribucion'][1]} (índice {pr['grasa_distribucion'][0]:.2f})."))
        if pr["deportes"]:
            b += [("h", "Deportes donde tus proporciones dan ventaja"), ("lista", [f"{d}: {', '.join(mo)}" for d, _, mo in pr["deportes"]])]
        if pr["z"]:
            filas = [[prop.NOMBRES.get(k, k), f"{pr['z'][k]:+.1f}", "proporcional" if abs(pr["z"][k]) <= .5 else ("mayor" if pr["z"][k] > 0 else "menor")]
                     for grupo, ks in prop.GRUPOS_Z for k in ks if pr["z"].get(k) is not None]
            b += [("h", "Perfil frente al Phantom (puntaje z)"), ("tabla", ["Medida", "z", "Respecto a tu estatura"], filas, [2.2, .7, 1.6])]
    b += [("salto",), ("h", "Historial"),
          ("tabla", ["Fecha", "Tipo", "Peso", "Cintura", "% grasa", "M. magra", "Músculo", "Somatotipo"],
           [[mm["fecha"], "Avanzada" if mm["tipo"] == "avanzada" else "Básica", _f(x["peso"], 1), _f(mm["datos"].get("cintura"), 1), _f(x.get("grasa"), 1),
             _f(x.get("mlg"), 1), _f(x.get("smm"), 1), f"{x['somatotipo']['endo']:.1f}-{x['somatotipo']['meso']:.1f}-{x['somatotipo']['ecto']:.1f}" if x.get("somatotipo") else "—"]
            for mm, x in reversed(res)], [1.1, .9, .7, .8, .8, .8, .8, 1.2]),
          ("nota", "Estimaciones de campo (±3-5 puntos de % de grasa). Úsalas para comparar tu tendencia. Fórmulas: Durnin-Womersley, Jackson-Pollock, Heath-Carter, Lee 2000, Rocha, Ross & Wilson (Phantom).")]
    return pdf_resp("Mediciones corporales", b, f"{target['nombre']} · {len(res)} mediciones")


@app.route("/mi-plan/pdf")
@login_required
def plan_inteligente_pdf():
    x = datos_plan_inteligente(perfil(g.user))
    ev = x["ev"]
    b = [("h", "Reglas que se aplicaron a tu caso")]
    b += [("p", f"<b>{rg['titulo']}.</b> {rg['texto']} <i>(Base: {rg['fuente']})</i>") for rg in ev["reglas"]] or [("p", "Sin restricciones especiales.")]
    if ev["cardio"]:
        b += [("h", "Cardio recomendado"), ("lista", [f"{c}{' (mejor opción)' if i == 0 else ''}" for i, c in enumerate(ev["cardio"])])]
        if ev.get("cardio_evitar"):
            b.append(("p", "Por ahora no: " + ", ".join(ev["cardio_evitar"]) + "."))
    b.append(("h", "Ejercicios recomendados por grupo"))
    filas = []
    for grupo in GRUPOS + ["Otros"]:
        for e in x["por_grupo"].get(grupo, [])[:4]:
            filas.append([grupo, e["nombre"], e["equipo"], e["tipo"]])
    b.append(("tabla", ["Grupo", "Ejercicio", "Equipo", "Tipo"], filas, [1.3, 3, 1.4, 1.1]))
    if x["movilidad"]:
        b += [("h", "Movilidad y recuperación"), ("lista", [e["nombre"] for e in x["movilidad"]])]
    if x["evitados"]:
        b += [("h", "Mejor dejar para después"), ("tabla", ["Ejercicio", "Motivo"], [[e["nombre"], mot] for e, mot in x["evitados"][:25]], [2.2, 4])]
    b.append(("nota", "Recomendaciones educativas basadas en guías (OARSI, Cochrane, NSCA, OMS, ADA, ACSM). Ante dolor o enfermedad, consulta a tu médico."))
    return pdf_resp("Mi plan inteligente", b, f"{g.user['nombre']} · equipo: {', '.join(x['equipo'])}")


def _bloques_hoja(ejercicios, con_historial=None):
    """Hoja para el gimnasio: ejercicio, series × reps, RIR, descanso y casillas para anotar."""
    b = []
    for i, e in enumerate(ejercicios, 1):
        nom = e.get("ex")
        info = EJERCICIOS.get(nom, {})
        b.append(("h", f"{i}. {nom}"))
        det = [("Series × repeticiones", f"{e['series']} × {e['rmin']}-{e['rmax']}"), ("Esfuerzo", f"RIR {e['rir']} (repeticiones en reserva)"),
               ("Descanso", f"{e['descanso'] // 60} min {e['descanso'] % 60:02d} s" if e.get("descanso") else "—"), ("Equipo", info.get("equipo", "—"))]
        if con_historial and con_historial.get(nom):
            det.append(("Última vez / sugerencia", con_historial[nom]))
        b.append(("kv", det))
        if info.get("claves"):
            b.append(("p", f"<i>Técnica:</i> {info['claves']}"))
        b.append(("tabla", ["Serie", "Peso (kg)", "Reps", "RIR", "Notas"], [[str(n), "", "", "", ""] for n in range(1, e["series"] + 1)], [.7, 1.2, 1, .8, 3]))
    return b


@app.route("/sesion/pdf")
@login_required
def sesion_pdf():
    prog = programa(g.user)
    fecha = request.args.get("fecha") or str(dt.date.today())
    try:
        fobj = dt.date.fromisoformat(fecha)
    except ValueError:
        fobj = dt.date.today(); fecha = str(fobj)
    x = datos_sesion(prog, fecha, fobj, request.args.get("dia"))
    hist = {}
    for pl in x["planes"]:
        partes = []
        if pl["ultima"]:
            partes.append(pl["ultima_fecha"] + ": " + ", ".join(f"{s['peso']:g}×{s['reps']}" for s in pl["ultima"]))
        if pl["sug"]:
            partes.append(pl["sug"][1])
        hist[pl["e"]["ex"]] = " · ".join(partes)
    b = [("p", f"Día: <b>{x['dia']['nombre']}</b> · {len(x['planes'])} ejercicios. Calienta 5-10 min y haz 1-3 series de aproximación en los compuestos.")]
    b += _bloques_hoja([pl["e"] for pl in x["planes"]], hist)
    return pdf_resp(f"Sesión: {x['dia']['nombre']}", b, f"{prog.get('nombre', 'Mi programa')} · {fecha}")


@app.route("/entrenar/pdf")
@login_required
def entrenar_pdf():
    p = perfil(g.user)
    musculos = [m for m in request.args.getlist("m") if m in MUSCULOS]
    if not musculos:
        return redirect(url_for("entrenar"))
    minutos = int(calc.num(request.args.get("min"), p["duracion"]) or 60)
    eq_sel = [e for e in request.args.getlist("eq") if e in EQUIPO_NOMBRES]
    plan = generar_sesion(musculos, minutos, set(eq_sel) if eq_sel else selmod.equipo_disponible(p), selmod.evaluar(p))
    dur = round(sum(e["series"] * (e["descanso"] + 45) for e in plan) / 60 + 10)
    b = [("p", f"Músculos: <b>{', '.join(MUSCULOS[m]['nombre'].split(' (')[0] for m in musculos)}</b> · duración estimada {dur} min (con 10 min de calentamiento).")]
    b += _bloques_hoja(plan)
    return pdf_resp("Sesión generada", b, f"{g.user['nombre']} · {dt.date.today():%d/%m/%Y}")


@app.route("/recetas/pdf")
def recetas_pdf():
    tipo, tag, q = request.args.get("tipo", ""), request.args.get("tag", ""), request.args.get("q", "").strip().lower()
    items = [r for r in todas_recetas() if (not tipo or r["tipo"] == tipo) and (not tag or tag in r["tags"]) and (not q or q in r["nombre"].lower())]
    total = len(items)
    items = items[:40]
    b = [("p", f"{total} recetas{' (se incluyen las primeras 40; usa los filtros para elegir otras)' if total > 40 else ''}."),
         ("tabla", ["Receta", "Tipo", "min", "kcal", "Proteína"], [[r["nombre"], TIPOS.get(r["tipo"], r["tipo"]), str(r.get("minutos", "")), _f(r["base"]["kcal"]), f"{_f(r['base']['prot'])} g"]
                                                               for r in items], [3.6, 1.1, .6, .7, .9])]
    for r in items:
        b += [("salto",), ("h", r["nombre"]),
              ("p", f"{TIPOS.get(r['tipo'], r['tipo'])} · {r.get('minutos', 0)} min · {_f(r['base']['kcal'])} kcal · P {_f(r['base']['prot'])} g · HC {_f(r['base']['carb'])} g · G {_f(r['base']['grasa'])} g"),
              ("tabla", ["Ingrediente", "Gramos", "Medida casera"], [[n, f"{gr:g}", r.get("medidas", {}).get(n, "")] for n, gr in r["ing"]], [3, 1, 2.2])]
        if r.get("pasos"):
            b.append(("lista", [f"{i}. {p_}" for i, p_ in enumerate(r["pasos"], 1)]))
        if r.get("tips"):
            b.append(("p", "<i>Tips:</i> " + " ".join(r["tips"])))
    titulo = "Recetario" + (f" · {TIPOS.get(tipo, tipo)}" if tipo else "") + (f" · {tag}" if tag else "")
    return pdf_resp(titulo, b, "Valores por porción base; en cada receta de la app puedes escalarla a tus calorías")


@app.route("/alimentos/pdf")
def alimentos_pdf():
    q, cat = request.args.get("q", ""), request.args.get("cat", "")
    lista = alim.buscar(q, cat)
    b = []
    for c in ([cat] if cat else alim.CATEGORIAS):
        filas = [[a["nombre"], _f(a["por100g"].get("kcal")), _f(a["por100g"].get("prot"), 1), _f(a["por100g"].get("carb"), 1), _f(a["por100g"].get("grasa"), 1),
                  _f(a["por100g"].get("fibra"), 1), (a["porciones"][0]["desc"] + f" = {a['porciones'][0]['g']:g} g") if a["porciones"] else ""]
                 for a in lista if a.get("categoria") == c]
        if filas:
            b += [("h", c), ("tabla", ["Alimento (por 100 g)", "kcal", "Prot", "HC", "Grasa", "Fibra", "Porción casera"], filas, [2.6, .6, .6, .6, .6, .6, 2.2])]
    b.append(("nota", "Fuentes: USDA FoodData Central, SMAE y etiquetas. Valores por 100 g de parte comestible."))
    return pdf_resp("Tabla de alimentos", b, f"{len(lista)} alimentos" + (f" · {cat}" if cat else ""))


@app.route("/ejercicios/<slug>/pdf")
def ejercicio_pdf(slug):
    e = next((x for x in EJERCICIOS.values() if x["slug"] == slug), None) or abort(404)
    musc = [MUSCULOS[m]["nombre"] for m in e["targets"] if m in MUSCULOS]
    b = [("kv", [("Músculo principal", musc[0] if musc else "—"), ("También trabaja", ", ".join(musc[1:]) or "—"), ("Equipo", e["equipo"]),
                 ("Tipo", e["tipo"]), ("Grupo", e["grupo"])])]
    if e.get("claves"):
        b += [("h", "Cómo se hace"), ("p", e["claves"])]
    subs = sustitutos(e["nombre"])[:8]
    if subs:
        b += [("h", "Alternativas (mismo músculo principal)"), ("lista", [f"{s['nombre']} ({s['equipo']})" for s in subs])]
    b += [("h", "Registro"), ("tabla", ["Fecha", "Serie", "Peso (kg)", "Reps", "RIR"], [["", str(n), "", "", ""] for n in range(1, 9)], [1.4, .8, 1.2, 1, .8])]
    return pdf_resp(e["nombre"], b, "Ficha de ejercicio")


@app.route("/descargas")
@login_required
def descargas():
    hoy = str(dt.date.today())
    grupos = [
        ("Alimentación", [("Mi plan de alimentación", "Calorías, macros, reparto por comida e ideas de recetas.", url_for("nutricion_pdf")),
                          ("Dieta por equivalentes", "Tu dieta SMAE por tiempo de comida.", url_for("dieta_pdf")),
                          ("Plan del día", "Menú de hoy con recetas y lista de compras.", url_for("plan_dia_pdf")),
                          ("Menú semanal", "7 días de recetas y lista de compras por pasillo.", url_for("menu_semanal_pdf")),
                          ("Diario de comidas de hoy", "Lo que registraste hoy, con totales.", url_for("diario_pdf", fecha=hoy)),
                          ("Puntaje nutricional de hoy", "Tu calificación y lo que te falta.", url_for("puntaje_pdf", fecha=hoy)),
                          ("Recetario completo", "Las primeras 40 recetas con ingredientes y pasos (filtra en Recetas).", url_for("recetas_pdf")),
                          ("Tabla de alimentos", "Todos los alimentos con macros y porciones caseras.", url_for("alimentos_pdf"))]),
        ("Entrenamiento", [("Mi programa", "Tu rutina completa por días.", url_for("programa_pdf")),
                           ("Sesión de hoy", "Hoja para el gimnasio con casillas para anotar.", url_for("sesion_pdf")),
                           ("Mi plan inteligente", "Ejercicios recomendados y por qué, según tu sondeo.", url_for("plan_inteligente_pdf"))]),
        ("Progreso y salud", [("Reporte de progreso", "Peso, fuerza, adherencia y gráficas.", url_for("progreso_pdf")),
                              ("Reporte del mes", "Tu mes en una página: lo que salió bien y qué mejorar.", url_for("reporte_mensual_pdf")),
                              ("Mediciones corporales", "Composición, somatotipo, proporcionalidad e historial.", url_for("mediciones_pdf")),
                              ("Perfil avanzado", "Nivel, marcas de fuerza, competencia y enfoque recomendado.", url_for("sondeo_avanzado_pdf")),
                              ("Mi expediente completo", "Todo tu historial en un solo documento.", url_for("mi_expediente_pdf")),
                              ("Mis datos", "Copia de todos tus registros.", url_for("mis_datos_pdf"))]),
    ]
    return render_template("descargas.html", grupos=grupos)


# ------------------------------------------------------------------ actualizaciones
def es_local():
    return request.remote_addr in ("127.0.0.1", "::1", "localhost")


def reiniciar_servidor(espera=1.2):
    """Reinicia el proceso del servidor para cargar la versión nueva."""
    import sys
    import threading
    import time

    def _re():
        time.sleep(espera)
        if os.name == "nt":  # Windows: abre el servidor nuevo en otra ventana y cierra este
            import subprocess
            subprocess.Popen([sys.executable] + sys.argv, cwd=os.path.dirname(os.path.abspath(__file__)),
                             env={**os.environ, "FITAPP_ESPERA": "3", "FITAPP_ABRIR": "0"}, creationflags=0x00000010)
            os._exit(0)
        os.execv(sys.executable, [sys.executable] + sys.argv)
    threading.Thread(target=_re, daemon=True).start()


@app.route("/actualizaciones", methods=["GET", "POST"])
@login_required
def actualizaciones():
    if not es_local():
        flash("Las actualizaciones solo se administran desde la computadora donde corre el servidor.", "error")
        return redirect(url_for("ajustes"))
    cfg = actualizador.leer_config()
    if request.method == "POST":
        acc = request.form.get("accion")
        try:
            if acc == "config":
                f = request.form
                repo = (f.get("repo") or "").strip().strip("/").replace("https://github.com/", "")
                url = (f.get("url") or "").strip()
                if repo and not actualizador.REPO_OK.match(repo):
                    raise ValueError("Escribe el repositorio como usuario/nombre, por ejemplo: mientrenador/fitbase.")
                if url and not url.startswith(("https://", "http://")):
                    raise ValueError("La dirección debe empezar con https://")
                cfg.update(fuente="url" if url else ("github" if repo else ""), repo=repo, url=url, auto=bool(f.get("auto")),
                           cada_horas=int(calc.num(f.get("cada_horas"), 6) or 6))
                actualizador.guardar_config(cfg)
                flash("Configuración guardada." + (" Buscando actualizaciones…" if cfg["fuente"] else ""), "ok")
                return redirect(url_for("actualizaciones", buscar=1 if cfg["fuente"] else None))
            if acc == "probar_github":
                repo = (request.form.get("repo") or cfg.get("repo") or "").strip().strip("/").replace("https://github.com/", "")
                est = actualizador.github_estado(repo, (request.form.get("token") or cfg.get("gh_token") or "").strip() or None)
                session["gh_estado"] = est
                return redirect(url_for("actualizaciones") + "#github")
            if acc == "publicar_github":
                f = request.form
                token = (f.get("token") or cfg.get("gh_token") or "").strip()
                version = (f.get("version") or "").strip()
                url_rel, tam = actualizador.github_publicar(cfg.get("repo"), token, version, (f.get("notas") or "").strip()[:2000])
                if f.get("recordar") and token:
                    cfg["gh_token"] = token; actualizador.guardar_config(cfg)
                session.pop("gh_estado", None)
                flash(f"¡Versión {version} publicada en GitHub ({tam / 1e6:.1f} MB)! Las computadoras con actualización automática la recibirán solas. {url_rel}", "ok")
                return redirect(url_for("actualizaciones") + "#github")
            if acc == "olvidar_token":
                cfg.pop("gh_token", None); actualizador.guardar_config(cfg)
                flash("Token de GitHub borrado de esta computadora.", "ok")
                return redirect(url_for("actualizaciones") + "#github")
            if acc == "zip" and request.files.get("paquete"):
                r = actualizador.aplicar(request.files["paquete"].read())
                actualizador.guardar_novedades(r["nueva"], "Instalada desde archivo.")
            elif acc == "en_linea":
                m = actualizador.consultar_en_linea()
                if not m or not m.get("disponible"):
                    raise ValueError("No hay una versión más nueva disponible.")
                r = actualizador.instalar_en_linea(m)
            elif acc == "restaurar":
                r = actualizador.restaurar_anterior()
                actualizador.guardar_novedades(r["nueva"], f"Regresaste a la versión {r['nueva']}.")
            else:
                raise ValueError("Selecciona un paquete de actualización (.zip).")
            ACTUALIZACION.clear()
            reiniciar_servidor()
            return render_template("reiniciando.html", r=r)
        except Exception as e:  # noqa: BLE001 - se muestra al usuario
            flash(f"No se pudo completar: {e}", "error")
            return redirect(url_for("actualizaciones"))
    manifiesto = None
    if request.args.get("buscar") and actualizador.url_manifiesto(cfg):
        try:
            manifiesto = actualizador.consultar_en_linea()
            if manifiesto and manifiesto.get("disponible"):
                ACTUALIZACION.clear(); ACTUALIZACION.update(manifiesto)
        except Exception as e:  # noqa: BLE001
            flash(f"No se pudo consultar las actualizaciones: {e}", "error")
        cfg = actualizador.leer_config()
    elif ACTUALIZACION:
        manifiesto = dict(ACTUALIZACION)
    return render_template("actualizaciones.html", version=actualizador.version_actual(), manifiesto=manifiesto, cfg=cfg,
                           fuente_url=actualizador.url_manifiesto(cfg), historial=actualizador.historial(), novedades=actualizador.novedades(),
                           respaldos=actualizador.respaldos_codigo()[:5], env_url=bool(os.environ.get("FITAPP_UPDATE_URL")),
                           pendiente=PENDIENTE_REINICIO[0], gh=session.pop("gh_estado", None), sig_version=actualizador.siguiente_version())


@app.route("/actualizaciones/reiniciar", methods=["POST"])
@login_required
def reiniciar():
    if not es_local():
        abort(403)
    reiniciar_servidor()
    return render_template("reiniciando.html")


# ------------------------------------------------------------------ notificaciones y actividad en vivo
def _num_txt(v, dec=0, suf=""):
    n = calc.num(v)
    return f"{n:,.{dec}f}{suf}" if n else None


def _describir_accion():
    """Traduce el POST que acaba de terminar bien a (tipo, texto, detalle) para el feed del entrenador. None = no se registra."""
    ep, f, j = request.endpoint, request.form, (request.get_json(silent=True) or {}) if request.is_json else {}
    acc = f.get("accion")
    if ep == "habitos":
        if acc == "checklist":
            return "dia", "actualizó su checklist de hábitos", None
        partes = [x for x in (_num_txt(f.get("peso"), 1, " kg"), _num_txt(f.get("pasos"), 0, " pasos"), _num_txt(f.get("sueno"), 1, " h de sueño"),
                              _num_txt(f.get("kcal"), 0, " kcal"), "entrenó" if f.get("entreno") else None) if x]
        return "dia", "registró su día", " · ".join(partes) or None
    if ep == "api_registro":
        partes = [x for x in (_num_txt(j.get("peso"), 1, " kg"), _num_txt(j.get("pasos"), 0, " pasos"), _num_txt(j.get("sueno"), 1, " h de sueño")) if x]
        return "dia", "registró su día", " · ".join(partes) or None
    if ep in ("sesion_view", "api_series"):
        src = j if ep == "api_series" else f
        if acc == "borrar" or not src.get("ejercicio"):
            return None
        ex = EJERCICIOS.get(src.get("ejercicio"), {})
        nombre = ex.get("nombre", src.get("ejercicio")) if isinstance(ex, dict) else src.get("ejercicio")
        return "entreno", "registró series de entrenamiento", f"{nombre}: {calc.num(src.get('peso')) or 0:g} kg × {int(calc.num(src.get('reps')) or 0)}"
    if ep in ("registrar_guardar", "api_comidas") and not request.view_args.get("cid"):
        items = j.get("items") or []
        return "comida", "registró comidas", ", ".join(str(i.get("nombre", ""))[:40] for i in items[:4]) + ("…" if len(items) > 4 else "") or None
    if ep == "diario":
        return "comida", "actualizó su diario de comidas", None
    if ep == "mediciones":
        return "medicion", "registró mediciones corporales", None
    if ep == "fotos_progreso":
        return "foto", "subió fotos de progreso", None
    if ep == "reto_detalle":
        r = get_db().execute("SELECT titulo FROM retos WHERE id=?", (request.view_args.get("rid"),)).fetchone()
        return "reto", ("se inscribió al reto" if acc in ("inscribir", "unirme") else "actualizó su avance en el reto"), r["titulo"] if r else None
    if ep == "feedback_view" and acc != "votar":
        return "feedback", "envió una opinión sobre la app", (f.get("texto") or "")[:80] or None
    if ep in ("sondeo", "sondeo_avanzado", "evaluacion", "aplicar_programa_nivel"):
        return "perfil", {"sondeo": "actualizó su sondeo inicial", "sondeo_avanzado": "actualizó su sondeo avanzado (marcas y experiencia)",
                          "evaluacion": "actualizó su evaluación y perfil", "aplicar_programa_nivel": "aplicó un programa de su nivel"}[ep], None
    if ep in ("programa_view", "entrenar", "dieta_propia", "auto_kcal", "descarga"):
        return "ajuste", {"programa_view": "ajustó su programa", "entrenar": "generó una sesión eligiendo músculos", "dieta_propia": "ajustó su dieta",
                          "auto_kcal": "cambió el ajuste automático de calorías", "descarga": "activó una semana de descarga"}[ep], None
    return None


COACH_A_CLIENTE = {"coach_dieta": ("ajuste", "Tu entrenador actualizó tu dieta", "dieta_propia"),
                   "coach_diario": ("comida", "Tu entrenador revisó tu diario de comidas", "diario"),
                   "coach_mediciones": ("medicion", "Tu entrenador registró nuevas mediciones", "mediciones"),
                   "coach_fotos": ("foto", "Tu entrenador revisó tus fotos de progreso", "fotos_progreso"),
                   "coach_sondeo_avanzado": ("perfil", "Tu entrenador actualizó tu sondeo avanzado", "sondeo_avanzado"),
                   "registrar_guardar": ("comida", "Tu entrenador agregó comidas a tu diario", "diario")}


# ------------------------------------------------------------------ idiomas
JS_TEXTOS = ["Saltar guía", "Atrás", "Siguiente", "¡Listo!", "Empezar", "de", "Notificaciones", "Marcar leídas", "Ver todas", "Cargando…",
             "No tienes notificaciones todavía.", "🔔 Avisarme aunque tenga la pestaña cerrada", "En vivo", "En pausa", "Sin conexión",
             "Nadie en este momento.", "✕ Salir de la vista en vivo", "▶ Pruébala aquí mismo", "EN VIVO", "clientes",
             "☀ Modo claro", "☾ Modo oscuro"]


def idioma_actual():
    if "idioma" in g:
        return g.idioma
    lang = request.cookies.get("idioma")
    if lang not in i18n.IDIOMAS:
        lang = request.accept_languages.best_match(list(i18n.IDIOMAS), default="es") if request else "es"
    g.idioma = lang
    return lang


def tr(texto):
    return i18n.t(texto, idioma_actual()) if idioma_actual() != "es" else texto


@app.route("/idioma/<lang>")
def cambiar_idioma(lang):
    if lang not in i18n.IDIOMAS:
        abort(404)
    destino = request.args.get("next") or request.referrer or url_for("inicio")
    try:
        from urllib.parse import urlparse
        u = urlparse(destino)
        destino = (u.path or "/") + (("?" + u.query) if u.query else "")
    except ValueError:
        destino = "/"
    if not destino.startswith("/") or destino.startswith("//"):
        destino = "/"
    resp = redirect(destino)
    resp.set_cookie("idioma", lang, max_age=3600 * 24 * 365, samesite="Lax")
    return resp


@app.after_request
def _traducir(resp):
    try:
        lang = idioma_actual()
    except RuntimeError:
        return resp
    resp.headers["Content-Language"] = i18n.IDIOMAS.get(lang, i18n.IDIOMAS["es"])[1]
    if lang == "es" or resp.direct_passthrough or resp.status_code >= 300 and resp.status_code < 400:
        return resp
    if resp.mimetype == "text/html":
        resp.set_data(i18n.traducir_html(resp.get_data(as_text=True), lang))
    elif resp.mimetype == "application/json" and request.endpoint in ("notificaciones_estado", "coach_actividad_json", "api_notificaciones",
                                                                     "api_coach_actividad", "api_guia"):
        d = resp.get_json(silent=True)

        def rec(x):
            if isinstance(x, dict):
                return {k: (i18n.t(v, lang) if k in ("titulo", "texto", "cuando", "nombre", "para", "como", "grupo") and isinstance(v, str) else
                            [i18n.t(e, lang) if isinstance(e, str) else rec(e) for e in v] if k == "detalle" and isinstance(v, list) else rec(v))
                        for k, v in x.items()}
            if isinstance(x, list):
                return [rec(e) for e in x]
            return x
        if d is not None:
            resp.set_data(json.dumps(rec(d), ensure_ascii=False))
    return resp


@app.after_request
def _cabeceras_seguridad(resp):
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")       # solo nuestra propia página puede mostrarla en un marco
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    return resp


@app.after_request
def _actividad_auto(resp):
    try:
        u = g.get("user")
        if request.method != "POST" or not u or resp.status_code >= 400 or request.endpoint in (None, "static"):
            return resp
        if resp.status_code == 200:
            if resp.mimetype != "application/json":
                return resp            # un formulario que se vuelve a mostrar suele ser un error de validación
            d = resp.get_json(silent=True) or {}
            if d.get("ok") is False or d.get("error"):
                return resp
        con = get_db()
        cid = (request.view_args or {}).get("cid")
        if u.get("rol") == "entrenador" and cid:
            if request.endpoint == "coach_cliente" and request.form.get("texto", "").strip():
                notif.avisar(con, cid, "comentario", "Tu entrenador te dejó un comentario", request.form["texto"].strip()[:220],
                             url_for("dashboard"), u["id"])
            elif request.endpoint in COACH_A_CLIENTE:
                t, titulo, destino = COACH_A_CLIENTE[request.endpoint]
                notif.avisar(con, cid, t, titulo, "", url_for(destino), u["id"])
            con.commit()
            return resp
        if u.get("rol") == "entrenador" and request.endpoint == "coach_retos" and request.form.get("accion") == "crear":
            for c in con.execute("SELECT id FROM usuarios WHERE coach_id=? AND activo=1", (u["id"],)).fetchall():
                notif.avisar(con, c["id"], "reto", "Nuevo reto de tu entrenador", (request.form.get("titulo") or "")[:120], url_for("retos_view"), u["id"])
            con.commit()
            return resp
        if u.get("rol") == "entrenador" and request.endpoint == "coach_feedback" and (request.form.get("respuesta") or "").strip():
            fb = con.execute("SELECT usuario_id FROM feedback WHERE id=?", (request.form.get("id"),)).fetchone()
            if fb and fb["usuario_id"] != u["id"]:
                notif.avisar(con, fb["usuario_id"], "feedback", "Respondieron a tu opinión", request.form["respuesta"].strip()[:200], url_for("feedback_view"), u["id"])
                con.commit()
            return resp
        if u.get("coach_id"):
            desc = _describir_accion()
            if desc:
                tipo, texto, detalle = desc
                notif.registrar_actividad(con, u, tipo, texto, url_for("coach_cliente", cid=u["id"]), detalle)
                if tipo == "foto":
                    notif.avisar(con, u["coach_id"], "foto", f"{u['nombre']} subió fotos de progreso", "", url_for("coach_fotos", cid=u["id"]), u["id"])
                con.commit()
    except Exception as e:   # el registro de actividad nunca debe romper la acción del usuario
        app.logger.warning("actividad: %s", e)
    return resp


def _avisos_del_dia(con, u):
    """Recordatorios automáticos, una vez al día por usuario."""
    hoy = str(dt.date.today())
    if session.get("avisos_dia") == hoy:
        return
    session["avisos_dia"] = hoy
    pl = plan_de(u)
    if pl.get("vence") and pl.get("pagable"):
        dias = (dt.date.fromisoformat(pl["vence"]) - dt.date.today()).days
        if 0 <= dias <= 5 and not con.execute("SELECT 1 FROM notificaciones WHERE usuario_id=? AND tipo='plan' AND texto LIKE ?",
                                               (u["id"], f"%{pl['vence']}%")).fetchone():
            notif.avisar(con, u["id"], "plan", f"Tu plan {pl['nombre']} vence {'hoy' if dias == 0 else f'en {dias} días'}",
                         f"Vigente hasta {pl['vence']}. Renuévalo para no perder la automatización.", url_for("pagar", clave=pl["clave"]))
            con.commit()


@app.route("/guia")
@login_required
def guia():
    return render_template("guia.html", secciones=guiamod.secciones_para(g.user), vista=g.user.get("guia_vista"))


@app.route("/guia/vista", methods=["POST"])
def guia_vista():
    if not g.user:
        return jsonify(ok=False), 401
    estado = "completa" if request.form.get("estado") == "completa" or (request.get_json(silent=True) or {}).get("estado") == "completa" else "omitida"
    get_db().execute("UPDATE usuarios SET guia_vista=? WHERE id=?", (f"{estado} {dt.date.today()}", g.user["id"]))
    get_db().commit()
    return jsonify(ok=True)


@app.route("/notificaciones", methods=["GET", "POST"])
@login_required
def notificaciones_view():
    con = get_db()
    if request.method == "POST":
        if request.form.get("accion") == "todas":
            con.execute("UPDATE notificaciones SET leida=1 WHERE usuario_id=?", (g.user["id"],))
        elif request.form.get("accion") == "borrar_leidas":
            con.execute("DELETE FROM notificaciones WHERE usuario_id=? AND leida=1", (g.user["id"],))
        con.commit()
        return redirect(url_for("notificaciones_view"))
    lista = notif.ultimas(con, g.user["id"], 100)
    con.execute("UPDATE notificaciones SET leida=1 WHERE usuario_id=? AND leida=0", (g.user["id"],))
    con.commit()
    return render_template("notificaciones.html", lista=lista)


@app.route("/notificaciones/estado.json")
def notificaciones_estado():
    if not g.user:
        return jsonify(ok=False), 401
    con = get_db()
    desde = int(calc.num(request.args.get("desde"), 0) or 0)
    return jsonify(ok=True, no_leidas=notif.no_leidas(con, g.user["id"]), nuevas=notif.ultimas(con, g.user["id"], 8, desde) if desde else [],
                   ultimas=notif.ultimas(con, g.user["id"], 8) if request.args.get("lista") else None)


@app.route("/notificaciones/<int:nid>/abrir")
@login_required
def notificacion_abrir(nid):
    con = get_db()
    n = con.execute("SELECT * FROM notificaciones WHERE id=? AND usuario_id=?", (nid, g.user["id"])).fetchone()
    if not n:
        abort(404)
    con.execute("UPDATE notificaciones SET leida=1 WHERE id=?", (nid,))
    con.commit()
    destino = n["url"] or url_for("notificaciones_view")
    return redirect(destino if destino.startswith("/") else url_for("notificaciones_view"))


@app.route("/notificaciones/leer", methods=["POST"])
def notificaciones_leer():
    if not g.user:
        return jsonify(ok=False), 401
    get_db().execute("UPDATE notificaciones SET leida=1 WHERE usuario_id=?", (g.user["id"],))
    get_db().commit()
    return jsonify(ok=True)


def _clientes_en_linea(con, coach_id):
    hace = (dt.datetime.now() - dt.timedelta(minutes=5)).isoformat(timespec="seconds")
    return [dict(r) for r in con.execute("SELECT id, nombre, ultimo_acceso FROM usuarios WHERE coach_id=? AND ultimo_acceso>=? ORDER BY ultimo_acceso DESC",
                                         (coach_id, hace)).fetchall()]


@app.route("/coach/actividad")
@login_required
def coach_actividad():
    if g.user["rol"] != "entrenador":
        abort(403)
    con = get_db()
    cliente = int(calc.num(request.args.get("cliente"), 0) or 0) or None
    tipo = request.args.get("tipo") if request.args.get("tipo") in notif.TIPOS else None
    clientes = [dict(r) for r in con.execute("SELECT id, nombre FROM usuarios WHERE coach_id=? ORDER BY nombre", (g.user["id"],)).fetchall()]
    hoy = str(dt.date.today())
    resumen = {"hoy": con.execute("SELECT COALESCE(SUM(n),0) FROM actividad WHERE coach_id=? AND substr(creado,1,10)=?", (g.user["id"], hoy)).fetchone()[0],
               "activos": con.execute("SELECT COUNT(DISTINCT actor_id) FROM actividad WHERE coach_id=? AND substr(creado,1,10)=?", (g.user["id"], hoy)).fetchone()[0],
               "clientes": len(clientes)}
    return render_template("coach_actividad.html", feed=notif.feed_coach(con, g.user["id"], cliente=cliente, tipo=tipo), clientes=clientes,
                           cliente=cliente, tipo=tipo, FILTROS=notif.FILTROS, en_linea=_clientes_en_linea(con, g.user["id"]), resumen=resumen,
                           ahora=notif.ahora())


@app.route("/coach/actividad.json")
def coach_actividad_json():
    if not g.user or g.user["rol"] != "entrenador":
        return jsonify(ok=False), 403
    con = get_db()
    cliente = int(calc.num(request.args.get("cliente"), 0) or 0) or None
    tipo = request.args.get("tipo") if request.args.get("tipo") in notif.TIPOS else None
    desde = request.args.get("desde") or None
    return jsonify(ok=True, ahora=notif.ahora(), items=notif.feed_coach(con, g.user["id"], desde=desde, cliente=cliente, tipo=tipo, limite=40),
                   en_linea=_clientes_en_linea(con, g.user["id"]))


# ------------------------------------------------------------------ pagos de planes (checkout)
COMPROBANTES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "comprobantes")
EXT_COMPROBANTE = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp", "pdf": "application/pdf"}


def _pedido_visible(folio):
    p = get_db().execute("SELECT * FROM pedidos WHERE folio=?", (folio,)).fetchone()
    if not p or not g.user or (p["usuario_id"] != g.user["id"] and not g.user.get("es_admin")):
        abort(404)
    return dict(p)


def _activar_pedido(con, p):
    vence = pagosmod.activar(con, p)
    if vence:
        nombre = pagosmod.CATALOGO.get(p["plan"], {}).get("nombre", p["plan"])
        notif.avisar(con, p["usuario_id"], "pago", f"¡Pago confirmado! {nombre} activo", f"Vigente hasta {vence}. Folio {p['folio']}.",
                     url_for("pago_ver", folio=p["folio"]))
        con.commit()
    return vence


def _sincronizar_stripe(p):
    """Pregunta a Stripe por un pedido con tarjeta/OXXO y aplica el plan si ya se pagó. Devuelve (pedido, sesión o None)."""
    if not p.get("stripe_sesion") or p["estado"] in ("pagado", "cancelado", "rechazado"):
        return p, None
    try:
        estado, s = pagosmod.consultar_checkout(p["stripe_sesion"])
    except pagosmod.ErrorPago as e:
        p["error_consulta"] = str(e)
        return p, None
    con = get_db()
    if estado == "pagado":
        _activar_pedido(con, p)
    elif estado != p["estado"] and estado in ("oxxo", "vencido"):
        con.execute("UPDATE pedidos SET estado=? WHERE id=?", (estado, p["id"]))
        con.commit()
    return dict(con.execute("SELECT * FROM pedidos WHERE id=?", (p["id"],)).fetchone()), s


def _decorar_pedido(p):
    p = dict(p)
    cat = pagosmod.CATALOGO.get(p["plan"], {"nombre": p["plan"]})
    p.update(plan_nombre=cat["nombre"], monto_txt=pagosmod.pesos(p["monto"]), metodo_txt=pagosmod.METODOS.get(p["metodo"], p["metodo"]),
             estado_txt=pagosmod.ESTADOS.get(p["estado"], p["estado"]), periodo_txt="1 año" if p["periodo"] == "anual" else "1 mes",
             factura_d=json.loads(p["factura"]) if p.get("factura") else None)
    return p


@app.route("/pagar/<clave>", methods=["GET", "POST"])
def pagar(clave):
    if clave not in pagosmod.CATALOGO:
        abort(404)
    if not g.user:
        flash("Inicia sesión o crea tu cuenta gratis para continuar con tu compra.", "info")
        return redirect(url_for("login", siguiente=request.full_path.rstrip("?")))
    if g.user.get("es_admin"):
        flash("Tu cuenta de administrador ya tiene todo desbloqueado: no necesitas pagar.", "info")
        return redirect(url_for("planes"))
    cfg = pagosmod.leer_config()
    plan = pagosmod.CATALOGO[clave]
    f = request.form if request.method == "POST" else request.args
    periodo = "anual" if f.get("periodo") == "anual" else "mensual"
    monto = plan[periodo]
    metodos = pagosmod.metodos_disponibles(monto, cfg)
    actual = plan_de(g.user)
    avisos = []
    if plan["tipo"] == "coach" and g.user["rol"] != "entrenador":
        avisos.append("Al activarse, tu cuenta se convierte en cuenta de entrenador (conservas tus datos) y obtienes tu enlace para invitar clientes.")
    if plan["tipo"] == "pro" and g.user.get("coach_id"):
        avisos.append("Ya tienes Pro incluido por tu entrenador mientras estés vinculado. Pagar solo tiene sentido si planeas seguir por tu cuenta.")
    if plan["tipo"] == "coach":
        usados = cupo_clientes(g.user)[1] if g.user["rol"] == "entrenador" else 0
        if usados > plan["clientes"]:
            avisos.append(f"Hoy tienes {usados} clientes y este plan es para {plan['clientes']}: no podrás sumar nuevos hasta elegir un plan mayor.")
    if actual.get("vence") and actual["clave"] == clave:
        avisos.append(f"Tu plan actual vence el {actual['vence']}: los días que pagues ahora se suman a partir de esa fecha.")
    if plan["tipo"] == "pro" and actual["clave"].startswith("coach") and actual.get("vence"):
        flash("Tu plan Coach ya incluye todo lo de Pro para tu cuenta.", "info")
        return redirect(url_for("mis_pagos"))
    if actual.get("pagable") and actual["clave"] != clave and actual.get("vence"):
        avisos.append(f"Tienes {actual['nombre']} hasta el {actual['vence']}: los días que te quedan se convierten en días extra del plan nuevo según su valor.")
    datos = {"nombre": g.user["nombre"], "email": g.user["email"], "telefono": (perfil(g.user).get("ingreso") or {}).get("telefono", "")}
    if request.method == "POST":
        datos = {k: (f.get(k) or "").strip() for k in ("nombre", "email", "telefono")}
        metodo = f.get("metodo")
        tel = re.sub(r"\D", "", datos["telefono"])
        errores = []
        if len(datos["nombre"]) < 3:
            errores.append("escribe tu nombre completo")
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", datos["email"]):
            errores.append("revisa tu correo")
        if tel and len(tel) not in (10, 12):
            errores.append("el teléfono debe tener 10 dígitos")
        if metodo not in metodos:
            errores.append("elige una forma de pago disponible")
        if not f.get("terminos"):
            errores.append("acepta los términos de compra")
        factura = None
        if f.get("quiere_factura"):
            factura = {"rfc": (f.get("rfc") or "").strip().upper().replace(" ", ""), "razon": (f.get("razon") or "").strip().upper()[:160],
                       "cp": re.sub(r"\D", "", f.get("cp") or "")[:5], "regimen": f.get("regimen") if f.get("regimen") in pagosmod.REGIMENES else "",
                       "uso": f.get("uso") if f.get("uso") in pagosmod.USOS_CFDI else pagosmod.USOS_CFDI[0]}
            if not pagosmod.RFC_OK.match(factura["rfc"]):
                errores.append("el RFC no tiene un formato válido (12 o 13 caracteres)")
            if not factura["razon"] or len(factura["cp"]) != 5 or not factura["regimen"]:
                errores.append("para facturar completa razón social, código postal fiscal y régimen")
        if errores:
            flash("Para continuar: " + "; ".join(errores) + ".", "error")
        else:
            con = get_db()
            folio = pagosmod.nuevo_folio()
            con.execute("INSERT INTO pedidos (folio, usuario_id, plan, periodo, monto, metodo, nombre, email, telefono, factura, referencia) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (folio, g.user["id"], clave, periodo, monto, metodo, datos["nombre"][:120], datos["email"][:160], tel or None,
                         json.dumps(factura, ensure_ascii=False) if factura else None, pagosmod.referencia_spei(folio)))
            con.commit()
            pedido = dict(con.execute("SELECT * FROM pedidos WHERE folio=?", (folio,)).fetchone())
            if metodo in ("tarjeta", "oxxo"):
                base = request.url_root.rstrip("/")
                try:
                    sid, url = pagosmod.crear_checkout(pedido, f"{base}/pago/{folio}?session_id={{CHECKOUT_SESSION_ID}}",
                                                       f"{base}/pago/{folio}?cancelado=1")
                except pagosmod.ErrorPago as e:
                    con.execute("UPDATE pedidos SET estado='cancelado', nota_admin=? WHERE id=?", (str(e)[:300], pedido["id"]))
                    con.commit()
                    flash(f"No se pudo abrir la página de pago: {e}", "error")
                    return redirect(url_for("pagar", clave=clave, periodo=periodo))
                con.execute("UPDATE pedidos SET stripe_sesion=? WHERE id=?", (sid, pedido["id"]))
                con.commit()
                return redirect(url, code=303)
            return redirect(url_for("pago_ver", folio=folio))
    otros = [(k, v) for k, v in pagosmod.CATALOGO.items() if v["tipo"] == plan["tipo"] and k != clave]
    return render_template("pagar.html", clave=clave, plan=plan, periodo=periodo, monto=monto, metodos=metodos, datos=datos, f=f,
                           avisos=avisos, actual=actual, otros=otros, ahorro=pagosmod.ahorro_anual(clave), pesos=pagosmod.pesos,
                           M=pagosmod.METODOS, REG=pagosmod.REGIMENES, USOS=pagosmod.USOS_CFDI, modo=pagosmod.stripe_modo(cfg),
                           vence_nuevo=(dt.date.today() + dt.timedelta(days=pagosmod.DIAS_PERIODO[periodo])), oxxo_max=pagosmod.OXXO_MAX,
                           stripe_ok=bool(pagosmod.stripe_clave(cfg)))


@app.route("/pago/<folio>", methods=["GET", "POST"])
def pago_ver(folio):
    if not g.user:
        return redirect(url_for("login", siguiente=request.path))
    p = _pedido_visible(folio)
    con = get_db()
    if request.method == "POST":
        acc = request.form.get("accion")
        if acc == "cancelar" and p["estado"] in ("pendiente", "oxxo") and p["metodo"] == "transferencia":
            con.execute("UPDATE pedidos SET estado='cancelado' WHERE id=?", (p["id"],))
            con.commit()
            flash("Pedido cancelado.", "ok")
        elif acc == "comprobante" and p["metodo"] == "transferencia" and p["estado"] in ("pendiente", "revision", "rechazado"):
            arch = request.files.get("archivo")
            ext = (arch.filename.rsplit(".", 1)[-1].lower() if arch and "." in arch.filename else "")
            datos = arch.read(5 * 1024 * 1024 + 1) if arch else b""
            if ext not in EXT_COMPROBANTE or not datos:
                flash("Sube una foto (JPG, PNG, WEBP) o PDF de tu comprobante.", "error")
            elif len(datos) > 5 * 1024 * 1024:
                flash("El archivo pesa más de 5 MB. Toma una captura de pantalla del comprobante.", "error")
            else:
                os.makedirs(COMPROBANTES_DIR, exist_ok=True)
                nombre = f"{p['folio']}.{ext}"
                with open(os.path.join(COMPROBANTES_DIR, nombre), "wb") as fh:
                    fh.write(datos)
                con.execute("UPDATE pedidos SET comprobante=?, estado='revision' WHERE id=?", (nombre, p["id"]))
                con.commit()
                flash("¡Gracias! Recibimos tu comprobante. Activaremos tu plan en cuanto confirmemos el depósito (normalmente el mismo día hábil).", "ok")
        elif acc == "ya_pague" and p["metodo"] == "transferencia" and p["estado"] == "pendiente":
            con.execute("UPDATE pedidos SET estado='revision' WHERE id=?", (p["id"],))
            con.commit()
            flash("Listo, revisaremos tu transferencia con la referencia de tu pedido.", "ok")
        return redirect(url_for("pago_ver", folio=folio))
    sesion = None
    if p["stripe_sesion"] and (not request.args.get("session_id") or request.args["session_id"] == p["stripe_sesion"]):
        p, sesion = _sincronizar_stripe(p)
    if request.args.get("cancelado") and p["estado"] == "pendiente":
        flash("No se completó el pago. Puedes intentarlo de nuevo o elegir otra forma de pago.", "info")
    cfg = pagosmod.leer_config()
    return render_template("pago.html", p=_decorar_pedido(p), t=cfg.get("transferencia", {}), ficha=pagosmod.ficha_oxxo(sesion) if sesion else None,
                           plan_actual=plan_de(g.user))


@app.route("/pago/<folio>/comprobante")
def pago_comprobante(folio):
    if not g.user:
        abort(404)
    p = _pedido_visible(folio)
    if not p["comprobante"]:
        abort(404)
    ruta = os.path.realpath(os.path.join(COMPROBANTES_DIR, p["comprobante"]))
    if not ruta.startswith(os.path.realpath(COMPROBANTES_DIR) + os.sep) or not os.path.exists(ruta):
        abort(404)
    resp = send_file(ruta, mimetype=EXT_COMPROBANTE.get(ruta.rsplit(".", 1)[-1], "application/octet-stream"), max_age=0)
    resp.headers["Cache-Control"] = "private, no-store"
    return resp


@app.route("/pago/<folio>/recibo.pdf")
def pago_recibo(folio):
    if not g.user:
        abort(404)
    p = _decorar_pedido(_pedido_visible(folio))
    if p["estado"] != "pagado":
        abort(404)
    bloques = [("kv", [("Folio", p["folio"]), ("Plan", f"{p['plan_nombre']} · {p['periodo_txt']}"), ("Importe (IVA incluido)", p["monto_txt"] + " MXN"),
                       ("Forma de pago", p["metodo_txt"]), ("Fecha de pago", (p["pagado_en"] or "")[:10]), ("Vigente hasta", p["vigencia_hasta"] or "—"),
                       ("A nombre de", p["nombre"] or "—"), ("Correo", p["email"] or "—")])]
    if p["factura_d"]:
        fd = p["factura_d"]
        bloques += [("h", "Datos para tu factura (CFDI)"), ("kv", [("RFC", fd["rfc"]), ("Razón social", fd["razon"]), ("Código postal fiscal", fd["cp"]),
                                                                  ("Régimen", fd["regimen"]), ("Uso del CFDI", fd["uso"])]),
                    ("nota", "La factura electrónica se emite por separado con estos datos.")]
    bloques.append(("nota", "Este recibo no es un comprobante fiscal (CFDI). Pago único sin renovación automática."))
    return pdf_resp("Recibo de pago", bloques, f"{APP_NOMBRE} · folio {p['folio']}", archivo=f"recibo-{p['folio']}.pdf")


@app.route("/mis-pagos")
def mis_pagos():
    if not g.user:
        return redirect(url_for("login", siguiente=request.path))
    con = get_db()
    filas = [dict(x) for x in con.execute("SELECT * FROM pedidos WHERE usuario_id=? ORDER BY id DESC LIMIT 50", (g.user["id"],)).fetchall()]
    for i, p in enumerate(filas):
        if i < 4 and p["stripe_sesion"] and p["estado"] in ("pendiente", "oxxo"):
            filas[i] = _sincronizar_stripe(p)[0]
    g.user = dict(con.execute("SELECT * FROM usuarios WHERE id=?", (g.user["id"],)).fetchone())
    actual = plan_de(g.user)
    return render_template("mis_pagos.html", pedidos=[_decorar_pedido(p) for p in filas], actual=actual,
                           renovar=actual["clave"] if actual.get("pagable") else None, cupo=cupo_clientes(g.user) if g.user["rol"] == "entrenador" else None)


@app.route("/pagos/stripe/webhook", methods=["POST"])
def stripe_webhook():
    """Aviso de Stripe (opcional, requiere que el servidor sea accesible desde internet). Sin él, los pagos se confirman al regresar
    de la página de pago y cada vez que el cliente o el administrador abren sus pagos."""
    cfg = pagosmod.leer_config()
    secreto = os.environ.get("STRIPE_WEBHOOK_SECRET") or cfg.get("stripe_webhook") or ""
    cuerpo = request.get_data()
    if not pagosmod.verificar_webhook(cuerpo, request.headers.get("Stripe-Signature", ""), secreto):
        abort(400)
    ev = json.loads(cuerpo)
    s = (ev.get("data") or {}).get("object") or {}
    folio = s.get("client_reference_id") or (s.get("metadata") or {}).get("folio")
    con = get_db()
    p = con.execute("SELECT * FROM pedidos WHERE folio=?", (folio,)).fetchone() if folio else None
    if p and s.get("id") == p["stripe_sesion"]:
        tipo = ev.get("type")
        if tipo in ("checkout.session.completed", "checkout.session.async_payment_succeeded") and s.get("payment_status") == "paid":
            _activar_pedido(con, dict(p))
        elif tipo == "checkout.session.completed":
            con.execute("UPDATE pedidos SET estado='oxxo' WHERE id=? AND estado='pendiente'", (p["id"],))
        elif tipo in ("checkout.session.async_payment_failed", "checkout.session.expired"):
            con.execute("UPDATE pedidos SET estado='vencido' WHERE id=? AND estado IN ('pendiente','oxxo')", (p["id"],))
        con.commit()
    return jsonify(recibido=True)


@app.route("/admin/idiomas", methods=["GET", "POST"])
@admin_required
def admin_idiomas():
    """Cobertura de traducciones y traducción con IA de las frases que aún faltan."""
    lang = request.values.get("lang") if request.values.get("lang") in ("en", "fr") else "en"
    if request.method == "POST":
        if request.form.get("accion") == "traducir":
            if not asistente.hay_credenciales():
                flash("Para traducir con IA se necesita la clave de Claude en esta computadora (variable ANTHROPIC_API_KEY). Revisa el LEEME.", "error")
            else:
                pendientes = [k for k, _ in i18n.faltantes(lang)][:int(calc.num(request.form.get("cuantas"), 150) or 150)]
                hechas, error = 0, None
                for i in range(0, len(pendientes), 60):
                    nuevas, error = i18n.traducir_con_ia(pendientes[i:i + 60], lang, asistente.MODELO)
                    if nuevas:
                        i18n.guardar_auto(lang, nuevas)
                        hechas += len(nuevas)
                    if error:
                        break
                flash(f"{hechas} frases traducidas al {i18n.IDIOMAS[lang][0]}." + (f" Se detuvo: {error}" if error else ""), "error" if error and not hechas else "ok")
        return redirect(url_for("admin_idiomas", lang=lang))
    return render_template("admin_idiomas.html", lang=lang, faltan=i18n.faltantes(lang)[:300], total_faltan=len(i18n.faltantes(lang)),
                           cobertura={k: i18n.cobertura(k) for k in ("en", "fr")}, ia=asistente.hay_credenciales())


@app.route("/admin/pagos", methods=["GET", "POST"])
@admin_required
def admin_pagos():
    con = get_db()
    cfg = pagosmod.leer_config()
    if request.method == "POST":
        f = request.form
        acc = f.get("accion")
        if acc == "config":
            if not es_local():
                abort(403)
            t = cfg["transferencia"]
            for k in ("banco", "beneficiario", "cuenta", "instrucciones"):
                t[k] = (f.get(k) or "").strip()[:400]
            clabe = re.sub(r"\D", "", f.get("clabe") or "")
            if clabe and not pagosmod.CLABE_OK.match(clabe):
                flash("La CLABE debe tener exactamente 18 dígitos.", "error")
            else:
                t["clabe"] = clabe
            cfg["cobro_activo"] = bool(f.get("cobro_activo"))
            cfg["sin_oxxo"] = bool(f.get("sin_oxxo"))
            clave = (f.get("stripe_secret") or "").strip()
            if clave:
                if not re.match(r"^(sk|rk)_(test|live)_[A-Za-z0-9]{10,}$", clave):
                    flash("La clave secreta de Stripe empieza con sk_test_ o sk_live_ (o rk_ si es restringida).", "error")
                else:
                    cfg["stripe_secret"] = clave
            wh = (f.get("stripe_webhook") or "").strip()
            if wh:
                cfg["stripe_webhook"] = wh
            if f.get("borrar_stripe"):
                cfg.pop("stripe_secret", None)
                cfg.pop("stripe_webhook", None)
            pagosmod.guardar_config(cfg)
            flash("Configuración de cobro guardada.", "ok")
            return redirect(url_for("admin_pagos") + "#config")
        if acc == "probar_stripe":
            try:
                b = pagosmod._stripe("GET", "/balance")
                disp = sum(x["amount"] for x in b.get("available", []) if x.get("currency") == "mxn")
                flash(f"Conexión con Stripe correcta ({'modo prueba' if pagosmod.stripe_modo() == 'prueba' else 'modo real'}). "
                      f"Saldo disponible: {pagosmod.pesos(disp)} MXN.", "ok")
            except pagosmod.ErrorPago as e:
                flash(str(e), "error")
            return redirect(url_for("admin_pagos") + "#config")
        p = con.execute("SELECT * FROM pedidos WHERE id=?", (f.get("id"),)).fetchone()
        if not p:
            abort(404)
        p = dict(p)
        if acc == "confirmar" and p["estado"] != "pagado":
            vence = _activar_pedido(con, p)
            con.execute("UPDATE pedidos SET nota_admin=? WHERE id=?", ((f.get("nota") or "Confirmado por el administrador")[:300], p["id"]))
            con.commit()
            flash(f"Pago {p['folio']} confirmado: plan activo hasta {vence}.", "ok")
        elif acc == "rechazar" and p["estado"] != "pagado":
            nota = (f.get("nota") or "No se encontró el depósito")[:300]
            con.execute("UPDATE pedidos SET estado='rechazado', nota_admin=? WHERE id=?", (nota, p["id"]))
            notif.avisar(con, p["usuario_id"], "pago", f"No pudimos confirmar tu pago {p['folio']}", nota, url_for("pago_ver", folio=p["folio"]))
            con.commit()
            flash(f"Pedido {p['folio']} marcado como rechazado.", "ok")
        elif acc == "verificar":
            p2, _ = _sincronizar_stripe(p)
            flash(p2.get("error_consulta") or f"{p['folio']}: {pagosmod.ESTADOS.get(p2['estado'], p2['estado'])}.", "error" if p2.get("error_consulta") else "ok")
        return redirect(url_for("admin_pagos", estado=request.args.get("estado", "")) + f"#p{p['id']}")
    if pagosmod.stripe_clave(cfg):   # sin webhook: confirma aquí los pagos con tarjeta/OXXO que ya se acreditaron
        for x in con.execute("SELECT * FROM pedidos WHERE stripe_sesion IS NOT NULL AND estado IN ('pendiente','oxxo') ORDER BY id DESC LIMIT 6").fetchall():
            _sincronizar_stripe(dict(x))
    filtro = request.args.get("estado", "")
    q = "SELECT p.*, u.nombre AS usuario_nombre, u.email AS usuario_email FROM pedidos p LEFT JOIN usuarios u ON u.id=p.usuario_id"
    filas = con.execute(q + (" WHERE p.estado=?" if filtro else "") + " ORDER BY CASE p.estado WHEN 'revision' THEN 0 WHEN 'oxxo' THEN 1 "
                        "WHEN 'pendiente' THEN 2 ELSE 3 END, p.id DESC LIMIT 200", (filtro,) if filtro else ()).fetchall()
    mes = dt.date.today().strftime("%Y-%m")
    stats = {"mes": con.execute("SELECT COALESCE(SUM(monto),0) FROM pedidos WHERE estado='pagado' AND substr(pagado_en,1,7)=?", (mes,)).fetchone()[0],
             "total": con.execute("SELECT COALESCE(SUM(monto),0) FROM pedidos WHERE estado='pagado'").fetchone()[0],
             "revision": con.execute("SELECT COUNT(*) FROM pedidos WHERE estado='revision'").fetchone()[0],
             "activos": con.execute("SELECT COUNT(*) FROM usuarios WHERE plan IN (%s) AND plan_vence>=?" % ",".join("?" * len(pagosmod.CATALOGO)),
                                    (*pagosmod.CATALOGO, str(dt.date.today()))).fetchone()[0]}
    t = cfg["transferencia"]
    return render_template("admin_pagos.html", pedidos=[_decorar_pedido(x) for x in filas], filtro=filtro, stats=stats, cfg=cfg, t=t,
                           pesos=pagosmod.pesos, E=pagosmod.ESTADOS, modo=pagosmod.stripe_modo(cfg), local=es_local(),
                           env_stripe=bool(os.environ.get("STRIPE_SECRET_KEY")), transf_ok=pagosmod.transferencia_lista(cfg),
                           webhook_url=request.url_root.rstrip("/") + url_for("stripe_webhook"))


# ------------------------------------------------------------------ planes
PLANES = [
    dict(nombre="Gratis", clave=None, para="Todo lo necesario para entrenar y comer bien, personalizado para ti.", precio="$0", periodo="para siempre",
         cta="Crear mi cuenta gratis", destacado=False,
         incluye=["Sondeo inicial y plan inteligente según tu cuerpo, dolores y equipo", "Rutina personalizada y generador de sesiones",
                  "Dieta personalizada, plan del día y las 312 recetas", "Registro de comidas por texto, voz y código de barras",
                  "Biblioteca de 150 ejercicios con animación 3D y mapa muscular", "Puntaje nutricional, proporcionalidad y niveles",
                  "Mediciones básicas y avanzadas con % de grasa, masa magra y somatotipo", "Historial completo y descargas en PDF"],
         limites="Coach IA: 15 mensajes y 10 fotos de comida al mes (cada análisis tiene un costo real). Sin anuncios y sin venta de datos."),
    dict(nombre="Pro", clave="pro", para="Para quien entrena por su cuenta y quiere que la app haga el seguimiento.", precio="$99", periodo="al mes",
         mensual=99, anual=799, anual_mes=67, ahorro=33, cta="Activar Pro", destacado=True,
         incluye=["Ajuste automático semanal de calorías según tu peso real (gasto adaptativo)",
                  "Periodización automática: progresión de cargas y semanas de descarga",
                  "Menú semanal completo con lista de compras agrupada por pasillo",
                  "Tendencias de tus mediciones: somatocarta, masa magra y grasa en el tiempo",
                  "Reporte mensual en PDF listo para tu médico o nutriólogo",
                  "Coach IA: 300 mensajes al mes y registro de comidas por foto",
                  "Respaldo en la nube y varios dispositivos (versión en línea)", "Acceso anticipado a nuevas funciones"],
         limites="Pago único por mes o por año, sin renovación automática ni cargos sorpresa. Si no renuevas conservas todos tus datos y vuelves a Gratis."),
    dict(nombre="Coach", clave="coach15", para="Para entrenadores y nutriólogos que trabajan con clientes.", precio="$0", periodo="hasta 3 clientes",
         cta="Empezar como coach", destacado=False,
         niveles=[("Inicial", None, 3, 0, 0), ("Coach 15", "coach15", 15, 349, 3490), ("Coach 40", "coach40", 40, 699, 6990),
                  ("Coach 100", "coach100", 100, 1290, 12900)],
         incluye=["Panel de clientes con alertas: inactividad, adherencia y estancamiento",
                  "Enlace de invitación con ficha de ingreso para cada cliente", "Asignar rutinas, dietas y metas a cada cliente",
                  "Ver calorías, diario, hábitos y entrenamientos de cada cliente", "Expedientes clínicos, mediciones ISAK e historial en PDF",
                  "Organizar retos con premios para tu comunidad", "Reporte general de tu cartera y tu marca en los PDF",
                  "Tus clientes reciben Pro incluido mientras estén contigo"],
         limites="Todas las funciones en todos los niveles: solo cambia cuántos clientes puedes tener. Sin complementos de pago extra."),
]
# (función, [Gratis, Pro, Coach])
TABLA = [
    ("Para ti", None),
    ("Sondeo, plan inteligente y rutina personalizada", [True, True, True]),
    ("Dieta personalizada y 312 recetas", [True, True, True]),
    ("Animaciones 3D y biblioteca de ejercicios", [True, True, True]),
    ("Mediciones básicas y avanzadas (ISAK)", [True, True, True]),
    ("Registro de comidas por texto, voz y código de barras", [True, True, True]),
    ("Registro por foto (IA)", ["10 al mes", "Uso amplio*", "Uso amplio*"]),
    ("Puntaje nutricional y «lo que te falta»", [True, True, True]),
    ("Proporcionalidad, somatotipo y deportes afines", [True, True, True]),
    ("Sondeo avanzado, fotos de progreso y niveles de novato a élite", [True, True, True]),
    ("Retos gratis, niveles (tiers) e insignias", [True, True, True]),
    ("Retos con premios", ["Cuota por reto", "Descuento por nivel", "Organiza y cobra"]),
    ("Historial y descargas en PDF", ["Completo", "Completo", "Completo"]),
    ("Coach IA (mensajes al mes)", ["15", "300", "300"]),
    ("Automatización y análisis", None),
    ("Ajuste semanal automático de calorías", ["Manual", True, True]),
    ("Periodización y descargas automáticas", ["Manual", True, True]),
    ("Menú semanal + lista de compras", ["Plan del día", True, True]),
    ("Tendencias de mediciones y somatocarta histórica", ["Última", True, True]),
    ("Reporte mensual en PDF", [False, True, True]),
    ("Respaldo en la nube y varios dispositivos", ["Local", True, True]),
    ("Administración profesional", None),
    ("Clientes vinculados", [False, False, "3 gratis · 15 · 40 · 100"]),
    ("Tus clientes reciben Pro incluido", [False, False, True]),
    ("Panel con alertas y seguimiento por cliente", [False, "Solo tu progreso", True]),
    ("Asignar rutinas, dietas y metas a otros", [False, False, True]),
    ("Expedientes clínicos de clientes y reporte de cartera", [False, False, True]),
    ("Marca propia en PDF", [False, False, True]),
    ("Compra", None),
    ("Precio mensual", ["$0", "$99", "$0 · $349 · $699 · $1,290"]),
    ("Precio anual (2 a 4 meses de regalo)", ["$0", "$799", "$3,490 · $6,990 · $12,900"]),
    ("Tarjeta, meses sin intereses en anual, OXXO o transferencia", ["—", True, True]),
    ("Renovación automática", ["—", "No: tú decides", "No: tú decides"]),
]
DIFERENCIA = [
    ("Gratis", "Te da el qué hacer: plan, rutina, dieta, recetas y técnica. Personalizado y completo."),
    ("Pro", "Hace el seguimiento por ti: revisa tus datos cada semana, ajusta calorías y cargas, y te explica tu tendencia. Solo ves tus propios datos."),
    ("Coach", "Es para trabajar con otras personas: ver, asignar y documentar a tus clientes. Empiezas gratis con 3 y pagas solo cuando creces."),
]


@app.route("/planes")
def planes():
    return render_template("planes.html", PLANES=PLANES, TABLA=TABLA, DIFERENCIA=DIFERENCIA, cobro=cobro_activo(),
                           metodos=pagosmod.metodos_disponibles(99_00))


# ------------------------------------------------------------------ entrenador
@app.route("/coach")
@login_required
def coach():
    if g.user["rol"] != "entrenador":
        flash("Esta sección es para cuentas de entrenador.", "error")
        return redirect(url_for("dashboard"))
    con = get_db()
    clientes = con.execute("SELECT * FROM usuarios WHERE coach_id=? ORDER BY nombre", (g.user["id"],)).fetchall()
    hoy = dt.date.today()
    hace7 = str(hoy - dt.timedelta(days=7))
    en_linea = {c["id"] for c in _clientes_en_linea(con, g.user["id"])}
    filas = []
    for c in clientes:
        c = dict(c)
        if not c.get("perfil"):
            filas.append({"u": c, "r": None, "nivel": "Sin evaluar", "tags": ["sin_eval"] + (["en_linea"] if c["id"] in en_linea else [])})
            continue
        filas.append(ficha_coach(con, c, hoy, hace7, en_linea))
    filas.sort(key=lambda f: (f["r"] is None, -len([1 for t in f["tags"] if t in ("riesgo", "inactivo")]), f["r"]["score"]["total"] if f["r"] else 0))
    conteo = lambda clave, val: sum(1 for f in filas if (f.get(clave) == val if clave != "tags" else val in f["tags"]))
    niveles = [(n, conteo("nivel", n)) for n in pa.NIVELES]
    objetivos = [(o, conteo("objetivo", o)) for o in ("Perder grasa", "Mantener", "Recomposición", "Ganar músculo")]
    estados = [(k, t, conteo("tags", k)) for k, t in (("atencion", "Necesitan atención"), ("riesgo", "Alerta de salud"), ("inactivo", "Sin registrar 3+ días"),
                                                       ("progreso", "Van muy bien"), ("nuevo", "Nuevos"), ("en_linea", "En línea ahora"), ("sin_eval", "Sin evaluación"))]
    return render_template("coach.html", filas=filas, hace7=hace7, niveles=niveles, objetivos=objetivos, estados=estados,
                           cupo=cupo_clientes(g.user), plan_coach=plan_de(g.user))


def nivel_cliente(p):
    """Novato → Élite: usa el sondeo avanzado si existe; si no, el nivel y la experiencia del sondeo inicial."""
    if p.get("avanzado"):
        try:
            n = datos_avanzado(p)["nivel_det"]
            if n:
                return n
        except Exception:
            pass
    exp = (p.get("sondeo") or {}).get("experiencia")
    if p.get("nivel") == "Principiante":
        return "Novato" if exp in ("nunca", "menos6") else "Principiante"
    return p.get("nivel") if p.get("nivel") in pa.NIVELES else "Principiante"


def ficha_coach(con, c, hoy, hace7, en_linea):
    """Resumen por cliente para el panel del entrenador: nivel, entrenamiento, dieta, progreso y actividad."""
    r = resumen_usuario(c)
    p = r["p"]
    ult = r["logs"][-1]["fecha"] if r["logs"] else None
    dias_sin = (hoy - ult).days if ult else None
    prog = programa(c)
    dia_hoy = next((d for d in prog.get("dias", []) if d.get("dia") == hoy.weekday()), None)
    proximo = dia_hoy or next((d for d in sorted(prog.get("dias", []), key=lambda d: (d.get("dia", 0) - hoy.weekday()) % 7)), None)
    ses = con.execute("SELECT fecha, ejercicio, MAX(peso) AS peso, COUNT(*) AS series, MAX(reps) AS reps FROM series WHERE usuario_id=? "
                      "AND fecha=(SELECT MAX(fecha) FROM series WHERE usuario_id=?) GROUP BY ejercicio ORDER BY MIN(id)", (c["id"], c["id"])).fetchall()
    kcal7 = [l["kcal"] for l in r["logs"] if l.get("kcal") and l["fecha"] >= hoy - dt.timedelta(days=6)]
    prot7 = [l["proteina"] for l in r["logs"] if l.get("proteina") and l["fecha"] >= hoy - dt.timedelta(days=6)]
    tr = [t for t in r["trend"] if t is not None]
    cambio28 = None
    if len(tr) >= 2:
        idx = max(0, len(tr) - 28)
        cambio28 = tr[-1] - tr[idx]
    act = con.execute("SELECT * FROM actividad WHERE actor_id=? ORDER BY creado DESC LIMIT 1", (c["id"],)).fetchone()
    nivel = nivel_cliente(p)
    tags = []
    if any(n == "riesgo" for n, _ in r["alertas"]):
        tags.append("riesgo")
    if dias_sin is None or dias_sin >= 3:
        tags.append("inactivo")
    if r["score"]["total"] >= 70 and (dias_sin is not None and dias_sin < 3):
        tags.append("progreso")
    if (p.get("ingreso") or {}).get("fecha", "") >= hace7 or (c.get("creado") or "")[:10] >= hace7:
        tags.append("nuevo")
    if c["id"] in en_linea:
        tags.append("en_linea")
    if "riesgo" in tags or "inactivo" in tags or r["score"]["total"] < 50 or any(n == "aviso" for n, _ in r["alertas"]):
        tags.append("atencion")
    return {"u": c, "r": r, "ultimo": ult, "dias_sin": dias_sin, "nivel": nivel, "objetivo": p["objetivo"], "tags": tags,
            "prog": prog, "dia_hoy": dia_hoy, "proximo": proximo, "sesion": [dict(x) for x in ses],
            "kcal7": sum(kcal7) / len(kcal7) if kcal7 else None, "prot7": sum(prot7) / len(prot7) if prot7 else None,
            "peso": tr[-1] if tr else None, "cambio28": cambio28, "act": notif.a_dict(act) if act else None,
            "grasa": (p.get("ultima_medicion") or {}).get("grasa") if isinstance(p.get("ultima_medicion"), dict) else None}


@app.route("/coach/cliente/<int:cid>", methods=["GET", "POST"])
@login_required
def coach_cliente(cid):
    c = get_db().execute("SELECT * FROM usuarios WHERE id=? AND coach_id=?", (cid, g.user["id"])).fetchone()
    if not c:
        abort(404)
    c = dict(c)
    if request.method == "POST" and request.form.get("texto", "").strip():
        get_db().execute("INSERT INTO comentarios (usuario_id, autor_id, texto) VALUES (?,?,?)", (cid, g.user["id"], request.form["texto"].strip()))
        get_db().commit()
        flash("Comentario enviado al cliente.", "ok")
        return redirect(url_for("coach_cliente", cid=cid))
    r = resumen_usuario(c)
    ult = r["logs"][-30:]
    graf = charts.linea([("Peso", [l["peso"] for l in ult], "s2", True), ("Tendencia", r["trend"][-30:], "s1", False)],
                        [f"{l['fecha'].day}/{l['fecha'].month}" for l in ult], titulo="Peso")
    com = get_db().execute("SELECT c.*, u.nombre FROM comentarios c JOIN usuarios u ON u.id=c.autor_id WHERE usuario_id=? ORDER BY c.id DESC", (cid,)).fetchall()
    return render_template("coach_cliente.html", c=c, r=r, graf=graf, radar=charts.radar(r["score"]["componentes"]), com=com, prog=programa(c))


# ------------------------------------------------------------------ ajustes y exportación
@app.route("/ajustes", methods=["GET", "POST"])
@login_required
def ajustes():
    if request.method == "POST":
        p = perfil(g.user)
        p["bienestar"] = bool(request.form.get("bienestar"))
        guardar(g.user, "perfil", p)
        flash("Ajustes guardados.", "ok")
        return redirect(url_for("ajustes"))
    disp = [dict(x) for x in get_db().execute("SELECT id, dispositivo, creado, ultimo_uso FROM api_tokens WHERE usuario_id=? ORDER BY id DESC", (g.user["id"],)).fetchall()]
    return render_template("ajustes.html", p=perfil(g.user), dispositivos=disp)


@app.route("/exportar.json")
@login_required
def exportar_json():
    u = g.user
    data = {"usuario": {k: u[k] for k in ("nombre", "email", "rol")}, "perfil": perfil(u), "programa": programa(u),
            "registros": [dict(l, fecha=str(l["fecha"])) for l in registros(u["id"])], "series": series_de(u["id"])}
    return Response(json.dumps(data, ensure_ascii=False, indent=2), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=mis-datos.json"})


@app.route("/exportar/<tipo>.csv")
@login_required
def exportar_csv(tipo):
    buf = io.StringIO()
    w = csv.writer(buf)
    if tipo == "series":
        rows = series_de(g.user["id"])
        w.writerow(["fecha", "ejercicio", "serie", "peso", "reps", "rir", "e1rm", "nota"])
        for s in rows:
            w.writerow([s["fecha"], s["ejercicio"], s["serie"], s["peso"], s["reps"], s["rir"], calc.e1rm(s["peso"], s["reps"], s["rir"]), s["nota"] or ""])
    elif tipo == "registros":
        w.writerow(["fecha", "peso", "kcal", "proteina", "pasos", "sueno", "entreno", "energia", "cintura", "notas"])
        for l in registros(g.user["id"]):
            w.writerow([l["fecha"], l["peso"], l["kcal"], l["proteina"], l["pasos"], l["sueno"], l["entreno"], l["energia"], l["cintura"], l["notas"] or ""])
    else:
        abort(404)
    return Response("﻿" + buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={tipo}.csv"})


# ------------------------------------------------------------------ descargas en PDF
def _f(v, d=0):
    return _fmt_num(v, d) if v is not None else "—"


def pdf_resp(titulo, bloques, subtitulo="", archivo=None):
    data = pdfmod.generar(titulo, bloques, subtitulo, app=APP_NOMBRE)
    return Response(data, mimetype="application/pdf",
                    headers={"Content-Disposition": f"{'attachment' if request.args.get('descargar') else 'inline'}; filename={archivo or pdfmod.nombre_archivo(titulo)}",
                             "Cache-Control": "no-store"})


FORMULAS_1RM = {
    "Epley (1985)": lambda w, r: w if r == 1 else w * (1 + r / 30), "Brzycki (1993)": lambda w, r: w * 36 / (37 - r),
    "Lombardi (1989)": lambda w, r: w * r ** 0.10, "O'Conner (1989)": lambda w, r: w * (1 + 0.025 * r),
    "Mayhew (1992)": lambda w, r: 100 * w / (52.2 + 41.9 * math.exp(-0.055 * r)),
    "Wathan (1994)": lambda w, r: 100 * w / (48.8 + 53.8 * math.exp(-0.075 * r)),
    "Lander (1985)": lambda w, r: 100 * w / (101.3 - 2.67123 * r)}
REPARTOS_MAC = {"equilibrado": ("Equilibrado", (40, 30, 30)), "bajo": ("Bajo en carbohidratos", (20, 40, 40)),
                "alto": ("Alto en proteína", (30, 40, 30)), "keto": ("Cetogénica", (5, 25, 70))}


@app.route("/calculadoras/pdf")
def calculadora_pdf():
    a, tipo, detalle = request.args, request.args.get("tipo"), request.args.get("vista") == "detalle"
    if tipo == "calorias":
        sexo = "Mujer" if a.get("sexo") == "Mujer" else "Hombre"
        p = db.perfil_base(sexo=sexo, edad=calc.num(a.get("edad"), 30), peso=calc.num(a.get("peso"), 70), talla=calc.num(a.get("talla"), 170))
        grasa = calc.num(a.get("grasa"))
        mlg = p["peso"] * (1 - grasa / 100) if grasa else None
        eqs = calc.ecuaciones_ger(p, mlg)
        usada = a.get("ecuacion") if a.get("ecuacion") in eqs else ("Cunningham (1980)" if mlg else "Mifflin-St Jeor (1990)")
        act = a.get("actividad") if a.get("actividad") in calc.FACTOR_ACTIVIDAD else "Moderado"
        ger = eqs[usada]; mant = ger * calc.FACTOR_ACTIVIDAD[act]
        obj = a.get("objetivo", "Mantener")
        ritmo = calc.num(a.get("ritmo"), {"Perder grasa": 0.5, "Ganar músculo": 0.25}.get(obj, 0))
        signo = {"Perder grasa": -1, "Ganar músculo": 1}.get(obj, 0)
        aj = lambda r: r / 100 * p["peso"] * 7700 / 7
        meta = round((mant + signo * aj(ritmo)) / 10) * 10
        b = [("metricas", [("Meta diaria", _f(meta), "kcal"), ("Gasto en reposo", _f(ger), "kcal"), ("Mantenimiento", _f(mant), "kcal"),
                           ("Cambio por semana", f"{signo * ritmo / 100 * p['peso']:+.2f}", "kg")]),
             ("kv", [("Sexo · edad · estatura · peso", f"{sexo} · {_f(p['edad'])} años · {_f(p['talla'])} cm · {_f(p['peso'], 1)} kg"),
                     ("Nivel de actividad", f"{act} (× {calc.FACTOR_ACTIVIDAD[act]})"), ("Objetivo", obj),
                     ("Para perder grasa (0.5 %/sem)", f"{_f(round((mant - aj(0.5)) / 10) * 10)} kcal"),
                     ("Para mantener", f"{_f(round(mant / 10) * 10)} kcal"), ("Para ganar músculo (0.25 %/sem)", f"{_f(round((mant + aj(0.25)) / 10) * 10)} kcal")])]
        if meta < ger:
            b.append(("aviso", "Tu meta queda por debajo de tu gasto en reposo. Hazlo solo por poco tiempo y con supervisión profesional."))
        if detalle:
            b += [("h", "Comparación de ecuaciones"), ("tabla", ["Ecuación", "Reposo (kcal)", "× actividad"],
                                                         [[k + (" (usada)" if k == usada else ""), _f(v), _f(v * calc.FACTOR_ACTIVIDAD[act])] for k, v in eqs.items()], [3, 1, 1])]
            if mlg:
                b.append(("p", f"Masa libre de grasa: <b>{_f(mlg, 1)} kg</b>. Disponibilidad energética aproximada: <b>{_f((meta - calc.kcal_met(3.5, p['peso'], 60, 3)) / mlg, 1)} kcal/kg MLG</b> (riesgo si &lt;30)."))
        b += [("h", "¿Qué significa?"), ("lista", [
            "<b>Gasto en reposo:</b> lo que tu cuerpo gasta solo por estar vivo (60–70 % del día).",
            "<b>Mantenimiento:</b> las calorías con las que tu peso se queda igual.",
            "<b>Meta diaria:</b> un poco menos que el mantenimiento para perder grasa; un poco más para ganar músculo.",
            "Es una estimación con error típico de ±10 %. Pésate 3–4 veces por semana y ajusta 100–200 kcal si en 2–3 semanas no avanzas como esperabas."]),
              ("nota", f"Fórmula: {usada} × factor de actividad. 1 kg de cambio de peso ≈ 7700 kcal (aproximación).")]
        return pdf_resp("Mis calorías diarias", b, "Resultado de la calculadora de calorías")
    if tipo == "macros":
        kcal, kg = calc.num(a.get("kcal"), 2000), calc.num(a.get("peso"), 70)
        com = max(1, min(8, int(calc.num(a.get("comidas"), 4))))
        rep = a.get("reparto", "evidencia")
        if rep in REPARTOS_MAC:
            nom, (pc, pp, pg) = REPARTOS_MAC[rep]
            c, pr, gr = kcal * pc / 400, kcal * pp / 400, kcal * pg / 900
        else:
            nom = "Recomendado (proteína según tu peso)"
            gkg = 2.2 if a.get("objetivo") == "Perder grasa" else 1.8
            pr = gkg * kg; gr = max(0.25 * kcal / 9, 0.5 * kg); c = max(0, (kcal - pr * 4 - gr * 9) / 4)
        b = [("metricas", [("Proteína", _f(pr), "g"), ("Carbohidratos", _f(c), "g"), ("Grasas", _f(gr), "g"), ("Calorías", _f(kcal), "kcal")]),
             ("tabla", ["Macro", "Gramos al día", "kcal", "% de las kcal", f"Por comida ({com})"],
              [["Proteína", _f(pr), _f(pr * 4), f"{_f(pr * 400 / kcal)} %", f"{_f(pr / com)} g"],
               ["Carbohidratos", _f(c), _f(c * 4), f"{_f(c * 400 / kcal)} %", f"{_f(c / com)} g"],
               ["Grasas", _f(gr), _f(gr * 9), f"{_f(gr * 900 / kcal)} %", f"{_f(gr / com)} g"]], [2, 1.3, 1, 1.2, 1.4]),
             ("p", f"Reparto: <b>{nom}</b> · peso {_f(kg, 1)} kg · proteína {_f(pr / kg, 1)} g/kg.")]
        if pr / kg < 1.6:
            b.append(("aviso", "La proteína queda por debajo de 1.6 g/kg, el mínimo recomendado para quien entrena."))
        if gr * 9 / kcal < 0.2:
            b.append(("aviso", "La grasa queda por debajo del 20 % de las calorías: a largo plazo puede afectar tus hormonas."))
        if detalle:
            b += [("h", "Detalle"), ("kv", [("Proteína por comida", f"{_f(pr / com / kg, 2)} g/kg (meta ≈ 0.4)"), ("Carbohidratos", f"{_f(c / kg, 2)} g/kg"),
                                            ("Grasas", f"{_f(gr / kg, 2)} g/kg"), ("Fibra sugerida", f"{_f(14 * kcal / 1000)} g/día"),
                                            ("Agua orientativa", f"{_f(0.035 * kg, 1)} L/día + sudor")])]
        b += [("h", "¿Qué hace cada macro?"), ("lista", [
            "<b>Proteína:</b> construye y repara músculo y da saciedad. Es la prioridad.",
            "<b>Carbohidratos:</b> combustible para entrenar intenso. Prefiere los que traen fibra.",
            "<b>Grasas:</b> necesarias para hormonas y vitaminas. Mídelas: 9 kcal por gramo.",
            "Reparte la proteína en 3–5 comidas; lo que más cuenta es el total del día."]),
              ("nota", "Morton 2018 (1.6–2.2 g/kg) · Helms 2014 · Schoenfeld y Aragon 2018 (≈0.4 g/kg por comida).")]
        return pdf_resp("Mis macros del día", b, "Resultado de la calculadora de macros")
    if tipo == "1rm":
        w, reps, rir = calc.num(a.get("peso"), 0), int(calc.num(a.get("reps"), 1)), calc.num(a.get("rir"), 0)
        u = "lb" if a.get("unidad") == "lb" else "kg"
        if not w:
            abort(400)
        rt = max(1, min(20, reps + rir)); paso = 2.5 if u == "kg" else 5
        red = lambda v: round(v / paso) * paso
        vals = {k: f(w, rt) for k, f in FORMULAS_1RM.items()}
        form = a.get("formula") if a.get("formula") in vals else "Epley (1985)"
        e = vals[form]
        b = [("metricas", [("1RM estimado", _f(e), u), ("Rango entre fórmulas", f"{_f(min(vals.values()))}–{_f(max(vals.values()))}", u),
                           ("Serie usada" + (f" · RIR {_f(rir, 1)}" if rir else ""), f"{w:g} × {reps}", u)]),
             ("h", "Zonas de entrenamiento"),
             ("tabla", ["Zona", "% del 1RM", f"Carga ({u})", "Para qué"],
              [["Calentamiento", "50–60 %", f"{_f(red(e * .5))}–{_f(red(e * .6))}", "Preparar articulaciones y técnica"],
               ["Volumen / hipertrofia", "65–80 %", f"{_f(red(e * .65))}–{_f(red(e * .8))}", "6–15 reps, ganar músculo"],
               ["Fuerza", "80–90 %", f"{_f(red(e * .8))}–{_f(red(e * .9))}", "3–6 reps"],
               ["Máximo", "95–100 %", f"{_f(red(e * .95))}–{_f(red(e))}", "Solo avanzados y con asistente"]], [2, 1.2, 1.5, 3])]
        if detalle:
            b += [("h", "Carga por repeticiones y RIR"),
                  ("tabla", ["Reps", "RIR 0", "RIR 1", "RIR 2", "RIR 3"], [[str(r)] + [_f(red(e / (1 + (r + x) / 30))) for x in range(4)] for r in (1, 2, 3, 4, 5, 6, 8, 10, 12, 15)]),
                  ("h", "Todas las fórmulas"), ("kv", [(k, f"{_f(v, 1)} {u}") for k, v in vals.items()])]
        b += [("h", "¿Qué es el 1RM?"), ("lista", [
            "El peso máximo que podrías levantar una vez con buena técnica. No necesitas probarlo: se estima con series de 3–10 repeticiones.",
            "Para ganar músculo funcionan cargas de ~30–85 % si llegas cerca del fallo (0–3 repeticiones en reserva).",
            "Recalcula cada 4–6 semanas o cuando una serie te salga con 2 o más repeticiones de sobra.",
            "Usa asistente o seguros en intentos pesados. Detente ante dolor punzante, mareo o dolor en el pecho."]),
              ("nota", f"Fórmula principal: {form}. Más precisas con ≤10 repeticiones (LeSuer 1997). Cargas redondeadas a {paso:g} {u}.")]
        return pdf_resp("Mi 1RM estimado", b, "Resultado de la calculadora de fuerza")
    abort(404)


@app.route("/dieta/pdf")
@login_required
def dieta_pdf():
    return _dieta_pdf(g.user)


@app.route("/coach/cliente/<int:cid>/dieta/pdf")
@login_required
def coach_dieta_pdf(cid):
    c = get_db().execute("SELECT * FROM usuarios WHERE id=? AND coach_id=?", (cid, g.user["id"])).fetchone()
    if not c or g.user["rol"] != "entrenador" or not c["perfil"]:
        abort(404)
    return _dieta_pdf(dict(c))


def _dieta_pdf(target):
    p, comp, en, mac = calcular(target)
    d = dietamod.normalizar(json.loads(target["smae"]) if target.get("smae") else None)
    metas = metas_de(d, mac)
    an = dietamod.analizar(d, metas)
    b = [("metricas", [("Calorías", _f(an["total"][0]), f"/ {_f(metas['kcal'])}"), ("Proteína", _f(an["total"][1]), "g"),
                       ("Grasas", _f(an["total"][2]), "g"), ("Carbohidratos", _f(an["total"][3]), "g")]),
         ("h", "Equivalentes por tiempo de comida")]
    filas = []
    for gname in dietamod.GRUPOS:
        qs = d["dist"].get(gname, [])
        if any(qs):
            filas.append([gname] + [(f"{q:g}" if q else "") for q in qs] + [f"{sum(qs):g}"])
    ab = {"Desayuno": "Desay.", "Colación AM": "Col. AM", "Colación PM": "Col. PM", "Pre-entreno": "Pre", "Post-entreno": "Post", "Colación": "Col."}
    b.append(("tabla", ["Grupo SMAE"] + [ab.get(t, t) for t in d["tiempos"]] + ["Total"], filas, [3] + [1] * len(d["tiempos"]) + [1]))
    b.append(("tabla", ["Tiempo", "kcal", "Proteína (g)", "Menú sugerido"],
              [[t, _f(an["por_tiempo"][i][0]), _f(an["por_tiempo"][i][1]), d["menu"].get(t, "") or "—"] for i, t in enumerate(d["tiempos"])], [1.4, .8, 1, 4]))
    b.append(("kv", [("Adecuación calorías", f"{_f((an['adec'][0] or 0) * 100)} %"), ("Adecuación proteína", f"{_f((an['adec'][1] or 0) * 100)} %"),
                     ("Adecuación grasas", f"{_f((an['adec'][2] or 0) * 100)} %"), ("Adecuación carbohidratos", f"{_f((an['adec'][3] or 0) * 100)} %")]))
    if d.get("notas"):
        b += [("h", "Notas del entrenador"), ("p", d["notas"])]
    b += [("h", "Cómo usar tu dieta por equivalentes"), ("lista", [
        "Cada número es un <b>equivalente</b>: una porción intercambiable dentro del mismo grupo (por ejemplo, 1 tortilla = 1/3 de bolillo).",
        "Puedes cambiar alimentos del mismo grupo sin alterar tus calorías: usa la Tabla de alimentos de la app.",
        "Una adecuación entre 90 % y 110 % se considera correcta.",
        "Pesa los alimentos las primeras semanas; después podrás calcular a ojo con más precisión."]),
          ("nota", "Grupos y valores: Sistema Mexicano de Alimentos Equivalentes (SMAE).")]
    sub = f"{target['nombre']} · {d.get('autor') and 'Elaborada por ' + d['autor'] or ''} {('· actualizada ' + d['actualizado']) if d.get('actualizado') else ''}"
    return pdf_resp("Dieta por equivalentes", b, sub.strip(" ·"))


@app.route("/plan-del-dia/pdf")
@login_required
def plan_dia_pdf():
    plan, tot, mac, compras = datos_plan_dia(int(request.args.get("variar", 0)))
    b = [("metricas", [("Calorías", _f(tot["kcal"]), f"/ {_f(mac['kcal'])}"), ("Proteína", _f(tot["prot"]), "g"),
                       ("Carbohidratos", _f(tot["carb"]), "g"), ("Grasas", _f(tot["grasa"]), "g")])]
    for tiempo, kc, r, f, m, ing in plan:
        b += [("h", f"{tiempo} · {r['nombre']}"),
              ("tabla", ["Ingrediente", "Cantidad"], [[n, f"{gr} g" + (f" ({r.get('medidas', {}).get(n)})" if r.get("medidas", {}).get(n) and f == 1 else "")] for n, gr in ing], [3, 2]),
              ("p", f"{_f(m['kcal'])} kcal · P {_f(m['prot'])} g · HC {_f(m['carb'])} g · G {_f(m['grasa'])} g")]
        if r.get("pasos"):
            b.append(("lista", r["pasos"]))
    b += [("salto",), ("h", "Lista de compras (para este día)"), ("tabla", ["Ingrediente", "Cantidad", "✓"], [[n, f"{gr} g", "☐"] for n, gr in compras], [4, 1.5, .5])]
    return pdf_resp("Mi plan del día", b, "Menú y lista de compras ajustados a tus calorías")


@app.route("/recetas/<rid>/pdf")
def receta_pdf(rid):
    r = buscar_receta(rid) or abort(404)
    kcal = calc.num(request.args.get("kcal"))
    f, m, ing = escalar(r, kcal) if kcal else (1.0, r["base"], r["ing"])
    b = [("metricas", [("Calorías", _f(m["kcal"]), "kcal"), ("Proteína", _f(m["prot"], 1), "g"), ("Carbohidratos", _f(m["carb"], 1), "g"), ("Grasas", _f(m["grasa"], 1), "g")]),
         ("h", "Ingredientes" + (f" (porción × {f:g})" if f != 1 else "")),
         ("tabla", ["Ingrediente", "Gramos", "Medida casera", "kcal"],
          [[n, f"{gr:g}", (r.get("medidas", {}).get(n, "") if f == 1 else ""), _f(ING[n][0] * gr / 100)] for n, gr in ing], [3, 1, 2.2, 1])]
    if r.get("pasos"):
        b += [("h", "Preparación"), ("lista", [f"{i}. {x}" for i, x in enumerate(r["pasos"], 1)])]
    if r.get("tips"):
        b += [("h", "Tips"), ("lista", r["tips"])]
    b.append(("nota", "Valores calculados por ingrediente con referencias USDA FoodData Central y SMAE; pueden variar según marca y cocción."))
    return pdf_resp(r["nombre"], b, f"{TIPOS.get(r['tipo'], r['tipo'])} · {r.get('minutos', 0)} min · {', '.join(r['tags'])}")


@app.route("/programa/pdf")
@login_required
def programa_pdf():
    prog, p = programa(g.user), perfil(g.user)
    b = [("p", f"Nivel {p['nivel']} · objetivo {p['objetivo']} · {len(prog['dias'])} días por semana.")]
    for d in prog["dias"]:
        b += [("h", f"{DIAS[d['dia']] if 0 <= d['dia'] < 7 else ''} · {d['nombre']} (≈{calc.duracion_sesion(d)} min)"),
              ("tabla", ["Ejercicio", "Series", "Reps", "RIR", "Descanso"], [[e["ex"], str(e["series"]), f"{e['rmin']}–{e['rmax']}", str(e["rir"]), f"{e['descanso']} s"] for e in d["ejercicios"]], [4, 1, 1, .8, 1.2])]
    b += [("h", "Cómo progresar"), ("lista", [
        "<b>Doble progresión:</b> cuando completes el tope de repeticiones en todas las series con el RIR indicado, sube la carga 2.5–5 %.",
        "<b>RIR</b> = repeticiones que te quedaban en reserva al terminar la serie.",
        "Calienta con 2–3 series ligeras antes del primer ejercicio pesado.",
        "Si una semana duermes mal o tienes mucho estrés, mantén las cargas en lugar de subirlas."])]
    return pdf_resp(prog.get("nombre", "Mi programa"), b, "Programa de entrenamiento")


@app.route("/progreso/pdf")
@login_required
def progreso_pdf():
    r = resumen_usuario(g.user)
    logs = r["logs"]
    p = perfil(g.user)
    pesos = [l["peso"] for l in logs if l["peso"]]
    b = [("metricas", [("Peso actual (tendencia)", _f(next((t for t in reversed(r["trend"]) if t), None), 1), "kg"),
                       ("Cambio desde el inicio", f"{(pesos[-1] - pesos[0]):+.1f}" if len(pesos) > 1 else "—", "kg"),
                       ("Días registrados", str(len(logs)), "")]),
         ("h", "Registro de los últimos días"),
         ("tabla", ["Fecha", "Peso", "kcal", "Proteína", "Pasos", "Sueño", "Entrenó"],
          [[str(l["fecha"]), _f(l["peso"], 1), _f(l["kcal"]), _f(l["proteina"]), _f(l["pasos"]), _f(l["sueno"], 1), l["entreno"] or ""] for l in logs[-28:]])]
    if r["pf"]:
        b += [("h", "Fuerza (1RM estimado)"), ("tabla", ["Ejercicio", "Series", "Mejor e1RM", "Cambio"],
                                                [[x["ejercicio"], str(x["series"]), f"{_f(x.get('mejor'), 1)} kg", f"{(x.get('cambio') or 0) * 100:+.1f} %"]
                                                 for x in sorted(r["pf"].values(), key=lambda x: -x["series"])[:12]], [4, 1, 1.5, 1.2])]
    b += [("h", "Cómo leer tu progreso"), ("lista", [
        "El peso diario sube y baja por agua, sal y digestión: fíjate en la <b>tendencia</b>, no en un solo día.",
        "Si la tendencia no se mueve en 2–3 semanas, ajusta tus calorías 100–200 kcal.",
        "Que tu fuerza suba mientras bajas de peso es la mejor señal de que conservas músculo."])]
    return pdf_resp("Mi reporte de progreso", b, f"{g.user['nombre']} · objetivo {p['objetivo']}")


@app.route("/diario/pdf")
@login_required
def diario_pdf():
    fecha = request.args.get("fecha") or str(dt.date.today())
    rows = get_db().execute("SELECT * FROM diario_comidas WHERE usuario_id=? AND fecha=? ORDER BY id", (g.user["id"], fecha)).fetchall()
    p, comp, en, mac = calcular(g.user)
    mins = minimos(p, mac)
    tot = {k: sum((x[k] or 0) for x in rows) for k in ("kcal", "prot", "carb", "grasa")}
    b = [("metricas", [("Calorías", _f(tot["kcal"]), f"/ {_f(mac['kcal'])}"), ("Proteína", _f(tot["prot"]), f"g / mín {mins['prot_min']}"),
                       ("Grasas", _f(tot["grasa"]), f"g / mín {mins['grasa_min']}"), ("Carbohidratos", _f(tot["carb"]), "g")])]
    for t in TIEMPOS_COMIDA:
        lst = [x for x in rows if x["tiempo"] == t]
        if lst:
            b += [("h", t), ("tabla", ["Alimento", "Porción", "kcal", "P", "HC", "G"],
                             [[x["alimento"], (x["porcion"] or "") + (f" ({_f(x['gramos'])} g)" if x["gramos"] else ""), _f(x["kcal"]), _f(x["prot"], 1), _f(x["carb"], 1), _f(x["grasa"], 1)] for x in lst], [3, 2.5, .8, .7, .7, .7])]
    if not rows:
        b.append(("p", "No hay alimentos registrados en esta fecha."))
    b.append(("nota", "Proteína mínima 1.6 g/kg · grasa mínima: la mayor entre 0.5 g/kg y 20 % de las kcal."))
    return pdf_resp(f"Diario de comidas {fecha}", b, g.user["nombre"])


@app.route("/mis-datos.pdf")
@login_required
def mis_datos_pdf():
    u, p = g.user, perfil(g.user)
    _p, comp, en, mac = calcular(u)
    logs = registros(u["id"])
    ser = series_de(u["id"])
    b = [("h", "Mi perfil"), ("kv", [("Nombre", u["nombre"]), ("Correo", u["email"]), ("Sexo · edad", f"{p['sexo']} · {p['edad']} años"),
                                      ("Estatura · peso", f"{_f(p['talla'])} cm · {_f(p['peso'], 1)} kg"), ("Objetivo", p["objetivo"]),
                                      ("Nivel · días de entrenamiento", f"{p['nivel']} · {p['dias']}"), ("Fecha de inicio", p.get("inicio", ""))]),
         ("h", "Mis metas"), ("kv", [("Calorías", f"{_f(mac['kcal'])} kcal"), ("Proteína", f"{_f(mac['prot'])} g"), ("Carbohidratos", f"{_f(mac['carb'])} g"),
                                      ("Grasas", f"{_f(mac['grasa'])} g"), ("% de grasa estimado", f"{_f((comp['grasa'] or 0) * 100, 1)} %" if comp.get("grasa") else "—")]),
         ("h", f"Registro diario ({len(logs)} días)"),
         ("tabla", ["Fecha", "Peso", "kcal", "Proteína", "Pasos", "Sueño", "Entrenó", "Notas"],
          [[str(l["fecha"]), _f(l["peso"], 1), _f(l["kcal"]), _f(l["proteina"]), _f(l["pasos"]), _f(l["sueno"], 1), l["entreno"] or "", l["notas"] or ""] for l in logs],
          [1.3, .8, .8, .9, .9, .7, .9, 2]),
         ("h", f"Series de entrenamiento ({len(ser)})"),
         ("tabla", ["Fecha", "Ejercicio", "Serie", "Peso", "Reps", "RIR", "e1RM"],
          [[s["fecha"], s["ejercicio"], str(s["serie"]), _f(s["peso"], 1), str(s["reps"]), _f(s["rir"], 1), _f(calc.e1rm(s["peso"], s["reps"], s["rir"]), 1)] for s in ser],
          [1.3, 3, .7, .8, .7, .7, .9])]
    return pdf_resp("Mis datos", b, "Copia completa de tu información en la plataforma (derecho de acceso, LFPDPPP)")


# ------------------------------------------------------------------ mediciones antropométricas
def lista_mediciones(uid):
    rows = get_db().execute("SELECT m.*, u.nombre AS autor FROM mediciones m LEFT JOIN usuarios u ON u.id=m.autor_id WHERE usuario_id=? ORDER BY fecha, id",
                            (uid,)).fetchall()
    return [dict(r, datos=json.loads(r["datos"])) for r in rows]


def vista_mediciones(target, url_self, es_coach):
    p = perfil(target)
    if request.method == "POST":
        f = request.form
        tipo = "avanzada" if f.get("tipo") == "avanzada" else "basica"
        campos = [k for k, _, _ in antro.BASICOS] + ["envergadura", "talla_sentado"] + (
            [k for k, _ in antro.PLIEGUES + antro.PERIMETROS + antro.DIAMETROS + prop.LONGITUDES + prop.DIAMETROS_EXTRA + prop.PERIMETROS_EXTRA]
            if tipo == "avanzada" else [])
        d = {k: calc.num(f.get(k)) for k in campos if calc.num(f.get(k)) is not None}
        if not d.get("peso"):
            flash("El peso es obligatorio.", "error")
            return redirect(url_self)
        fecha = f.get("fecha") or str(dt.date.today())
        get_db().execute("INSERT INTO mediciones (usuario_id, autor_id, fecha, tipo, datos) VALUES (?,?,?,?,?)",
                         (target["id"], g.user["id"], fecha, tipo, json.dumps(d)))
        r = antro.calcular(p, d)
        for k in ("peso", "talla", "cintura", "cadera", "cuello"):
            if d.get(k):
                p[k] = d[k]
        if r.get("grasa_metodo") in ("Durnin-Womersley", "Jackson-Pollock 3", "Bioimpedancia"):
            p["grasa_medida"] = round(r["grasa"], 1)
        p["somatotipo"] = r["somatotipo"]
        get_db().execute("UPDATE usuarios SET perfil=? WHERE id=?", (json.dumps(p), target["id"]))
        get_db().commit()
        flash("Medición guardada. Tus calorías y macros se recalcularon con los nuevos datos.", "ok")
        return redirect(url_self)
    hist = lista_mediciones(target["id"])
    res = [(m, antro.calcular(p, m["datos"])) for m in hist]
    puntos = [(r["somatotipo"]["x"], r["somatotipo"]["y"], m["fecha"]) for m, r in res if r.get("somatotipo")]
    pr = None
    if res:   # proporcionalidad con la medición más reciente que tenga longitudes o diámetros
        for m, r in reversed(res):
            pr = prop.calcular(p, m["datos"], r.get("somatotipo"))
            if pr and (pr["indices"] or pr["rasgos"]):
                pr["fecha"] = m["fecha"]; pr["grafica"] = prop.grafica_z(pr["z"])
                break
            pr = None
    tendencias = None
    if len(res) >= 2:
        et = [m["fecha"][8:10] + "/" + m["fecha"][5:7] for m, _ in res]
        tendencias = {
            "kg": charts.linea([("Peso", [r["peso"] for _, r in res], "s2", False), ("Masa magra", [r.get("mlg") for _, r in res], "s1", False),
                                ("Músculo esquelético", [r.get("smm") for _, r in res], "s3", True)], et, titulo="Kilos", alto=190, unidad="kg"),
            "pct": charts.linea([("% de grasa", [r.get("grasa") for _, r in res], "s1", False)], et, titulo="% de grasa", alto=170, unidad="%"),
            "cm": charts.linea([("Cintura", [m["datos"].get("cintura") for m, _ in res], "s2", False)], et, titulo="Cintura (cm)", alto=170, unidad="cm"),
        }
        a, b = res[0][1], res[-1][1]
        tendencias["cambios"] = [(n, b.get(k) - a.get(k), u) for n, k, u in [("Peso", "peso", "kg"), ("% de grasa", "grasa", "puntos"), ("Masa magra", "mlg", "kg"),
                                                                             ("Músculo", "smm", "kg")] if a.get(k) is not None and b.get(k) is not None]
        cin = [m["datos"].get("cintura") for m, _ in res if m["datos"].get("cintura")]
        if len(cin) >= 2:
            tendencias["cambios"].append(("Cintura", cin[-1] - cin[0], "cm"))
        tendencias["desde"] = res[0][0]["fecha"]
    return render_template("mediciones.html", tendencias=tendencias, target=target, p=p, res=res, ultimo=res[-1] if res else None, pr=pr, PR=prop,
                           carta=antro.somatocarta_svg(puntos) if puntos else "", A=antro, es_coach=es_coach, url_self=url_self,
                           hoy=str(dt.date.today()))


@app.route("/mediciones", methods=["GET", "POST"])
@login_required
def mediciones():
    return vista_mediciones(g.user, url_for("mediciones"), False)


@app.route("/coach/cliente/<int:cid>/mediciones", methods=["GET", "POST"])
@login_required
def coach_mediciones(cid):
    c = _cliente_de_coach(cid)
    return vista_mediciones(c, url_for("coach_mediciones", cid=cid), True)


# ------------------------------------------------------------------ expediente clínico y de entrenamiento
def datos_expediente(u):
    """Toda la información de un cliente en un solo lugar (para entrenador y para el propio cliente)."""
    r = resumen_usuario(u)
    p, comp, en, mac = r["p"], r["comp"], r["en"], r["mac"]
    todos = registros(u["id"])
    ev = selmod.evaluar(p)
    s = p.get("sondeo") or {}
    medidas = [l for l in todos if l.get("cintura")]
    d = dietamod.normalizar(json.loads(u["smae"]) if u.get("smae") else None)
    an = dietamod.analizar(d, metas_de(d, mac))
    desde = str(dt.date.today() - dt.timedelta(days=13))
    filas = get_db().execute("SELECT fecha, SUM(kcal) k, SUM(prot) p, SUM(carb) c, SUM(grasa) g, COUNT(*) n FROM diario_comidas "
                             "WHERE usuario_id=? AND fecha>=? GROUP BY fecha ORDER BY fecha", (u["id"], desde)).fetchall()
    com = get_db().execute("SELECT c.*, us.nombre FROM comentarios c JOIN usuarios us ON us.id=c.autor_id WHERE usuario_id=? ORDER BY c.id DESC",
                           (u["id"],)).fetchall()
    fuerza = sorted(r["pf"].values(), key=lambda x: -x["series"])
    dolor = dict(DOLORES)
    antro_hist = [(m, antro.calcular(p, m["datos"])) for m in lista_mediciones(u["id"])]
    avz = datos_avanzado(p)
    fotos = [dict(f) for f in get_db().execute("SELECT * FROM fotos WHERE usuario_id=? ORDER BY fecha DESC, id DESC LIMIT 8", (u["id"],)).fetchall()]
    return dict(avz=avz, fotos=fotos, u=u, r=r, p=p, comp=comp, en=en, mac=mac, ev=ev, sondeo=s, todos=todos, medidas=medidas, dieta=d, an=an, antro=antro_hist,
                diario=[dict(x) for x in filas], com=[dict(x) for x in com], fuerza=fuerza, prog=programa(u),
                parq=list(zip(PARQ, p.get("parq") or [False] * len(PARQ))),
                condiciones=[t for k, t in CONDICIONES if k in (p.get("condiciones") or [])],
                dolor=[dolor.get(x, x) for x in s.get("dolor") or []],
                experiencia=next((t for k, t, _ in EXPERIENCIA if k == s.get("experiencia")), p.get("nivel")))


def _cliente_de_coach(cid):
    c = get_db().execute("SELECT * FROM usuarios WHERE id=? AND coach_id=?", (cid, g.user["id"])).fetchone()
    if not c or g.user["rol"] != "entrenador" or not c["perfil"]:
        abort(404)
    return dict(c)


@app.route("/coach/cliente/<int:cid>/expediente")
@login_required
def coach_expediente(cid):
    x = datos_expediente(_cliente_de_coach(cid))
    return render_template("expediente.html", x=x, es_coach=True, pdf=url_for("coach_expediente_pdf", cid=cid))


@app.route("/mi-expediente")
@login_required
def mi_expediente():
    x = datos_expediente(g.user)
    return render_template("expediente.html", x=x, es_coach=False, pdf=url_for("mi_expediente_pdf"))


@app.route("/coach/cliente/<int:cid>/expediente.pdf")
@login_required
def coach_expediente_pdf(cid):
    return _expediente_pdf(datos_expediente(_cliente_de_coach(cid)), para_coach=True)


@app.route("/mi-expediente.pdf")
@login_required
def mi_expediente_pdf():
    return _expediente_pdf(datos_expediente(g.user), para_coach=False)


def _expediente_pdf(x, para_coach):
    p, comp, en, mac, r = x["p"], x["comp"], x["en"], x["mac"], x["r"]
    si_no = lambda v: "Sí" if v else "No"
    b = [("metricas", [("Fitness Score", str(r["score"]["total"]), ""), ("Adherencia 28 días", f"{(r['adherencia'] or 0) * 100:.0f}", "%"),
                       ("Calorías objetivo", _f(mac["kcal"]), "kcal"), ("Días registrados", str(len(x["todos"])), "")]),
         ("h", "1. Datos generales"),
         ("kv", [("Nombre", x["u"]["nombre"]), ("Correo", x["u"]["email"]), ("Sexo · edad", f"{p['sexo']} · {_f(p['edad'])} años"),
                 ("Estatura · peso actual", f"{_f(p['talla'])} cm · {_f(p['peso'], 1)} kg"), ("Objetivo · ritmo", f"{p['objetivo']} · {_f(p.get('ritmo'), 2)} %/sem"),
                 ("Experiencia · nivel", f"{x['experiencia']} · {p['nivel']}"), ("Días y minutos de entrenamiento", f"{p['dias']} días · {_f(p['duracion'])} min"),
                 ("Fecha de inicio", p.get("inicio", "—"))]),
         ("h", "2. Evaluación de salud"),
         ("kv", [("Condiciones declaradas", ", ".join(x["condiciones"]) or "Ninguna"), ("Molestias o dolor", ", ".join(x["dolor"]) or "Ninguno"),
                 ("FC en reposo", f"{_f(p.get('fc_reposo'))} lpm" if p.get("fc_reposo") else "—"),
                 ("Presión arterial", f"{_f(p.get('pas'))}/{_f(p.get('pad'))} mmHg" if p.get("pas") else "—"),
                 ("Puede bajar al suelo y levantarse", "No" if x["sondeo"].get("suelo") == "no" else "Sí"),
                 ("Camina 10 min seguidos", "No" if x["sondeo"].get("camina10") == "no" else "Sí")]),
         ("tabla", ["PAR-Q+", "Respuesta"], [[q, si_no(v)] for q, v in x["parq"]], [6, 1])]
    if r["alertas"]:
        b += [("h", "Alertas activas"), ("lista", [t for _, t in r["alertas"]])]
    b += [("h", "3. Composición corporal y energía"),
          ("kv", [("IMC", f"{_f(comp['imc'], 1)} ({comp.get('imc_clase') or ''})"), ("% de grasa", f"{_f((comp['grasa'] or 0) * 100, 1)} % ({comp.get('metodo') or ''})" if comp.get("grasa") else "—"),
                  ("Masa libre de grasa", f"{_f(comp['mlg'], 1)} kg" if comp.get("mlg") else "—"), ("Índice cintura/estatura", _f(comp.get("ice"), 2) if comp.get("ice") else "—"),
                  ("Gasto en reposo", f"{_f(en['ger'])} kcal ({en['usada']})"), ("Gasto total estimado", f"{_f(en['gasto_total'])} kcal"),
                  ("Gasto adaptativo (datos reales)", f"{_f(r['adapt'])} kcal" if r["adapt"] else "Sin datos suficientes"),
                  ("Metas", f"{_f(mac['kcal'])} kcal · P {_f(mac['prot'])} g · HC {_f(mac['carb'])} g · G {_f(mac['grasa'])} g")])]
    if x["medidas"]:
        b += [("h", "Medidas registradas"), ("tabla", ["Fecha", "Peso (kg)", "Cintura (cm)"], [[str(m["fecha"]), _f(m["peso"], 1), _f(m["cintura"], 1)] for m in x["medidas"]], [2, 1, 1])]
    if x["antro"]:
        filas = []
        for m, ar in x["antro"]:
            so = ar.get("somatotipo")
            filas.append([m["fecha"], "Avanzada" if m["tipo"] == "avanzada" else "Básica", _f(ar["peso"], 1), _f(ar.get("grasa"), 1), ar.get("grasa_metodo") or "—",
                          _f(ar.get("mlg"), 1), _f(ar.get("smm"), 1), f"{so['endo']:.1f}-{so['meso']:.1f}-{so['ecto']:.1f} {so['categoria']}" if so else "—"])
        b += [("h", "Mediciones antropométricas"), ("tabla", ["Fecha", "Tipo", "Peso", "% grasa", "Método", "M. magra", "Músculo", "Somatotipo"], filas,
                                                     [1.1, .9, .7, .7, 1.4, .8, .8, 2])]
        for m, ar in reversed(x["antro"]):
            pr = prop.calcular(p, m["datos"], ar.get("somatotipo"))
            if pr and (pr["indices"] or pr["rasgos"]):
                b += [("h", f"Proporcionalidad ({m['fecha']})")]
                if pr["rasgos"]:
                    b.append(("p", " · ".join(f"<b>{n}</b>: {v}" for n, v in pr["rasgos"])))
                if pr["indices"]:
                    b.append(("tabla", ["Índice", "Valor", "Interpretación"], [[n, v, c] for n, v, c, _ in pr["indices"]], [1.6, .7, 3]))
                if pr["zonas"]:
                    b.append(("tabla", ["Zona", "Perímetro corregido", "Detalle"], [list(z) for z in pr["zonas"]], [1, 1.2, 3]))
                if pr["deportes"]:
                    b.append(("lista", [f"{dep}: {', '.join(mot)}" for dep, _, mot in pr["deportes"]]))
                break
    ing = p.get("ingreso") or {}
    if ing:
        filas_ing = [(k, str(v)) for k, v in [("Fecha de ingreso", ing.get("fecha")), ("Meta", ing.get("meta")), ("Para cuándo", ing.get("fecha_meta")),
                     ("Compromiso", f"{ing['compromiso']}/10" if ing.get("compromiso") else None), ("Motivación", ing.get("motivacion")),
                     ("Experiencia previa", ing.get("experiencia_previa")), ("Horario", ing.get("horario")), ("Medicamentos", ing.get("medicamentos")),
                     ("Lesiones", ing.get("lesiones")), ("Sueño", f"{ing['sueno']} h" if ing.get("sueno") else None), ("Estrés", f"{ing['estres']}/5" if ing.get("estres") else None),
                     ("Alcohol / tabaco", " / ".join(x for x in (ing.get("alcohol"), ing.get("tabaco")) if x)), ("Cocina", ing.get("cocina")),
                     ("Alergias", ing.get("alergias")), ("No le gusta", ing.get("no_gusta")), ("Teléfono", ing.get("telefono") if para_coach else None)] if v]
        b += [("h", "Ficha de ingreso"), ("kv", filas_ing)]
    if x["avz"]["av"]:
        b += [("h", "Perfil avanzado")] + _bloques_avanzado(p, x["avz"])
    if x["fotos"]:
        b.append(("p", f"Fotos de progreso: {len(x['fotos'])} recientes (la más reciente del {x['fotos'][0]['fecha']}). Se consultan en la app."))
    b += [("h", "4. Plan inteligente (reglas activas)")]
    b += [("p", f"<b>{rg['titulo']}.</b> {rg['texto']}") for rg in x["ev"]["reglas"]] or [("p", "Sin restricciones especiales.")]
    if x["ev"]["cardio"]:
        b.append(("p", "Cardio recomendado: " + ", ".join(x["ev"]["cardio"]) + "."))
    b += [("h", "5. Programa de entrenamiento: " + x["prog"].get("nombre", ""))]
    for dd in x["prog"]["dias"]:
        b.append(("tabla", [f"{DIAS[dd['dia']] if 0 <= dd['dia'] < 7 else ''} · {dd['nombre']}", "Series", "Reps", "RIR"],
                  [[e["ex"], str(e["series"]), f"{e['rmin']}–{e['rmax']}", str(e["rir"])] for e in dd["ejercicios"]], [4, 1, 1, .8]))
    if x["fuerza"]:
        b += [("h", "6. Progreso de fuerza (e1RM)"), ("tabla", ["Ejercicio", "Series", "Inicial", "Mejor", "Cambio"],
                                                   [[f["ejercicio"], str(f["series"]), _f(f["inicial"], 1), _f(f["mejor"], 1), f"{f['cambio'] * 100:+.1f} %"] for f in x["fuerza"]], [4, .8, 1, 1, 1])]
    an = x["an"]
    b += [("h", "7. Dieta por equivalentes"), ("kv", [("Calorías de la dieta", f"{_f(an['total'][0])} kcal (adecuación {_f((an['adec'][0] or 0) * 100)} %)"),
                                                     ("Proteína", f"{_f(an['total'][1])} g (adecuación {_f((an['adec'][1] or 0) * 100)} %)"),
                                                     ("Elaborada por", x["dieta"].get("autor") or "—"), ("Última actualización", x["dieta"].get("actualizado") or "—")])]
    if x["dieta"].get("notas"):
        b.append(("p", "Notas: " + x["dieta"]["notas"]))
    if x["diario"]:
        b += [("h", "8. Diario de comidas (últimos 14 días)"), ("tabla", ["Fecha", "kcal", "Proteína", "HC", "Grasa", "Registros"],
                                                                    [[d["fecha"], _f(d["k"]), _f(d["p"]), _f(d["c"]), _f(d["g"]), str(d["n"])] for d in x["diario"]])]
    b += [("salto",), ("h", "9. Registro diario completo"),
          ("tabla", ["Fecha", "Peso", "kcal", "Prot.", "Pasos", "Sueño", "Entrenó", "Energía", "Notas"],
           [[str(l["fecha"]), _f(l["peso"], 1), _f(l["kcal"]), _f(l["proteina"]), _f(l["pasos"]), _f(l["sueno"], 1), l["entreno"] or "", _f(l["energia"]), (l["notas"] or "")[:60]] for l in x["todos"]],
           [1.3, .8, .8, .8, .9, .7, .9, .8, 2])]
    if x["com"]:
        b += [("h", "10. Comentarios del entrenador"), ("tabla", ["Fecha", "Autor", "Comentario"], [[c["creado"][:10], c["nombre"], c["texto"]] for c in x["com"]], [1.2, 1.5, 5])]
    b.append(("nota", "Documento confidencial con datos personales y de salud (LFPDPPP). Compártelo solo con profesionales autorizados por el cliente."))
    titulo = f"Expediente de {x['u']['nombre']}"
    return pdf_resp(titulo, b, ("Vista del entrenador · " if para_coach else "") + f"Generado el {dt.date.today():%d/%m/%Y}")


@app.route("/coach/reporte.pdf")
@login_required
def coach_reporte_pdf():
    if g.user["rol"] != "entrenador":
        abort(403)
    clientes = [dict(c) for c in get_db().execute("SELECT * FROM usuarios WHERE coach_id=? ORDER BY nombre", (g.user["id"],)).fetchall()]
    filas, alertas = [], []
    for c in clientes:
        if not c.get("perfil"):
            filas.append([c["nombre"], "Sin evaluación", "", "", "", ""])
            continue
        r = resumen_usuario(c)
        pesos = [l["peso"] for l in r["logs"] if l["peso"]]
        filas.append([c["nombre"], r["p"]["objetivo"], str(r["score"]["total"]), f"{(r['adherencia'] or 0) * 100:.0f} %",
                      f"{(pesos[-1] - pesos[0]):+.1f} kg" if len(pesos) > 1 else "—", str(len(r["alertas"]))])
        alertas += [f"{c['nombre']}: {t}" for _, t in r["alertas"]]
    b = [("metricas", [("Clientes", str(len(clientes)), ""), ("Con alertas", str(len({a.split(':')[0] for a in alertas})), "")]),
         ("h", "Resumen por cliente"), ("tabla", ["Cliente", "Objetivo", "Score", "Adherencia", "Cambio de peso (90 d)", "Alertas"], filas, [2.2, 1.6, .8, 1, 1.4, .8])]
    if alertas:
        b += [("h", "Alertas a revisar"), ("lista", alertas)]
    return pdf_resp("Reporte de clientes", b, f"{g.user['nombre']} · {dt.date.today():%d/%m/%Y}")


@app.errorhandler(404)
def no_encontrado(e):
    return render_template("404.html"), 404


# ------------------------------------------------------------------ arranque
def _seed_diario_demo(con):
    """Diario de comidas de ejemplo para la cuenta demo (solo si está vacío)."""
    u = con.execute("SELECT id FROM usuarios WHERE email='demo@fitapp.local'").fetchone()
    if not u or con.execute("SELECT 1 FROM diario_comidas WHERE usuario_id=?", (u["id"],)).fetchone():
        return
    dias = ["Desayuno: 2 huevos, 2 tortillas, media taza de frijoles y un café con leche\nComida: 1 filete de pechuga de pollo, 1 taza de arroz, 1 taza de brócoli y una manzana\nColación PM: 1 yogur griego con fresas\nCena: 2 rebanadas de pan integral, 2 rebanadas de jamón de pavo y 1 vaso de leche",
            "Desayuno: 1 taza de avena con un plátano y 1 scoop de proteína whey\nComida: 3 tacos al pastor y un refresco de cola\nCena: 1 taza de ensalada de atún",
            "Desayuno: chilaquiles verdes y un jugo de naranja\nComida: 1 filete de salmón, 1 taza de arroz integral, 1 taza de espinaca y un aguacate\nColación PM: un puño de almendras y una pera\nCena: 1 quesadilla de queso y 1 taza de calabacita",
            "Desayuno: 2 huevos, 1 taza de nopales, 2 tortillas y una naranja\nComida: 1 taza de lentejas, 1 bistec, 1 taza de arroz y 1 taza de ejotes\nColación PM: 1 yogur griego con 1 cucharada de chía\nCena: 1 sándwich de pavo y una manzana"]
    hoy = dt.date.today()
    for i, txt in enumerate(dias):
        fecha = str(hoy - dt.timedelta(days=len(dias) - i))
        items, _ = rr.interpretar_texto(txt)
        for x in items:
            con.execute("INSERT INTO diario_comidas (usuario_id, fecha, tiempo, alimento, porcion, gramos, kcal, prot, carb, grasa, fibra, alimento_id, fuente) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (u["id"], fecha, x.get("tiempo") or "Comida", x["nombre"], x["porcion"], x["gramos"], x["kcal"], x["prot"], x["carb"], x["grasa"],
                         round((x["por100g"].get("fibra") or 0) * x["gramos"] / 100, 1), x.get("alimento_id"), "ejemplo"))
        sincronizar_registro(con, u["id"], fecha)
    con.commit()


def _seed_retos(con):
    if con.execute("SELECT 1 FROM retos").fetchone():
        return
    coach = con.execute("SELECT id FROM usuarios WHERE rol='entrenador' ORDER BY id LIMIT 1").fetchone()
    hoy = dt.date.today()
    for r in rt.RETOS_BASE:
        con.execute("""INSERT INTO retos (titulo, descripcion, tipo, meta, inicio, fin, puntos, nivel, cuota, premios, cupo, validar, creador_id)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (r["titulo"], r["descripcion"], r["tipo"], r["meta"], str(hoy - dt.timedelta(days=3)), str(hoy + dt.timedelta(days=r["dias"] - 3)),
                     r["puntos"], r["nivel"], r["cuota"], r["premios"], r.get("cupo"), r.get("validar", 0), coach["id"] if coach else None))
    con.commit()


def preparar():
    db.respaldar()
    con = db.conectar()
    db.init_db(con)
    db.seed_demo(con)
    _seed_diario_demo(con)
    _seed_retos(con)
    con.close()


def ip_local():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


preparar()

ACTUALIZACION = {}
PENDIENTE_REINICIO = [None]   # versión ya instalada que espera un momento sin uso para reiniciar


@app.context_processor
def _ctx_actualizacion():
    return {"actualizacion": ACTUALIZACION if ACTUALIZACION and es_local() else None,
            "actualizacion_pendiente": PENDIENTE_REINICIO[0] if es_local() else None}


def _tick_actualizaciones(ahora=None):
    """Una vuelta del vigilante. Devuelve lo que hizo (para pruebas y registro)."""
    import time
    ahora = ahora or time.time()
    cfg = actualizador.leer_config()
    if PENDIENTE_REINICIO[0]:
        if ahora - ULTIMA_ACTIVIDAD[0] > 120:
            print(f"  Reiniciando para usar la versión {PENDIENTE_REINICIO[0]}…")
            reiniciar_servidor(0.5)
            return "reinicio"
        return "esperando"
    if not actualizador.url_manifiesto(cfg):
        return "sin_fuente"
    ult = cfg.get("ultima_revision")
    vencida = not ult or (dt.datetime.now() - dt.datetime.strptime(ult, "%Y-%m-%d %H:%M")).total_seconds() >= cfg.get("cada_horas", 6) * 3600
    if not vencida:
        return "al_dia"
    m = actualizador.consultar_en_linea()
    if not (m and m.get("disponible")):
        return "sin_novedad"
    ACTUALIZACION.clear(); ACTUALIZACION.update(m)
    if not cfg.get("auto"):
        return "aviso"
    r = actualizador.instalar_en_linea(m)
    ACTUALIZACION.clear()
    PENDIENTE_REINICIO[0] = r["nueva"]
    print(f"  Actualización {r['nueva']} instalada. Se reiniciará cuando nadie esté usando la app.")
    return "instalada"


def _vigilante_actualizaciones():
    """Revisa cada N horas; si la actualización automática está activa, instala y reinicia cuando nadie use la app."""
    import time
    time.sleep(20)
    while True:
        try:
            if _tick_actualizaciones() == "reinicio":
                return
        except Exception:  # noqa: BLE001 - sin internet se reintenta en la siguiente vuelta
            pass
        time.sleep(60)


def _auto_actualizar():
    """Al arrancar (nadie está usando la app todavía): si la actualización automática está activa, instala y reinicia."""
    import sys
    cfg = actualizador.leer_config()
    if not (cfg.get("auto") or os.environ.get("FITAPP_AUTO_ACTUALIZAR") == "1") or not actualizador.url_manifiesto(cfg):
        return
    try:
        m = actualizador.consultar_en_linea()
        if m and m.get("disponible"):
            print(f"  Instalando la actualización {m['version']}…")
            r = actualizador.instalar_en_linea(m)
            print(f"  Listo: {r['anterior']} -> {r['nueva']}. Reiniciando…")
            os.execv(sys.executable, [sys.executable] + sys.argv)
    except Exception as e:  # noqa: BLE001
        print(f"  No se pudo buscar actualizaciones ({e}). Se reintentará más tarde.")


if __name__ == "__main__":
    puerto = int(os.environ.get("PORT", 5000))
    if os.environ.get("FITAPP_ESPERA"):
        import time
        time.sleep(float(os.environ["FITAPP_ESPERA"]))
    _auto_actualizar()
    import threading
    threading.Thread(target=_vigilante_actualizaciones, daemon=True).start()
    if os.environ.get("FITAPP_ABRIR") == "1":
        import webbrowser
        threading.Timer(1.5, lambda: webbrowser.open(f"http://localhost:{puerto}")).start()
    print(f"\n  {APP_NOMBRE} {actualizador.version_actual()} listo:\n   · En esta PC:      http://localhost:{puerto}\n   · En tu red local: http://{ip_local()}:{puerto}\n"
          f"   · Cuenta demo: demo@fitapp.local / demo1234  ·  entrenador: coach@fitapp.local / demo1234\n"
          f"   · Administrador: http://localhost:{puerto}/admin  (la primera vez se crea en /admin/crear)\n")
    try:
        from waitress import serve
        serve(app, host="0.0.0.0", port=puerto, threads=8)
    except ImportError:
        app.run(host="0.0.0.0", port=puerto, debug=False)
