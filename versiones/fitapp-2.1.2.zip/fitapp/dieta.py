"""Dietocálculo profesional por equivalentes SMAE (inspirado en el Excel del usuario y la plantilla de dietocálculo).

Estructura guardada en usuarios.smae (JSON):
  {"v": 2, "tiempos": [...], "dist": {grupo: [eq por tiempo]}, "menu": {tiempo: texto},
   "recetas": {tiempo: id_receta}, "notas": str, "metas": {...} | null, "autor": str, "actualizado": "AAAA-MM-DD"}
"""
import datetime as dt
from data.contenido import SMAE

TIEMPOS = ["Desayuno", "Colación AM", "Comida", "Pre-entreno", "Post-entreno", "Cena"]
# fracción de kcal por tiempo (suma 1)
REPARTO_KCAL = [0.25, 0.08, 0.30, 0.08, 0.12, 0.17]
GRUPOS = [g[0] for g in SMAE]
VAL = {g[0]: g[1:] for g in SMAE}  # kcal, prot, lip, hc

# Grupos que conviene concentrar en ciertos tiempos (heurística de distribución)
PREFERENCIA = {
    "Verduras": [1, 0, 2, 0, 0, 2],
    "Frutas": [1, 1, 0, 1, 0, 0],
    "Cereales sin grasa": [2, 0, 3, 1, 2, 1],
    "Leguminosas": [0, 0, 1, 0, 0, 0],
    "AOA muy bajo en grasa": [3, 0, 4, 0, 1, 3],
    "AOA bajo en grasa": [1, 1, 2, 0, 0, 1],
    "AOA moderado en grasa": [2, 0, 1, 0, 0, 1],
    "Leche descremada": [1, 0, 0, 0, 1, 0],
    "Aceites y grasas sin proteína": [1, 0, 2, 0, 0, 1],
    "Aceites y grasas con proteína": [0, 1, 0, 1, 0, 0],
}


def r05(x):
    return max(0.0, round(x * 2) / 2)


def normalizar(raw):
    """Convierte el formato antiguo {grupo: cantidad} al formato v2."""
    if raw and raw.get("v") == 2:
        d = raw
        d.setdefault("tiempos", TIEMPOS)
        d.setdefault("dist", {})
        d.setdefault("menu", {})
        d.setdefault("recetas", {})
        d.setdefault("notas", "")
        return d
    eq = {k: float(v) for k, v in (raw or {}).items() if k in VAL and v}
    return {"v": 2, "tiempos": TIEMPOS, "dist": distribuir(eq), "menu": {}, "recetas": {}, "notas": "", "metas": None}


def totales_por_grupo(d):
    return {g: sum(d["dist"].get(g, [0] * len(d["tiempos"]))) for g in GRUPOS}


def calcular_equivalentes(metas, kcal):
    """Propuesta inicial de equivalentes para acercarse a las metas de macros."""
    eq = {g: 0.0 for g in GRUPOS}
    eq["Verduras"] = 5
    eq["Frutas"] = 2 if kcal < 1800 else 3
    eq["Leguminosas"] = 1
    eq["Leche descremada"] = 1 if kcal < 2200 else 2

    def suma():
        t = [0, 0, 0, 0]
        for g, q in eq.items():
            for i, v in enumerate(VAL[g]):
                t[i] += q * v
        return t
    _, p, l, c = suma()
    eq["Cereales sin grasa"] = r05(max(0, metas["carb"] - c) / 15)
    _, p, l, c = suma()
    rest_p = max(0, metas["prot"] - p)
    eq["AOA moderado en grasa"] = 1 if rest_p > 40 else 0
    rest_p -= 7 * eq["AOA moderado en grasa"]
    eq["AOA bajo en grasa"] = r05(rest_p * 0.3 / 7)
    eq["AOA muy bajo en grasa"] = r05(rest_p * 0.7 / 7)
    _, p, l, c = suma()
    rest_l = max(0, metas["grasa"] - l)
    eq["Aceites y grasas con proteína"] = r05(rest_l / 3 / 5)
    eq["Aceites y grasas sin proteína"] = r05(rest_l * 2 / 3 / 5)
    return {g: q for g, q in eq.items() if q}


def distribuir(eq, n=len(TIEMPOS)):
    """Reparte cada grupo entre los tiempos de comida según preferencias (redondeo a 0.5 y cuadre exacto)."""
    dist = {}
    for g, q in eq.items():
        pref = PREFERENCIA.get(g, REPARTO_KCAL)[:n]
        tot = sum(pref) or 1
        vals = [r05(q * w / tot) for w in pref]
        diff = r05(q) - sum(vals)
        orden = sorted(range(n), key=lambda i: -pref[i])
        k = 0
        while abs(diff) >= 0.5 and k < 50:
            i = orden[k % n]
            paso = 0.5 if diff > 0 else -0.5
            if vals[i] + paso >= 0:
                vals[i] += paso
                diff -= paso
            k += 1
        dist[g] = vals
    return dist


def analizar(d, metas):
    n = len(d["tiempos"])
    por_tiempo = [[0.0, 0.0, 0.0, 0.0] for _ in range(n)]
    total = [0.0, 0.0, 0.0, 0.0]
    for g in GRUPOS:
        qs = d["dist"].get(g, [0] * n)
        for i in range(n):
            q = qs[i] if i < len(qs) else 0
            for j, v in enumerate(VAL[g]):
                por_tiempo[i][j] += q * v
                total[j] += q * v
    m = [metas["kcal"], metas["prot"], metas["grasa"], metas["carb"]]
    adec = [t / x if x else None for t, x in zip(total, m)]
    estado = ["ok" if a is not None and 0.9 <= a <= 1.1 else ("bajo" if a is not None and a < 0.9 else "alto") for a in adec]
    kcal_tot = total[0] or 1
    pct_kcal = [pt[0] / kcal_tot for pt in por_tiempo]
    macro_pct = {"prot": total[1] * 4 / kcal_tot, "lip": total[2] * 9 / kcal_tot, "hc": total[3] * 4 / kcal_tot}
    return {"por_tiempo": por_tiempo, "total": total, "metas": m, "adec": adec, "estado": estado,
            "pct_kcal": pct_kcal, "macro_pct": macro_pct}


def sello(d, autor):
    d["autor"] = autor
    d["actualizado"] = str(dt.date.today())
    return d
