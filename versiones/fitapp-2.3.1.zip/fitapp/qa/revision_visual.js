// Revisión visual: capturas + medición automática. Uso: node qa/revision_visual.js [tag] [rol] [vistas] [temas] [filtro]
const { chromium, devices } = require('playwright');
const fs = require('fs');
const BASE = 'http://localhost:5002';
const OUT = '/home/user/fitapp/qa/salida/visual_todas';
const [,, TAG = 'antes', ROLFILT = '', VISTAS = 'pc,tab,ios,and', TEMAS = 'claro,oscuro', FILT = ''] = process.argv;
const CUENTAS = {
  lucia: ['lucia.qa@example.com', 'Lucia2026!'], demo: ['demo@fitapp.local', 'demo1234'], coach: ['coach@fitapp.local', 'demo1234'], pub: null };
const PAGS = {
  lucia: ['/app', '/habitos', '/nutricion', '/diario', '/registrar', '/menu-semanal', '/progreso', '/cuerpo', '/puntaje', '/retos', '/suplementacion', '/mi-privacidad', '/ajustes', '/sesion', '/programa', '/dieta', '/alimentos', '/recetas', '/ejercicios', '/mi-plan', '/planes', '/notificaciones', '/asistente', '/guia', '/nutricion/preferencias', '/fotos', '/feedback', '/entrenar'],
  demo: ['/app', '/puntaje', '/progreso'],
  coach: ['/coach', '/coach/cliente/6', '/coach/cliente/6/puntaje', '/coach/retos', '/coach/actividad', '/coach/invitar', '/coach/feedback', '/admin', '/admin/pagos', '/admin/crear', '/app'],
  pub: ['/', '/planes', '/login', '/registro', '/calculadoras', '/articulos', '/mitos', '/emergencia', '/ejercicios', '/recetas', '/alimentos', '/cuerpo', '/privacidad']
};
const VIS = {
  pc: { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 },
  tab: { viewport: { width: 1024, height: 1366 }, deviceScaleFactor: 1 },
  ios: { ...devices['iPhone 14 Pro Max'], deviceScaleFactor: 1 },
  and: { viewport: { width: 360, height: 780 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36' }
};
function medir() {
  const res = { recortes: [], desborde: [], alturas: [], contraste: [], encimados: [], imgs: [], hscroll: document.documentElement.scrollWidth > innerWidth + 1 };
  const sel = el => { let s = el.tagName.toLowerCase(); if (el.id) s += '#' + el.id; if (el.className && typeof el.className === 'string') s += '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.'); return s; };
  const vis = el => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width > 2 && r.height > 2 && cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0'; };
  const all = [...document.querySelectorAll('body *')].filter(el => !['SCRIPT', 'STYLE', 'TEMPLATE', 'PATH', 'SVG', 'CIRCLE', 'LINE', 'RECT', 'G', 'POLYLINE', 'TEXT', 'TSPAN'].includes(el.tagName.toUpperCase()) && vis(el));
  const parse = c => { const m = c.match(/[\d.]+/g); return m ? m.map(Number) : [0, 0, 0, 1]; };
  const lum = ([r, g, b]) => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); };
  const over = (f, b) => { const a = f[3] ?? 1; return [0, 1, 2].map(i => f[i] * a + b[i] * (1 - a)).concat(1); };
  const bgEf = el => { const ch = []; let e = el; while (e) { const c = parse(getComputedStyle(e).backgroundColor); if (c.length < 4) c.push(1); if (c[3] > 0) ch.push(c); if (c[3] >= 1) break; e = e.parentElement; } let b = [255, 255, 255, 1]; if (!ch.length || ch[ch.length - 1][3] < 1) b = [getComputedStyle(document.documentElement).colorScheme === 'dark' ? 0 : 255, 0, 0, 1]; for (let i = ch.length - 1; i >= 0; i--) b = over(ch[i], b); return b; };
  for (const el of all) {
    const cs = getComputedStyle(el), r = el.getBoundingClientRect();
    if (el.closest('.side') && matchMedia('(max-width:900px)').matches && !document.body.classList.contains('menu-abierto')) { /* drawer cerrado */ }
    if (r.right < 0 || r.left > innerWidth + 5 && !el.closest('.tbl, .scroll, table')) { }
    const ovx = cs.overflowX, ovy = cs.overflowY;
    if ((ovx === 'hidden' || ovx === 'clip') && el.scrollWidth > el.clientWidth + 2 && el.clientWidth > 0) res.recortes.push({ el: sel(el), tipo: 'x', sw: el.scrollWidth, cw: el.clientWidth, txt: (el.innerText || '').trim().slice(0, 40) });
    if ((ovy === 'hidden' || ovy === 'clip') && el.scrollHeight > el.clientHeight + 2 && el.clientHeight > 0) res.recortes.push({ el: sel(el), tipo: 'y', sh: el.scrollHeight, ch: el.clientHeight, txt: (el.innerText || '').trim().slice(0, 40) });
    if (el.children.length === 0 && (el.innerText || '').trim() && cs.overflow === 'visible' && el.scrollWidth > el.clientWidth + 2 && cs.display !== 'inline' && !(el.closest('.side') && getComputedStyle(el.closest('.side')).transform !== 'none')) res.desborde.push({ el: sel(el), sw: el.scrollWidth, cw: el.clientWidth, txt: el.innerText.trim().slice(0, 40) });
    if (el.children.length === 0 || [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) {
      const txt = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join('').trim();
      if (txt && !(el.closest('.side') && getComputedStyle(el.closest('.side')).transform !== 'none' && r.left < 0)) {
        const fg = parse(cs.color); if (fg.length < 4) fg.push(1); const bg = bgEf(el); const f = over(fg, bg);
        const L1 = lum(f), L2 = lum(bg), cr = (Math.max(L1, L2) + .05) / (Math.min(L1, L2) + .05);
        const big = parseFloat(cs.fontSize) >= 24 || (parseFloat(cs.fontSize) >= 18.6 && +cs.fontWeight >= 700);
        if (cr < (big ? 3 : 4.5) && !el.disabled && cs.backgroundImage === 'none') res.contraste.push({ el: sel(el), cr: +cr.toFixed(2), txt: txt.slice(0, 30) });
      }
    }
  }
  // alturas distintas en filas de tarjetas
  for (const p of document.querySelectorAll('.grid, .cards, .kpis, .kpi-row, [class*=grid], .flex')) {
    const k = [...p.children].filter(vis); if (k.length < 2) continue;
    const rows = {}; k.forEach(c => { const r = c.getBoundingClientRect(); (rows[Math.round(r.top / 10)] ||= []).push(r); });
    for (const rr of Object.values(rows)) { if (rr.length < 2) continue; const hs = rr.map(x => x.height); const mx = Math.max(...hs), mn = Math.min(...hs); if (mx > 40 && mn / mx < .6 && p.matches('.grid,.cards,.kpis,[class*=grid]')) res.alturas.push({ el: sel(p), min: Math.round(mn), max: Math.round(mx) }); }
  }
  for (const i of document.images) if (i.complete && i.naturalWidth === 0 && i.src) res.imgs.push(i.src.slice(0, 80));
  // elementos de texto que se salen de su tarjeta
  for (const el of all) { if (el.children.length) continue; const p = el.parentElement; if (!p || !(el.innerText || '').trim()) continue; const pc = getComputedStyle(p); if (pc.overflow !== 'visible') continue; const a = el.getBoundingClientRect(), b = p.getBoundingClientRect(); if (a.right > b.right + 3 && b.width > 50 && !el.closest('.side') && getComputedStyle(el).position !== 'absolute') res.encimados.push({ el: sel(el), sobra: Math.round(a.right - b.right) }); }
  const dedup = a => { const m = new Map(); a.forEach(x => { const k = JSON.stringify([x.el, x.txt]); if (!m.has(k)) m.set(k, x); }); return [...m.values()].slice(0, 25); };
  for (const k of ['recortes', 'desborde', 'contraste', 'encimados', 'alturas']) res[k] = dedup(res[k]);
  res.vw = innerWidth; res.sw = document.documentElement.scrollWidth;
  return res;
}
(async () => {
  const br = await chromium.launch();
  const resultados = {};
  for (const rol of Object.keys(PAGS)) {
    if (ROLFILT && !ROLFILT.split(',').includes(rol)) continue;
    for (const v of VISTAS.split(',')) for (const tema of TEMAS.split(',')) {
      const ctx = await br.newContext({ ...VIS[v], colorScheme: tema === 'claro' ? 'light' : 'dark' });
      await ctx.addInitScript(t => { try { localStorage.setItem('tema', t); localStorage.setItem('guiaVista', '1'); } catch (e) { } }, tema === 'claro' ? 'light' : 'dark');
      const p = await ctx.newPage();
      if (CUENTAS[rol]) {
        await p.goto(BASE + '/login'); await p.fill('form:has([name=password]) [name=email]', CUENTAS[rol][0]); await p.fill('form:has([name=password]) [name=password]', CUENTAS[rol][1]);
        await Promise.all([p.waitForLoadState('load'), p.click('form:has([name=password]) button')]); await p.waitForTimeout(500);
      }
      for (const url of PAGS[rol]) {
        if (FILT && !url.includes(FILT)) continue;
        try {
          await p.goto(BASE + url, { waitUntil: 'load', timeout: 20000 }); await p.waitForTimeout(450);
          if (await p.locator('.guia-capa').count()) { await p.keyboard.press('Escape'); await p.waitForTimeout(200); }
          const nombre = `${rol}_${url.replace(/[^a-z0-9]+/gi, '_').replace(/^_|_$/g, '') || 'raiz'}_${v}_${tema}_${TAG}`;
          await p.screenshot({ path: `${OUT}/${nombre}.jpg`, type: 'jpeg', quality: 70, fullPage: true });
          const m = await p.evaluate(medir); m.status = 'ok'; resultados[nombre] = m;
        } catch (e) { resultados[`${rol}_${url}_${v}_${tema}`] = { error: String(e).slice(0, 120) }; }
      }
      await ctx.close();
    }
  }
  fs.writeFileSync(`${OUT}/medicion_${TAG}${ROLFILT ? '_' + ROLFILT.replace(/,/g, '') : ''}.json`, JSON.stringify(resultados, null, 1));
  await br.close();
})();
