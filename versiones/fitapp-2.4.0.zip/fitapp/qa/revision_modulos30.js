// Revisión visual rápida de los módulos 3.0 (cronómetros, sueño, bienestar, calentamiento, recuperación, alta, guía de mediciones)
const { chromium, devices } = require('playwright');
const BASE = 'http://127.0.0.1:' + (process.env.PUERTO || 5004), OUT = process.argv[2] || 'qa/salida/modulos30';
const PAGS = [['herramientas', '/herramientas?preset=box-3x1'], ['sueno', '/sueno'], ['bienestar', '/bienestar'], ['calentamiento', '/calentamiento?deporte=running'],
  ['recuperacion', '/recuperacion'], ['alta', '/coach/cliente/6/alta'], ['habitos', '/habitos'], ['mediciones', '/mediciones'], ['sesion', '/sesion']];
(async () => {
  require('fs').mkdirSync(OUT, { recursive: true });
  const b = await chromium.launch(); const malos = [];
  for (const [disp, o] of [['pc', { viewport: { width: 1440, height: 900 } }], ['cel', devices['iPhone 14 Pro Max']], ['and', { viewport: { width: 360, height: 780 }, isMobile: true, hasTouch: true }]]) {
    for (const tema of ['dark', 'light']) {
      const c = await b.newContext(o); const p = await c.newPage();
      await p.goto(BASE + '/login'); await p.evaluate(t => localStorage.setItem('tema', t), tema);
      await p.fill('input[name=email]', 'coach@fitapp.local'); await p.fill('input[name=password]', 'demo1234');
      await Promise.all([p.waitForNavigation(), p.click('button[type=submit]')]);
      for (const [n, u] of PAGS) {
        const r = await p.goto(BASE + u); await p.waitForTimeout(250);
        const m = await p.evaluate(() => {
          const out = { sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, cortados: [] };
          document.querySelectorAll('.card, .tz-kpi, .btn, .cr-preset, .rc-item, .mg-item, .al-paso, h1, h2').forEach(e => {
            const cs = getComputedStyle(e); if (cs.display === 'none' || !e.offsetParent) return;
            if ((cs.overflowX === 'hidden' || cs.overflow === 'hidden') && e.scrollWidth > e.clientWidth + 2) out.cortados.push((e.className || e.tagName) + ': ' + (e.innerText || '').slice(0, 30));
            const rr = e.getBoundingClientRect(); if (rr.right > document.documentElement.clientWidth + 1) out.cortados.push('fuera: ' + (e.className || e.tagName) + ' ' + (e.innerText || '').slice(0, 30));
          }); return out; });
        if (r.status() >= 400 || m.sw > m.cw || m.cortados.length) malos.push(`${disp}/${tema}/${n}: ${r.status()} sw=${m.sw}/${m.cw} ${m.cortados.slice(0, 4).join(' | ')}`);
        if (tema === 'dark' || disp === 'pc') await p.screenshot({ path: `${OUT}/${disp}_${tema}_${n}.png`, fullPage: false });
      }
      await c.close();
    }
  }
  console.log(malos.length ? malos.join('\n') : 'Sin desbordes ni recortes'); await b.close();
})();
