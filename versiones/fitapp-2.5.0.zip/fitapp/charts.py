"""Gráficas en SVG generadas en el servidor (sin dependencias externas; respetan el tema claro/oscuro)."""
import math


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def linea(series, etiquetas, alto=200, ancho=640, titulo="", unidad=""):
    """series: lista de (nombre, valores[None permitido], clase_css, punteada)."""
    vals = [v for _, vs, _, _ in series for v in vs if v is not None]
    if len(vals) < 2:
        return '<p class="vacio">Aún no hay datos suficientes para la gráfica.</p>'
    lo, hi = min(vals), max(vals)
    if hi - lo < 1e-6:
        hi, lo = hi + 1, lo - 1
    pad = (hi - lo) * 0.12
    lo, hi = lo - pad, hi + pad
    n = max(len(vs) for _, vs, _, _ in series)
    x0, x1, y0, y1 = 44, ancho - 10, 14, alto - 26
    X = lambda i: x0 + (x1 - x0) * (i / max(n - 1, 1))
    Y = lambda v: y1 - (y1 - y0) * ((v - lo) / (hi - lo))
    out = [f'<svg viewBox="0 0 {ancho} {alto}" class="chart" role="img" aria-label="{_esc(titulo)}">']
    for k in range(4):
        v = lo + (hi - lo) * k / 3
        y = Y(v)
        out.append(f'<line x1="{x0}" x2="{x1}" y1="{y:.1f}" y2="{y:.1f}" class="grid"></line>')
        out.append(f'<text x="4" y="{y + 4:.1f}" class="axis">{v:.1f}</text>')
    paso = max(1, n // 6)
    for i in range(0, n, paso):
        if i < len(etiquetas):
            out.append(f'<text x="{X(i):.1f}" y="{alto - 6}" class="axis" text-anchor="middle">{_esc(etiquetas[i])}</text>')
    for nombre, vs, clase, punteada in series:
        pts = [f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(vs) if v is not None]
        if not pts:
            continue
        dash = ' stroke-dasharray="4 4"' if punteada else ""
        out.append(f'<polyline points="{" ".join(pts)}" class="serie {clase}"{dash}></polyline>')
        if punteada:
            for pnt in pts:
                x, y = pnt.split(",")
                out.append(f'<circle cx="{x}" cy="{y}" r="2.5" class="punto {clase}"></circle>')
    out.append("</svg>")
    leyenda = "".join(f'<span class="ley {c}">{_esc(nm)}</span>' for nm, _, c, _ in series)
    return "".join(out) + f'<div class="leyenda">{leyenda}</div>'


def barras(valores, etiquetas, alto=170, ancho=640, titulo="", clases=None, referencia=None):
    if not valores or max(valores) <= 0:
        return '<p class="vacio">Aún no hay datos suficientes para la gráfica.</p>'
    hi = max(max(valores), referencia or 0) * 1.1
    n = len(valores)
    x0, x1, y0, y1 = 10, ancho - 10, 10, alto - 24
    w = (x1 - x0) / n
    out = [f'<svg viewBox="0 0 {ancho} {alto}" class="chart" role="img" aria-label="{_esc(titulo)}">']
    for i, v in enumerate(valores):
        h = (y1 - y0) * v / hi
        c = clases[i] if clases else "bar"
        if "vacia" in c:      # día sin registro: marca punteada en la base (no es un cero)
            out.append(f'<rect x="{x0 + i * w + w * 0.15:.1f}" y="{y1 - 4:.1f}" width="{w * 0.7:.1f}" height="4" rx="2" class="{c}"><title>{_esc(etiquetas[i])}: sin registro</title></rect>')
        else:
            out.append(f'<rect x="{x0 + i * w + w * 0.15:.1f}" y="{y1 - max(h, 3):.1f}" width="{w * 0.7:.1f}" height="{max(h, 3):.1f}" rx="3" class="{c}"><title>{_esc(etiquetas[i])}: {v:,.0f}</title></rect>')
        if n <= 16 or i % 2 == 0:
            out.append(f'<text x="{x0 + i * w + w / 2:.1f}" y="{alto - 8}" class="axis" text-anchor="middle">{_esc(etiquetas[i])}</text>')
    if referencia:
        y = y1 - (y1 - y0) * referencia / hi
        out.append(f'<line x1="{x0}" x2="{x1}" y1="{y:.1f}" y2="{y:.1f}" class="ref"></line>')
    out.append("</svg>")
    return "".join(out)


def radar(componentes, tam=300):
    n = len(componentes)
    cx = cy = tam / 2
    R = tam / 2 - 56
    pt = lambda i, r: (cx + r * math.cos(-math.pi / 2 + 2 * math.pi * i / n), cy + r * math.sin(-math.pi / 2 + 2 * math.pi * i / n))
    poly = lambda f: " ".join(f"{x:.1f},{y:.1f}" for x, y in (pt(i, R * f(i)) for i in range(n)))
    out = [f'<svg viewBox="-36 0 {tam + 72} {tam}" class="chart radar" role="img" aria-label="Radar del Fitness Score">']
    for k in (0.25, 0.5, 0.75, 1):
        out.append(f'<polygon points="{poly(lambda i: k)}" class="grid"></polygon>')
    out.append(f'<polygon points="{poly(lambda i: componentes[i][1] / 100)}" class="area"></polygon>')
    for i, (nombre, v) in enumerate(componentes):
        x, y = pt(i, R + 26)
        out.append(f'<text x="{x:.1f}" y="{y:.1f}" class="axis" text-anchor="middle">{_esc(nombre)}</text>')
        out.append(f'<text x="{x:.1f}" y="{y + 12:.1f}" class="axis fuerte" text-anchor="middle">{v}</text>')
    out.append("</svg>")
    return "".join(out)


def area(valores, etiquetas, alto=230, ancho=520, titulo="", prefijo=""):
    """Área acumulada con degradado (estilo P&L acumulado)."""
    if len(valores) < 2:
        return '<p class="vacio">Aún no hay datos suficientes para la gráfica.</p>'
    lo, hi = min(0, min(valores)), max(valores) * 1.08 or 1
    x0, x1, y0, y1 = 54, ancho - 8, 10, alto - 24
    X = lambda i: x0 + (x1 - x0) * i / (len(valores) - 1)
    Y = lambda v: y1 - (y1 - y0) * (v - lo) / (hi - lo)
    pts = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(valores))
    out = [f'<svg viewBox="0 0 {ancho} {alto}" class="chart" role="img" aria-label="{_esc(titulo)}">',
           '<defs><linearGradient id="gArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--pos)" stop-opacity=".55"></stop><stop offset="1" stop-color="var(--pos)" stop-opacity=".04"></stop></linearGradient></defs>']
    for k in range(5):
        v = lo + (hi - lo) * k / 4
        out.append(f'<line x1="{x0}" x2="{x1}" y1="{Y(v):.1f}" y2="{Y(v):.1f}" class="grid"></line><text x="4" y="{Y(v) + 4:.1f}" class="axis">{prefijo}{v:,.0f}</text>')
    out.append(f'<polygon points="{X(0):.1f},{Y(lo):.1f} {pts} {X(len(valores) - 1):.1f},{Y(lo):.1f}" fill="url(#gArea)"></polygon>')
    out.append(f'<polyline points="{pts}" fill="none" stroke="var(--accent)" stroke-width="2"></polyline>')
    paso = max(1, len(etiquetas) // 4)
    for i in range(0, len(etiquetas), paso):
        out.append(f'<text x="{X(i):.1f}" y="{alto - 6}" class="axis" text-anchor="middle">{_esc(etiquetas[i])}</text>')
    out.append("</svg>")
    return "".join(out)


def anillo(frac, tam=64, grosor=7):
    """Anillo verde/rojo (estilo profit factor)."""
    r = (tam - grosor) / 2
    c = 2 * math.pi * r
    f = max(0, min(1, frac or 0))
    return (f'<svg viewBox="0 0 {tam} {tam}" width="{tam}" height="{tam}" role="img" aria-label="{f * 100:.0f} %">'
            f'<circle cx="{tam / 2}" cy="{tam / 2}" r="{r}" fill="none" stroke="var(--neg)" stroke-width="{grosor}"></circle>'
            f'<circle cx="{tam / 2}" cy="{tam / 2}" r="{r}" fill="none" stroke="var(--pos)" stroke-width="{grosor}" stroke-dasharray="{c * f:.1f} {c:.1f}" '
            f'transform="rotate(-90 {tam / 2} {tam / 2})" stroke-linecap="butt"></circle></svg>')


def medidor(ok, mid, bad, ancho=96):
    """Semicírculo verde/azul/rojo con conteos (estilo win %)."""
    tot = max(ok + mid + bad, 1)
    cx, cy, r = ancho / 2, ancho / 2, ancho / 2 - 8
    def arco(a0, a1, color):
        import math as m
        p0 = (cx + r * m.cos(m.pi * (1 - a0)), cy - r * m.sin(m.pi * (1 - a0)))
        p1 = (cx + r * m.cos(m.pi * (1 - a1)), cy - r * m.sin(m.pi * (1 - a1)))
        return f'<path d="M{p0[0]:.1f},{p0[1]:.1f} A{r},{r} 0 0 1 {p1[0]:.1f},{p1[1]:.1f}" fill="none" stroke="{color}" stroke-width="8"></path>' if a1 > a0 else ""
    a, b = ok / tot, (ok + mid) / tot
    return (f'<svg viewBox="0 0 {ancho} {ancho / 2 + 22}" width="{ancho}" role="img" aria-label="{ok} cumplidos, {mid} descanso, {bad} faltas">'
            + arco(0, a, "var(--pos)") + arco(a, b, "var(--mid)") + arco(b, 1, "var(--neg)")
            + f'<text x="{cx - 30}" y="{cy + 18}" class="axis" text-anchor="middle" style="fill:var(--pos)">{ok}</text>'
            f'<text x="{cx}" y="{cy + 18}" class="axis" text-anchor="middle" style="fill:var(--mid)">{mid}</text>'
            f'<text x="{cx + 30}" y="{cy + 18}" class="axis" text-anchor="middle" style="fill:var(--neg)">{bad}</text></svg>')
