/* Respiración guiada: la burbuja crece al inhalar, se mantiene al sostener y se encoge al exhalar. */
(function () {
  const caja = document.getElementById('respiracion'); if (!caja) return;
  const T = (s) => (window.FBtr ? window.FBtr(s) : s);
  const bur = document.getElementById('bn-burbuja'), fase = document.getElementById('bn-fase'), cuenta = document.getElementById('bn-cuenta');
  const bIni = document.getElementById('bn-iniciar'), rest = document.getElementById('bn-restante'), fuente = document.getElementById('bn-fuente');
  let tec = null, h = null, fin = 0, lock = null;
  const reducir = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  caja.querySelectorAll('[data-resp]').forEach(b => b.addEventListener('click', () => {
    parar(); tec = JSON.parse(b.dataset.resp);
    caja.querySelectorAll('[data-resp]').forEach(x => x.classList.toggle('on', x === b));
    fase.textContent = tec.nombre; cuenta.textContent = tec.min + ' min'; fuente.textContent = tec.fuente; bIni.disabled = false;
  }));
  function parar() { clearTimeout(h); h = null; bIni.textContent = T('Iniciar'); bur.style.transition = 'transform .6s ease'; bur.style.transform = 'scale(.55)'; rest.textContent = '';
    if (lock) { lock.release().catch(() => {}); lock = null; } }
  function paso(k) {
    if (Date.now() >= fin) { parar(); fase.textContent = T('¡Listo! ¿Cómo te sientes?'); cuenta.textContent = ''; return; }
    const [nom, seg] = tec.fases[k % tec.fases.length];
    fase.textContent = T(nom);
    const inh = /inhala/i.test(nom), exh = /exhala/i.test(nom);
    bur.style.transition = reducir ? 'none' : `transform ${seg}s ${inh || exh ? 'ease-in-out' : 'linear'}`;
    if (inh) bur.style.transform = 'scale(1)'; else if (exh) bur.style.transform = 'scale(.55)';
    let s = seg; cuenta.textContent = s;
    const t = setInterval(() => { s -= 1; if (s > 0) cuenta.textContent = s; else clearInterval(t); }, 1000);
    const m = Math.max(0, Math.ceil((fin - Date.now()) / 60000)); rest.textContent = m + ' ' + T('min restantes');
    try { navigator.vibrate && navigator.vibrate(30); } catch (e) {}
    h = setTimeout(() => { clearInterval(t); paso(k + 1); }, seg * 1000);
  }
  bIni.addEventListener('click', async () => {
    if (h) { parar(); return; }
    fin = Date.now() + tec.min * 60000; bIni.textContent = T('Detener');
    try { if ('wakeLock' in navigator) lock = await navigator.wakeLock.request('screen'); } catch (e) {}
    paso(0);
  });
})();
