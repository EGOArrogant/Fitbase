/* FitBase · motor de cronómetros (preciso: usa marcas de tiempo, no acumula setInterval).
   Tipos: cronómetro con vueltas, cuenta regresiva e intervalos (HIIT, Tabata, EMOM, AMRAP, For Time, boxeo). */
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const raiz = $('#crono');
  if (!raiz) return;
  const T = (s) => (window.FBtr ? window.FBtr(s) : s);
  const ahora = () => performance.now();

  // ---------- sonido, vibración y pantalla encendida ----------
  let ctx = null, sonido = true, lock = null;
  try { sonido = localStorage.getItem('cronoSonido') !== '0'; } catch (e) {}
  function bip(freq = 880, dur = 0.12, vol = 0.25) {
    if (!sonido) return;
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = freq; o.type = 'sine'; g.gain.value = vol;
      o.connect(g); g.connect(ctx.destination); o.start();
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur); o.stop(ctx.currentTime + dur + 0.02);
    } catch (e) {}
  }
  const vibra = (p) => { try { navigator.vibrate && navigator.vibrate(p); } catch (e) {} };
  async function pantallaEncendida(si) {
    try {
      if (si && 'wakeLock' in navigator && !lock) { lock = await navigator.wakeLock.request('screen'); lock.addEventListener('release', () => { lock = null; }); }
      if (!si && lock) { await lock.release(); lock = null; }
    } catch (e) {}
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && corriendo()) pantallaEncendida(true); });

  const fmt = (ms, dec) => {
    ms = Math.max(0, ms);
    const t = Math.floor(ms / 1000), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
    const base = (h ? h + ':' + String(m).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(s).padStart(2, '0');
    return dec ? base + '.' + String(Math.floor((ms % 1000) / 100)) : base;
  };

  // ---------- elementos ----------
  const disp = $('#crono-tiempo'), fase = $('#crono-fase'), ronda = $('#crono-ronda'), aro = $('#crono-aro'), sig = $('#crono-sig');
  const bIni = $('#crono-iniciar'), bReset = $('#crono-reiniciar'), bVuelta = $('#crono-vuelta'), bMas = $('#crono-mas'), bFin = $('#crono-termine');
  const lista = $('#crono-vueltas'), titulo = $('#crono-titulo'), nota = $('#crono-nota');
  const CIRC = 2 * Math.PI * 54;
  if (aro) { aro.style.strokeDasharray = CIRC; aro.style.strokeDashoffset = 0; }

  // ---------- estado ----------
  let modo = 'cronometro';            // cronometro | plan
  let plan = null;                    // [{fase, ms, ronda, total}]
  let i = 0, inicioFase = 0, acumulado = 0, pausado = true, raf = null, vueltas = [], ultimaVuelta = 0, avisado = {};
  const corriendo = () => !pausado;

  function construir(p) {
    const pasos = [];
    if (p.prep) pasos.push({ fase: 'prep', ms: p.prep * 1000, ronda: 0, total: p.rondas });
    for (let r = 1; r <= p.rondas; r++) {
      pasos.push({ fase: 'trabajo', ms: p.trabajo * 1000, ronda: r, total: p.rondas });
      if (p.descanso && r < p.rondas) pasos.push({ fase: 'descanso', ms: p.descanso * 1000, ronda: r, total: p.rondas });
    }
    return pasos;
  }
  const NOMBRE_FASE = { prep: 'Prepárate', trabajo: 'Trabajo', descanso: 'Descanso', fin: '¡Terminaste!' };

  function cargar(p) {
    detener(); modo = p ? 'plan' : 'cronometro';
    plan = p ? construir(p) : null; i = 0; acumulado = 0; vueltas = []; ultimaVuelta = 0; avisado = {};
    raiz.dataset.modo = modo; raiz.dataset.tipo = p ? p.tipo : 'cronometro';
    titulo.textContent = p ? p.nombre : T('Cronómetro');
    nota.textContent = p ? (p.nota || '') : T('Toca «Vuelta» para marcar parciales (series, kilómetros, rounds).');
    bVuelta.hidden = !!p && p.tipo !== 'amrap' && p.tipo !== 'fortime';
    bFin.hidden = !(p && p.tipo === 'fortime');
    bMas.hidden = !p;
    raiz.dataset.preset = p ? (p.id || '') : '';
    raiz._preset = p;
    pintarVueltas(); pintar();
    document.querySelectorAll('.cr-preset').forEach(b => b.classList.toggle('on', p && b.dataset.id === p.id));
  }

  function restanteFase(t) { return plan[i].ms - (acumulado + (pausado ? 0 : t - inicioFase)); }

  function pintar() {
    const t = ahora();
    if (modo === 'cronometro') {
      const ms = acumulado + (pausado ? 0 : t - inicioFase);
      disp.textContent = fmt(ms, true); fase.textContent = pausado && ms === 0 ? T('Listo') : (pausado ? T('En pausa') : T('Corriendo'));
      ronda.textContent = vueltas.length ? T('Vueltas') + ': ' + vueltas.length : '';
      if (aro) aro.style.strokeDashoffset = CIRC * (1 - ((ms / 1000) % 60) / 60);
      sig.textContent = '';
      return;
    }
    if (i >= plan.length) { disp.textContent = '00:00'; fase.textContent = T(NOMBRE_FASE.fin); raiz.dataset.fase = 'fin'; if (aro) aro.style.strokeDashoffset = 0; return; }
    const paso = plan[i], rest = restanteFase(t);
    const p = raiz._preset;
    disp.textContent = (p.tipo === 'fortime' || p.tipo === 'amrap') && paso.fase === 'trabajo' ? fmt(rest) : fmt(rest + 999);
    fase.textContent = T(NOMBRE_FASE[paso.fase]); raiz.dataset.fase = paso.fase;
    ronda.textContent = paso.ronda ? (p.tipo === 'boxeo' ? T('Round') : p.tipo === 'emom' ? T('Minuto') : T('Ronda')) + ' ' + paso.ronda + ' / ' + paso.total : '';
    if (aro) aro.style.strokeDashoffset = CIRC * (1 - Math.min(1, Math.max(0, rest / paso.ms)));
    const prox = plan[i + 1];
    sig.textContent = prox ? T('Sigue') + ': ' + T(NOMBRE_FASE[prox.fase]) + ' · ' + fmt(prox.ms) : T('Último bloque');
  }

  function tick() {
    raf = null;
    if (pausado) return;
    const t = ahora();
    if (modo === 'plan') {
      let rest = restanteFase(t);
      const p = raiz._preset;
      // cuenta 3-2-1 y aviso de fin de round
      const s = Math.ceil(rest / 1000), clave = i + ':' + s;
      if (s <= 3 && s >= 1 && !avisado[clave]) { avisado[clave] = 1; bip(660, 0.09); }
      if (p.aviso && plan[i].fase === 'trabajo' && s === p.aviso && !avisado['a' + i]) { avisado['a' + i] = 1; bip(990, 0.08); setTimeout(() => bip(990, 0.08), 160); vibra(80); }
      while (rest <= 0 && i < plan.length) {          // avanza aunque el teléfono se haya dormido
        const sobra = -rest;
        i += 1; acumulado = 0; inicioFase = t - sobra;
        if (i >= plan.length) { terminar(); return; }
        const f = plan[i].fase;
        bip(f === 'trabajo' ? 1040 : 520, 0.35, 0.35); vibra(f === 'trabajo' ? [250] : [120, 80, 120]);
        rest = restanteFase(t);
      }
    }
    pintar();
    raf = requestAnimationFrame(tick);
  }
  // si la pestaña está oculta requestAnimationFrame se pausa: este respaldo mantiene los avisos
  setInterval(() => { if (!pausado && document.hidden) tick(); }, 500);

  function iniciar() {
    if (modo === 'plan' && i >= plan.length) cargar(raiz._preset);
    pausado = false; inicioFase = ahora(); bIni.textContent = T('Pausa'); bIni.classList.remove('pri');
    pantallaEncendida(true); if (!raf) raf = requestAnimationFrame(tick);
    try { ctx && ctx.resume && ctx.resume(); } catch (e) {}
  }
  function detener() {
    if (!pausado) acumulado += ahora() - inicioFase;
    pausado = true; bIni.textContent = T('Iniciar'); bIni.classList.add('pri');
    if (raf) cancelAnimationFrame(raf); raf = null; pantallaEncendida(false); pintar();
  }
  function terminar() {
    pausado = true; bIni.textContent = T('Otra vez'); bIni.classList.add('pri'); pantallaEncendida(false);
    bip(880, 0.2); setTimeout(() => bip(1175, 0.4), 220); vibra([300, 100, 300]); pintar();
  }
  function marcarVuelta() {
    const t = ahora();
    let total;
    if (modo === 'cronometro') total = acumulado + (pausado ? 0 : t - inicioFase);
    else total = plan.slice(0, i).reduce((a, x) => a + x.ms, 0) + (plan[i] ? plan[i].ms - restanteFase(t) : 0);
    vueltas.push({ total, parcial: total - ultimaVuelta }); ultimaVuelta = total; bip(1200, 0.05); pintarVueltas();
  }
  function pintarVueltas() {
    lista.innerHTML = vueltas.map((v, k) => `<li><span>${T(raiz._preset && raiz._preset.tipo === 'amrap' ? 'Ronda' : 'Vuelta')} ${k + 1}</span><b>${fmt(v.parcial, true)}</b><span class="sub">${fmt(v.total, true)}</span></li>`).reverse().join('');
    lista.hidden = !vueltas.length;
  }

  bIni.addEventListener('click', () => (pausado ? iniciar() : detener()));
  bReset.addEventListener('click', () => cargar(raiz._preset || null));
  bVuelta.addEventListener('click', marcarVuelta);
  bMas.addEventListener('click', () => { if (modo === 'plan' && plan[i]) { plan[i].ms += 10000; pintar(); } });
  bFin.addEventListener('click', () => { marcarVuelta(); i = plan.length; terminar(); });
  document.addEventListener('keydown', (e) => {
    if (e.target.closest('input,textarea,select')) return;
    if (e.code === 'Space') { e.preventDefault(); bIni.click(); }
    if (e.key === 'v' || e.key === 'V') bVuelta.hidden || bVuelta.click();
  });
  const bSon = $('#crono-sonido');
  const pintaSon = () => { bSon.setAttribute('aria-pressed', sonido ? 'true' : 'false'); bSon.textContent = sonido ? T('Sonido: sí') : T('Sonido: no'); };
  bSon.addEventListener('click', () => { sonido = !sonido; try { localStorage.setItem('cronoSonido', sonido ? '1' : '0'); } catch (e) {} pintaSon(); if (sonido) bip(); });
  pintaSon();

  // ---------- presets ----------
  const datos = JSON.parse($('#crono-datos').textContent);
  const todos = {};
  [...datos.base, ...datos.coach, ...datos.mios].forEach(p => { todos[p.id] = p; });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('.cr-preset');
    if (b) { cargar(todos[b.dataset.id] || null); raiz.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    const c = e.target.closest('[data-crono-modo="cronometro"]');
    if (c) cargar(null);
  });

  // editor de temporizador propio
  const f = $('#crono-editor');
  if (f) {
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(f);
      const p = { id: 'u' + Date.now().toString(36), nombre: fd.get('nombre') || T('Mi temporizador'), tipo: fd.get('tipo'),
        trabajo: (+fd.get('tm') || 0) * 60 + (+fd.get('ts') || 0), descanso: (+fd.get('dm') || 0) * 60 + (+fd.get('ds') || 0),
        rondas: +fd.get('rondas') || 1, prep: +fd.get('prep') || 0, aviso: +fd.get('aviso') || 0, nota: fd.get('nota') || '' };
      if (p.trabajo < 1) { alert(T('El tiempo de trabajo debe ser mayor a 0.')); return; }
      const destino = f.dataset.destino;          // 'mios' o 'coach' (entrenador asignando a cliente)
      const arr = destino === 'coach' ? datos.coach : datos.mios;
      arr.push(p); todos[p.id] = p;
      const r = await fetch(f.action, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ presets: arr }) });
      if (r.ok) location.href = location.pathname + '?preset=' + encodeURIComponent(p.id);
    });
  }
  document.querySelectorAll('[data-borrar-preset]').forEach(b => b.addEventListener('click', async () => {
    const destino = b.dataset.destino, arr = destino === 'coach' ? datos.coach : datos.mios;
    const k = arr.findIndex(x => x.id === b.dataset.borrarPreset); if (k < 0) return;
    if (!confirm(T('¿Borrar este temporizador?'))) return;
    arr.splice(k, 1);
    const r = await fetch(f.action, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ presets: arr }) });
    if (r.ok) location.reload();
  }));

  cargar(datos.inicial && todos[datos.inicial] ? todos[datos.inicial] : null);
})();
