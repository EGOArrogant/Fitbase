/* Guía visual de mediciones: muestra la marca de la medida elegida sobre la silueta correcta y sus pasos. */
(function () {
  const raiz = document.getElementById('guia-mediciones'); if (!raiz || raiz.dataset.listo) return; raiz.dataset.listo = '1';
  const items = [...raiz.querySelectorAll('.mg-item')];
  let tipo = 'Básica', k = 0;
  function visibles() { return items.filter(b => !b.hidden); }
  function mostrar(b) {
    if (!b) return;
    items.forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
    const clave = b.dataset.mg, vista = b.dataset.vista;
    raiz.querySelectorAll('.mg-svg').forEach(s => s.toggleAttribute('hidden', s.dataset.vista !== vista));
    raiz.querySelectorAll('.mg-capa').forEach(g => g.toggleAttribute('hidden', g.dataset.med !== clave));
    raiz.querySelectorAll('.mg-ficha').forEach(f => { f.hidden = f.dataset.mgFicha !== clave; });
    const capa = raiz.querySelector(`.mg-capa[data-med="${clave}"]`);
    if (capa) { capa.classList.remove('anima'); void capa.getBBox; requestAnimationFrame(() => capa.classList.add('anima')); }
    k = visibles().indexOf(b);
  }
  function filtrar(t) {
    tipo = t;
    raiz.querySelectorAll('[data-mg-tipo]').forEach(x => x.classList.toggle('on', x.dataset.mgTipo === t));
    items.forEach(b => { b.hidden = b.dataset.tipo !== t; });
    mostrar(visibles()[0]);
  }
  raiz.addEventListener('click', (e) => {
    const b = e.target.closest('.mg-item'); if (b) return mostrar(b);
    const t = e.target.closest('[data-mg-tipo]'); if (t) return filtrar(t.dataset.mgTipo);
    const n = e.target.closest('[data-mg-nav]');
    if (n) { const v = visibles(); mostrar(v[(k + +n.dataset.mgNav + v.length) % v.length]); }
  });
  // permite abrir una medida concreta desde el formulario: <a href="#mg-triceps">
  const inicial = (location.hash.match(/^#mg-(.+)$/) || [])[1];
  const b0 = inicial && items.find(b => b.dataset.mg === inicial);
  filtrar(b0 ? b0.dataset.tipo : 'Básica'); if (b0) mostrar(b0);
})();
