# PROMPT DE EJECUCIÓN · FitBase 3.0 «Plataforma multidisciplinaria y profesional»

> **Cómo usarlo:** pega todo este documento como instrucción a la IA o al equipo que vaya a ejecutar. Funciona junto con el paquete `fitbase-exportacion-ia.zip` (código, `PROMPT_MAESTRO.md` y `docs/`). Si la IA ya tiene el proyecto abierto, solo pega este documento.

---

## 1. Tu rol y tu objetivo

Eres el equipo técnico de **FitBase**: líder de producto, desarrollador full-stack (Flask, Jinja, SQLite y JS vanilla), investigador en ciencias del ejercicio y la nutrición, diseñador UX/UI y responsable de cumplimiento legal en México.

Tu misión es convertir FitBase en una plataforma **multidisciplinaria y profesional**. Debe servir para musculación, running, boxeo, cardio, calistenia, yoga, pilates y entrenamiento mixto. Debe tener secciones para **nutriólogos y fisioterapeutas**, bienestar mental, herramientas de marketing para profesionales, sesiones en vivo e integración con relojes inteligentes.

Todo debe estar basado en evidencia de la última década (2015–2026) y facilitarle la vida al usuario y al profesional.

**Antes de escribir código lee:**
- `PROMPT_MAESTRO.md`;
- `docs/02_ARQUITECTURA.md`;
- `docs/05_FORMULAS_Y_LOGICA.md`;
- `docs/06_DISENO.md`;
- `docs/10_REGLAS_NO_NEGOCIABLES.md`.

Esas reglas siguen vigentes y tienen prioridad sobre cualquier cosa de este documento.

## 2. Reglas de ejecución

1. **Trabaja por fases (sección 5) y en orden.** Cada fase termina con una versión publicada (`2.4.0`, `2.5.0`…), siguiendo `docs/12_OPERACION.md`. Antes de publicar:
   - `python diagnostico.py` debe dar 0 fallas;
   - el diseño debe estar revisado en computadora, tableta y celular, con los dos modos de menú, en claro y oscuro;
   - hay que actualizar `LEEME.md`.
2. **Cada módulo nuevo debe:**
   - aparecer en el menú con su categoría, color e ícono (`navegacion.py`);
   - estar en la guía interactiva (`guia.py`) y en la API `/api/v1`, para la futura app móvil;
   - tener sus textos en `idiomas/fuente_ui.txt` (ES, EN y FR);
   - tener PDF si el usuario lo necesitaría impreso;
   - registrar actividad para el coach (`notificaciones.py`);
   - estar cubierto por pruebas en `diagnostico.py`.
3. **Investigación con rigor:**
   - Cada fórmula, dosis, protocolo o recomendación lleva su **fuente citada**: autor, año, revista o institución, y DOI o URL.
   - Prioriza, en este orden: consensos y posturas oficiales (ACSM, NSCA, ISSN, COI, AASM, OMS, ISAK, World Athletics, AIBA/IBA), metaanálisis y revisiones sistemáticas, y después estudios individuales.
   - Guarda las notas en `research_notes/<tema>/` y el resumen en `docs/`.
   - Si la evidencia es débil o contradictoria, dilo en la interfaz con lenguaje sencillo.
4. **Contenido propio y persistente.** Todo artículo, receta, alimento, ficha de ejercicio o protocolo que agregues:
   - se redacta con palabras propias;
   - se guarda en la base de datos o en `data/`, para que **no desaparezca** aunque la fuente original se borre;
   - conserva la cita y el enlace original;
   - nunca copia textos, imágenes ni videos con derechos de autor.
5. **Delega para ahorrar.** Usa los agentes de `agentes/`:
   - `qa-entrenador` y `corrector-web` con un modelo intermedio;
   - `disenador-visual` con un modelo intermedio;
   - investigación masiva y redacción de contenido con un modelo intermedio o económico, con revisión final del modelo principal.
   - Dentro de la app: el modelo principal (`FITAPP_MODELO`) solo para el Coach IA y para la visión (fotos); el económico (`FITAPP_MODELO_RAPIDO`) para traducción, clasificación y extracción.
6. **Nunca pidas claves ni contraseñas por chat.** Cada integración (redes sociales, videollamadas, relojes, Stripe) se configura en Administración, con el secreto guardado solo en local.
7. **Al final de cada fase, entrega un reporte honesto:** qué se hizo, qué se probó, qué no y qué queda pendiente.

## 3. Aclaraciones de viabilidad (léelas antes de prometer algo)

Estas solicitudes del dueño tienen límites técnicos o legales. Impleméntalas con la alternativa indicada y explícale al dueño la razón:

| Solicitud | Límite real | Cómo se hace bien |
|---|---|---|
| «Entrenar la IA con videos de YouTube» para el modelo 3D | Los Términos de YouTube prohíben descargar videos y usarlos sin permiso, y los videos tienen derechos de autor. Tampoco existe la «precisión absoluta». | (a) Datos de movimiento con licencia que permita uso comercial (por ejemplo la base de captura de movimiento de CMU, que es gratuita, o animaciones con licencia comercial), (b) grabaciones propias o de atletas que firmen permiso, procesadas con estimación de pose (MediaPipe Pose o MoveNet), (c) validación biomecánica contra rangos articulares publicados y revisión de un experto. Los videos de YouTube se pueden **enlazar o incrustar** con su reproductor oficial como referencia, citando al autor. |
| Libros como fuente | Tienen derechos de autor. | Citar, resumir con palabras propias y referenciar (autor, edición, página). No copiar texto ni figuras. |
| «Apple Care» y relojes | Apple Health (HealthKit) **solo** se lee desde una app nativa de iOS; Health Connect de Android, solo desde una app nativa de Android; Google Fit está en retiro. | Web: importar archivos (exportación de Apple Health `export.zip`/`export.xml`, GPX, TCX y FIT) y conectar por OAuth servicios con API web (Fitbit Web API, Strava, Polar AccessLink, Withings, Oura, Garmin Health API, este último con solicitud de socio). Lectura directa de HealthKit y Health Connect en la **app móvil**. |
| Publicar directo en redes | Cada red exige registrar la app y pasar revisión: Meta (Instagram profesional y páginas de Facebook) con App Review, TikTok con auditoría de Content Posting API, LinkedIn, y X (API de pago). Además, la app debe estar publicada en internet con HTTPS. | Fase A: diseñar, descargar y compartir (Web Share API). Fase B: publicar y programar con OAuth en las redes cuyos registros complete el dueño. |
| Videollamadas «como Meet o Zoom» dentro de la app | Construirlo desde cero es inviable; necesita servidores TURN y HTTPS. | Integrar **Jitsi Meet** (código abierto; incrustado o en servidor propio) o LiveKit. Alternativa: crear enlaces de Zoom o Google Meet con sus APIs (OAuth). La grabación solo se hace con consentimiento de ambas partes. |
| Salud mental | Una app no diagnostica, y algunos cuestionarios detectan riesgo suicida. | Usar instrumentos validados y de libre uso, con protocolo de crisis obligatorio (sección 4.7). Sin diagnósticos: solo orientación y canalización. |
| Fisioterapia y nutrición clínica | Diagnosticar y tratar es un acto profesional regulado. | Las funciones clínicas son para profesionales verificados (cédula profesional). Al usuario final solo se le muestran contenidos educativos y su plan asignado. |

## 4. Módulos a construir (especificación)

Para cada módulo: objetivo, funciones, datos, interfaz y **criterios de aceptación (CA)**.

### 4.1 Herramientas: relojes, cronómetros y sueño
- **Cronómetro y temporizador**, siempre a la mano desde la barra superior y la barra inferior del celular. Tipos:
  - cronómetro con vueltas;
  - cuenta regresiva;
  - descanso entre series, que arranca solo al registrar una serie y usa el descanso del programa;
  - **intervalos** configurables: HIIT, Tabata 20/10 × 8, EMOM, AMRAP, «For Time» y **rounds de boxeo** (3:00 de trabajo y 1:00 de descanso, con aviso a los 10 s);
  - intervalos de carrera (trabajo y recuperación por tiempo o distancia).
- **Comportamiento del temporizador:**
  - sonido y vibración (Vibration API), y la pantalla no se apaga (Wake Lock API);
  - funciona sin internet;
  - presets guardados por usuario y presets que el coach asigna a su cliente.
- **Sueño:**
  - hora de acostarse y de levantarse (o importada de un reloj), duración, calidad 1–5, despertares y siesta;
  - indicadores: duración promedio, **regularidad** (desviación de la hora de dormir) y deuda de sueño;
  - recomendaciones según AASM/SRS: adultos ≥7 h, deportistas 7–9 h o más;
  - gráfica semanal y conexión con el Fitness Score y la recuperación.
- **CA:** el temporizador no se desfasa más de 1 s en 30 min (usa `performance.now()`, no `setInterval` acumulado), funciona en celular con la pantalla activa y el sueño aparece en el registro diario, el expediente y la API.

### 4.2 Plataforma multidisciplinaria (investigación + registro + progreso)
- **Investiga (2015–2026), deporte por deporte:**
  - qué se mide;
  - cómo se progresa;
  - qué carga es segura;
  - qué indicadores predicen rendimiento o lesión.
- **Deportes y qué registrar en cada uno:**
  - **Musculación:** lo que ya existe.
  - **Running:** distancia, tiempo, ritmo, FC, cadencia, desnivel, RPE, tipo de sesión (rodaje, tempo, intervalos, largo). Además, zonas de FC y de ritmo (VDOT de Daniels o umbral), carga de entrenamiento con sRPE (Foster) y relación aguda:crónica con sus advertencias según la evidencia reciente, y planes de 5K, 10K, 21K y 42K.
  - **Boxeo y deportes de combate:** rounds, tipo (sombra, saco, manoplas, sparring, técnica), duración, RPE, golpes si hay sensor y alertas de impactos a la cabeza.
  - **Cardio:** máquina o actividad, tiempo, distancia, FC y MET (Compendio de Actividades Físicas 2024).
  - **Calistenia:** árbol de habilidades con progresiones (dominadas → muscle-up, flexiones → planche, pino, front lever…), repeticiones o tiempo, variante y criterios para avanzar de nivel.
  - **Yoga y pilates:** sesión, estilo, duración, posturas o ejercicios, RPE y movilidad percibida.
  - **Multidisciplinario o híbrido:** semana que combina varios deportes, con control de interferencia entre fuerza y resistencia.
- **Perfil deportivo:** el usuario elige su deporte o deportes principales y su nivel. El dashboard, las recomendaciones, el calentamiento, la recuperación, la nutrición (carbohidratos por g/kg según el volumen) y los retos se adaptan a ese perfil.
- **CA:**
  - cada deporte tiene formulario de registro rápido (menos de 30 s), gráfica de progreso, récords personales y al menos 3 planes base con su fuente;
  - el coach ve todo en la ficha del cliente;
  - funciona por API.

### 4.3 Calentamiento, estiramientos y vuelta a la calma por deporte
- Protocolos basados en evidencia: modelo RAMP (Jeffreys), calentamientos tipo FIFA 11+, movilidad dinámica antes y estiramiento estático corto después o en otra sesión.
- Se generan según el deporte, la sesión del día (los músculos y patrones que se van a trabajar), el nivel, las lesiones declaradas y el tiempo disponible.
- Se integran **al iniciar la sesión** (paso previo con temporizador) y **al terminar** (vuelta a la calma más recomendaciones).
- Cada ejercicio de calentamiento tiene ilustración o animación, duración o repeticiones, y su indicación clave.
- **CA:** las 7 disciplinas tienen protocolos; aparecen solos en la sesión; se pueden saltar o ajustar; el coach puede editarlos para su cliente.

### 4.4 Recuperación
- Al **terminar una sesión**, mostrar una tarjeta de «Recuperación prioritaria» con 3 a 5 indicaciones ordenadas por prioridad, calculadas con: deporte, duración, intensidad (RPE o FC), nivel, peso, clima si se captura, sueño previo y carga semanal.
- **Ejemplos de lo que debe indicar:**
  - **Hidratación:** si registró peso antes y después, reponer 1.25–1.5 L por kg perdido, con sodio en sesiones largas o de mucho sudor.
  - **Nutrición:** proteína de 0.3 g/kg en las siguientes horas; carbohidratos de 1–1.2 g/kg/h cuando haya otra sesión en menos de 8 h.
  - **Descanso mínimo** antes de repetir el mismo grupo o tipo de sesión, por ejemplo 48–72 h para fuerza o excéntricos intensos, y la regla de distribución de intensidad en running.
  - **Sueño** objetivo.
  - **Movilidad.**
  - **Señales de alarma** que indican parar y consultar.
- **Readiness diario** (opcional): sueño, dolor muscular, estrés, energía y, si hay reloj, HRV y FC en reposo, comparados contra la línea base del usuario. El resultado sugiere entrenar normal, ajustar o descansar.
- **CA:** las recomendaciones cambian según el deporte y el nivel (un corredor avanzado después de 30 km no recibe lo mismo que un principiante después de 20 min de caminata); cada una muestra su fuente con «¿por qué?».

### 4.5 Apartado Zen: yoga, pilates, respiración y relajación
- Biblioteca de secuencias de yoga y pilates (mat), por nivel y objetivo (movilidad, espalda, core, relajación, antes de dormir), con ilustraciones propias.
- Respiración guiada con animación: caja 4-4-4-4, 4-7-8, coherencia cardiaca ~6 respiraciones/min y suspiro fisiológico.
- Meditación y relajación muscular progresiva (Jacobson) con temporizador y sonido opcional.
- Registro de minutos y de estado de ánimo antes y después, conectado con salud mental y sueño.
- **CA:** funciona sin internet; tiene un modo oscuro especialmente calmado; da recomendaciones según el estrés reportado.

### 4.6 Nutriólogo («full nutricionista»)
- **Rol nuevo `nutriologo`**, con licencia como la de coach y verificación de **cédula profesional** (captura y revisión del administrador).
- **Expediente nutricional completo:**
  - historia clínica y dietética;
  - recordatorio de 24 h y frecuencia de consumo;
  - antropometría (y la ISAK de la sección 4.10);
  - datos bioquímicos capturados (glucosa, perfil de lípidos, HbA1c, etc., con rangos de referencia citados);
  - diagnóstico nutricional en formato PES;
  - requerimientos con las fórmulas que ya existen;
  - plan por equivalentes SMAE (ya existe), menús y recetas, metas, notas de evolución SOAP y citas.
- **Plantillas de planes reutilizables**, PDF con su marca (sección 4.12) y comunicación con el paciente.
- El usuario «paciente» ve su plan, su registro y sus citas.
- **CA:**
  - un nutriólogo puede llevar a un paciente de la primera consulta al seguimiento sin salir de la app;
  - el PDF es profesional y lleva su logo;
  - todo queda en la API.

### 4.7 Fisioterapeuta
- **Rol nuevo `fisioterapeuta`**, con verificación de cédula.
- **Evaluación:**
  - motivo de consulta y mapa corporal de dolor (reutiliza `bodymap.py`);
  - dolor con escala NPRS 0–10;
  - rangos de movimiento por goniometría, con valores de referencia citados;
  - pruebas funcionales;
  - **banderas rojas** con canalización médica.
- **Plan terapéutico:** ejercicios terapéuticos con progresión por fases, dosificación, educación, frecuencia, notas SOAP y seguimiento del dolor y de la función.
- **Lado del usuario:** su programa de rehabilitación con videos o ilustraciones, temporizador y registro de dolor por sesión. Si el dolor sube más de 2 puntos, se alerta al profesional.
- **CA:** las banderas rojas bloquean las recomendaciones de ejercicio y muestran el aviso; al usuario final no se le dan diagnósticos.

### 4.8 Salud mental y bienestar
- **Cuestionarios validados de uso libre**, con frecuencia sugerida y resultados explicados con lenguaje sencillo, sin diagnosticar:
  - **PSS-10** (estrés percibido);
  - **WHO-5** (bienestar);
  - **GAD-7** (ansiedad);
  - **PHQ-9** (ánimo).
- **Protocolo de crisis obligatorio.** Si el PHQ-9 indica algo en el ítem 9, o si el usuario escribe señales de riesgo:
  - mostrar de inmediato la **Línea de la Vida 800 911 2000** (México, 24 h), el **911** y recomendación de acudir a urgencias;
  - no bloquear al usuario;
  - avisar al profesional vinculado solo si el usuario dio su consentimiento para eso.
- **Recomendaciones:** respiración, sueño, actividad física, contacto social y búsqueda de ayuda profesional. Seguimiento de tendencias.
- **Privacidad reforzada:** dato sensible con consentimiento específico. El coach ve **solo** un indicador general («estrés alto esta semana») si el usuario lo autoriza; nunca las respuestas.
- **CA:** el protocolo de crisis está probado en `diagnostico.py`; los textos fueron revisados para no dar diagnósticos; existe el consentimiento nuevo con su constancia.

### 4.9 Mediciones corporales guiadas (cuerpo humano ilustrado)
- Un **cuerpo humano ilustrado propio** (SVG de hombre y mujer, de frente, perfil y espalda) que, por cada medición:
  - marca el punto anatómico de referencia;
  - muestra con una línea animada **de dónde a dónde** se mide;
  - indica la dirección del pliegue (vertical u oblicuo), el lado del cuerpo (derecho, según ISAK) y la postura del medido;
  - muestra la posición del instrumento (cinta, plicómetro o antropómetro).
- **Instrucciones paso a paso** con lenguaje sencillo: cómo localizar el punto, cómo tomar el pliegue, cuántas veces medir y errores comunes.
- Las ilustraciones se hacen desde cero: no se copian las figuras del manual ISAK.
- **CA:** una persona sin experiencia entiende cada medición en menos de 1 minuto. Antes de terminar, prueba las instrucciones con el agente `qa-entrenador`, que hace de cliente novato.

### 4.10 ISAK por niveles (entrenadores y nutriólogos avanzados)
- **Modos:**
  - **Básico:** peso, talla, cintura y cadera.
  - **ISAK Nivel 1, perfil restringido:** masa, talla, talla sentado y envergadura; 8 pliegues (tríceps, subescapular, bíceps, cresta ilíaca, supraespinal, abdominal, muslo frontal y pantorrilla medial); perímetros de brazo relajado, brazo flexionado y contraído, cintura, glúteos o cadera y pantorrilla; diámetros de húmero y fémur.
  - **ISAK Nivel 2, perfil completo:** todos los sitios del perfil completo.
- **Protocolo de medición:**
  - registro de **2 o 3 tomas por sitio**;
  - la tercera toma se exige si las dos primeras difieren más de 5 % (pliegues) o más de 1 % (resto);
  - se usa la mediana o el promedio según el número de tomas;
  - se calcula el **Error Técnico de Medición (ETM/TEM)** intra y entre evaluadores.
- **Resultados con fórmulas citadas:**
  - suma de pliegues;
  - % de grasa por distintas ecuaciones, según población;
  - fraccionamiento en 5 componentes (Kerr);
  - somatotipo de Heath-Carter con somatocarta;
  - proporcionalidad Phantom (ya existe);
  - comparación con normas de referencia.
- Verifica **cada sitio, criterio y ecuación con la fuente oficial** (ISAK, *International Standards for Anthropometric Assessment*; Norton y Olds) antes de implementarlos. No uses de memoria nada que no hayas verificado.
- **CA:** el PDF es de calidad profesional; hay comparación entre fechas; el ETM queda registrado para cada evaluador.

### 4.11 Licencia de coach y guía de alta de cliente
- Cuando un coach con licencia (todos los módulos desbloqueados) registra o invita a un cliente, se abre un **asistente paso a paso**. Cada paso marca si está completo e incluye un botón «hacerlo ahora»:
  1. Datos y consentimientos.
  2. PAR-Q+ y banderas rojas.
  3. Sondeo (deporte, nivel y metas).
  4. Mediciones base (guiadas, sección 4.9) y fotos de inicio (con consentimiento).
  5. Pruebas iniciales según el deporte (1RM estimado, test de 5 km o de Cooper, pruebas de movilidad).
  6. Programa y calentamiento.
  7. Plan nutricional.
  8. Metas SMART con fechas.
  9. Herramientas del cliente: recordatorios, temporizador y reloj vinculado.
  10. Primera cita de seguimiento agendada (sección 4.13).
- **Checklist persistente** en la ficha del cliente, con el % de configuración completa. El coach recibe recordatorios de los pasos pendientes. Hay versión equivalente para nutriólogo y fisioterapeuta.
- **CA:** un coach nuevo deja a un cliente completamente configurado sin buscar nada en los menús; la guía se puede volver a abrir.

### 4.12 Marca y marketing del profesional
- **Marca personal:**
  - el profesional sube su logo (PNG/SVG), su lema, su nombre comercial y sus redes;
  - de su logo se **extrae automáticamente la paleta** (k-means o mediana de colores en el servidor con Pillow) y se genera un tema premium: color primario, secundario y de acento, con verificación de **contraste WCAG AA** (≥4.5:1) en claro y oscuro, corrigiendo la luminosidad cuando no se cumple;
  - el tema se aplica a su portal, a la vista de sus clientes, a sus PDF y a sus plantillas;
  - incluye vista previa y la opción de ajustarlo a mano.
- **Estudio de contenido** (editor dentro de la app):
  - plantillas propias (no copiadas) para post 1080×1080, carrusel 1080×1350 e historia o reel 1080×1920;
  - temas: receta con macros (desde la base de recetas), «plato del día», menú semanal, rutina o WOD, tip con evidencia y su fuente, frase, antes y después (**solo con el consentimiento escrito del cliente** guardado como constancia), reto, anuncio de cupo o promoción;
  - editor visual: texto, colores de su marca, logo, fotos propias, íconos y gráficas de macros;
  - exportar en PNG, JPG o PDF y guardar los borradores.
- **Publicación:**
  - Fase A: descargar, o compartir con Web Share API.
  - Fase B: conectar redes por OAuth (sección 3) y **programar publicaciones**, con calendario de contenido.
- **CA:**
  - al subir un logo, el portal cambia de colores sin perder contraste;
  - una receta se convierte en un post listo en menos de 1 minuto;
  - los textos del post respetan las reglas de publicidad en salud (sin promesas milagro), con un aviso automático cuando se detecten.

### 4.13 Asesorías en vivo (agenda + videollamada)
- **Agenda del profesional:** disponibilidad, duración y precio por tipo de sesión, zona horaria, reservas del cliente, recordatorios (notificación y correo), reprogramación y cancelación con políticas.
- **Videollamada integrada** con Jitsi (o LiveKit), dentro de la app y con sala privada por cita. Además:
  - notas de la sesión en paralelo;
  - compartir pantalla;
  - chat;
  - **grabación solo con el consentimiento de ambas partes**;
  - alternativa: enlace de Zoom o Meet.
- **Pago de sesiones** con el sistema de pagos existente: Stripe y SPEI.
- **CA:** reservar, pagar, conectarse y dejar notas funciona de punta a punta en computadora y en celular.

### 4.14 Relojes inteligentes y teléfonos (multiconectividad)
- **Investigación rigurosa** de:
  - la exactitud de los wearables según metaanálisis y validaciones recientes (FC, pasos, distancia, sueño, VO₂máx estimado, calorías; el gasto calórico suele ser el menos preciso);
  - los APIs disponibles;
  - los permisos y la privacidad.
  - Con eso se escribe `docs/13_WEARABLES.md`.
- **Implementación:**
  - **Importar archivos:** Apple Health (`export.zip`), GPX, TCX y FIT. Se extraen FC (reposo, promedio y máxima), HRV, pasos, distancia, sueño, entrenamientos y VO₂máx.
  - **OAuth:** Fitbit, Strava, Polar, Withings, Oura y Garmin, según la aprobación de cada programa.
  - **App móvil:** HealthKit y Health Connect.
- **Datos:**
  - normalizados en tablas nuevas (`dispositivos`, `muestras_salud` con fuente y precisión, `actividades_externas`);
  - se eliminan duplicados entre fuentes;
  - se respeta la prioridad que elija el usuario.
- **Uso:** llenan el registro diario (pasos y sueño), la sesión (FC, zonas y carga), la recuperación (HRV y FC en reposo) y el progreso.
- **Privacidad:** consentimiento por fuente, revocación con borrado y tokens cifrados.
- **CA:**
  - el usuario importa su exportación de Apple Health en la web y ve sus pasos, FC y sueño de los últimos 90 días;
  - un corredor conecta Strava y sus carreras aparecen con zonas y carga.

### 4.15 Alimentos, combinaciones, recetas y artículos (más contenido)
- **Generador de combinaciones mexicanas.** Ejemplo de las tortas: pan (telera, bolillo, integral) × proteína (milanesa de res o pollo, jamón, pierna, chorizo, huevo, cochinita, pollo deshebrado, queso de puerco, panela, aguacate…) × extras (frijoles, aguacate, queso, mayonesa, crema, jitomate, cebolla, chiles, lechuga) × porción.
  - Los macros se calculan con los ingredientes y el nombre se genera solo («Torta de milanesa de pollo con frijoles y aguacate»).
  - Lo mismo con tacos, quesadillas, gorditas, sopes, tlacoyos, tamales, sándwiches, ensaladas, bowls, licuados y avena.
  - Meta: pasar de 2 tortas a **decenas de variantes realistas** por platillo, sin combinaciones absurdas (reglas de compatibilidad).
- **Ampliar la base de alimentos** con fuentes abiertas y citadas (SMAE, USDA FoodData Central y tablas mexicanas con licencia que lo permita), con porciones caseras.
  - Meta: **+1,000 alimentos**, **+300 recetas**, de ellas al menos 100 altas en proteína vegetal o con huevo, y recetas por deporte (pre y post entrenamiento, carga de carbohidratos).
- **Artículos:** **+150 artículos nuevos** en todos los deportes, recuperación, sueño, salud mental, fisioterapia y nutrición clínica.
  - Cada uno tiene: resumen, «qué hacer», nivel de evidencia y referencias con DOI.
  - Se guardan en la base de datos para que **nunca se pierdan**, con fecha de revisión.
- **CA:** el buscador encuentra «torta de jamón con aguacate» con sus macros calculados; el diagnóstico verifica que ninguna combinación rompa alergias o tipos de dieta.

### 4.16 Ejercicio por foto de la máquina
- El usuario toma una foto de una máquina o aparato. La IA de visión (modelo principal) identifica el tipo de equipo: prensa, jalón, Smith, hack, poleas, etc.
- **Primero se busca en el catálogo propio.** Si no está, se usa **búsqueda web** con la herramienta oficial de búsqueda de la API de Claude, priorizando fuentes confiables (NSCA, ACE, ACSM, manuales de fabricantes).
- Con eso se genera una **ficha propia**:
  - ajuste de la máquina (asiento, respaldo, rango);
  - ejecución paso a paso;
  - errores comunes;
  - músculos;
  - variantes y alternativas.
- La ficha lleva fuentes citadas, se guarda en el catálogo (queda disponible para todos) y se marca «pendiente de revisión» hasta que un coach o el administrador la apruebe.
- **CA:** de una foto de prueba de 10 máquinas distintas, al menos 8 se identifican bien; las fichas tienen fuentes; no se copia texto literal.

### 4.17 Modelo 3D y técnica (mejora mayor)
- **Datos:** usar solo los de la sección 3: mocap con licencia, grabaciones propias o autorizadas con estimación de pose, y literatura biomecánica citada (libros y artículos resumidos y referenciados).
- **Animaciones 3D por ejercicio** en el visor existente (three.js):
  - fases (excéntrica, concéntrica);
  - ángulos articulares clave;
  - músculos activos resaltados por fase;
  - vista desde 3 ángulos y cámara lenta.
  - Cubren gimnasio, calistenia, yoga y pilates (posturas), y técnica de carrera y de boxeo (guardia y golpes básicos).
- **Validación:** se comparan los ángulos con rangos publicados y un experto los revisa con una lista de verificación por ejercicio. Se documenta la precisión alcanzada, sin prometer «precisión absoluta».
- **Extra de alto valor: retroalimentación de técnica con la cámara del celular**, con MediaPipe Pose en el navegador:
  - conteo de repeticiones, rango de movimiento y alertas simples (rodillas hacia dentro, espalda redondeada);
  - privacidad: el video se procesa en el dispositivo y no se sube.
- **CA:** los 30 ejercicios más usados tienen animación validada; la retroalimentación por cámara funciona en sentadilla, flexión y plancha.

### 4.18 Comparativa con las apps líderes del mundo
- Lee el artículo de Forbes Health «Best Fitness Apps» (https://www.forbes.com/health/weight-loss/best-fitness-apps/) y fuentes equivalentes recientes.
  - **Nota:** en la sesión anterior `forbes.com` estaba bloqueado por la red. Pide al dueño permitir ese dominio o usa fuentes alternativas, y no inventes el contenido del artículo.
- Haz una matriz «qué tienen ellos / qué tenemos / qué nos falta / prioridad». Revisa como mínimo estas apps, consideradas referentes del mercado (verifica sus funciones actuales):
  - Nike Training Club;
  - Strava;
  - MyFitnessPal;
  - Apple Fitness+;
  - Peloton;
  - Fitbod;
  - Centr;
  - Sweat;
  - Les Mills+;
  - Noom;
  - Headspace o Calm (bienestar);
  - Runna (running);
  - Down Dog (yoga).
- Agrega las mejoras útiles que no estén en este documento a la sección 5 como «Fase extra» y justifícalas.
- **Entrega:** `docs/14_COMPARATIVA_APPS.md`.

## 5. Plan por fases (orden recomendado: valor primero, riesgo después)

| Fase | Versión | Contenido | Por qué en este orden |
|---|---|---|---|
| 0 | — | Investigación base (4.2, 4.3, 4.4, 4.8, 4.10 y 4.14) y comparativa (4.18). Se entregan `docs/13…` y `docs/14…` y la lista de decisiones para el dueño. | Sin evidencia no se construye. |
| 1 | 2.4.0 | Cronómetros y sueño (4.1), calentamiento, vuelta a la calma y recuperación (4.3, 4.4), salud mental (4.8), combinaciones de alimentos (4.15, primera parte), guía de alta de cliente (4.11) y mediciones ilustradas (4.9). | Alto valor diario y bajo riesgo técnico. |
| 2 | 2.5.0 | Multideporte: registro y progreso (4.2), Zen (4.5), roles de nutriólogo y fisioterapeuta (4.6, 4.7) e ISAK por niveles (4.10). | Abre los nuevos públicos profesionales. |
| 3 | 2.6.0 | Marca, paleta automática y estudio de contenido (4.12, fase A); agenda y videollamada (4.13). | Monetización de profesionales. |
| 4 | 2.7.0 | Wearables: importación de archivos y OAuth (4.14); ejercicio por foto (4.16); redes sociales (4.12, fase B) cuando el dueño complete los registros. | Dependen de terceros y de la app publicada en internet. |
| 5 | 3.0.0 | Modelo 3D validado y retroalimentación por cámara (4.17); app móvil con HealthKit y Health Connect. | Lo más complejo, sobre una base estable. |
| Continua | cada versión | Contenido (4.15): artículos, recetas y alimentos; traducciones EN/FR. | Valor acumulativo. |

## 6. Decisiones que debes pedirle al dueño (antes de la fase en la que se necesiten)
1. **Precios y licencias** de los roles nuevos: nutriólogo, fisioterapeuta y paquete «multiprofesional». Define también si las sesiones en vivo cobran comisión.
2. **Videollamadas:** Jitsi en servidor público, Jitsi propio, LiveKit, o solo enlaces de Zoom o Meet.
3. **Redes sociales** a conectar primero (recomendado: Instagram y Facebook). El dueño debe crear las apps de desarrollador en cada red; nunca compartirá las claves por chat.
4. **Publicación en internet:** hosting con HTTPS y dominio. Es requisito para OAuth, webhooks, redes y videollamadas.
5. **Cómo se verifican** las cédulas de nutriólogos y fisioterapeutas: revisión manual del administrador o consulta al Registro Nacional de Profesionistas.
6. **Revisión legal de los temas nuevos:** salud mental, telemedicina o teleasesoría, uso de imagen de clientes en marketing, datos de wearables y transferencias internacionales. Hay que actualizar los avisos y consentimientos y subir `legal.VERSION`.

## 7. Formato de tu respuesta en cada entrega
1. Resumen en 5 líneas para el dueño, con lenguaje sencillo.
2. Lista de lo hecho por módulo, con sus CA cumplidos o no.
3. Qué se probó (diagnóstico, revisión visual, flujo de punta a punta) y qué no.
4. Decisiones pendientes del dueño.
5. Versión publicada y enlace al ZIP.

---
*Generado el 23/11/2026 a partir de la solicitud del dueño de FitBase. Complementa a `PROMPT_MAESTRO.md` y a la carpeta `docs/` de la exportación.*
