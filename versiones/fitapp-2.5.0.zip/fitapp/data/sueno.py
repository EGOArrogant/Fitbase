"""Sueño: metas por edad, indicadores (duración, regularidad, deuda) y recomendaciones basadas en evidencia.

Fuentes:
- Watson NF et al. (2015). Recommended Amount of Sleep for a Healthy Adult. AASM/SRS. J Clin Sleep Med 11(6):591-592. doi:10.5664/jcsm.4758
- Paruthi S et al. (2016). Recommended Amount of Sleep for Pediatric Populations. AASM. J Clin Sleep Med 12(6):785-786. doi:10.5664/jcsm.5866
- Hirshkowitz M et al. (2015). National Sleep Foundation's sleep time duration recommendations. Sleep Health 1(1):40-43. doi:10.1016/j.sleh.2014.12.010
- Walsh NP et al. (2021). Sleep and the athlete: narrative review and 2021 expert consensus recommendations. Br J Sports Med 55:356-368. doi:10.1136/bjsports-2020-102025
- Windred DP et al. (2024). Sleep regularity is a stronger predictor of mortality risk than sleep duration. Sleep 47(1):zsad253. doi:10.1093/sleep/zsad253
- Dutheil F et al. (2021). Effects of a short daytime nap on cognitive performance: meta-analysis. Int J Environ Res Public Health 18(19):10212. doi:10.3390/ijerph181910212
- Irish LA et al. (2015). The role of sleep hygiene in promoting public health. Sleep Med Rev 22:23-36. doi:10.1016/j.smrv.2014.10.001
"""
import statistics


def meta_por_edad(edad, deportista=False):
    """(mínimo, máximo) de horas recomendadas."""
    edad = edad or 30
    if edad < 13:
        rango = (9, 12)
    elif edad < 18:
        rango = (8, 10)
    elif edad < 65:
        rango = (7, 9)
    else:
        rango = (7, 8)
    if deportista and edad >= 18:
        rango = (max(rango[0], 7), 9)  # Walsh 2021: atletas, 7-9 h y más en cargas altas
    return rango


def _min(h):
    """'23:30' → minutos desde 12:00 (así las horas de dormir cerca de medianoche quedan continuas)."""
    if not h:
        return None
    m = int(h[:2]) * 60 + int(h[3:5])
    return (m - 720) % 1440


def regularidad(horas_dormir):
    """Desviación estándar (minutos) de la hora de acostarse. <30 regular, 30-60 variable, >60 irregular."""
    xs = [x for x in (_min(h) for h in horas_dormir) if x is not None]
    if len(xs) < 3:
        return None
    return round(statistics.pstdev(xs))


def hora_media(horas):
    xs = [x for x in (_min(h) for h in horas) if x is not None]
    if not xs:
        return None
    m = (round(sum(xs) / len(xs)) + 720) % 1440
    return f"{m // 60:02d}:{m % 60:02d}"


def analizar(logs, edad, deportista=False, dias=14):
    """logs: registros diarios (dicts con sueno, hora_dormir, hora_despertar, calidad_sueno, despertares, siesta_min)."""
    ult = [l for l in logs if l.get("sueno")][-dias:]
    lo, hi = meta_por_edad(edad, deportista)
    if not ult:
        return {"n": 0, "meta": (lo, hi)}
    durs = [l["sueno"] for l in ult]
    ult7 = durs[-7:]
    deuda = round(sum(max(0.0, lo - d) for d in ult7), 1)
    cal = [l["calidad_sueno"] for l in ult if l.get("calidad_sueno")]
    reg = regularidad([l.get("hora_dormir") for l in ult])
    pct_meta = round(100 * sum(1 for d in durs if d >= lo) / len(durs))
    return {"n": len(ult), "meta": (lo, hi), "prom": round(sum(durs) / len(durs), 1), "prom7": round(sum(ult7) / len(ult7), 1),
            "deuda7": deuda, "pct_meta": pct_meta, "calidad": round(sum(cal) / len(cal), 1) if cal else None,
            "regularidad": reg, "reg_txt": None if reg is None else ("regular" if reg < 30 else "variable" if reg <= 60 else "irregular"),
            "acostarse": hora_media([l.get("hora_dormir") for l in ult]), "levantarse": hora_media([l.get("hora_despertar") for l in ult])}


def recomendaciones(a, estres_alto=False):
    """Lista (prioridad, título, texto, fuente) según el análisis."""
    out = []
    if not a.get("n"):
        return [(2, "Empieza a registrar tu sueño",
                 "Anota a qué hora te acuestas y te levantas durante 7 días. Con eso calculamos tu promedio, tu regularidad y tu deuda de sueño.",
                 "Watson 2015 (AASM/SRS)")]
    lo, hi = a["meta"]
    if a["prom7"] < lo:
        out.append((1, f"Duermes menos de {lo} h",
                    f"Tu promedio de la última semana es {a['prom7']} h. Adelanta tu hora de acostarte 15–30 min cada pocos días hasta llegar a {lo}–{hi} h.",
                    "Watson 2015; Walsh 2021"))
    if a.get("deuda7", 0) >= 5:
        out.append((1, "Deuda de sueño alta",
                    f"Acumulaste {a['deuda7']} h por debajo de tu meta en 7 días. Evita entrenamientos muy intensos hoy y prioriza dormir más esta semana.",
                    "Walsh 2021"))
    if a.get("regularidad") is not None and a["regularidad"] > 60:
        out.append((1, "Horario irregular",
                    f"Tu hora de acostarte varía ±{a['regularidad']} min. Acostarte y levantarte a la misma hora (también en fin de semana) se asocia con mejor salud, incluso más que dormir muchas horas.",
                    "Windred 2024"))
    elif a.get("regularidad") is not None and a["regularidad"] > 30:
        out.append((2, "Horario algo variable",
                    f"Tu hora de acostarte varía ±{a['regularidad']} min. Intenta un margen de 30 min.", "Windred 2024"))
    if a.get("calidad") is not None and a["calidad"] < 3:
        out.append((2, "Calidad de sueño baja",
                    "Cuarto oscuro, fresco y silencioso; nada de pantallas 30–60 min antes; cafeína solo antes de las 14:00 y alcohol lo menos posible.",
                    "Irish 2015"))
    if estres_alto:
        out.append((2, "Estrés y sueño",
                    "Prueba 5 min de respiración lenta (unas 6 respiraciones por minuto) antes de dormir: en Bienestar tienes la guía.",
                    "Zaccaro 2018"))
    out.append((3, "Siestas cortas",
                "Si duermes poco, una siesta de 10–30 min a primera hora de la tarde mejora la atención sin afectar tu sueño nocturno.",
                "Dutheil 2021"))
    if a["prom7"] >= lo and not out[:-1]:
        out.insert(0, (3, "¡Vas muy bien!", f"Promedias {a['prom7']} h y cumples tu meta el {a['pct_meta']} % de los días. Mantén tu horario.", "Watson 2015"))
    return sorted(out, key=lambda x: x[0])[:5]


if __name__ == "__main__":
    assert meta_por_edad(30) == (7, 9) and meta_por_edad(15) == (8, 10)
    assert regularidad(["23:00", "23:10", "22:50", "23:05"]) < 30
    assert regularidad(["22:00", "01:30", "23:00", "02:00"]) > 60
    a = analizar([{"sueno": 5.5, "hora_dormir": "01:00"}] * 7, 30)
    assert a["deuda7"] == 10.5 and recomendaciones(a)[0][0] == 1
    print("sueno.py OK")
