"""Deportes, calentamiento (RAMP), vuelta a la calma y recuperación basada en evidencia.

Notas completas con fuentes: research_notes/deportes/*.md. Fuentes principales:
- Jeffreys I (2007) RAMP. Prof Strength Cond 6:12-18 · McGowan CJ et al. (2015) Sports Med doi:10.1007/s40279-015-0376-x
- Behm DG et al. (2016) Appl Physiol Nutr Metab doi:10.1139/apnm-2015-0235 (estático <60 s: efecto trivial)
- Thorborg K et al. (2017) Br J Sports Med doi:10.1136/bjsports-2016-097066 (FIFA 11+)
- Van Hooren B, Peake JM (2018) Sports Med doi:10.1007/s40279-018-0916-2 (vuelta a la calma)
- Thomas DT, Erdman KA, Burke LM (2016) ACSM/AND/DC Med Sci Sports Exerc doi:10.1249/MSS.0000000000000852
- Jäger R et al. (2017) ISSN proteína doi:10.1186/s12970-017-0177-8 · Kerksick CM et al. (2017) ISSN timing doi:10.1186/s12970-017-0189-4
- Burke LM, van Loon LJC, Hawley JA (2017) J Appl Physiol doi:10.1152/japplphysiol.00860.2016
- Hew-Butler T et al. (2015) Clin J Sport Med doi:10.1097/JSM.0000000000000221 (hiponatremia)
- Morán-Navarro R et al. (2017) Eur J Appl Physiol doi:10.1007/s00421-017-3725-7 (recuperación tras fuerza)
- Walsh NP et al. (2021) Br J Sports Med doi:10.1136/bjsports-2020-102025 (sueño del atleta)
- Roberts LA et al. (2015) J Physiol doi:10.1113/JP270570 (agua fría atenúa hipertrofia)
- Meeusen R et al. (2013) Eur J Sport Sci doi:10.1080/17461391.2012.730061 (sobreentrenamiento)
- Patricios JS et al. (2023) Br J Sports Med doi:10.1136/bjsports-2023-106898 (conmoción, 6.º consenso)
- Seiler S (2010) IJSPP doi:10.1123/ijspp.5.3.276 (distribución de intensidad en resistencia)
"""

DEPORTES = {
    "musculacion": {"nombre": "Gimnasio / musculación", "icono": "pesa", "color": "ent"},
    "running": {"nombre": "Running", "icono": "tendencia", "color": "nut"},
    "boxeo": {"nombre": "Boxeo y combate", "icono": "trofeo", "color": "coa"},
    "cardio": {"nombre": "Cardio (bici, elíptica, remo, natación)", "icono": "pulso", "color": "her"},
    "calistenia": {"nombre": "Calistenia", "icono": "cuerpo", "color": "ana"},
    "yoga": {"nombre": "Yoga", "icono": "loto", "color": "com"},
    "pilates": {"nombre": "Pilates", "icono": "loto", "color": "com"},
    "hibrido": {"nombre": "Multidisciplinario / híbrido", "icono": "cuadricula", "color": "gen"},
}
NIVELES = ["Principiante", "Intermedio", "Avanzado"]

# ---------------------------------------------------------------- calentamiento (RAMP)
# (nombre, dosis, indicación clave, nivel mínimo 0-2)
_ELEVAR = {
    "musculacion": [("Bici, remo o caminadora suave", "3–5 min", "Que puedas platicar; empieza a sudar ligeramente.", 0)],
    "running": [("Trote muy suave", "5–8 min", "Ritmo en el que puedas hablar con frases completas.", 0)],
    "boxeo": [("Saltar la cuerda", "3 × 1 min", "Rebote ligero sobre la punta de los pies, muñecas relajadas.", 0),
              ("Sombra suave", "2 min", "Movimiento de pies y golpes al 50 %.", 0)],
    "cardio": [("La misma máquina a ritmo muy suave", "5 min", "Sube poco a poco la intensidad.", 0)],
    "calistenia": [("Jumping jacks y trote en el lugar", "2–3 min", "Respira con ritmo y suelta los brazos.", 0)],
    "yoga": [("Respiración y movilidad suave sentado", "2–3 min", "Respira lento por la nariz.", 0)],
    "pilates": [("Respiración lateral (costal)", "2 min", "Abre las costillas hacia los lados al inhalar.", 0)],
    "hibrido": [("Remo o bici suave", "4 min", "Aumenta poco a poco el ritmo.", 0)],
}
_MOVILIZAR = {
    "musculacion": [("Rotación torácica en cuadrupedia", "8 por lado", "Gira desde la parte alta de la espalda, no desde la cintura.", 0),
                    ("Sentadilla profunda con pausa", "8", "Talones en el suelo, pecho arriba; empuja rodillas hacia afuera.", 0),
                    ("Bisagra de cadera con palo", "10", "Lleva la cadera atrás manteniendo la espalda neutra.", 0)],
    "running": [("Balanceo de pierna adelante-atrás y lateral", "10 por pierna", "Movimiento controlado, sin rebotar.", 0),
                ("Zancada con giro", "6 por lado", "Rodilla alineada con el pie.", 0),
                ("Tobillo a la pared", "10 por lado", "Lleva la rodilla hacia la pared sin despegar el talón.", 0)],
    "boxeo": [("Círculos de hombros y brazos", "10 por sentido", "Amplitud cómoda, sin dolor.", 0),
              ("Rotación de tronco en guardia", "10 por lado", "Gira desde la cadera, como al golpear.", 0),
              ("Cuello: inclinaciones suaves", "5 por lado", "Lento y sin forzar.", 0)],
    "cardio": [("Balanceo de piernas", "10 por pierna", "Controlado.", 0), ("Gato-camello", "8", "Mueve la columna vértebra por vértebra.", 0)],
    "calistenia": [("Círculos de muñecas en cuadrupedia", "10 por sentido", "Carga el peso poco a poco sobre las manos.", 0),
                   ("Dislocaciones de hombro con banda", "10", "Brazos estirados, agarre amplio.", 0),
                   ("Colgado pasivo de la barra", "20–30 s", "Relaja los hombros y respira.", 1)],
    "yoga": [("Gato-vaca (Marjaryasana-Bitilasana)", "8 respiraciones", "Mueve con la respiración.", 0),
             ("Saludo al sol suave", "2–3 rondas", "Sin prisa; dobla rodillas si lo necesitas.", 0)],
    "pilates": [("Puente articulado (rodar la columna)", "8", "Sube y baja vértebra por vértebra.", 0),
                ("Rotaciones de cadera acostado", "8 por lado", "Pelvis estable.", 0)],
    "hibrido": [("Gusano (inchworm) con flexión", "6", "Camina con las manos hasta plancha y regresa.", 0),
                ("Sentadilla profunda con apertura torácica", "6 por lado", "Abre el brazo hacia el techo.", 0)],
}
_ACTIVAR = {
    "musculacion": [("Puente de glúteo", "12", "Aprieta glúteos arriba 1 s.", 0), ("Remo con banda", "15", "Junta escápulas sin subir hombros.", 0),
                    ("Plancha", "20–30 s", "Cuerpo en línea recta.", 0)],
    "running": [("Puente de glúteo a una pierna", "8 por lado", "Pelvis nivelada.", 0), ("Elevación de talones", "15", "Sube despacio y controla la bajada.", 0),
                ("Plancha lateral", "20 s por lado", "Cadera alta (bloque tipo FIFA 11+).", 0)],
    "boxeo": [("Plancha con toque de hombro", "10 por lado", "Sin girar la cadera.", 0), ("Sentadilla con salto suave", "8", "Aterriza silencioso.", 1)],
    "cardio": [("Puente de glúteo", "12", "", 0), ("Sentadilla con peso corporal", "10", "", 0)],
    "calistenia": [("Retracción escapular colgado", "8", "Baja los hombros sin doblar codos.", 1), ("Flexión en pared o inclinada", "10", "Codos a 45°.", 0),
                   ("Hollow hold", "20 s", "Zona lumbar pegada al suelo.", 0)],
    "yoga": [("Perro boca abajo (Adho Mukha Svanasana)", "5 respiraciones", "Alarga la espalda; rodillas dobladas si hace falta.", 0)],
    "pilates": [("Hundred modificado", "50 bombeos", "Cabeza apoyada si molesta el cuello.", 0), ("Dead bug", "8 por lado", "Espalda baja estable.", 0)],
    "hibrido": [("Kettlebell swing ligero", "10", "Empuja con la cadera, no con los brazos.", 1), ("Plancha", "30 s", "", 0)],
}
_POTENCIAR = {
    "musculacion": [("Series de aproximación del primer ejercicio", "2–3 series", "Ej.: 50 % × 8, 70 % × 4, 85 % × 2 del peso de trabajo.", 0)],
    "running": [("Skipping y talones al glúteo", "2 × 20 m", "Postura alta.", 0), ("Aceleraciones progresivas (strides)", "4 × 80 m", "Llega al 80–90 % y relaja.", 1)],
    "boxeo": [("Combinaciones al saco a ritmo de pelea", "2 × 30 s", "Velocidad y técnica, no fuerza máxima.", 1)],
    "cardio": [("2–3 aceleraciones de 20 s", "", "Al ritmo de tu sesión principal.", 0)],
    "calistenia": [("Versión fácil de tu habilidad principal", "2 series cortas", "Ej.: dominada con banda antes de dominadas.", 0)],
    "yoga": [("Postura de pie de la sesión, versión suave", "3 respiraciones", "", 0)],
    "pilates": [("Roll-up asistido", "5", "Usa las manos detrás de los muslos si hace falta.", 0)],
    "hibrido": [("Primer movimiento de la sesión con poco peso", "2 series", "", 0)],
}

VUELTA_CALMA = {
    "musculacion": [("Caminar o bici muy suave", "3–5 min", "Respiración nasal."), ("Estiramiento de cadera (flexores) en zancada", "30 s por lado", "Aprieta el glúteo de atrás."),
                    ("Estiramiento de pecho en marco de puerta", "30 s por lado", "Sin dolor.")],
    "running": [("Trote o caminata suave", "5 min", "Deja que baje el pulso poco a poco."), ("Gemelos en pared", "30 s por lado", "Rodilla recta y luego doblada."),
                ("Isquiotibiales acostado con banda", "30 s por lado", "Espalda apoyada.")],
    "boxeo": [("Sombra muy suave y respiración", "2–3 min", ""), ("Estiramiento de hombros y pecho", "30 s por lado", ""), ("Respiración caja 4-4-4-4", "2 min", "Baja el pulso.")],
    "cardio": [("Misma máquina muy suave", "3–5 min", ""), ("Cuádriceps de pie", "30 s por lado", "")],
    "calistenia": [("Estiramiento de muñecas y antebrazos", "30 s por posición", ""), ("Postura del niño (Balasana)", "1 min", "")],
    "yoga": [("Savasana", "3–5 min", "Suelta el cuerpo y respira natural.")],
    "pilates": [("Postura del niño", "1 min", ""), ("Rodillas al pecho", "1 min", "")],
    "hibrido": [("Caminar", "3 min", ""), ("Movilidad de cadera 90/90", "1 min por lado", "")],
}
FUENTE_CALENTAMIENTO = "RAMP (Jeffreys 2007); McGowan 2015; Behm 2016; FIFA 11+ (Thorborg 2017). Vuelta a la calma opcional: Van Hooren y Peake 2018."


def calentamiento_para(deporte, nivel="Principiante", minutos=10, lesiones=()):
    """Plan de calentamiento por fases RAMP. minutos ≤6 → versión corta."""
    d = deporte if deporte in DEPORTES else "musculacion"
    nv = NIVELES.index(nivel) if nivel in NIVELES else 0
    corto = minutos <= 6
    fases = []
    for clave, titulo, fuente in (("elevar", "Elevar temperatura", _ELEVAR), ("movilizar", "Movilizar", _MOVILIZAR),
                                  ("activar", "Activar", _ACTIVAR), ("potenciar", "Potenciar", _POTENCIAR)):
        ejs = [{"nombre": n, "dosis": ds, "clave": c} for n, ds, c, mn in fuente.get(d, []) if mn <= nv]
        if corto:
            ejs = ejs[:1] if clave != "movilizar" else ejs[:2]
        if ejs:
            fases.append({"fase": clave, "titulo": titulo, "ejercicios": ejs})
    aviso = "Tienes molestias registradas: haz los movimientos en un rango sin dolor y omite los que lo provoquen." if lesiones else None
    return {"deporte": d, "fases": fases, "aviso": aviso, "minutos": 5 if corto else 10, "fuente": FUENTE_CALENTAMIENTO}


def vuelta_calma_para(deporte):
    return [{"nombre": n, "dosis": ds, "clave": c} for n, ds, c in VUELTA_CALMA.get(deporte, VUELTA_CALMA["musculacion"])]


# ---------------------------------------------------------------- recuperación
# horas mínimas antes de repetir el mismo estímulo intenso (prácticas prudentes; evidencia moderada)
DESCANSO_MINIMO = {
    "fuerza_lejos_fallo": (24, "Fuerza con 2–3 repeticiones en reserva", "Morán-Navarro 2017"),
    "fuerza_al_fallo": (48, "Fuerza al fallo o muy pesada", "Morán-Navarro 2017"),
    "excentrico_nuevo": (72, "Ejercicio nuevo o muy excéntrico (dolor tardío)", "Morán-Navarro 2017; efecto de carga repetida"),
    "carrera_dura": (48, "Intervalos, tempo o competencia", "Seiler 2010; práctica de entrenadores"),
    "carrera_larga": (48, "Rodaje largo (>90 min)", "Práctica de entrenadores (evidencia débil)"),
    "sparring": (48, "Sparring con contacto a la cabeza", "Prudencia por impactos repetidos; Patricios 2023"),
}

# Reglas: (id, deportes|None=todos, condición, prioridad 1-3, título, texto, por qué, fuente)
# condición: dict con claves min_dur, max_dur, min_rpe, max_rpe, niveles, min_perdida_pct, max_siguiente_h, calor, contacto
REGLAS_RECUPERACION = [
    ("hidr_perdida_alta", None, {"min_perdida_pct": 2.0}, 1, "Rehidrátate con sal",
     "Perdiste {perdida_kg} kg ({perdida_pct} % de tu peso). Bebe {litros} L en las próximas horas, con algo de sodio (bebida con electrolitos o comida salada).",
     "Reponer 125–150 % de lo perdido compensa la orina que produces al rehidratarte.", "Thomas 2016 (ACSM/AND/DC)"),
    ("hidr_larga", None, {"min_dur": 90}, 2, "Hidratación tras sesión larga",
     "Bebe agua con tu comida y orina en las próximas horas; si sudaste mucho, agrega sodio. No fuerces litros de agua sola.",
     "Beber de más sin sodio puede causar hiponatremia.", "Hew-Butler 2015"),
    ("hidr_corta", None, {"max_dur": 45, "max_rpe": 6}, 3, "Agua según sed",
     "Con esta sesión basta beber según tu sed.", "En esfuerzos cortos y moderados la deshidratación no suele ser relevante.", "Thomas 2016"),
    ("cho_doble", None, {"max_siguiente_h": 8, "min_rpe": 6}, 1, "Carga carbohidratos para tu siguiente sesión",
     "Entrenas de nuevo en menos de 8 h: come ~{cho_h} g de carbohidratos por hora durante las próximas 4 h (arroz, pan, fruta, avena).",
     "Repone el glucógeno más rápido cuando el tiempo es corto.", "Burke 2017; Thomas 2016"),
    ("prot_post", None, {}, 2, "Proteína en las próximas horas",
     "Incluye unos {prot} g de proteína en tu siguiente comida (pollo, huevo, lácteos, tofu o leguminosas).",
     "~0.3 g/kg por comida maximiza la síntesis muscular; la «ventana» de 30 min es mucho más amplia de lo que se creía.", "Jäger 2017; Kerksick 2017"),
    ("run_largo_avanzado", ["running"], {"min_dur": 120, "niveles": ["Avanzado", "Intermedio"]}, 1, "Recuperación tras tirada larga",
     "Hoy: come carbohidratos y proteína, eleva las piernas un rato y camina suave más tarde. Las próximas 48 h solo rodaje suave o descanso.",
     "Las tiradas largas producen fatiga muscular y de glucógeno que tarda 1–3 días en recuperarse.", "Thomas 2016; Seiler 2010"),
    ("run_maraton", ["running"], {"min_dur": 180}, 1, "Después de una distancia de maratón",
     "Tómate de 3 a 7 días de caminata o trote muy suave antes de volver a sesiones de calidad; prioriza dormir y comer suficiente.",
     "El daño muscular y la fatiga tras 42 km se mantienen varios días.", "Práctica de entrenadores; evidencia débil (por verificar)"),
    ("run_principiante", ["running"], {"max_dur": 40, "niveles": ["Principiante"]}, 2, "Buen trabajo: deja un día entre carreras",
     "Al empezar, alterna días de correr con días de descanso o caminata para que tendones y huesos se adapten.",
     "El tejido conectivo se adapta más lento que el corazón y los pulmones.", "Práctica clínica; Nielsen 2014 (progresión gradual, por verificar)"),
    ("run_intervalos", ["running", "cardio", "hibrido"], {"min_rpe": 8}, 2, "48 h antes de otra sesión dura",
     "Fue una sesión intensa: mañana haz algo suave (zona 1–2) o descansa; la próxima sesión dura, en 48 h.",
     "En resistencia, ~80 % del volumen suave y ~20 % intenso da mejores resultados.", "Seiler 2010"),
    ("fuerza_fallo", ["musculacion", "calistenia", "hibrido"], {"min_rpe": 9}, 2, "Músculos al límite: 48–72 h",
     "Trabajaste cerca del fallo: espera 48–72 h antes de volver a entrenar fuerte los mismos músculos.",
     "La fuerza tarda más en recuperarse cuando las series llegan al fallo.", "Morán-Navarro 2017"),
    ("fuerza_normal", ["musculacion", "calistenia"], {"max_rpe": 8}, 3, "Recuperación normal",
     "Puedes volver a entrenar estos músculos en 24–48 h. Muévete suave el resto del día.", "Con repeticiones en reserva la recuperación es más rápida.", "Morán-Navarro 2017"),
    ("no_hielo_fuerza", ["musculacion", "calistenia"], {"min_dur": 30}, 3, "Evita el agua helada de rutina",
     "Si buscas ganar músculo, no te metas en agua helada después de entrenar fuerza como costumbre.",
     "El frío rutinario puede reducir las adaptaciones de hipertrofia.", "Roberts 2015"),
    ("box_sparring", ["boxeo"], {"contacto": True}, 1, "Vigila tu cabeza",
     "Si hoy hubo golpes en la cabeza y notas dolor de cabeza, mareo, náusea, visión borrosa o confusión, no entrenes y consulta a un médico. Deja al menos 48 h antes de otro sparring.",
     "Los síntomas de conmoción pueden aparecer horas después y requieren reposo y valoración.", "Patricios 2023 (consenso de conmoción)"),
    ("box_manos", ["boxeo"], {"min_dur": 45}, 3, "Cuida manos y muñecas",
     "Revisa nudillos y muñecas; si hay inflamación, aplica frío local 10–15 min y vendaje correcto la próxima vez.", "", "Práctica clínica"),
    ("yoga_suave", ["yoga", "pilates"], {}, 3, "Integra lo practicado",
     "Bebe agua y nota cómo te sientes. Puedes repetir la respiración de hoy antes de dormir.", "", "Práctica"),
    ("sueno", None, {"min_rpe": 7}, 2, "Duerme 7–9 h hoy",
     "El sueño es la herramienta de recuperación con más evidencia: procura acostarte a tu hora y, si dormiste poco, una siesta de 20–30 min ayuda.",
     "Dormir poco reduce el rendimiento y aumenta el riesgo de lesión.", "Walsh 2021"),
    ("calor", None, {"calor": True}, 1, "Enfríate y rehidrátate",
     "Entrenaste con calor: busca sombra, enfría con agua y bebe con sal. Si tienes confusión, dolor de cabeza intenso o dejas de sudar, pide ayuda médica.",
     "El golpe de calor es una emergencia.", "Racinais 2015 (consenso de calor, BJSM)"),
    ("vuelta_calma", ["running", "cardio", "boxeo", "hibrido"], {"min_rpe": 7}, 3, "Baja el pulso poco a poco",
     "Camina o pedalea suave 3–5 min antes de detenerte por completo.", "Evita mareos al frenar de golpe; no acelera la recuperación.", "Van Hooren y Peake 2018"),
    ("estirar", None, {"max_rpe": 10}, 3, "Estira si te gusta",
     "Estirar después es opcional: mejora la sensación de rigidez, pero no previene el dolor muscular del día siguiente.", "", "Afonso 2021"),
    ("alarma", None, {"min_rpe": 9, "min_dur": 60}, 2, "Señales de alarma",
     "Si tu rendimiento baja varias sesiones seguidas, duermes mal y tu pulso en reposo sube, toma 2–3 días suaves: pueden ser signos de sobrecarga.",
     "", "Meeusen 2013"),
]


def _cumple(cond, x):
    if "min_dur" in cond and (x["duracion"] or 0) < cond["min_dur"]:
        return False
    if "max_dur" in cond and (x["duracion"] or 0) > cond["max_dur"]:
        return False
    if "min_rpe" in cond and (x["rpe"] or 0) < cond["min_rpe"]:
        return False
    if "max_rpe" in cond and (x["rpe"] or 10) > cond["max_rpe"]:
        return False
    if "niveles" in cond and x["nivel"] not in cond["niveles"]:
        return False
    if "min_perdida_pct" in cond and (x["perdida_pct"] or 0) < cond["min_perdida_pct"]:
        return False
    if "max_siguiente_h" in cond and (x["siguiente_h"] is None or x["siguiente_h"] > cond["max_siguiente_h"]):
        return False
    if cond.get("calor") and not x["calor"]:
        return False
    if cond.get("contacto") and not x["contacto"]:
        return False
    return True


def recomendaciones_recuperacion(deporte, duracion_min, rpe, nivel="Principiante", peso_kg=None, peso_post_kg=None,
                                 siguiente_sesion_h=None, calor=False, contacto=False, maximo=5):
    perd = (peso_kg - peso_post_kg) if peso_kg and peso_post_kg and peso_kg > peso_post_kg else None
    x = {"duracion": duracion_min, "rpe": rpe, "nivel": nivel, "perdida_pct": round(perd / peso_kg * 100, 1) if perd else None,
         "siguiente_h": siguiente_sesion_h, "calor": calor, "contacto": contacto}
    vals = {"perdida_kg": round(perd, 2) if perd else 0, "perdida_pct": x["perdida_pct"] or 0, "litros": round(perd * 1.5, 1) if perd else 0,
            "prot": round(0.3 * peso_kg) if peso_kg else 25, "cho_h": round(1.1 * peso_kg) if peso_kg else 70}
    out = []
    for rid, deps, cond, pri, tit, txt, porque, fuente in REGLAS_RECUPERACION:
        if deps and deporte not in deps:
            continue
        if _cumple(cond, x):
            out.append({"id": rid, "prioridad": pri, "titulo": tit, "texto": txt.format(**vals), "por_que": porque, "fuente": fuente})
    out.sort(key=lambda r: r["prioridad"])
    return out[:maximo]


def descanso_sugerido(deporte, rpe, duracion_min, contacto=False):
    if deporte == "boxeo" and contacto:
        return DESCANSO_MINIMO["sparring"]
    if deporte in ("running", "cardio", "hibrido"):
        if (duracion_min or 0) >= 90:
            return DESCANSO_MINIMO["carrera_larga"]
        return DESCANSO_MINIMO["carrera_dura"] if (rpe or 0) >= 8 else (24, "Sesión moderada", "Seiler 2010")
    if deporte in ("musculacion", "calistenia"):
        return DESCANSO_MINIMO["fuerza_al_fallo"] if (rpe or 0) >= 9 else DESCANSO_MINIMO["fuerza_lejos_fallo"]
    return (24, "Sesión de baja intensidad", "Práctica")


if __name__ == "__main__":
    a = [r["id"] for r in recomendaciones_recuperacion("running", 180, 8, "Avanzado", 70, 68.2, siguiente_sesion_h=None)]
    b = [r["id"] for r in recomendaciones_recuperacion("running", 20, 3, "Principiante", 70)]
    assert a != b and "hidr_perdida_alta" in a and "run_principiante" in b, (a, b)
    assert recomendaciones_recuperacion("boxeo", 60, 8, contacto=True)[0]["id"] == "box_sparring"
    c = calentamiento_para("running", "Principiante", 5)
    assert c["minutos"] == 5 and all(f["ejercicios"] for f in c["fases"])
    print("deportes.py OK", a, b)
