"""Combinaciones realistas de platillos mexicanos y de todos los días (tortas, tacos, quesadillas, gorditas, sopes,
molletes, sándwiches, chilaquiles, enchiladas, tostadas, burritos, ensaladas, bowls, licuados, avena y hot cakes).

Los macros se CALCULAN a partir de los ingredientes reales de la base (alimentos_a/b/c/d.json), por eso cada variante
sale con valores coherentes. Las reglas de cada platillo evitan combinaciones absurdas: cada relleno solo admite
los extras con los que se acostumbra servir.
"""
import itertools

# Rellenos/proteínas (nombre corto para el platillo, ingrediente en la base, gramos por pieza en torta/taco)
_R = {
    "jamón": ("Jamón de pavo", 50), "milanesa de res": ("Milanesa de res empanizada frita", 110), "milanesa de pollo": ("Milanesa de pollo empanizada frita", 110),
    "pierna": ("Pierna de cerdo cocida (maciza, magra)", 90), "cochinita pibil": ("Cochinita pibil", 90), "pollo": ("Pollo deshebrado", 80),
    "tinga de pollo": ("Tinga de pollo", 90), "huevo": ("Huevo revuelto", 100), "chorizo": ("Chorizo de cerdo frito (escurrido)", 45),
    "chorizo con huevo": (None, None), "salchicha": ("Salchicha de pavo", 60), "queso de puerco": ("Queso de puerco", 50),
    "panela": ("Queso panela", 60), "pastor": ("Carne al pastor (cerdo adobado asado)", 90), "asada": ("Arrachera / carne asada", 90),
    "cecina": ("Cecina de res asada", 80), "atún": ("Atún en agua (escurrido)", 70), "pechuga asada": ("Pechuga de pollo cocida", 90),
    "suadero": ("Suadero de res guisado", 90), "chicharrón prensado": ("Chicharrón prensado guisado", 60), "longaniza": ("Longaniza frita", 50),
    "carnitas": ("Pierna de cerdo cocida (maciza, magra)", 90), "pescado": ("Pescado empanizado frito", 90), "camarón": ("Camarón cocido (sin cáscara)", 80),
    "papa con chorizo": ("Papa con chorizo", 90), "rajas con crema": ("Rajas con crema", 80), "champiñones": ("Champiñones guisados", 80),
    "huitlacoche": ("Huitlacoche guisado", 70), "flor de calabaza": ("Flor de calabaza", 60), "frijoles": ("Frijoles refritos", 60),
    "picadillo": ("Carne molida de res guisada", 80), "bistec": ("Bistec de res cocido (magro)", 90), "nopales": ("Nopal cocido", 70),
    "queso Oaxaca": ("Queso Oaxaca", 45),
}
_COMPUESTOS = {"chorizo con huevo": [("Chorizo de cerdo frito (escurrido)", 30), ("Huevo revuelto", 70)]}

# Extras: (nombre visible, ingrediente, gramos)
_E = {
    "frijoles": ("Frijoles refritos", 30), "aguacate": ("Aguacate", 30), "queso": ("Queso Oaxaca", 25), "panela": ("Queso panela", 30),
    "mayonesa": ("Mayonesa", 10), "crema": ("Crema ácida (crema mexicana)", 15), "jitomate": ("Jitomate", 25), "cebolla": ("Cebolla", 10),
    "jalapeños": ("Chiles jalapeños en vinagre", 10), "lechuga": ("Lechuga", 10), "salsa verde": ("Salsa verde", 25), "salsa roja": ("Salsa roja", 25),
    "piña": ("Piña", 20), "cilantro y cebolla": ("Cebolla", 12), "guacamole": ("Guacamole", 30), "nopales": ("Nopal cocido", 30),
    "pico de gallo": ("Jitomate", 30), "queso cotija": ("Queso cotija", 10), "arroz": ("Arroz rojo a la mexicana (con aceite)", 60),
    "elote": ("Elote desgranado", 30), "huevo": ("Huevo estrellado (frito con aceite)", 50), "pollo": ("Pollo deshebrado", 60),
}


def _extras_sets(base, max_n=2):
    """Combinaciones de 0..max_n extras sin repetir."""
    out = [()]
    for n in range(1, max_n + 1):
        out += list(itertools.combinations(base, n))
    return out


def _y(xs):
    xs = list(xs)
    return xs[0] if len(xs) == 1 else ", ".join(xs[:-1]) + " y " + xs[-1]


def _nombre(P, nb, rel, ext):
    """Nombres naturales: «Torta de jamón con aguacate», «Chilaquiles verdes con pollo y crema», «Quesadilla de flor de calabaza (tortilla de harina)»."""
    base = P["nombre"]
    sufijo = ""
    if nb.startswith("de ") or nb.startswith("en "):
        sufijo = f" ({'tortilla ' + nb if nb.startswith('de ') and base == 'Quesadilla' else nb})"
        nb = ""
    nombre = base + (f" {nb}" if nb else "")
    con = P.get("conector", "de")
    if rel and con == "de":
        nombre += f" de {rel}"
        if ext:
            if " con " in rel:     # «Gordita de papa con chorizo y crema», no «… con chorizo con crema»
                nombre += (" y " if len(ext) == 1 else ", ") + _y(ext)
            else:
                nombre += " con " + _y(ext)
    else:
        lista = ([rel] if rel else []) + list(ext)
        if lista:
            nombre += " con " + _y(lista)
        elif base in ("Quesadilla", "Torta"):
            nombre += " sencilla"
    return nombre + sufijo


# Definición de platillos: (nombre, categoría base [(ingrediente, g)], rellenos permitidos, extras permitidos por relleno o comunes,
#                           extras incluidos siempre, máx. extras opcionales, factor de relleno, descripción de pieza)
PLATILLOS = [
    {"nombre": "Torta", "bases": {"": [("Telera", 90)], "en pan integral": [("Pan integral", 80)]},
     "rellenos": ["jamón", "milanesa de res", "milanesa de pollo", "pierna", "cochinita pibil", "pollo", "tinga de pollo", "huevo", "chorizo con huevo",
                  "salchicha", "queso de puerco", "panela", "pastor", "asada", "cecina", "atún", "pechuga asada"],
     "incluye": [("jitomate",), ("cebolla",), ("jalapeños",), ("mayonesa",)], "extras": ["frijoles", "aguacate", "queso"], "max": 2, "factor": 1.0, "pieza": "1 torta"},
    {"nombre": "Tacos", "bases": {"": [("Tortilla de maíz", 60)]},
     "rellenos": ["pastor", "asada", "suadero", "carnitas", "pollo", "tinga de pollo", "bistec", "chorizo", "longaniza", "cecina", "cochinita pibil",
                  "pescado", "camarón", "papa con chorizo", "rajas con crema", "chicharrón prensado", "picadillo", "huevo", "champiñones", "nopales"],
     "incluye": [("cilantro y cebolla",), ("salsa verde",)], "extras": ["guacamole", "queso", "piña"], "max": 1, "factor": 0.9,
     "pieza": "3 tacos", "solo_extras": {"piña": ["pastor"]}},
    {"nombre": "Quesadilla", "bases": {"de maíz": [("Tortilla de maíz", 30), ("Queso Oaxaca", 35)], "de harina": [("Tortilla de harina de trigo", 40), ("Queso Oaxaca", 35)]},
     "rellenos": ["", "champiñones", "flor de calabaza", "huitlacoche", "rajas con crema", "papa con chorizo", "chicharrón prensado", "tinga de pollo", "pollo",
                  "chorizo", "jamón", "pastor", "asada", "frijoles"],
     "incluye": [("salsa verde",)], "extras": ["guacamole", "crema"], "max": 1, "factor": 0.6, "pieza": "1 quesadilla"},
    {"nombre": "Gordita", "bases": {"": [("Tortilla de maíz", 70)]},
     "rellenos": ["chicharrón prensado", "frijoles", "papa con chorizo", "rajas con crema", "picadillo", "huevo", "queso Oaxaca", "tinga de pollo", "nopales"],
     "incluye": [("salsa roja",)], "extras": ["queso cotija", "crema"], "max": 2, "factor": 0.6, "pieza": "1 gordita"},
    {"nombre": "Sope", "bases": {"": [("Tortilla de maíz", 55), ("Frijoles refritos", 25)]},
     "rellenos": ["", "pollo", "tinga de pollo", "chorizo", "asada", "bistec", "huevo", "nopales", "papa con chorizo"],
     "incluye": [("lechuga",), ("salsa verde",)], "extras": ["queso cotija", "crema", "aguacate"], "max": 2, "factor": 0.5, "pieza": "1 sope"},
    {"nombre": "Tlacoyo", "bases": {"de frijol": [("Tortilla de maíz", 70), ("Frijoles refritos", 20)]},
     "rellenos": ["", "nopales", "queso Oaxaca"], "incluye": [("salsa verde",), ("cilantro y cebolla",)], "extras": ["queso cotija"], "max": 1, "factor": 0.6, "pieza": "1 tlacoyo"},
    {"nombre": "Tostada", "bases": {"": [("Totopos de maíz fritos", 20)]},
     "rellenos": ["tinga de pollo", "pollo", "atún", "camarón", "picadillo", "pierna", "frijoles"],
     "incluye": [("lechuga",), ("salsa roja",)], "extras": ["crema", "queso cotija", "aguacate"], "max": 2, "factor": 0.6, "pieza": "1 tostada"},
    {"nombre": "Burrito", "bases": {"": [("Tortilla de harina de trigo", 75)]},
     "rellenos": ["asada", "pollo", "pastor", "chorizo con huevo", "frijoles", "picadillo", "huevo", "carnitas", "papa con chorizo"],
     "incluye": [("pico de gallo",)], "extras": ["frijoles", "arroz", "queso", "guacamole"], "max": 2, "factor": 1.0, "pieza": "1 burrito"},
    {"nombre": "Mollete", "bases": {"": [("Bolillo", 40), ("Frijoles refritos", 35), ("Queso Oaxaca", 25)]},
     "rellenos": ["", "chorizo", "jamón", "salchicha"], "incluye": [], "extras": ["pico de gallo", "aguacate"], "max": 1, "factor": 0.35, "pieza": "1 mitad de bolillo"},
    {"nombre": "Sándwich", "bases": {"blanco": [("Pan blanco de caja", 56)], "integral": [("Pan integral de caja", 56)]},
     "rellenos": ["jamón", "pechuga asada", "atún", "panela", "huevo", "salchicha"],
     "incluye": [("lechuga",), ("jitomate",)], "extras": ["mayonesa", "aguacate", "queso"], "max": 2, "factor": 0.8, "pieza": "1 sándwich"},
    {"nombre": "Chilaquiles", "bases": {"verdes": [("Totopos de maíz fritos", 60), ("Salsa verde", 90)], "rojos": [("Totopos de maíz fritos", 60), ("Salsa roja", 90)]},
     "conector": "con", "rellenos": ["", "pollo", "huevo", "asada", "cecina"], "incluye": [("cebolla",)], "extras": ["crema", "queso cotija", "frijoles"], "max": 2, "factor": 1.0, "pieza": "1 plato"},
    {"nombre": "Enchiladas", "bases": {"verdes": [("Tortilla de maíz", 90), ("Salsa verde", 90)], "rojas": [("Tortilla de maíz", 90), ("Salsa roja", 90)]},
     "rellenos": ["pollo", "queso Oaxaca", "huevo", "picadillo"], "incluye": [("cebolla",)], "extras": ["crema", "queso cotija", "frijoles", "arroz"], "max": 2, "factor": 1.0, "pieza": "3 enchiladas"},
]

# Bowls, licuados, avena y hot cakes: combinaciones definidas a mano (sin productos cartesianos absurdos)
_BOWL_PROT = {"pollo": ("Pechuga de pollo cocida", 120), "atún": ("Atún en agua (escurrido)", 100), "carne asada": ("Arrachera / carne asada", 110),
              "huevo": ("Huevo entero (crudo o cocido)", 100), "frijoles": ("Frijoles de la olla", 150), "camarón": ("Camarón cocido (sin cáscara)", 110)}
_BOWL_BASE = {"arroz": ("Arroz blanco cocido", 150), "arroz integral": ("Arroz integral cocido", 150), "lechuga": ("Lechuga romana", 80), "papa": ("Papa cocida (sin cáscara)", 150)}
_LICUADOS = [("Licuado de plátano", [("Leche descremada", 250), ("Plátano", 100)]), ("Licuado de fresa", [("Leche descremada", 250), ("Fresas", 120)]),
             ("Licuado de plátano con avena", [("Leche descremada", 250), ("Plátano", 100), ("Avena en hojuelas cruda", 30)]),
             ("Licuado de plátano con crema de cacahuate", [("Leche descremada", 250), ("Plátano", 100), ("Crema de cacahuate", 16)]),
             ("Licuado de proteína con plátano", [("Leche descremada", 250), ("Plátano", 100), ("Proteína whey concentrada", 30)]),
             ("Licuado de proteína con fresa", [("Agua natural", 250), ("Fresas", 120), ("Proteína whey concentrada", 30)]),
             ("Licuado de mango", [("Leche descremada", 250), ("Mango", 120)]), ("Licuado de papaya", [("Leche descremada", 250), ("Papaya", 150)]),
             ("Licuado verde (espinaca, piña y plátano)", [("Agua natural", 200), ("Espinaca", 30), ("Piña", 100), ("Plátano", 60)]),
             ("Licuado de soya con plátano", [("Leche de soya sin azúcar", 250), ("Plátano", 100)])]
_AVENA_TOP = {"plátano": ("Plátano", 60), "fresas": ("Fresas", 80), "manzana": ("Manzana", 80), "crema de cacahuate": ("Crema de cacahuate", 16),
              "nuez": ("Nuez", 10), "miel": ("Miel de abeja", 10), "proteína": ("Proteína whey concentrada", 30), "chía": ("Chía", 10)}


def generar(base):
    """base: lista de alimentos ya cargados (con 'nombre' y 'por100g'). Devuelve las combinaciones con el mismo formato."""
    idx = {a["nombre"]: a for a in base}

    def val(nombre):
        a = idx.get(nombre)
        return a["por100g"] if a else None

    def armar(nombre, cat, ingredientes, pieza):
        tot = {"kcal": 0.0, "prot": 0.0, "carb": 0.0, "grasa": 0.0, "fibra": 0.0}
        g = 0.0
        for ing, gr in ingredientes:
            v = val(ing)
            if not v or not gr:
                return None
            g += gr
            for k in tot:
                tot[k] += (v.get(k) or 0) * gr / 100
        if g <= 0:
            return None
        p100 = {k: round(v / g * 100, 1) for k, v in tot.items()}
        p100["kcal"] = round(p100["kcal"])
        return {"nombre": nombre, "categoria": cat, "smae": None, "por100g": p100, "porciones": [{"desc": f"{pieza} ({round(g)} g)", "g": round(g)}],
                "eq_smae_g": None, "fuente": "Calculado a partir de sus ingredientes (SMAE/USDA)", "ingredientes": [[i, round(x)] for i, x in ingredientes]}

    out, vistos = [], set()

    def agregar(x):
        if x and x["nombre"].lower() not in vistos:
            vistos.add(x["nombre"].lower())
            out.append(x)

    for P in PLATILLOS:
        for nb, bas in P["bases"].items():
            for rel in P["rellenos"]:
                if rel and rel not in _R:
                    continue
                if rel in _COMPUESTOS:
                    rel_ing = [(i, g * P["factor"]) for i, g in _COMPUESTOS[rel]]
                elif rel:
                    ing, g = _R[rel]
                    rel_ing = [(ing, g * P["factor"])]
                else:
                    rel_ing = []
                for ext in _extras_sets(P["extras"], P["max"]):
                    if rel and any(e in rel for e in ext):      # p. ej. «rajas con crema» + crema
                        continue
                    if any(rel not in P.get("solo_extras", {}).get(e, [rel]) for e in ext):
                        continue
                    if rel == "frijoles" and "frijoles" in ext:
                        continue
                    ings = list(bas) + rel_ing + [_E[e[0]][0:2] for e in P["incluye"]] + [_E[e] for e in ext]
                    nombre = _nombre(P, nb, rel, ext)
                    agregar(armar(nombre, "Platillos mexicanos (combinaciones)", ings, P["pieza"]))
    for np_, (pi, pg) in _BOWL_PROT.items():
        for nb, (bi, bg) in _BOWL_BASE.items():
            for ext in _extras_sets(["aguacate", "elote", "frijoles"], 1):
                if np_ == "frijoles" and "frijoles" in ext:
                    continue
                nombre = f"Bowl de {np_} con " + _y([nb] + list(ext))
                agregar(armar(nombre, "Bowls y ensaladas (combinaciones)", [(bi, bg), (pi, pg), ("Jitomate", 40)] + [_E[e] for e in ext], "1 bowl"))
    for n, ings in _LICUADOS:
        agregar(armar(n, "Licuados y avena (combinaciones)", ings, "1 vaso"))
    for base_av, liq in (("con leche", ("Leche descremada", 200)), ("con agua", ("Agua natural", 200))):
        for ext in _extras_sets(list(_AVENA_TOP), 2):
            nombre = f"Avena {base_av}" + (((" y " if len(ext) == 1 else ", ") if base_av == "con leche" else " y ") + _y(ext) if ext else "")
            agregar(armar(nombre, "Licuados y avena (combinaciones)", [("Avena en hojuelas cruda", 40), liq] + [_AVENA_TOP[e] for e in ext], "1 tazón"))
    for ext in _extras_sets(["Miel de abeja", "Plátano", "Fresas", "Crema de cacahuate"], 1):
        top = {"Miel de abeja": ("miel", 20), "Plátano": ("plátano", 60), "Fresas": ("fresas", 60), "Crema de cacahuate": ("crema de cacahuate", 16)}
        nombre = "Hot cakes (3)" + (" con " + top[ext[0]][0] if ext else "")
        agregar(armar(nombre, "Licuados y avena (combinaciones)", [("Hot cake (preparado)", 150)] + [(e, top[e][1]) for e in ext], "3 hot cakes"))
    return out


if __name__ == "__main__":
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import alimentos
    c = [a for a in alimentos.ALIMENTOS if "(combinaciones)" in a.get("categoria", "")]
    tortas = [a for a in c if a["nombre"].startswith("Torta")]
    nombres = [a["nombre"].lower() for a in c]
    assert len(nombres) == len(set(nombres)), "nombres repetidos"
    assert len(tortas) >= 40, len(tortas)
    t = next(a for a in c if a["nombre"] == "Torta de jamón con aguacate")
    assert 150 < t["por100g"]["kcal"] < 300, t
    for a in c:
        assert 20 < a["por100g"]["kcal"] < 450, a["nombre"]
    print(len(c), "combinaciones ·", len(tortas), "tortas · ejemplo:", t["nombre"], t["por100g"], t["porciones"])
