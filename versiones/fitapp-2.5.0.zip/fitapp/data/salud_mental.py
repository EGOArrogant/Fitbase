"""Bienestar y salud mental: cuestionarios validados de uso libre, interpretación SIN diagnóstico y protocolo de crisis (México).

Licencias:
- PHQ-9 y GAD-7: desarrollados por Spitzer, Williams y Kroenke con apoyo de Pfizer; «no se requiere permiso para
  reproducir, traducir, mostrar o distribuir» (phqscreeners.com). Versión en español de los PHQ Screeners.
- WHO-5: Índice de Bienestar de la OMS (Psychiatric Research Unit, Mental Health Centre North Zealand): uso libre citando la fuente.
- Se EXCLUYÓ el PSS-10 (Cohen): su autorización de uso gratuito es para fines no comerciales/académicos; no hay licencia
  clara para una app comercial. En su lugar se usa el registro diario de estrés (1–5), que NO es un instrumento validado.

Fuentes:
- Kroenke K, Spitzer RL, Williams JB (2001). The PHQ-9. J Gen Intern Med 16(9):606-613. doi:10.1046/j.1525-1497.2001.016009606.x
- Spitzer RL et al. (2006). A brief measure for assessing generalized anxiety disorder: the GAD-7. Arch Intern Med 166(10):1092-1097. doi:10.1001/archinte.166.10.1092
- Topp CW et al. (2015). The WHO-5 Well-Being Index: a systematic review. Psychother Psychosom 84(3):167-176. doi:10.1159/000376585
- García-Campayo J et al. (2010). Cultural adaptation into Spanish of the GAD-7. Health Qual Life Outcomes 8:8. doi:10.1186/1477-7525-8-8
- Arrieta J et al. (2017). Validity and utility of the PHQ-9 for detection of depression in primary care in rural Chiapas, Mexico. J Clin Psychol 73(9):1076-1090. doi:10.1002/jclp.22390
- Línea de la Vida (CONASAMA, Secretaría de Salud de México): 800 911 2000, 24 h.
NOTA: la redacción de los ítems sigue la versión en español de los PHQ Screeners; antes de publicar comercialmente,
compárala palabra por palabra con el PDF oficial de phqscreeners.com (marcado «por verificar literal»).
"""

FRECUENCIA_2SEM = [("Ningún día", 0), ("Varios días", 1), ("Más de la mitad de los días", 2), ("Casi todos los días", 3)]
WHO5_OPC = [("Todo el tiempo", 5), ("La mayor parte del tiempo", 4), ("Más de la mitad del tiempo", 3),
            ("Menos de la mitad del tiempo", 2), ("De vez en cuando", 1), ("Nunca", 0)]

INSTRUMENTOS = {
    "who5": {
        "nombre": "Índice de bienestar (WHO-5)", "que_mide": "Tu bienestar general en las últimas 2 semanas.", "dias": 14,
        "instrucciones": "Marca la opción que más se acerque a cómo te has sentido durante las últimas dos semanas.",
        "items": ["Me he sentido alegre y de buen humor.", "Me he sentido tranquilo(a) y relajado(a).", "Me he sentido activo(a) y con energía.",
                  "Me he despertado fresco(a) y descansado(a).", "Mi vida diaria ha estado llena de cosas que me interesan."],
        "opciones": WHO5_OPC, "fuente": "Topp 2015 · OMS (Psychiatric Research Unit, Hillerød)", "licencia": "Uso libre citando la fuente",
    },
    "phq9": {
        "nombre": "Estado de ánimo (PHQ-9)", "que_mide": "Síntomas de ánimo bajo en las últimas 2 semanas.", "dias": 14,
        "instrucciones": "Durante las últimas 2 semanas, ¿qué tan seguido has tenido molestias debido a los siguientes problemas?",
        "items": ["Poco interés o placer en hacer cosas.", "Sentirte decaído(a), deprimido(a) o sin esperanza.",
                  "Dificultad para quedarte dormido(a) o permanecer dormido(a), o dormir demasiado.", "Sentirte cansado(a) o con poca energía.",
                  "Poco apetito o comer en exceso.",
                  "Sentirte mal contigo mismo(a), o que eres un fracaso o que le has fallado a ti mismo(a) o a tu familia.",
                  "Dificultad para concentrarte en cosas como leer o ver la televisión.",
                  "Moverte o hablar tan lento que otras personas lo han notado, o lo contrario: estar tan inquieto(a) que te mueves mucho más de lo normal.",
                  "Pensamientos de que estarías mejor muerto(a) o de lastimarte de alguna manera."],
        "opciones": FRECUENCIA_2SEM, "fuente": "Kroenke 2001; validación en México: Arrieta 2017", "licencia": "Libre (PHQ Screeners, Pfizer)",
    },
    "gad7": {
        "nombre": "Ansiedad (GAD-7)", "que_mide": "Síntomas de ansiedad en las últimas 2 semanas.", "dias": 14,
        "instrucciones": "Durante las últimas 2 semanas, ¿con qué frecuencia te han molestado los siguientes problemas?",
        "items": ["Sentirte nervioso(a), ansioso(a) o con los nervios de punta.", "No poder dejar de preocuparte o no poder controlar la preocupación.",
                  "Preocuparte demasiado por diferentes cosas.", "Dificultad para relajarte.",
                  "Estar tan inquieto(a) que es difícil permanecer sentado(a) tranquilamente.", "Molestarte o irritarte fácilmente.",
                  "Sentir miedo, como si algo terrible fuera a pasar."],
        "opciones": FRECUENCIA_2SEM, "fuente": "Spitzer 2006; versión en español: García-Campayo 2010", "licencia": "Libre (PHQ Screeners, Pfizer)",
    },
}

CRISIS = {
    "titulo": "Si estás pensando en hacerte daño, no estás solo(a)",
    "texto": "Habla hoy mismo con alguien. Hay personas capacitadas para escucharte, a cualquier hora y sin costo.",
    "contactos": [("Línea de la Vida (gratis, 24 h, todo México)", "800 911 2000", "tel:8009112000"),
                  ("Emergencias", "911", "tel:911")],
    "extra": "Si sientes que puedes hacerte daño en este momento, ve al servicio de urgencias más cercano o pide a alguien de confianza que te acompañe.",
}
# Palabras que, escritas en notas o en el Coach IA, muestran el protocolo (lista prudente; no diagnostica)
PALABRAS_RIESGO = ["suicid", "quitarme la vida", "matarme", "no quiero vivir", "quiero morir", "hacerme daño", "lastimarme",
                   "acabar con todo", "mejor muerto", "mejor muerta", "cortarme"]


def riesgo_en_texto(texto):
    t = (texto or "").lower()
    return any(p in t for p in PALABRAS_RIESGO)


RECOMENDACIONES = {
    "base": [("Muévete", "La actividad física regular reduce síntomas de depresión y ansiedad; caminar 30 min al día ya cuenta.", "Singh 2023, BJSM (umbrella review)"),
             ("Duerme lo suficiente", "Procura 7–9 h con horario regular; el sueño y el ánimo se afectan mutuamente.", "Watson 2015; Windred 2024"),
             ("Respira lento", "5 min de respiración a ~6 respiraciones por minuto ayudan a calmar el sistema nervioso.", "Zaccaro 2018, Front Hum Neurosci"),
             ("Conéctate", "Habla con alguien de confianza esta semana; el apoyo social protege tu salud mental.", "Holt-Lunstad 2010, PLoS Med")],
    "ayuda": ("Busca apoyo profesional", "Tus respuestas sugieren que te vendría bien hablar con un psicólogo o médico. Puedes acudir a tu centro de salud, "
              "a tu seguro (IMSS/ISSSTE) o llamar a la Línea de la Vida (800 911 2000) para orientación.", "Recomendación clínica estándar (PHQ/GAD ≥10)"),
}


def _nivel(clave, puntaje):
    if clave == "who5":
        pct = puntaje * 4
        if pct <= 28:
            return "bajo", f"Tu bienestar está bajo ({pct}/100). Vale la pena hablar con un profesional de la salud.", True
        if pct <= 50:
            return "medio", f"Tu bienestar es moderado ({pct}/100). Pequeños cambios en sueño, movimiento y descanso pueden ayudarte.", False
        return "bueno", f"Tu bienestar es bueno ({pct}/100). ¡Sigue cuidándolo!", False
    cortes = [(4, "mínimo"), (9, "leve"), (14, "moderado"), (19, "moderadamente alto"), (99, "alto")] if clave == "phq9" else \
             [(4, "mínimo"), (9, "leve"), (14, "moderado"), (99, "alto")]
    nivel = next(n for lim, n in cortes if puntaje <= lim)
    tema = "ánimo bajo" if clave == "phq9" else "ansiedad"
    ayuda = puntaje >= 10
    txt = f"Tus respuestas muestran síntomas de {tema} en nivel {nivel} ({puntaje} puntos). Esto no es un diagnóstico."
    if ayuda:
        txt += " Te recomendamos platicarlo con un psicólogo o médico."
    return nivel, txt, ayuda


def calificar(clave, respuestas):
    """respuestas: lista de enteros (valor de cada opción). Devuelve dict con puntaje, nivel, texto, ayuda y crisis."""
    ins = INSTRUMENTOS[clave]
    if len(respuestas) != len(ins["items"]):
        raise ValueError("Faltan respuestas")
    validos = {v for _, v in ins["opciones"]}
    if any(r not in validos for r in respuestas):
        raise ValueError("Respuesta inválida")
    puntaje = sum(respuestas)
    nivel, texto, ayuda = _nivel(clave, puntaje)
    crisis = clave == "phq9" and respuestas[8] > 0
    return {"puntaje": puntaje, "pct": puntaje * 4 if clave == "who5" else None, "nivel": nivel, "texto": texto, "ayuda": ayuda, "crisis": crisis}


if __name__ == "__main__":
    assert calificar("phq9", [0] * 9)["nivel"] == "mínimo"
    assert calificar("phq9", [1] * 8 + [1])["crisis"] is True
    assert calificar("gad7", [2] * 7)["ayuda"] is True
    assert calificar("who5", [5] * 5)["pct"] == 100 and calificar("who5", [1] * 5)["nivel"] == "bajo"
    assert riesgo_en_texto("a veces quiero morir") and not riesgo_en_texto("me morí de risa")
    print("salud_mental.py OK")
