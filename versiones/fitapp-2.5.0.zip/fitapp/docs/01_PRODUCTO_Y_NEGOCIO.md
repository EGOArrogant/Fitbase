# 01 · Producto y negocio

## Qué es
FitBase es una plataforma de entrenamiento y nutrición **basada en evidencia científica** (ACSM, NSCA, ISSN, OMS, SMAE mexicano), en español de México, con inglés y francés. Combina:
- **Seguimiento diario:** peso, calorías, proteína, pasos, sueño, energía, entrenamiento, hábitos (checklist).
- **Entrenamiento:** programas por plantillas (Full body 3 días, Torso/Pierna 4, PPL 6, Casa 2), editor de programa, sesión del día con registro de series (peso × reps × RIR), e1RM, volumen por músculo, mapa muscular, 150 ejercicios con ficha, músculos resaltados, video y sustitutos por equipo.
- **Nutrición:** metas de energía y macros, dieta por equivalentes SMAE, diario de comidas, registro rápido (texto, voz, foto con IA, código de barras), puntaje nutricional del día, plan del día, menú semanal con lista de compras por pasillo, 312 recetas escaladas a tus calorías, alergias y tipos de dieta (keto, vegana, vegetariana, mediterránea, pescetariana, baja en carbohidratos, paleo, sin cerdo), suplementación personalizada.
- **Progreso:** tendencias, Fitness Score, mediciones ISAK, proporcionalidad, fotos, reportes mensuales, PDF profesionales.
- **Comunidad:** retos con niveles (tiers), retos de pago con premios, feedback.
- **Aprende:** 260 artículos con evidencia, mitos, guía de suplementos, calculadoras.
- **Coach:** panel con filtros inteligentes (nivel Novato…Élite, objetivo, estado), ficha por cliente (dieta, entreno, progreso, alergias), actividad en vivo, notificaciones, invitaciones por enlace y QR, expediente clínico, comentarios, retos para sus clientes.
- **Coach IA:** asistente con Claude (Anthropic) que usa los datos del cliente; modo básico por reglas si no hay clave.
- **Guía interactiva** paso a paso (web, celular y app móvil vía API) y manual consultable (`/guia`).

## Públicos
1. **Persona sin entrenador:** cuenta gratis completa; Pro para automatización.
2. **Entrenador (coach):** administra clientes; sus clientes reciben Pro incluido.
3. **Administrador (dueño):** todo desbloqueado; configura cobro, legal, idiomas, IA, diagnóstico y actualizaciones.

## Planes y precios (MXN, IVA incluido)
| Plan | Mensual | Anual | Qué incluye |
|---|---|---|---|
| Gratis | $0 | — | Registro, programa, nutrición, recetas, artículos, calculadoras, retos. |
| Pro | $99 | $799 | Automatización y análisis: menú semanal, plan del día, kcal automáticas, descargas PDF avanzadas, reporte mensual. |
| Coach Inicial | $0 | — | Hasta 3 clientes. |
| Coach 15 | $349 | $3,490 | Hasta 15 clientes (con Pro incluido). |
| Coach 40 | $699 | $6,990 | Hasta 40 clientes. |
| Coach 100 | $1,290 | $12,900 | Hasta 100 clientes · equipos y estudios. |

- Precios guardados en centavos en `pagos.CATALOGO`.
- El cobro solo se exige cuando el administrador activa el interruptor **«Activar cobro»** (Administración → Pagos). Mientras tanto todo está abierto.
- Cambiar de plan acredita los días restantes según el precio por día (`pagos.activar`).

## Formas de pago
- **Tarjeta (crédito/débito) y OXXO:** Stripe Checkout alojado (los datos de tarjeta nunca tocan el servidor). Meses sin intereses en planes anuales con tarjeta. OXXO de $10 a $10,000 MXN. Webhook con verificación HMAC.
- **Transferencia/depósito SPEI:** referencia de 7 dígitos; el cliente sube su comprobante; el administrador confirma en Administración → Pagos.
- Folios `FB-AAMM-XXXXX`, recibos PDF, datos CFDI (RFC, régimen, uso), «Mis pagos».

## Estrategia y marketing ya implementados
- Portada (`/`) con animaciones, sección de dispositivos con medidas reales (celular 440×956, tableta 1032×1376, laptop 1440×900) y una **demo en vivo** dentro de un iframe.
- No hay testimonios inventados: la portada usa capturas reales de la app.
