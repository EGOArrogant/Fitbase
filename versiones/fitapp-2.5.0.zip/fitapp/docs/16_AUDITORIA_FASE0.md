# FitBase · Auditoría integral (Fase 0)

Fecha: 28/11/2026 · Versión auditada: 2.4.0 · Método: lectura de código, pruebas automáticas con datos de la clienta de prueba, medición de rendimiento y revisión contra el «Prompt maestro de evolución integral».

> Regla de esta fase: **no se reestructuró nada**. Solo se midió, se probó y se documentó. Los cambios empiezan cuando apruebes el plan (sección 9).

---

## 1. Resumen ejecutivo

- **La base es sólida y conviene evolucionarla, no reescribirla.** El código tiene unas 11,400 líneas de Python, 173 rutas (22 de ellas para la app móvil), 24 tablas, 95 pantallas y 22 pruebas automáticas que pasan sin fallas. La tienda de alimentos tiene ~1,500 registros (más de 1,000 son combinaciones calculadas), 312 recetas, 150 ejercicios y 260 artículos.
- **Encontré 7 errores reales** en los puntos que pediste revisar. La sección 3 los detalla con su evidencia. Los más importantes:
  1. El **reporte diario** muestra los últimos 14 *registros* y no los últimos 14 *días*, así que oculta los días sin registro.
  2. **Cambiar de plantilla** borra sin aviso todo lo que personalizaste del programa.
  3. **Cambiar los días disponibles** no reorganiza el programa.
  4. El **sondeo inicial se sobrescribe**: no hay historial ni versión original intacta.
  5. Hay **46 alimentos básicos sin porción casera**: son los campos de porciones que salen vacíos.
- **Rendimiento:**
  - Con 1 usuario, las páginas responden en 3–25 ms; el diario tarda hasta 0.8 s la primera vez porque envía la tabla completa de alimentos.
  - Con 20 usuarios simultáneos baja a ~33 peticiones por segundo, con ~620 ms de espera. El cuello de botella es la arquitectura de **un solo proceso con SQLite**, no el lenguaje.
- **Sobre migrar de Python:** recomiendo **no migrar todavía**. La sección 5 explica por qué. Propongo una arquitectura modular por etapas y un **laboratorio experimental en Docker** (Go o TypeScript), separado de producción, para medir con datos antes de decidir. Docker, Go, Rust y Node ya están disponibles en este entorno.
- **Dependencias externas que requieren acción tuya:**
  - Publicar la app en internet con HTTPS.
  - Cuentas de desarrollador: Apple, Google, Meta/Instagram, TikTok, Garmin y Fitbit.
  - Proveedor de videollamadas.
  - Permiso de la Secretaría de Gobernación (SEGOB) para **sorteos** (Ley Federal de Juegos y Sorteos).
  - Revisión legal del expediente clínico de fisioterapia: NOM-004-SSA3-2012 y NOM-024-SSA3-2012.

---

## 2. Estado actual medido

| Aspecto | Medición |
|---|---|
| Código | ~11,400 líneas Python (app.py 5,574) · 95 plantillas · ~3,200 líneas CSS/JS |
| Rutas | 173 (22 de API `/api/v1` con token) |
| Base de datos | SQLite, 24 tablas, migraciones tolerantes en `db.py` |
| Dependencias | Flask 3.1, Waitress 3.0, Anthropic SDK 2.12, ReportLab 5.0, segno 1.6 (todas mantenidas, sin vulnerabilidades conocidas al momento) |
| Pruebas | Bot `diagnostico.py`: 22 pruebas (todas las páginas en 4 roles × 3 idiomas, 30+ PDF, API, flujos, cálculos, alergias, crisis) · 0 fallas |
| Latencia (1 usuario, mediana) | Inicio 7 ms · Diario 13 ms (máx. 799 ms) · Menú semanal 23 ms · Nutrición 8 ms · API 3 ms |
| Concurrencia (20 usuarios) | 32.7 peticiones/s · p50 622 ms · p95 691 ms · 94 MB de RAM |
| Alimentos | 1,497; solo 8 con calorías ≠ macros (>20 %), y 7 de ellos son bebidas alcohólicas (el alcohol aporta 7 kcal/g; es correcto) |

---

## 3. Errores encontrados (con evidencia)

| # | Módulo | Problema confirmado | Evidencia | Severidad |
|---|---|---|---|---|
| B1 | Reporte diario (Inicio) | Grafica los últimos 14 **registros**, no los últimos 14 **días**: con días sin registro, la gráfica junta fechas no consecutivas (aparecían el 23 y el 28 de noviembre juntos) y engaña sobre la constancia | `app.py` (dashboard): `rep = r["logs"][-14:]` | Alta |
| B2 | Reporte diario | Un día con solo una comida registrada (195 kcal) recibe puntaje 0, como si fuera un día malo. El puntaje parcial no se distingue de un día completo | Prueba de flujo | Media |
| B3 | Programa · plantillas | «Cambiar plantilla» reemplaza el programa completo sin vista previa, sin conservar ejercicios ni opción de deshacer | `programa_view`, acción `plantilla` | Alta |
| B4 | Programa · días | Cambiar los días disponibles en Evaluación no reorganiza el programa. Desde la 2.4.0 solo se explica la diferencia en una nota (`programa_nota`) | `evaluacion()` no toca `programa` | Alta |
| B5 | Sondeo | Se sobrescribe en cada edición (`p["sondeo"] = s`). No existe la versión original inmutable ni un historial | `sondeo()` | Alta (requisito explícito) |
| B6 | Porciones | 46 alimentos básicos solo tienen «100 g» como porción (aguacate, almendras, brócoli, cebolla, bistec…): los campos de porción casera salen vacíos | Auditoría de `alimentos.ALIMENTOS` | Media |
| B7 | Menú semanal | Algunas porciones se escalan ×1.75–2.0 (doble receta) y la cena reutiliza recetas tipo «comida». Las calorías cuadran (±1–8 %), pero el menú se ve poco natural | `datos_menu_semana` | Media |
| B8 | Diario | La primera carga envía ~1,500 alimentos en la página (hasta 0.8 s). Con más alimentos crecerá | Medición | Baja (rendimiento) |
| — | PDF | Los 19 PDF de usuario se generan sin errores. Los dos que requieren parámetros (calculadora y entrenar) responden bien con ellos. No hay campos vacíos ni «None» | Extracción de texto de cada PDF | Sin error |
| — | Calorías contra macros | Cuadran (ver sección 2) | Auditoría | Sin error |
| — | Conversión de piezas a gramos | Funciona para 17 casos comunes (2 huevos = 100 g, 3 tortillas = 90 g, medio aguacate = 68 g, 1 lata de atún = 100 g…) | Prueba con texto | Sin error |

---

## 4. Matriz de funcionalidades (prompt maestro contra lo que existe)

Estados: **✔ Existe** · **◐ Parcial** · **✘ Falta**. Prioridades: P1 (Fase 1, correcciones críticas) a P6.

| § | Funcionalidad solicitada | Estado actual | Falta o problema | Solución propuesta | Dependencias | Prior. | Riesgos |
|---|---|---|---|---|---|---|---|
| 3 | Ecosistema multideporte | ◐ Calentamiento, vuelta a la calma y recuperación para 8 disciplinas; registro genérico de sesiones (`sesiones_deporte`) | Sondeo, planificación, métricas, récords y progreso propios de cada disciplina | Ampliar `data/deportes.py` y `sesiones_deporte` con métricas por deporte (ritmo y zonas en running, rounds en boxeo, árbol de habilidades en calistenia…) | Sondeo v2 | P2 | Métricas mal elegidas: validar con literatura |
| 4 | Sondeo inteligente por nivel | ◐ Sondeo inicial y avanzado | Profundidad según nivel; zonas prioritarias, hidratación, horarios de comida, alimentos favoritos y rechazados; **versionado inmutable** (B5) | Tabla `sondeos` (versión, fecha, JSON, autor); la original nunca se edita | — | **P1** (versionado) · P2 (rediseño) | Migrar sondeos actuales como versión 1 |
| 5 | Nutrición avanzada | ◐ Metas, diario, equivalentes, menú, recetas, alergias, combinaciones | Micronutrientes, **hidratación**, favoritos adaptativos, registro digestivo, porciones (B6), menú (B7) | Ampliar base (sodio, potasio, hierro, calcio, vitaminas D/B12), tabla `hidratacion`, tabla `favoritos`, escalado de favoritos al cambiar la meta | Fuentes con licencia (USDA, SMAE) | **P1** (B6, B7, hidratación) · P2 | Datos de micronutrientes incompletos |
| 6 | Entrenamiento inteligente | ◐ Programa, plan inteligente, entrenar por músculos, sesión, sustitutos por equipo | Cambio de plantilla seguro (B3), reorganizar al cambiar días (B4), **conversión gimnasio ↔ casa**, descanso recomendado, «¿Qué entrenamos hoy?» | Motor de reorganización con vista previa (antes y después) + deshacer; convertidor por patrón de movimiento y músculo | Catálogo de equivalencias | **P1** | Reorganización que pierda ejercicios: probar con casos |
| 6 | Temporizadores | ✔ 2.4.0: cronómetro, intervalos, descansos y presets del coach | Descanso sugerido según ejercicio e intensidad y opción «aún no me recupero» | Ampliar el temporizador de sesión | — | P2 | — |
| 7 | Calentamiento y recuperación | ✔ 2.4.0, 8 deportes, 20 reglas | Integrar al final de cada registro de sesión; separar «general» de «clínico» | Ampliación | — | P2 | — |
| 8 | Sueño y bienestar | ✔ 2.4.0 (sueño, WHO-5, PHQ-9, GAD-7, crisis) | Fatiga y motivación, relación con rendimiento | Agregar campos y correlaciones | — | P2 | Privacidad (ya hay consentimiento) |
| 9 | Wearables | ✘ | Todo | Fase A: importar archivos (Apple Health, GPX, TCX, FIT). Fase B: OAuth (Fitbit, Garmin, Strava, Polar). Fase C: HealthKit y Health Connect en la app móvil | HTTPS público · registros de desarrollador · app móvil | P4 | Exactitud del dato; los APIs cambian |
| 10 | Fisioterapia | ✘ (solo PAR-Q+, condiciones y mapa de dolor) | Rol, expediente, evaluación, rangos de movimiento, sesiones, rehabilitación, síntomas | Módulo `fisio` con permisos por rol | Revisión legal (NOM-004, NOM-024) · verificar cédula | P3 | Responsabilidad clínica |
| 11 | Mediciones e ISAK | ◐ ISAK básico, somatotipo, proporcionalidad, guía ilustrada (22 sitios) | Niveles ISAK 1, 2 y 3, varias tomas, ETM, permisos por acreditación, figura femenina | Módulo `isak` con protocolo y acreditación capturada | Documentación oficial ISAK | P3 | No presentarlo como certificado sin acreditación real |
| 12 | Máquina por foto | ✘ (la visión con IA ya existe para comida) | Todo | Visión con Claude + catálogo propio + nivel de confianza + confirmación | Clave de Claude | P4 | Errores de identificación: pedir confirmación |
| 13 | 3D y biomecánica | ◐ Visor 3D y animaciones prototipo | Biomecánica validada y métricas de error | Mocap con licencia + estimación de pose con permiso + validación | Datos con licencia | P4–P5 | Derechos de autor (YouTube) |
| 14 | Zen | ◐ Respiración y relajación (2.4.0) | Yoga, pilates, programas, progreso, sesiones grupales | Ampliar Bienestar | Videos propios o con licencia | P2 | — |
| 15 | Marketing para profesionales | ✘ | Marca, paleta del logo, editor, plantillas, redes | Módulo `marca`: paleta con Pillow, editor SVG/Canvas, exportar PNG/PDF; redes por OAuth después | Meta App Review, TikTok audit | P5 | Reglas de publicidad en salud |
| 16 | Videollamadas | ✘ | Todo | Agenda + Jitsi (código abierto) o LiveKit | Servidor/TURN, HTTPS | P5 | Calidad de red; grabación con consentimiento |
| 17 | Licencias multiprofesional | ◐ Coach con cupos y alta guiada (2.4.0) | Roles de nutriólogo y fisioterapeuta, permisos granulares por expediente | Tabla `permisos_expediente` y roles | Precios | P3 | Fugas de datos entre profesionales |
| 18 | Importar archivos (ETL) | ✘ | Excel, CSV, PDF, XML, fotos con OCR | Flujo: subir → detectar → extraer con IA → vista previa → confirmar → historial | Clave de Claude | P4 | Sobrescrituras: siempre con confirmación |
| 19 | Offline / PWA | ◐ manifest.json, sin service worker | Caché offline, cola de sincronización | Service worker + IndexedDB + cola idempotente | — | P6 | Conflictos de datos |
| 20 | Logros y premios | ◐ Retos con niveles y retos de pago | Renombrar a «Logros», récords y distancias; premios y sorteos | Ampliar `retos.py` | **Permiso SEGOB para sorteos** | P5 | Legal; no premiar pérdida de peso extrema |
| 21 | Plan inteligente | ◐ Existe | Explicar qué hacer, qué evitar, por qué y con qué fuente; revisión profesional | Rediseño con secciones desplegables | — | P2 | — |
| 22 | Biblioteca de conocimiento | ◐ 260 artículos en código, con fuentes | Persistencia en base de datos, versionado, búsqueda, DOI estructurado | Tabla `articulos` con versiones | — | P2 | Derechos de autor (solo resúmenes propios) |
| 23 | Comparativa competitiva | ✘ | Forbes está bloqueado en esta sesión | Hacerla con sitios oficiales o con el dominio permitido | Permiso de red | P2 | — |
| 24 | Modelo de negocio | ◐ Gratis, Pro, Coach 15/40/100 | Licencias de nutriólogo, fisioterapeuta y multiprofesional; planes para empresas y gimnasios; análisis de costos y unidades | Documento de modelo con supuestos | Tus precios | P2 (documento) | — |
| 25 | Rediseño UX | ◐ Sistema visual y pulido | Menos saturación, secciones desplegables en las pantallas que señalaste | Rediseño por pantalla, empezando por las 9 citadas | — | **P1** (las 9) | Regresiones visuales: correr los agentes visuales |
| 26 | Seguridad | ◐ Consentimientos, ARCO, roles básicos, tokens con hash | Bitácora de auditoría, cifrado en reposo de datos clínicos, permisos granulares, plan de respaldo y recuperación | Tabla `auditoria`, cifrado de campos sensibles, respaldos programados | — | P3 (antes de clínico) | Datos clínicos sin bitácora |
| 27 | Arquitectura | ◐ Monolito Flask + SQLite, módulos nuevos ya separados en `modulos/` | Multi-proceso, PostgreSQL, cola de tareas, almacenamiento de archivos, observabilidad | Ver sección 5 | Hosting | P6 (P3 si se publica en internet) | Migrar datos sin pérdida |
| 31 | Laboratorio de migración | ✘ | Entorno experimental en Docker | Ver sección 5 | Autorización | P6 | — |

---

## 5. Arquitectura recomendada y evaluación de migración

### 5.1 Diagnóstico
- El límite actual (~33 peticiones por segundo con 20 usuarios) viene de **un proceso con 4 hilos y SQLite**. Una reescritura en Go o TypeScript con la misma base SQLite tendría el mismo techo de escritura.
- Para una plataforma SaaS con profesionales, empresas y gimnasios hacen falta:
  - varios procesos (gunicorn o waitress por proceso, detrás de Nginx o Caddy);
  - **PostgreSQL** para concurrencia de escritura, multiempresa y respaldos;
  - **cola de tareas** (Redis + RQ o Celery) para OCR, IA, sincronización de wearables, PDF pesados y correos;
  - **almacenamiento de objetos** (S3 o compatible) para fotos, comprobantes y plantillas;
  - **tiempo real** (WebSockets o SSE) para actividad en vivo y chat, hoy resueltos con consultas cada 5–20 s;
  - observabilidad (logs estructurados y métricas).

### 5.2 Evaluación de lenguajes

| Criterio | Python (Flask, actual) | TypeScript (NestJS / Fastify) | Go | Rust |
|---|---|---|---|---|
| Costo de reescribir 11,400 líneas + 95 plantillas | 0 | Alto (6–10 semanas) | Alto | Muy alto |
| Concurrencia por proceso | Media (GIL; se resuelve con más procesos) | Alta (event loop) | Muy alta | Muy alta |
| Ecosistema de IA, PDF, datos y OCR | Excelente | Bueno | Regular | Limitado |
| Compartir código con la app móvil (React Native) | No | **Sí** | No | No |
| Mantenimiento por un equipo pequeño | Fácil | Fácil | Medio | Difícil |
| Recomendación | **Mantener como núcleo** | Candidato para el servicio en tiempo real y la API móvil | Candidato para la sincronización masiva de wearables | Solo si hubiera cómputo intensivo (no es el caso) |

### 5.3 Decisión propuesta
1. **Mantener Python** y evolucionar a un **monolito modular**: separar `app.py` en blueprints (cuenta, entrenamiento, nutrición, coach, pagos, admin, API) siguiendo el patrón de `modulos/` ya iniciado en la 2.4.0.
2. **Al publicar en internet:** pasar a PostgreSQL, varios procesos, Redis y almacenamiento de objetos. Con eso se esperan más de 300 peticiones por segundo en un servidor modesto; hay que confirmarlo con el laboratorio.
3. **Laboratorio de migración (§31)**, en una rama `lab/backend-alterno` con Docker Compose:
   - mismo contrato `/api/v1`;
   - copia controlada de los datos de prueba;
   - pruebas de equivalencia contra Python;
   - carga con k6.
   - Candidatos: **TypeScript + Fastify** (por la app móvil) y **Go** (por la sincronización).
   - Se decide con números. La migración definitiva requiere tu autorización.

---

## 6. Modelo de datos propuesto (tablas nuevas, sin tocar las existentes)

| Tabla | Para qué | Fase |
|---|---|---|
| `sondeos` (id, usuario_id, version, datos JSON, autor_id, creado, motivo) | Sondeo inmutable y versionado (B5) | 1 |
| `programa_versiones` (id, usuario_id, programa JSON, motivo, creado, autor_id) | Deshacer cambios de plantilla o días (B3, B4) | 1 |
| `hidratacion` (usuario_id, fecha, ml, recipiente_ml, hora) | Vasos y litros configurables | 1 |
| `favoritos` (usuario_id, tipo alimento/receta/plan, ref, ajuste JSON, aprobado_por) | Favoritos adaptativos | 2 |
| `sintomas` (usuario_id, fecha, tipo, intensidad, relacion ejercicio/comida, nota) | Digestivo y síntomas | 2 |
| `metricas_deporte` (sesion_id, clave, valor, unidad) | Métricas propias de cada disciplina | 2 |
| `articulos` (id, version, titulo, resumen, doi, autor, fecha, fuente, nivel_evidencia, categoria) | Biblioteca persistente | 2 |
| `profesionales` (usuario_id, tipo, cedula, verificado, acreditacion_isak) · `permisos_expediente` | Licencias y permisos | 3 |
| `fisio_evaluaciones`, `fisio_sesiones`, `isak_tomas` (con ETM) | Clínico | 3 |
| `auditoria` (quién, qué, cuándo, expediente) | Bitácora de acceso a datos clínicos | 3 |
| `dispositivos`, `muestras_salud`, `actividades_externas` (fuente, unidad, calidad, hash para duplicados) | Wearables | 4 |
| `importaciones` (archivo, formato, vista previa, estado, autor) | Importación ETL | 4 |
| `marcas`, `plantillas_diseno`, `publicaciones` · `citas`, `salas` | Marketing y videollamadas | 5 |

---

## 7. Mapa de dependencias

- **Sondeo v2 →** planificación por deporte, nutrición personalizada y plan inteligente.
- **Versionado de programa →** conversión gimnasio↔casa y reorganización por días.
- **Roles y permisos + auditoría →** fisioterapia, ISAK por niveles, nutriólogo y empresas.
- **HTTPS público →** OAuth (wearables y redes sociales), webhooks de Stripe, videollamadas y enlaces de invitación externos.
- **App móvil →** HealthKit y Health Connect.
- **Cola de tareas →** importación con OCR, sincronización de wearables y publicación programada.

---

## 8. Costos estimados (por verificar con cotización; USD al mes salvo indicación)

| Concepto | Etapa inicial (hasta ~1,000 usuarios) | Crecimiento (~10,000) |
|---|---|---|
| Servidor (VPS 2–4 vCPU) | $12–40 | $80–200 |
| PostgreSQL administrado | $15–30 | $60–150 |
| Almacenamiento de objetos y CDN | $1–5 | $10–40 |
| Redis | $0–10 | $15–40 |
| IA (Claude: modelo económico para tareas mecánicas, principal para Coach y visión) | $5–40 (según uso) | $100–600 |
| Videollamadas (Jitsi propio o LiveKit) | $20–60 | $150–500 |
| Stripe | Comisión por transacción, según la tarifa vigente para México | — |
| Cuentas de desarrollador | Apple $99/año · Google $25 una vez · Meta, TikTok, Garmin y Fitbit sin costo, con revisión | — |
| Respaldos | $2–10 | $20–50 |

---

## 9. Riesgos principales

1. **Legal:**
   - expediente clínico de fisioterapia (NOM-004, NOM-024);
   - sorteos (permiso SEGOB);
   - publicidad en salud (COFEPRIS);
   - datos sensibles (LFPDPPP 2025).
2. **Responsabilidad:** las recomendaciones automáticas no deben verse como diagnóstico; los avisos ya existen y se reforzarán en el módulo clínico.
3. **Datos:** las migraciones de esquema deben ser reversibles, con respaldo previo, y la versión 1 del sondeo debe conservarse.
4. **Terceros:** los APIs de wearables y redes cambian y requieren revisión; nada se marcará como «funciona» sin conexión real.
5. **Alcance:** el prompt equivale a varios meses de trabajo. Se avanzará por fases y cada una se publicará probada.

---

## 10. Plan por fases (alineado a tu prompt)

| Fase | Contenido | Versión |
|---|---|---|
| **1 · Correcciones críticas** | Bugs B1–B8. Además: sondeo versionado; cambio de plantilla y de días con vista previa y deshacer; conversión gimnasio ↔ casa; porciones de los 46 alimentos; menú más natural (máx. ×1.5 y guarniciones); hidratación con vasos configurables; rediseño de «¿Qué entrenamos hoy?», «Mi plan inteligente» y reporte diario con secciones desplegables | 2.5.0 |
| 2 · Núcleo multidisciplinario | Sondeo v2 por nivel; métricas y planes por deporte; Zen completo; favoritos adaptativos; micronutrientes; síntomas; biblioteca persistente; comparativa | 2.6.0 |
| 3 · Profesionales | Roles de nutriólogo y fisioterapeuta, permisos, auditoría, ISAK 1-2-3, expediente clínico, licencias | 2.7.0 |
| 4 · Inteligencia y conectividad | Importación de archivos y OAuth de wearables, máquina por foto, importación ETL, biomecánica | 2.8.0 |
| 5 · Ecosistema | Marca y editor, redes, agenda y videollamadas, empresas, gimnasios, logros y premios | 2.9.0 |
| 6 · Offline y escala | PWA offline, PostgreSQL, varios procesos, laboratorio de migración con comparativa | 3.0.0 |

---

## 11. Decisiones que necesito de ti
1. **¿Apruebas empezar la Fase 1 (correcciones críticas)?** No requiere servicios externos.
2. Precios de las licencias de nutriólogo, fisioterapeuta y multiprofesional, y de los planes para empresas y gimnasios. Puedo proponer una tabla con análisis de margen si prefieres.
3. ¿Cuándo publicarás la app en internet? Desbloquea los puntos 9, 15, 16 y 27.
4. ¿Autorizas crear la rama del **laboratorio de migración** (Docker, sin tocar producción) en la Fase 6, o la quieres antes?
5. Sorteos: ¿se tramitará el permiso de SEGOB? Si no, los premios pueden ser por logros verificables, sin azar, lo que es más simple legalmente.
