# 09 · Pendientes, errores conocidos y hoja de ruta

## Para el dueño (no requieren programar)
1. **Administración → Legal:** capturar los datos del responsable. Mientras tanto, los avisos públicos muestran marcadores entre corchetes.
2. **Revisión legal** por un abogado (ver 07).
3. **Administración → Coach IA:** pegar la clave de Claude para activar el Coach completo, la foto de comida y las traducciones automáticas.
4. **Stripe:** crear la cuenta, capturar las claves y el webhook, y activar el cobro cuando la app esté publicada en internet con HTTPS.

## Errores o limitaciones conocidas
- **Traducciones:** quedan unas 3,400 frases sin traducir en EN y FR, sobre todo en ejercicios, recetas, artículos, textos legales y suplementación. Se resuelve en Administración → Idiomas con IA o agregándolas a `fuente_ui.txt`. Los textos legales en otros idiomas deben adaptarse a cada país, no solo traducirse.
- **Proteína en dietas muy restringidas** (por ejemplo vegetariana más alergia a lácteos y frutos secos): las recetas compatibles se quedan cortas, así que el menú sugiere un complemento. Mejora posible: más recetas altas en proteína vegetal y con huevo.
- **Recetas de dieta vegana:** cubren menos proteína. La dieta por equivalentes vegana llega a unos 90 de 110 g de proteína y lo muestra en la adecuación.
- **Diseño** (detalle en `reportes_qa/VISUAL2.md`):
  - a 360 px la cabecera de la portada ocupa dos filas; hay que ajustar `landing.css`;
  - `/recetas` a 360 px solo se revisó por trozos;
  - el medidor visual tiene falsos positivos conocidos, documentados en ese reporte.
- **`app.py` es muy grande** (unas 5,550 líneas). Una refactorización a *blueprints* (cuenta, coach, nutrición, entrenamiento, pagos, admin, API) facilitaría el mantenimiento.
- **Servidor local:** el acceso desde fuera de la red de la casa requiere publicar la app (VPS o PaaS con HTTPS). El webhook de Stripe y los enlaces de invitación lo necesitan.

## Hoja de ruta sugerida
1. **App móvil** (pedido del dueño) con React Native o Flutter sobre `/api/v1`. Ya existen login por token, hoy, registro, comidas (con interpretación), series, progreso, retos, notificaciones, guía, actividad y clientes del coach. Falta:
   - fotos de progreso y de comida por API;
   - notificaciones push;
   - pagos dentro de la app (cuidando las reglas de las tiendas de apps).
2. **Despliegue en la nube:** VPS con HTTPS (Caddy o Nginx) y `waitress`. SQLite basta al inicio; PostgreSQL si crece. Respaldos automáticos.
3. **Facturación CFDI** con un PAC (hoy solo se capturan los datos fiscales).
4. **Recordatorios por correo o WhatsApp** (con consentimiento de mercadotecnia o de servicio).
5. **Más contenido:** recetas altas en proteína vegetal, videos propios de ejercicios y artículos traducidos.
6. **Pruebas automáticas** (pytest) además del bot de diagnóstico.
