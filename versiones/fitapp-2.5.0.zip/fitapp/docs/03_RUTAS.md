# 03 · Rutas (URL → función en app.py)

Generado automáticamente desde `app.url_map` el 23/11/2026. Total: 158 rutas. Para ver el código de una ruta, busca `def <función>` en `app.py`.


## API móvil /api/v1 (18)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/api` | GET | `api_docs` |  |
| `/api/asistente` | POST | `asistente_api` |  |
| `/api/v1` | GET | `api_docs` |  |
| `/api/v1/coach/actividad` | GET | `api_coach_actividad` | Actividad de clientes. ?desde=<marca 'ahora' de la respuesta anterior> para recibir solo lo nuevo; ?cliente=<id>; ?tipo=<tipo>. |
| `/api/v1/coach/clientes` | GET | `api_coach_clientes` |  |
| `/api/v1/comidas` | GET,POST | `api_comidas` |  |
| `/api/v1/comidas/interpretar` | POST | `api_comidas_interpretar` |  |
| `/api/v1/ejercicios` | GET | `api_ejercicios` |  |
| `/api/v1/guia` | GET,POST | `api_guia` | Pasos del recorrido (cada uno con 'pantalla' para que la app lo muestre en su pantalla) y el manual por secciones. |
| `/api/v1/hoy` | GET | `api_hoy` |  |
| `/api/v1/login` | POST | `api_login` |  |
| `/api/v1/logout` | POST | `api_logout` |  |
| `/api/v1/notificaciones` | GET,POST | `api_notificaciones` | GET ?desde=<id> → nuevas (para sondear cada 15-30 s o al abrir la app). POST {"leidas": true} → marca todas como leídas. |
| `/api/v1/progreso` | GET | `api_progreso` |  |
| `/api/v1/registro` | POST | `api_registro` | Peso, pasos, sueño y si entrenó hoy (o en 'fecha'). Solo actualiza los campos enviados. |
| `/api/v1/retos` | GET | `api_retos` |  |
| `/api/v1/series` | POST | `api_series` |  |
| `/api/v1/yo` | GET | `api_yo` |  |

## Administración (9)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/actualizaciones` | GET,POST | `actualizaciones` |  |
| `/actualizaciones/reiniciar` | POST | `reiniciar` |  |
| `/admin` | GET,POST | `admin_panel` |  |
| `/admin/crear` | GET,POST | `admin_crear` | Primera configuración: crea (o promueve) la cuenta de administrador. Solo desde la computadora del servidor. |
| `/admin/diagnostico` | GET,POST | `admin_diagnostico` |  |
| `/admin/ia` | GET,POST | `admin_ia` |  |
| `/admin/idiomas` | GET,POST | `admin_idiomas` | Cobertura de traducciones y traducción con IA de las frases que aún faltan. |
| `/admin/legal` | GET,POST | `admin_legal` |  |
| `/admin/pagos` | GET,POST | `admin_pagos` |  |

## Aprende (6)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/articulos` | GET | `articulos` |  |
| `/articulos/<slug>` | GET | `articulo` |  |
| `/articulos/<slug>/pdf` | GET | `articulo_pdf` |  |
| `/calculadoras` | GET | `calculadoras` |  |
| `/calculadoras/pdf` | GET | `calculadora_pdf` |  |
| `/mitos` | GET | `mitos` |  |

## Comunidad (3)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/feedback` | GET,POST | `feedback_view` |  |
| `/retos` | GET | `retos_view` |  |
| `/retos/<int:rid>` | GET,POST | `reto_detalle` |  |

## Cuenta (5)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/ajustes` | GET,POST | `ajustes` |  |
| `/idioma/<lang>` | GET | `cambiar_idioma` |  |
| `/login` | GET,POST | `login` |  |
| `/registro` | GET,POST | `registro` |  |
| `/unirme/<token>` | GET,POST | `unirme` |  |

## Entrenador (coach) (27)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/coach` | GET | `coach` |  |
| `/coach/actividad` | GET | `coach_actividad` |  |
| `/coach/actividad.json` | GET | `coach_actividad_json` |  |
| `/coach/cliente/<int:cid>` | GET,POST | `coach_cliente` |  |
| `/coach/cliente/<int:cid>/diario` | GET,POST | `coach_diario` |  |
| `/coach/cliente/<int:cid>/dieta` | GET,POST | `coach_dieta` |  |
| `/coach/cliente/<int:cid>/dieta/pdf` | GET | `coach_dieta_pdf` |  |
| `/coach/cliente/<int:cid>/expediente` | GET | `coach_expediente` |  |
| `/coach/cliente/<int:cid>/expediente.pdf` | GET | `coach_expediente_pdf` |  |
| `/coach/cliente/<int:cid>/fotos` | GET,POST | `coach_fotos` |  |
| `/coach/cliente/<int:cid>/mediciones` | GET,POST | `coach_mediciones` |  |
| `/coach/cliente/<int:cid>/mediciones/pdf` | GET | `mediciones_pdf` |  |
| `/coach/cliente/<int:cid>/menu-semanal` | GET | `menu_semanal` |  |
| `/coach/cliente/<int:cid>/menu-semanal/pdf` | GET | `menu_semanal_pdf` |  |
| `/coach/cliente/<int:cid>/preferencias` | GET,POST | `preferencias_alimentarias` |  |
| `/coach/cliente/<int:cid>/puntaje` | GET | `coach_puntaje` |  |
| `/coach/cliente/<int:cid>/puntaje/pdf` | GET | `puntaje_pdf` |  |
| `/coach/cliente/<int:cid>/registrar` | GET | `registrar` |  |
| `/coach/cliente/<int:cid>/registrar/guardar` | POST | `registrar_guardar` |  |
| `/coach/cliente/<int:cid>/reporte-mensual.pdf` | GET | `reporte_mensual_pdf` | Pro: resumen del mes en lenguaje sencillo, para la persona, su médico o su entrenador. |
| `/coach/cliente/<int:cid>/sondeo-avanzado` | GET,POST | `coach_sondeo_avanzado` |  |
| `/coach/cliente/<int:cid>/sondeo-avanzado/pdf` | GET | `sondeo_avanzado_pdf` |  |
| `/coach/cliente/<int:cid>/suplementacion` | GET,POST | `suplementacion` |  |
| `/coach/feedback` | GET,POST | `coach_feedback` |  |
| `/coach/invitar` | GET,POST | `coach_invitar` |  |
| `/coach/reporte.pdf` | GET | `coach_reporte_pdf` |  |
| `/coach/retos` | GET,POST | `coach_retos` |  |

## Entrenamiento (13)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/cuerpo` | GET | `cuerpo` |  |
| `/ejercicios` | GET | `ejercicios` |  |
| `/ejercicios/<slug>` | GET | `ejercicio` |  |
| `/ejercicios/<slug>/pdf` | GET | `ejercicio_pdf` |  |
| `/ejercicios/<slug>/video` | POST | `ejercicio_video` |  |
| `/entrenar` | GET,POST | `entrenar` |  |
| `/entrenar/pdf` | GET | `entrenar_pdf` |  |
| `/mi-plan` | GET | `plan_inteligente` |  |
| `/mi-plan/pdf` | GET | `plan_inteligente_pdf` |  |
| `/programa` | GET,POST | `programa_view` |  |
| `/programa/pdf` | GET | `programa_pdf` |  |
| `/sesion` | GET,POST | `sesion_view` |  |
| `/sesion/pdf` | GET | `sesion_pdf` |  |

## General (25)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/` | GET | `inicio` |  |
| `/app` | GET | `dashboard` |  |
| `/asistente` | GET | `asistente_view` |  |
| `/aviso-simplificado` | GET | `aviso_simplificado` |  |
| `/consentimiento-informado` | GET | `consentimiento_informado` |  |
| `/demo` | GET | `demo` |  |
| `/descarga` | POST | `descarga` |  |
| `/dispositivos` | POST | `dispositivos` |  |
| `/emergencia` | GET | `emergencia` |  |
| `/evaluacion` | GET,POST | `evaluacion` |  |
| `/exportar.json` | GET | `exportar_json` |  |
| `/exportar/<tipo>.csv` | GET | `exportar_csv` |  |
| `/habitos` | GET,POST | `habitos` |  |
| `/mi-expediente` | GET | `mi_expediente` |  |
| `/mi-expediente.pdf` | GET | `mi_expediente_pdf` |  |
| `/mis-datos.pdf` | GET | `mis_datos_pdf` |  |
| `/pagos/stripe/webhook` | POST | `stripe_webhook` | Aviso de Stripe (opcional, requiere que el servidor sea accesible desde internet). Sin él, los pagos se confirman al regresar |
| `/planes` | GET | `planes` |  |
| `/reporte-mensual.pdf` | GET | `reporte_mensual_pdf` | Pro: resumen del mes en lenguaje sencillo, para la persona, su médico o su entrenador. |
| `/salir` | GET | `salir` |  |
| `/sondeo` | GET,POST | `sondeo` |  |
| `/sondeo-avanzado` | GET,POST | `sondeo_avanzado` |  |
| `/sondeo-avanzado/aplicar-programa` | POST | `aplicar_programa_nivel` |  |
| `/sondeo-avanzado/pdf` | GET | `sondeo_avanzado_pdf` |  |
| `/terminos-entrenadores` | GET | `terminos_entrenadores` |  |

## Legal y privacidad (4)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/consentimiento` | GET,POST | `consentimiento` |  |
| `/mi-privacidad` | GET,POST | `privacidad_centro` |  |
| `/privacidad` | GET | `privacidad` |  |
| `/terminos` | GET | `terminos` |  |

## Notificaciones y guía (6)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/guia` | GET | `guia` |  |
| `/guia/vista` | POST | `guia_vista` |  |
| `/notificaciones` | GET,POST | `notificaciones_view` |  |
| `/notificaciones/<int:nid>/abrir` | GET | `notificacion_abrir` |  |
| `/notificaciones/estado.json` | GET | `notificaciones_estado` |  |
| `/notificaciones/leer` | POST | `notificaciones_leer` |  |

## Nutrición (30)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/alimentos` | GET | `alimentos_view` |  |
| `/alimentos/pdf` | GET | `alimentos_pdf` |  |
| `/diario` | GET,POST | `diario` |  |
| `/diario/pdf` | GET | `diario_pdf` |  |
| `/dieta` | GET,POST | `dieta_propia` |  |
| `/dieta/pdf` | GET | `dieta_pdf` |  |
| `/menu-semanal` | GET | `menu_semanal` |  |
| `/menu-semanal/pdf` | GET | `menu_semanal_pdf` |  |
| `/nutricion` | GET | `nutricion` |  |
| `/nutricion/auto-kcal` | POST | `auto_kcal` |  |
| `/nutricion/pdf` | GET | `nutricion_pdf` |  |
| `/nutricion/preferencias` | GET,POST | `preferencias_alimentarias` |  |
| `/plan-del-dia` | GET | `plan_dia` |  |
| `/plan-del-dia/pdf` | GET | `plan_dia_pdf` |  |
| `/puntaje` | GET | `puntaje_nutricional` |  |
| `/puntaje/pdf` | GET | `puntaje_pdf` |  |
| `/recetas` | GET | `recetas` |  |
| `/recetas/<rid>` | GET | `receta` |  |
| `/recetas/<rid>/borrar` | POST | `receta_borrar` |  |
| `/recetas/<rid>/pdf` | GET | `receta_pdf` |  |
| `/recetas/nueva` | GET,POST | `receta_nueva` |  |
| `/recetas/pdf` | GET | `recetas_pdf` |  |
| `/registrar` | GET | `registrar` |  |
| `/registrar/codigo` | POST | `registrar_codigo` |  |
| `/registrar/foto` | POST | `registrar_foto` |  |
| `/registrar/guardar` | POST | `registrar_guardar` |  |
| `/registrar/interpretar` | POST | `registrar_interpretar` |  |
| `/registrar/producto` | POST | `registrar_producto` |  |
| `/suplementacion` | GET,POST | `suplementacion` |  |
| `/suplementos` | GET | `suplementos` |  |

## Pagos (5)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/mis-pagos` | GET | `mis_pagos` |  |
| `/pagar/<clave>` | GET,POST | `pagar` |  |
| `/pago/<folio>` | GET,POST | `pago_ver` |  |
| `/pago/<folio>/comprobante` | GET | `pago_comprobante` |  |
| `/pago/<folio>/recibo.pdf` | GET | `pago_recibo` |  |

## Progreso (7)

| URL | Métodos | Función | Descripción |
|---|---|---|---|
| `/descargas` | GET | `descargas` |  |
| `/fotos` | GET,POST | `fotos_progreso` |  |
| `/fotos/archivo/<int:fid>` | GET | `foto_archivo` |  |
| `/mediciones` | GET,POST | `mediciones` |  |
| `/mediciones/pdf` | GET | `mediciones_pdf` |  |
| `/progreso` | GET | `progreso` |  |
| `/progreso/pdf` | GET | `progreso_pdf` |  |
