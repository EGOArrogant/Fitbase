# 05 · Fórmulas y lógica de negocio (con fuentes)

Todo está en `calc.py` salvo que se indique otro módulo. Las fórmulas fueron auditadas contra el Excel del dueño del proyecto y su material de certificación (verificación previa, «Excel v3»).

## Composición corporal
- **IMC** = kg / m².
- **% de grasa (Marina de EE. UU.)**: Hodgdon y Beckett 1984, versión métrica (cuello, cintura y, en mujeres, cadera).
- Masa libre de grasa (MLG) = peso × (1 − % grasa). Si hay % medido (bioimpedancia, pliegues ISAK), tiene prioridad.
- ISAK, somatotipo (Heath-Carter) y proporcionalidad (Phantom de Ross y Wilson): `antropometria.py`, `proporcionalidad.py`.

## Energía
- **Gasto en reposo (GER)**, se elige la recomendada:
  - con MLG → **Cunningham 1980**: 500 + 22 × MLG (alternativas Katch-McArdle, Tinsley 2019 MLG);
  - sin MLG → **Mifflin-St Jeor 1990** (principiantes) o **ten Haaf y Weijs 2014** (entrenados);
  - también disponibles Harris-Benedict 1919 y 1984 y Tinsley 2019 (peso).
- **EAT** (ejercicio): (MET − 1) × kg × horas × sesiones / 7 (pesas MET 3.5 + cardio declarado).
- **NEAT** = GER × factor (15 % por defecto, editable).
- **Gasto total** = (GER + NEAT + EAT) / 0.9 (el 10 % restante es el efecto térmico de los alimentos).
- **Meta** = gasto total ± ritmo × peso × 7700 / 7 (ritmo en % del peso por semana: perder grasa 0.5–1 %, Helms 2014; ganar músculo 0.25–0.5 %, Iraki 2019). Redondeo a 10 kcal.
- **Disponibilidad energética** = (meta − EAT) / MLG: <30 riesgo, 30–45 adecuada, ≥45 óptima.
- **Gasto adaptativo** (≥14 pesos y ≥10 días con kcal): promedio kcal − Δtendencia × 7700 / días. `energia_ajustada` limita el ajuste a ±20 %.
- **Tendencia de peso**: media móvil exponencial, α = 0.1.

## Macros
- Proteína: 2.2 g/kg en déficit, 1.8 g/kg en otros casos (rango con evidencia 1.6–2.2 g/kg, Morton 2018).
- Grasa: el mayor entre 25 % de las kcal y 0.5 g/kg.
- Carbohidratos: el resto.
- Ajuste por tipo de dieta (`restricciones.ajustar_macros`): keto ≤30 g de carbohidratos; baja en carbohidratos ≤25 % de las kcal; mediterránea con grasa ≥33 %.
- Fibra 14 g/1000 kcal; agua 35 ml/kg.
- Mínimos del diario: proteína 1.6 g/kg; grasa mayor entre 0.5 g/kg y 20 % de las kcal.

## Dieta por equivalentes SMAE (`dieta.py`)
- Grupos y valores del SMAE (kcal, proteína, lípidos, hidratos por equivalente).
- `calcular_equivalentes(metas, kcal, restricciones)`:
  1. Base: verduras 5, frutas 2–3, leguminosas 1, leche 1–2 (se quitan según restricciones).
  2. Cereales según carbohidratos restantes.
  3. Proteína con alimentos de origen animal (AOA) muy bajo, bajo o moderado en grasa; en dieta vegana con leguminosas y oleaginosas.
  4. Grasas con o sin proteína (sin oleaginosas si hay alergia a frutos secos, cacahuate o sésamo).
  5. Cuadre de energía a ±3 %.
- Restricciones: sin lácteos (alergia, vegana, paleo); sin AOA (vegana); sin leguminosas (keto, paleo); pocos carbohidratos (keto, baja en carbohidratos).
- `avisos()` advierte si la dieta guardada choca con alergias o con el tipo de dieta.
- Reparto por tiempos de comida con preferencias por grupo y redondeo a 0.5 equivalentes.

## Recetas, plan del día y menú semanal (`app.py`)
- `candidatas(tipo, perfil, objetivo)` filtra por compatibilidad con alergias y dieta (`restricciones.revisar_receta`, con caché).
- `escalar(receta, kcal)`: factor 0.5–2.5 redondeado a 0.25.
- `elegir_receta()` prioriza recetas con proteína por kcal cercana a la meta y grasa que no la rebase, rotando para no repetir.
- `complemento_proteina()` sugiere un alimento compatible si el día queda corto de proteína por más de 10 g.

## Alergias y dietas (`restricciones.py`)
- Alérgenos: gluten, lácteos, huevo, pescado, mariscos, cacahuate, frutos secos, soya, sésamo, cada uno con su lista de palabras clave.
- La detección es por palabra completa con plural; hay excepciones: leche de soya, crema de cacahuate, galleta de arroz.
- Tipos de dieta: omnívora, mediterránea, vegetariana, vegana, pescetariana, keto (≤12 g de carbohidratos por porción), baja en carbohidratos (≤30 g), paleo, sin cerdo.

## Suplementación (`suplementacion.py`)
| Suplemento | Dosis o regla |
|---|---|
| Creatina | 3–5 g/día |
| Cafeína | 3 mg/kg, máx. 400 mg (2.5 mg/kg en menores, pero los menores quedan bloqueados) |
| Proteína | 0.35 g/kg por toma (20–40 g) |
| Beta-alanina, nitratos, carbohidratos, electrolitos | según deporte |
| Bicarbonato | 0.2–0.3 g/kg |
| Vitamina D | 1000–2000 UI (si no toma sol) |
| Omega-3 | 1–2 g (si no come pescado) |
| B12 | en veganos |

- Fuentes: ISSN, consenso del COI 2018, AIS (grupos A/B), EFSA, Health Canada.
- **Bloqueos generales:** menores de 18 años; embarazo o lactancia.
- **Bloqueos por suplemento:**
  - cafeína: cardiaco, ansiedad o hipertensión;
  - bicarbonato: hipertensión o enfermedad renal;
  - también hay reglas para anticoagulantes y medicamentos.
- Los bloqueos se validan **en el servidor** al agregar. Si después cambia la salud de la persona, los suplementos ya no permitidos se retiran del plan con aviso.

## Entrenamiento
- **e1RM** (Epley ajustado por RIR) = peso × (1 + (reps + RIR)/30).
- Progresión doble: sube la carga al llegar al tope del rango con el RIR objetivo.
- **Volumen efectivo** = series directas + 0.5 × indirectas. Rangos por nivel; frecuencia ≥2 por semana.
- **Plantillas:** Full body 3, Torso/Pierna 4, PPL 6, Casa 2. `plantilla_para(perfil)` elige según días, equipo y nivel, y explica en `programa_nota` cuando los días pedidos no coinciden.
- **Zonas de FC:** FCmáx de Tanaka (208 − 0.7 × edad) y método de reserva de Karvonen.
- **VO₂máx:** Rockport (Kline 1987) y Cooper 1968 (versión corregida).

## Puntajes
- **Puntaje del día** (calendario de Inicio, 0–100): promedio de entrenó, proteína ≥90 % de la meta, kcal ±10 % y sueño ≥7 h.
- **Fitness Score** (ponderado):
  - consistencia 25 %;
  - proteína 15 %, proporcional (100 al 90 % de la meta, 0 por debajo del 50 %);
  - calorías 15 % (100 dentro de ±10 %, 0 a partir de ±30 %);
  - sueño 15 %;
  - fuerza 15 %;
  - ritmo de peso 10 %;
  - checklist 5 %.
  - Etiquetas: ≥85 Excelente, ≥70 Bueno, ≥50 Regular, menos de 50 Por mejorar.
- **Puntaje nutricional** (`puntaje.py`): energía, proteína, fibra, grasas, ultraprocesados y azúcar. Incluye la sección «qué te falta».
- **Nivel del cliente** para los filtros del coach: Novato, Principiante, Intermedio, Avanzado o Élite, según experiencia, años y marcas (`nivel_cliente`).

## Validaciones
`calc.RANGOS`, aplicados en la web y en la API:

| Dato | Rango válido |
|---|---|
| Peso | 20–400 kg |
| Calorías | 0–15,000 kcal |
| Proteína | 0–600 g |
| Pasos | 0–150,000 |
| Sueño | 0–24 h |
| Energía | 1–5 |
| Estrés | 1–5 |
| Cintura | 30–250 cm |
| Presión arterial | sistólica 70–250, diastólica 40–150 mmHg |
| Frecuencia cardiaca en reposo | 30–130 lpm |
