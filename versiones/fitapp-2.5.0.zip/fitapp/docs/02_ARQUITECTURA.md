# 02 · Arquitectura

## Stack
| Capa | Tecnología |
|---|---|
| Servidor | Python 3.11+, Flask 3, `waitress` (producción local), puerto 5000 (`PORT`) |
| Base de datos | SQLite, archivo `fitapp.db` (ruta alternativa con `FITAPP_DB`, la usa el diagnóstico) |
| Plantillas | Jinja2 (`templates/`, todas extienden `base.html`) |
| Estilos | CSS propio con variables: `app.css` → `landing.css` (portada) → `pulido.css` (gana al final) |
| JS | Vanilla: `app.js` (tema, menú en riel, notificaciones, toasts, idioma), `guia.js` (tour), `landing.js` (dispositivos/demo), `visor3d.js` (three.js en `static/vendor/three`) |
| PDF | ReportLab (`pdf.py`), fuente DejaVu incluida en `static/fonts` |
| Gráficas | SVG generado en servidor (`charts.py`) + gráficas ReportLab en PDF |
| IA | SDK `anthropic` (Coach IA: `claude-opus-5-5`; tareas mecánicas: `claude-haiku-5-5` vía `FITAPP_MODELO_RAPIDO`) |
| QR | `segno` |
| Pagos | Stripe REST por `urllib` (sin SDK), SPEI manual |

## Mapa de archivos (raíz de `fitapp/`)
| Archivo | Líneas | Responsabilidad |
|---|---|---|
| `app.py` | ~5,550 | Todas las rutas, hooks (`before_request`, `after_request`), helpers de negocio, generación de PDF por pantalla, API `/api/v1`. |
| `db.py` | 371 | Conexión, `CREATE TABLE`, migraciones tolerantes, datos demo (`seed_demo`), `crear_usuario`, respaldos. |
| `calc.py` | 321 | Fórmulas: composición, energía (GER, NEAT, EAT), macros, e1RM, volumen, tendencia, gasto adaptativo, Fitness Score, calculadoras. |
| `dieta.py` | 210 | Dietocálculo por equivalentes SMAE: propuesta automática según metas y restricciones, reparto por tiempos, análisis, avisos. |
| `restricciones.py` | 159 | Alérgenos, grupos, tipos de dieta, revisión de recetas/alimentos, ajuste de macros por dieta. |
| `suplementacion.py` | 213 | Suplementos con evidencia, dosis personalizadas, bloqueos por edad/condición, preguntas de contexto. |
| `puntaje.py` | 162 | Puntaje nutricional diario (0–100) y «qué te falta». |
| `registro_rapido.py` | 452 | Interpretar texto/voz/foto/código de barras → alimentos con porciones; búsqueda difusa; IA con caché. |
| `alimentos.py` | 67 | Carga `data/alimentos_*.json` + ingredientes de recetas. |
| `pagos.py` | 262 | Catálogo, Stripe Checkout, webhook, OXXO, SPEI, folios, activación idempotente. |
| `legal.py` | 147 | Consentimientos con constancia (hash, IP, UA, versión), datos del responsable, ARCO con plazos en días hábiles. |
| `notificaciones.py` | 95 | Avisos a usuarios y feed de actividad para el coach (agrupa repeticiones). |
| `i18n.py` | 208 | Idiomas ES-419/EN/FR: compila `fuente_ui.txt`, traduce HTML renderizado, traducciones con IA. |
| `navegacion.py` | 150 | Íconos SVG y menú por categorías con color. |
| `guia.py` | 125 | Manual y pasos del tour guiado por rol. |
| `pdf.py` | 371 | Motor de PDF de marca: portada con banda degradada, encabezados, tablas cebra, gráficas, dona, barras de progreso, «Página X de Y». |
| `charts.py` | 135 | Gráficas SVG (línea, barras, radar, velas). |
| `antropometria.py`, `proporcionalidad.py` | 200 / 207 | ISAK, somatotipo, proporcionalidad, afinidades deportivas. |
| `seleccion.py`, `perfil_avanzado.py` | 173 / 172 | Selección de ejercicios por sondeo; sondeo avanzado por nivel. |
| `retos.py` | 102 | Retos, tiers, feedback. |
| `asistente.py` | 128 | Coach IA (Claude) y modo básico por reglas. |
| `actualizador.py` | 372 | Actualizaciones sin reinstalar desde GitHub (Releases o `version.json` en `main`), respaldo del código, restaurar. |
| `diagnostico.py` | 359 | Bot que prueba toda la app sobre una copia de la base. |
| `bodymap.py` | 31 | Mapa corporal SVG. |
| `data/` | — | `ejercicios.py` (150), `recetas.py` + `recetas_extra.json` (312), `articulos*.py` (260), `alimentos_a/b/c.json` (421), `contenido.py` (plantillas de programa, SMAE, PAR-Q…), `musculos.py`, `equipo.py`, `animaciones.py`, `cuerpo_svg.json`. |
| `idiomas/` | — | `fuente_ui.txt` (fuente de verdad), `en.json`/`fr.json` (compilados), `auto/` (traducciones con IA). |
| `templates/` | 86 | Pantallas (ver lista en `03_RUTAS.md`). |
| `static/` | — | CSS, JS, íconos PWA, `manifest.json`, imágenes de portada, cuerpo 3D, fuentes, three.js. |
| `scripts/` | — | `crear_paquete.py` (publicar versión), `crear_admin.py`, generadores del cuerpo. |
| Instaladores | — | `instalar_windows.bat`, `iniciar_windows.bat`, `instalar_mac_linux.sh`, `iniciar_mac_linux.sh`. |

## Flujo de una petición
1. `before_request`: carga `g.user`; idioma (`idioma_actual()`: cookie → perfil → Accept-Language); `_exigir_consentimiento` (si faltan consentimientos obligatorios de la versión vigente, redirige a `/consentimiento`; las cuentas demo `@fitapp.local` están exentas; la API responde 403); avisos del día (`_avisos_del_dia`: vencimiento de plan, clientes del coach sin registrar).
2. La vista calcula con `calcular(u)` → `(p, comp, en, mac)` y `resumen_usuario(u)` (logs, tendencia, score, alertas).
3. `after_request`:
   - `_actividad_auto`: convierte POST de clientes en actividad para su coach y POST del coach en notificaciones al cliente.
   - `_traducir`: si el idioma no es español, traduce el HTML (nodos de texto y atributos) y ciertos JSON.
   - `_cabeceras_seguridad`: `X-Frame-Options: SAMEORIGIN`, `nosniff`, `Referrer-Policy`.
4. Errores 500 se registran en la tabla `errores` y muestran `error500.html`.

## Planes y permisos
- `plan_de(u)` devuelve el plan efectivo: admin → todo; plan pagado vigente; entrenador sin pago → Coach Inicial (3); cliente con coach → Pro incluido; si no → Gratis.
- `pro_required` solo bloquea si `cobro_activo()`; responde 402 con `pro_requerido.html`.
- `cupo_clientes(coach)` limita invitaciones por plan.

## Idiomas
- Se escribe todo en español. `idiomas/fuente_ui.txt` tiene ~1,080 líneas `es ||| en ||| fr` y patrones `re:` con grupos `{1}`.
- `i18n.compilar_fuente()` genera `en.json`/`fr.json`; `traducir_html()` reemplaza texto después de renderizar; las cadenas JS usan `window.FB_T` y `FBtr()`.
- Administración → Idiomas muestra faltantes y traduce por lotes con IA (modelo económico).
- Cambio de idioma `/idioma/<code>`: protegido contra *prefetch* del navegador (cabecera `Sec-Purpose`), excluido de *speculation rules*; se guarda en el perfil.

## Actualizaciones automáticas
- `version.json` (versión, url del zip, sha256, notas) en la raíz del repo `main` + `versiones/fitapp-X.Y.Z.zip`.
- La app consulta Releases y, si no hay, `raw.githubusercontent.com/<repo>/main/version.json`. Verifica SHA-256, respalda el código actual en `respaldos/`, copia archivos y respeta los **protegidos** (`fitapp.db`, `pagos.json`, `comprobantes/`, `legal.json`, `ia.json`, `idiomas/auto/`, `diagnostico/`, `qa/salida/`, `.claude/`, etc.).
- Tras actualizar, corre el diagnóstico a los 120 s y avisa al admin si hay fallas.

## IA (Anthropic)
- Clave: variable `ANTHROPIC_API_KEY` o `ia.json` (capturada en Administración → Coach IA, solo localhost). Nunca en el código.
- `asistente.responder_ia`: `claude-opus-5-5`, `effort: low`, `max_tokens 2000`, prompt de sistema con `cache_control`, `fallbacks="default"` (beta server-side fallback), historial de 12 mensajes, manejo de `refusal`.
- `registro_rapido._ia`: salidas estructuradas (`json_schema`); texto con el modelo económico y caché en memoria; fotos con el modelo principal.
- `i18n.traducir_con_ia`: modelo económico, `max_tokens` según el lote.
- Consentimiento: el uso de IA requiere el consentimiento opcional «ia»; sin él, se bloquea la foto IA y el Coach IA.

## PDF
`pdf_resp(titulo, bloques, subtitulo)` con bloques: `h`, `p`, `kv`, `tabla`, `lista`, `metricas`, `nota`, `salto`, `grafica` (línea/barras), `dona`, `progreso`. Más de 30 PDF: plan, dieta, menú semanal, plan del día, receta, expediente, mediciones, progreso, reporte mensual, recibo de pago, mis datos, etc.

## API para la app móvil (`/api/v1`)
Autenticación: `POST /api/v1/login` devuelve un token; se envía como `Authorization: Bearer <token>` (se guarda solo su hash en `api_tokens`; el usuario puede revocarlo en Ajustes). Endpoints: `yo`, `hoy`, `comidas` (+ `interpretar`), `registro`, `series`, `progreso`, `retos`, `notificaciones`, `guia`, `coach/actividad`, `coach/clientes`, `ejercicios`, `logout`. Documentación visible en `/api`. Pensada para la futura app móvil.
