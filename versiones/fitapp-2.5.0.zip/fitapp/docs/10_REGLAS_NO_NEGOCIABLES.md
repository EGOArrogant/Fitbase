# 10 · Reglas no negociables

## Seguridad y privacidad
1. **Secretos fuera del chat y del código.** La clave de Anthropic, las claves de Stripe (secreta y del webhook) y el token de GitHub se capturan en Administración (solo desde localhost) o en variables de entorno. Nunca se piden por chat, nunca se imprimen en logs y nunca se suben al repositorio. Los archivos `ia.json`, `pagos.json`, `legal.json` y `actualizar.json` son locales y están protegidos por el actualizador.
2. **Tarjetas:** nunca se capturan en nuestro formulario. Solo se usa Stripe Checkout alojado; el webhook se verifica con HMAC y la activación es idempotente.
3. **Datos personales del dueño o de los usuarios:** no se incluyen en peticiones a servicios externos (búsquedas, APIs, cabeceras), salvo con autorización expresa.
4. **Administrador:** sin contraseña por defecto; la cuenta se crea o promueve solo desde la computadora del servidor.
5. **Comprobantes SPEI:** solo los ve el dueño del pedido o un administrador. Se validan la ruta y la extensión, y se sirven con `no-store`.
6. **Cabeceras:** `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff` y `Referrer-Policy`.
7. **API:** tokens guardados solo como hash; los revoca el usuario.

## Salud
8. Los bloqueos de seguridad se validan **en el servidor**:
   - suplementos para menores, embarazo, lactancia, hipertensión, enfermedad renal o cardiaca, ansiedad, anticoagulantes y medicamentos;
   - alergias en recetas, menús, dieta y sugerencias.
9. PAR-Q+, presión elevada y disponibilidad energética baja muestran alertas y recomiendan valoración médica.
10. La app es **educativa** y no sustituye la valoración médica ni nutricional. Ese texto ya está en los consentimientos y en los pies de los PDF.

## Legal y ética
11. Consentimiento expreso para datos de salud, con constancia. Respetar ARCO y la revocación.
12. No inventar testimonios, reseñas, usuarios ni cifras.
13. No copiar marcas, logotipos, textos, bases de datos ni diseños de terceros (TradeZella, MuscleWiki, Fitia, etc.). Solo se permite inspiración.
14. Las fórmulas y dosis deben tener una fuente citada. Si cambias una, actualiza la fuente.

## Calidad
15. Después de cada cambio, `python diagnostico.py` debe dar **0 fallas**.
16. El diseño debe verificarse en computadora (1440×900), tableta (1024×1366) y celular (390–440 px de ancho y 360 px en Android), en modo claro y oscuro. Ningún texto, contorno, tarjeta o tabla debe verse recortado, encimado o desbordado.
17. Todo texto nuevo de la interfaz se agrega también en `idiomas/fuente_ui.txt` (EN/FR).
18. La app debe seguir funcionando sin la clave de Claude (modo básico), sin Stripe (SPEI) y sin internet (salvo IA y actualizaciones).
19. Nunca se borran datos de usuarios en migraciones. Siempre hay respaldo de la base (`db.respaldar`) y del código antes de actualizar.

## Estilo
20. Interfaz en español de México, cálido, claro y sin tecnicismos para el usuario final. Para el dueño (no programador): explicar paso a paso y con lenguaje sencillo.
