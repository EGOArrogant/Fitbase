# 07 · Legal (México)

> Los documentos se redactaron con base en la ley vigente investigada, pero **deben ser revisados por un abogado** antes de operar comercialmente. No es posible excluir toda la responsabilidad: la responsabilidad por dolo no se puede renunciar (CCF art. 2106) y las cláusulas abusivas no surten efecto (LFPC art. 90).

## Marco considerado
- **LFPDPPP (DOF 20/03/2025)**, que abrogó la ley de 2010.
  - Los datos de salud son **datos personales sensibles** y requieren consentimiento **expreso y por escrito** (firma electrónica o un mecanismo de autenticación).
  - La autoridad es la **Secretaría Anticorrupción y Buen Gobierno**, antes INAI.
- **Derechos ARCO** y revocación: respuesta en **20 días hábiles** y ejecución en 15. El cálculo de días hábiles (`legal.sumar_habiles`) descuenta los días inhábiles de la LFT, art. 74.
- **Código de Comercio** arts. 89 y siguientes: validez del consentimiento electrónico. **NOM-151-SCFI-2016**: conservación de mensajes de datos.
- **LFPC**:
  - contratos de adhesión;
  - art. 56: revocación en 5 días hábiles;
  - art. 90: cláusulas abusivas.
- **Ley General de Salud:** orientación alimentaria. Los suplementos (art. 215, fr. V) no son medicamentos.
- **CCF** arts. 2106 y 2117: límites a la limitación de responsabilidad.

## Lo implementado (`legal.py`, plantillas `legal_*.html`)
- **Documentos públicos:**
  - Aviso de Privacidad Integral (13 secciones) y Aviso Simplificado;
  - Términos y Condiciones (13 cláusulas);
  - Consentimiento Informado de Actividad Física;
  - Términos para Entrenadores.
- **Consentimientos granulares** (`legal.CONSENTIMIENTOS`). Obligatorios:
  - `terminos`;
  - `datos_salud` (sensibles);
  - `actividad_fisica`.
- **Consentimientos opcionales:**
  - `compartir_coach`: necesario para vincularse con un coach;
  - `ia`: Coach IA y fotos de comida, procesadas por Anthropic en EE. UU. y sin usarse para entrenar modelos;
  - `mercadotecnia`.
- **Constancias inmutables** en la tabla `consentimientos`: tipo, otorgado, versión, huella SHA-256 del texto, IP, agente y fecha. Cada cambio es un registro nuevo.
- **Versión vigente** `VERSION = "2026.11"`. Al subirla, todos los usuarios vuelven a aceptar (`_exigir_consentimiento`).
- **Mayoría de edad:** el usuario declara si es mayor o menor. Los menores requieren la autorización de su tutor y tienen la suplementación de rendimiento bloqueada.
- **Centro de privacidad** (`/mi-privacidad`):
  - ver y revocar consentimientos;
  - descargar los datos;
  - solicitudes ARCO con folio `ARCO-AAMM-XXXXX` y vencimiento calculado.
- **Administración → Legal:**
  - capturar los datos del responsable: razón social, RFC, domicilio, correo de privacidad, teléfono, sitio, ciudad y área responsable;
  - gestionar las solicitudes ARCO.
- Mientras falten datos, los documentos muestran marcadores `[RFC]`, `[NOMBRE O RAZÓN SOCIAL]` y similares, y el diagnóstico lo avisa.
- **Suplementación:** al agregar el primer suplemento se registra una constancia propia (`suplementacion`).

## Pendiente para el dueño
1. Capturar los datos del responsable en Administración → Legal.
2. Revisión por un abogado especialista en datos personales y salud. Puntos clave:
   - la transferencia internacional a Anthropic y Stripe;
   - el rol del coach (encargado o tercero);
   - los retos de pago y sus premios;
   - la facturación CFDI.
3. Antes de lanzar fuera de México, adaptar los documentos a cada país: GDPR en Europa (francés) y leyes estatales en EE. UU. (inglés).
