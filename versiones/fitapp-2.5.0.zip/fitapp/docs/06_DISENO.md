# 06 · Diseño y sistema visual

## Principios que pidió el dueño
- Estética **coherente**, simplificada y con buen contraste. Las categorías se distinguen por **color e ícono minimalista**.
- Navegación fluida (objetivo 60 fps): transiciones solo con `transform` y `opacity`, *speculation rules* de prefetch con exclusiones, sin saltos de diseño.
- **Modo oscuro** como preferido. El **modo claro es de bajo brillo** para no cansar la vista: fondo `#E4E1DC`, superficie `#ECE9E3`, texto `#2B2833`. Dos veces se pidió bajar el brillo, así que no se debe volver a blancos puros.
- Menú lateral tipo **«riel»**: columna de íconos con menús flotantes por grupo, inspirado en la barra lateral de TradeZella sin copiarla. Se puede alternar con el menú expandido (`localStorage menuModo`).
- Debe verse perfecto en **computadora, tableta y celular**. Ningún texto, contorno, tarjeta o tabla puede verse recortado.

## Archivos
- `static/css/app.css` es la base, con bloques añadidos por versión: sistema visual 2.2, riel, modo claro de bajo brillo, estabilidad para textos largos en francés.
- `static/css/landing.css` es la portada: dispositivos con medidas reales y unidades `cqw`.
- `static/css/pulido.css` contiene los ajustes finos del agente diseñador. Se carga al final y **gana**. Las correcciones visuales nuevas van aquí, cada una numerada y con un comentario de causa.

## Colores por categoría (`--c-*`)

| Categoría | Variable | Claro | Oscuro |
|---|---|---|---|
| Hoy (gen) | `--c-gen` | `#6048D0` | `#A08CFF` |
| Entrenamiento | `--c-ent` | `#2563EB` | `#76A4FF` |
| Nutrición | `--c-nut` | `#11804F` | `#45D693` |
| Progreso / análisis | `--c-ana` | `#B45F06` | `#F6AE3B` |
| Coach | `--c-coa` | `#C8401F` | `#FF8466` |
| Comunidad | `--c-com` | `#B8327A` | `#F57AB8` |
| Aprende | `--c-her` | `#0E7C8B` | `#3CCFDF` |
| Cuenta | `--c-cue` | `#525A69` | `#AEB6C4` |

- `body[data-cat]` aplica el color de la sección activa y el título h1 lleva una insignia con su ícono.
- **Acento de marca:** `--accent` es `#6552CF` en claro y `#7B61FF`/`#8E75F0` en oscuro. Los PDF usan `#6048D0`.
- **Semánticos:** `--pos`, `--neg`, `--mid` y celdas `--cell-hi`, `--cell-lo` y `--cell-mid`. Los macros usan `--mac-c`, `--mac-p` y `--mac-g`.
- El tema se guarda en `localStorage tema` y en `data-theme` de `<html>`.

## Componentes principales
- **Tarjetas:** `tz-card`, `card`.
- **KPI:** `tz-kpi`, `card.kpi`.
- **Calendario de Inicio:** `tz-cal`, con `.dia`, `.dia.hoy` y `.dow`.
- **Chips y pills:** `chip` (con `.pos` y `.neg`), `pill`, `chip-r` (radio y casilla).
- **Alertas:** `alert` con las variantes `info`, `aviso`, `ok`, `riesgo` y `error`.
- **Tablas:** `tabla-wrap` se desliza en celular. Las tablas usan filas cebra y encabezado con acento.
- **Coach:** `cp-*`, que incluye tarjetas de cliente, filtros, KPI y alergias en pills.
- **Navegación en celular:** `tabbar`, la barra inferior con el botón «+» de registro rápido; `drawer`, el menú lateral; y `riel-fly`, los menús flotantes.
- **Notificaciones:** toasts y panel de campana (`notif-*`).
- **Guía:** overlay con foco (*spotlight*) en `guia.js`.
- **Íconos:** `ico("nombre")`. Son trazos SVG de `navegacion.ICONOS`, como escudo-hoja, balanza, documento o bicho.

## Reglas de pulido aprendidas (no repetir errores)
1. Un **contorno** (`outline`) por fuera de un elemento dentro de un contenedor con `overflow` se recorta. Pasó con el día de hoy en el calendario y se corrigió con `box-shadow: inset 0 0 0 2px var(--accent)` y aire en el contenedor. En casillas y tarjetas dentro de `.tabla-wrap` usa contornos hacia dentro.
2. Una clase genérica (por ejemplo `.pos` del ranking) puede contaminar otro componente (`.chip.pos`). Así se recortó el recuadro verde de «Puntaje». Hay que usar selectores específicos.
3. Textos largos en francés: evita `white-space: normal` en barras de navegación. Para eso se usan traducciones cortas, botones solo con ícono por debajo de 1560 px y un selector de idioma en celular.
4. Contraste: el texto debe tener una razón de al menos 4.5:1 en los dos temas. Los verdes y rojos del modo claro se oscurecieron.
5. Los KPI y montos no deben partirse en dos líneas (`white-space: nowrap`).
6. Las tablas anchas en celular deben indicar que hay más contenido al deslizar.
7. Con el **menú lateral expandido** el área de contenido pierde unos 130 px: prueba los dos modos (`localStorage menuModo` = `riel` / `expandido`) y anchos intermedios (1180–1440). Así se cortó la columna «Semana» del calendario. Se corrigió con `min-width:min(760px,100%)`.
8. QR: SVG con `viewBox` (`omitsize=True`), margen de 4 módulos y 168 px.

## Portada
- Animaciones al hacer scroll.
- Sección de dispositivos con marcos a escala real: celular 440×956, tableta 1032×1376 y laptop 1440×900.
- Demo en vivo dentro de un iframe escalado.
- Capturas reales en `static/landing/`.
