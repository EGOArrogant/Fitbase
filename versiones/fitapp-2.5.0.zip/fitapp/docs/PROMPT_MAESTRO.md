# PROMPT MAESTRO · Copia todo lo de abajo y pégalo en la otra IA

---

Vas a continuar el desarrollo de **FitBase**, una plataforma web de entrenamiento y nutrición basada en evidencia, en español de México (con inglés y francés), para dos públicos: **personas que entrenan solas** y **entrenadores (coaches) que administran clientes**. Hoy corre en una PC con Windows del dueño (instalador + acceso directo, servidor local `waitress` en el puerto 5000, accesible desde celulares de la misma red) y se planea una **app móvil** que consumirá la API `/api/v1`.

Te adjunto el código completo y una carpeta `docs/` con la arquitectura, rutas, base de datos, fórmulas, diseño, reglas legales, historial y pendientes. **Antes de proponer cambios, lee `docs/02_ARQUITECTURA.md` y `docs/10_REGLAS_NO_NEGOCIABLES.md`.**

## Stack y estructura
- **Python 3.11+ · Flask 3 · Jinja2 · SQLite** (un solo archivo `fitapp.db`) · `waitress` para servir · **ReportLab** para PDF · **segno** para QR · SDK oficial **`anthropic`** para el Coach IA.
- Front-end **sin frameworks**: HTML con Jinja, CSS propio con variables (tokens) para modo claro/oscuro, JavaScript vanilla (`static/js/app.js`, `guia.js`, `landing.js`). Gráficas SVG generadas en el servidor (`charts.py`).
- Un archivo principal grande, `app.py` (~5,500 líneas, todas las rutas), y módulos de dominio: `calc.py` (fórmulas), `dieta.py` (equivalentes SMAE), `restricciones.py` (alergias y tipos de dieta), `suplementacion.py`, `puntaje.py`, `registro_rapido.py`, `pagos.py`, `legal.py`, `notificaciones.py`, `i18n.py`, `navegacion.py`, `guia.py`, `pdf.py`, `actualizador.py`, `diagnostico.py`, `db.py`.
- Datos de contenido en `data/` (150 ejercicios, 312 recetas, 260 artículos, 421 alimentos con porciones caseras y equivalentes SMAE).
- Estilos: `static/css/app.css` (base), `static/css/landing.css` (portada), `static/css/pulido.css` (ajustes finos que ganan al final).

## Convenciones
- Todo el texto de la interfaz se escribe **en español (Latinoamérica)**. La traducción a EN/FR se hace **después de renderizar** (`i18n.traducir_html`) usando `idiomas/fuente_ui.txt` (formato `español ||| english ||| français`, y patrones `re:` con `{1}`). Si agregas texto nuevo, agrega su línea en `fuente_ui.txt`.
- El perfil del usuario es un JSON en `usuarios.perfil`; se lee con `perfil(u)` y se guarda con `guardar(u, "perfil", p)`. Los cálculos derivados salen de `calcular(u)` → `(p, comp, en, mac)`.
- Plantillas extienden `base.html`; los íconos se dibujan con `ico("nombre")` (SVG de trazo, `navegacion.ICONOS`). Cada categoría del menú tiene color (`--c-gen`, `--c-ent`, `--c-nut`, `--c-ana`, `--c-coa`, `--c-com`, `--c-her`, `--c-cue`).
- Decoradores: `@login_required`, `@pro_required` (solo si el administrador activó el cobro), `admin_required`. Toda acción POST relevante de un cliente genera actividad para su coach (`_actividad_auto` en `after_request`).
- Migraciones: en `db.py` (lista de `ALTER TABLE` tolerantes). Nunca borres columnas.
- Las versiones se publican con `python scripts/crear_paquete.py X.Y.Z "notas" --repo USUARIO/REPO` y se suben `version.json` + `versiones/fitapp-X.Y.Z.zip` a la rama `main`; la app se actualiza sola.
- Después de cualquier cambio corre `python diagnostico.py` (prueba todas las páginas, roles, idiomas, PDF, API y datos sobre una copia de la base) y debe dar **0 fallas**.

## Reglas que no puedes romper (resumen; detalle en docs/10)
1. **Nunca** pidas ni escribas claves (Anthropic, Stripe, GitHub) en el chat ni en el código; se capturan en Administración o en variables de entorno.
2. Los datos de tarjeta **nunca** pasan por nuestro servidor: se usa Stripe Checkout (página alojada por Stripe).
3. No copies marcas, bases de datos, textos ni diseños de otras apps (TradeZella, MuscleWiki, Fitia, etc.): solo inspiración.
4. No inventes testimonios, reseñas ni cifras de usuarios.
5. Datos de salud = datos personales sensibles (LFPDPPP 2025): requieren consentimiento expreso con constancia; respeta ARCO. Los textos legales deben revisarlos un abogado; no se puede excluir toda responsabilidad (CCF 2106, LFPC 90).
6. Seguridad en salud: bloqueos de suplementos para menores de 18, embarazo/lactancia, hipertensión, renal, cardiaco, anticoagulantes; aplicar los bloqueos **del lado del servidor**, no solo en pantalla. Respetar alergias en recetas, menús, dietas y sugerencias.
7. Cuenta de administrador: sin contraseña por defecto; solo se crea desde la computadora del servidor.
8. Mantén la app funcionando sin la clave de Claude (modo básico) y sin Stripe (transferencia SPEI manual).
9. Cuida el diseño en **computadora, tableta y celular** (y con el menú lateral en modo riel y expandido), en modo claro (de bajo brillo, no cansa la vista) y oscuro; ningún texto, contorno o tarjeta debe verse recortado o desbordado.
10. Responde y escribe la interfaz en español de México, claro y cálido; sin tecnicismos innecesarios para el usuario final.

## Cómo quiero que trabajes
- Antes de editar, lee el archivo y busca si ya existe una función parecida (el proyecto es grande y casi todo tiene ayuda: `candidatas()`, `escalar()`, `dieta_de()`, `plan_de()`, `notif.avisar()`, `legalmod.registrar()`…).
- Cambios pequeños y verificables; corre `diagnostico.py`; si tocas diseño, revisa a 1440×900, 1024×1366 y 390×844 en claro y oscuro.
- Al terminar, actualiza `LEEME.md` (sección «Novedades de la versión X») y `VERSION`.
- Dime con honestidad qué probaste, qué no y qué quedó pendiente.

---
