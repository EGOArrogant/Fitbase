# 08 · Historial del proyecto (qué se pidió, cómo se resolvió y por qué)

Cronología resumida de lo que pidió el dueño y de las decisiones tomadas. Sirve para que la siguiente IA no repita discusiones ya cerradas.

## Fase 1 · Investigación y bases
1. Investigación de evidencia en fitness: entrenamiento, nutrición, suplementos, recuperación, salud, hábitos y apps del mercado. Se entregó un informe.
2. Auditoría de las fórmulas del Excel del dueño y un Excel mejorado (v3) basado en evidencia.
3. Verificación del material de su certificación de entrenador personal (módulos 1–12, SMAE, dietocálculo) contra la evidencia. Se entregó un informe de discrepancias.

## Fase 2 · Plataforma web
4. Bocetos (9 pantallas y arquitectura), luego la app en Flask.
5. Mapa muscular anatómico de hombre y mujer, calculadoras (calorías con dial, macros con barras, 1RM con zonas), 200+ artículos con evidencia de los últimos 10 años, descargas en PDF.
6. Equipamiento por ejercicio con filtro, sondeo inicial con selección inteligente de ejercicios, ficha de ejercicio con músculos resaltados y video.
7. 300+ recetas, expediente del cliente para el coach con PDF de historial completo e íconos minimalistas.
8. Prototipos de animación 3D y cuerpo 3D continuo tipo escultura (three.js).
9. Planes: Gratis completo, Pro con beneficios, Coach para administrar clientes.
10. Mediciones básicas y avanzadas (ISAK), proporcionalidad.
11. Actualizaciones sin reinstalar e instalador definitivo para Windows.
12. Registro de comidas por foto, voz, texto y código de barras. Bases de alimentos inspiradas en Fitia, **sin copiar su base** (fuentes abiertas: USDA, SMAE).
13. Puntaje nutricional, «qué te falta» y plan semanal.
14. Sondeo avanzado, fotos de progreso y personalización por nivel.
15. Feedback, retos con tiers y retos de pago con premios.
16. Invitación del coach por enlace con ficha de ingreso; QR.
17. Cuenta de administrador desbloqueada: sin contraseña por defecto y creada solo desde localhost.

## Fase 3 · Versión 2.x
18. **Checkout:**
    - tarjeta y OXXO con Stripe hosted Checkout, SPEI manual con comprobante, CFDI, recibos, «Mis pagos» y Admin → Pagos;
    - precios definidos tras investigar el mercado mexicano (ver 01).
19. **Notificaciones y actividad en vivo para el coach.** **Guía de uso por pasos** en la web y en celular, que se puede volver a consultar (`/guia`).
20. **Portada con dispositivos de medidas reales** (iPhone tipo Pro Max, tableta y laptop) y demo en vivo.
21. **Panel del coach con filtros inteligentes:** nivel Novato…Élite, objetivo y estado. También muestra dietas, ejercicios y progreso.
22. **Idiomas ES-419, EN y FR.** Se corrigieron dos problemas:
    - el idioma cambiaba solo por el *prefetch* del navegador;
    - en francés se desacomodaba el diseño.
23. **GitHub como fuente de actualizaciones.** Releases quedó bloqueado para la sesión, así que se publica con `version.json` y `versiones/` en la rama `main`.
24. **Rediseño de contraste y categorías** con colores e íconos minimalistas («te dejo libre creatividad»).
25. **Barra lateral en «riel»** inspirada en TradeZella. El dueño aclaró que se refería a la barra lateral izquierda, **no** a las velas.
26. **Alergias y tipos de dieta** (keto, vegana, mediterránea…), **suplementación** con dosis personalizadas y bloqueos.
27. **Legal México:**
    - aviso de privacidad profesional, términos y consentimientos granulares con constancia;
    - ARCO;
    - Admin → Legal.
28. **Coach IA:** campo para la clave en Admin → Coach IA, sin comandos.
29. **Bot de diagnóstico** y registro de errores. **PDF profesionales** de marca con gráficas.
30. **Modo claro de bajo brillo:** se pidió dos veces porque «se siente muy fuerte en los ojos». Se corrigió también el QR mal posicionado.

## Fase 4 · Agentes y calidad (23/11/2026)
31. Se pidió **delegar** para optimizar el uso de Claude. Se crearon 4 agentes (ver 11_PRUEBAS_Y_AGENTES.md):
    - **qa-entrenador:** prueba todo como coach con una clienta de prueba y encontró 20 hallazgos;
    - **analista-ahorro:** propuso 12 ahorros de IA;
    - **corrector-web:** revisa idiomas, barras, navegación y celular;
    - **disenador-visual:** revisa recuadros recortados y coherencia, en web y celular.
32. **Versión 2.3.1:**
    - corrigió los 20 hallazgos (suplementos validados en el servidor, dieta personalizada por alergias, proteína del menú, diario, registro rápido, ficha de ingreso con presión y pulso, notificaciones, validaciones, pagos);
    - aplicó el pulido visual;
    - agregó ~270 traducciones;
    - redujo el costo de IA con Haiku en tareas mecánicas.
33. El dueño detectó que **el contorno del día de hoy en el calendario se veía cortado**. Se corrigió (pulido.css, regla 11), se endurecieron las reglas del agente diseñador y se lanzó una segunda revisión exhaustiva.
34. **Versión 2.3.2:**
    - segunda revisión visual con 20 correcciones;
    - la columna «Semana» del calendario ya cabe con el menú expandido;
    - sombras que indican tablas deslizables;
    - `segno` pasa a ser una dependencia obligatoria.
35. Se pidió esta **exportación avanzada** para continuar en otra IA.

## Decisiones cerradas (no reabrir sin que el dueño lo pida)
- Stack Flask + SQLite + JS vanilla, porque corre en la PC del dueño sin servicios externos. La app móvil consumirá `/api/v1`.
- Los precios y planes de la tabla en 01.
- Modo claro de bajo brillo; el oscuro es el preferido.
- Menú en riel inspirado en TradeZella, con su propio diseño.
- Publicar versiones vía archivos en `main` (Releases no está disponible).
- Sin testimonios inventados. Sin copiar marcas ni bases de datos de terceros.
