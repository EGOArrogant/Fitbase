# 11 · Pruebas y agentes

## Bot de diagnóstico (`diagnostico.py`)
Se corre con `python diagnostico.py` o desde Administración → Diagnóstico.

- **Cómo trabaja:** copia `fitapp.db` a `diagnostico/prueba.db`, fija `FITAPP_DB` e importa la app. Escribe los resultados en `diagnostico/ultimo.json` y `estado.json`.
- **Páginas:** todas las páginas GET para visitante, cliente, entrenador y admin, en ES, EN y FR, más las páginas con parámetros.
- **Contenido:** todos los PDF y el flujo de un usuario nuevo de principio a fin.
- **Idioma:** comprueba que persiste, incluido el *prefetch*, y revisa la cobertura de traducción.
- **API:** prueba sus endpoints.
- **Cálculos:**
  - la suma de macros de cada dieta;
  - las kcal de las recetas;
  - las alergias en recetas y candidatas;
  - las dosis de suplementos.
- **Datos:** enlaces rotos, y la consistencia de pedidos, ARCO, errores y datos legales.
- **Resultado esperado:** 0 fallas. Hoy hay 2 avisos conocidos: traducciones faltantes y datos legales sin capturar.

## Scripts de QA (`qa/`, Node + Playwright)
- `recorrido_entrenador.js`: el recorrido completo como coach con una clienta de prueba. Fases: datos, cliente, coach, admin, idioma, PDF y pantallas.
- `revisor_web.js`: revisa unas 570 páginas en 3 anchos, en claro y oscuro, en ES, EN y FR. Busca desbordes, barras, idioma y navegación.
- `revision_visual.js` y `revision_estados.js`: medición visual de recortes, contraste, alturas, encimados, imágenes y estados.
- `verificar_hoy.js` y `verificar_calendario.js`: verifican el contorno del día de hoy y que el calendario quepa en 14 anchos de pantalla con los dos modos de menú.
- `capturas_export.js`: genera las capturas de `capturas/`.
- Auxiliares: `resumir_revision.py`, `faltantes_clave.py`, `cap.js`, `explorar.js` y `depurar.js`.
- Cada agente usa su propia copia de la base y su propio puerto: 5000 QA, 5001 corrector y 5002 diseñador.

## Agentes (definiciones en `agentes/`, para Claude Code: `.claude/agents/*.md`)

| Agente | Modelo sugerido | Qué hace | Qué puede tocar |
|---|---|---|---|
| `qa-entrenador` | Sonnet | Prueba cada módulo como entrenador con una clienta de prueba y recopila discrepancias de textos, datos, PDF, registro, dieta y ejercicios. | Solo lee el código; escribe en `qa/`. |
| `analista-ahorro` | Haiku | Analiza de forma pasiva el uso de IA y propone ahorros. | Solo lectura; entrega un reporte. |
| `corrector-web` | Sonnet | Prueba la web (idioma, barras de datos, secciones, flechas y navegación, formularios, celular) y corrige. | Plantillas, CSS y `fuente_ui.txt`, con respaldo. Nada de textos legales, precios, dosis ni fórmulas. |
| `disenador-visual` | Sonnet | Revisión visual de diseñador: recortes (incluidos contornos), proporciones, alineación, espaciado, contraste y coherencia. Revisa web, tableta y celular, en claro y oscuro. | Solo `static/css/pulido.css` (y plantillas si es indispensable). |

En otra IA sin subagentes, se pueden usar como «roles»: pega el contenido del `.md` del agente como instrucción y pídele que ejecute esa revisión.

## Reportes del 23/11/2026 (`reportes_qa/`)
- `REPORTE.md`: 20 hallazgos del agente entrenador (2 críticos, 5 altos, 8 medios y 5 bajos). Todos se atendieron en la 2.3.1.
- `CORRECCIONES.md`: lo que corrigió el corrector web.
- `VISUAL.md` y `VISUAL2.md`: primera y segunda pasada del diseñador visual. En `antes_y_despues/` están los 19 pares ampliados de la segunda pasada.
- `ahorro-2026-11-23.md`: los 12 ahorros de IA. Se aplicaron el modelo económico, `max_tokens`, la caché y la prueba de conexión barata.
