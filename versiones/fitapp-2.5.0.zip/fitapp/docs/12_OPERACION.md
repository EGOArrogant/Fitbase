# 12 · Operación: instalar, correr, publicar y configurar

## Instalar y correr
- **Windows:** descomprimir `fitapp.zip`, doble clic en `instalar_windows.bat`. El instalador crea el entorno, instala las dependencias de `requirements.txt` y deja un acceso directo en el escritorio. El día a día es con `iniciar_windows.bat`.
- **Mac/Linux:** `instalar_mac_linux.sh` y después `iniciar_mac_linux.sh`.
- **Manual:**

  ```bash
  python -m venv .venv && . .venv/bin/activate
  pip install -r requirements.txt
  python app.py   # http://localhost:5000
  ```

- **Celular en la misma red:** abrir `http://IP-de-la-PC:5000`. Se puede instalar como PWA (`static/manifest.json`).
- **Cuentas demo** (`@fitapp.local`, contraseña `demo1234`): coach, demo y clientes de ejemplo. Están exentas del consentimiento.
- **Crear el administrador:** desde la misma PC, en `/admin/crear` o con `python scripts/crear_admin.py`.

## Variables de entorno

| Variable | Uso |
|---|---|
| `PORT` | Puerto (por defecto 5000) |
| `FITAPP_DB` | Ruta alternativa de la base (pruebas y diagnóstico) |
| `ANTHROPIC_API_KEY` | Clave de Claude (alternativa a Admin → Coach IA) |
| `FITAPP_MODELO` | Modelo del Coach IA y de fotos (por defecto `claude-opus-5-5`) |
| `FITAPP_MODELO_RAPIDO` | Modelo económico (por defecto `claude-haiku-5-5`) |
| `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` | Alternativa a Admin → Pagos |
| `FITAPP_UPDATE_URL` | Forzar la URL del `version.json` |

## Publicar una versión nueva
1. Actualizar `LEEME.md` (sección «Novedades») y probar con `python diagnostico.py`.
2. Crear el paquete:

   ```bash
   python scripts/crear_paquete.py 2.3.2 "Qué trae" --repo USUARIO/REPO
   ```

   Genera `dist/fitapp-2.3.2.zip` y `dist/version.json` con SHA-256.
3. En el repositorio de GitHub (rama `main`), copiar `dist/version.json` a la raíz y `dist/fitapp-2.3.2.zip` a `versiones/`. Después commit y push.
4. Cada PC con el repositorio configurado en **Actualizaciones** se actualiza sola, o con el botón «Buscar e instalar». Antes de actualizar respalda el código en `respaldos/` y se puede restaurar la versión anterior.
5. El repositorio actual del dueño publica en `https://raw.githubusercontent.com/<repo>/main/version.json`. El nombre del repositorio está en LEEME.md.

## Configurar el cobro (Administración → Pagos)
1. Capturar la clave secreta de Stripe (o usar `STRIPE_SECRET_KEY`) y el secreto del webhook. El webhook apunta a `/pagos/stripe/webhook` (requiere la app publicada en internet con HTTPS).
2. Capturar los datos bancarios para SPEI (CLABE y beneficiario).
3. Activar el interruptor **«Activar cobro»**. Mientras esté apagado, todo está abierto.

## Datos legales (Administración → Legal)
Capturar la razón social, RFC, domicilio, correo de privacidad, teléfono, sitio y ciudad. Revisar los textos con un abogado.

## Idiomas (Administración → Idiomas)
Muestra las frases faltantes por idioma y las traduce por lotes con IA (requiere la clave de Claude). Las traducciones automáticas se guardan en `idiomas/auto/`. Las manuales van en `idiomas/fuente_ui.txt`.

## Diagnóstico (Administración → Diagnóstico)
Ejecuta `diagnostico.py` en segundo plano. Muestra las pruebas, fallas, avisos y los últimos errores 500. También corre solo después de cada actualización.
