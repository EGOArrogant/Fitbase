# 04 · Base de datos (SQLite)

Archivo `fitapp.db` junto a la app (o la ruta de `FITAPP_DB`). Esquema completo en `esquema.sql`. Las migraciones están en `db.py` (lista de `ALTER TABLE` que ignora errores si la columna ya existe). **Nunca borres columnas**; agrega nuevas.

## Tablas

### `actividad`
Feed de actividad de clientes para su coach (agrupa repeticiones con `n`).

Columnas: `id` INTEGER, `actor_id` INTEGER, `coach_id` INTEGER, `tipo` TEXT, `texto` TEXT, `url` TEXT, `detalle` TEXT, `n` INTEGER, `creado` TEXT

### `api_tokens`
Tokens de la app móvil (solo hash).

Columnas: `id` INTEGER, `hash` TEXT, `usuario_id` INTEGER, `dispositivo` TEXT, `creado` TEXT, `ultimo_uso` TEXT

### `comentarios`


Columnas: `id` INTEGER, `usuario_id` INTEGER, `autor_id` INTEGER, `texto` TEXT, `creado` TEXT

### `consentimientos`
Constancias legales inmutables (tipo, otorgado, versión, huella, IP, agente, fecha).

Columnas: `id` INTEGER, `usuario_id` INTEGER, `tipo` TEXT, `otorgado` INTEGER, `version` TEXT, `huella` TEXT, `ip` TEXT, `agente` TEXT, `detalle` TEXT, `creado` TEXT

### `diario_comidas`
Diario de comidas con macros por alimento; se sincroniza a `registros`.

Columnas: `id` INTEGER, `usuario_id` INTEGER, `fecha` TEXT, `tiempo` TEXT, `alimento` TEXT, `porcion` TEXT, `gramos` REAL, `kcal` REAL, `prot` REAL, `carb` REAL, `grasa` REAL, `fibra` REAL, `alimento_id` INTEGER, `fuente` TEXT

### `errores`
Errores 500 registrados para el diagnóstico.

Columnas: `id` INTEGER, `ruta` TEXT, `metodo` TEXT, `usuario_id` INTEGER, `tipo` TEXT, `mensaje` TEXT, `traza` TEXT, `veces` INTEGER, `creado` TEXT, `ultimo` TEXT, `resuelto` INTEGER

### `feedback`
Opiniones de usuarios y respuesta del coach/admin.

Columnas: `id` INTEGER, `usuario_id` INTEGER, `tipo` TEXT, `area` TEXT, `calificacion` INTEGER, `texto` TEXT, `publico` INTEGER, `estado` TEXT, `respuesta` TEXT, `respondio_id` INTEGER, `creado` TEXT, `actualizado` TEXT

### `feedback_votos`


Columnas: `feedback_id` INTEGER, `usuario_id` INTEGER

### `fotos`


Columnas: `id` INTEGER, `usuario_id` INTEGER, `autor_id` INTEGER, `fecha` TEXT, `angulo` TEXT, `archivo` TEXT, `peso` REAL, `nota` TEXT, `creado` TEXT

### `invitaciones`
Enlaces de invitación de coaches.

Columnas: `id` INTEGER, `token` TEXT, `coach_id` INTEGER, `nombre` TEXT, `contacto` TEXT, `nota` TEXT, `max_usos` INTEGER, `usos` INTEGER, `expira` TEXT, `cliente_id` INTEGER, `creado` TEXT, `ultimo_uso` TEXT

### `mediciones`


Columnas: `id` INTEGER, `usuario_id` INTEGER, `autor_id` INTEGER, `fecha` TEXT, `tipo` TEXT, `datos` TEXT, `creado` TEXT

### `notificaciones`
Avisos por usuario (tipo, título, texto, url, actor, leída).

Columnas: `id` INTEGER, `usuario_id` INTEGER, `tipo` TEXT, `titulo` TEXT, `texto` TEXT, `url` TEXT, `actor_id` INTEGER, `leida` INTEGER, `creado` TEXT

### `pedidos`
Pedidos de pago (folio, plan, periodo, monto, método, estado, Stripe, comprobante SPEI, datos de factura).

Columnas: `id` INTEGER, `folio` TEXT, `usuario_id` INTEGER, `plan` TEXT, `periodo` TEXT, `monto` INTEGER, `moneda` TEXT, `metodo` TEXT, `estado` TEXT, `nombre` TEXT, `email` TEXT, `telefono` TEXT, `factura` TEXT, `stripe_sesion` TEXT, `referencia` TEXT, `comprobante` TEXT, `nota_admin` TEXT, `creado` TEXT, `pagado_en` TEXT, `vigencia_hasta` TEXT

### `productos`


Columnas: `codigo` TEXT, `nombre` TEXT, `marca` TEXT, `kcal` REAL, `prot` REAL, `carb` REAL, `grasa` REAL, `fibra` REAL, `azucar` REAL, `sodio` REAL, `porcion_g` REAL, `porcion_desc` TEXT, `fuente` TEXT, `autor_id` INTEGER, `creado` TEXT

### `recetas_usuario`


Columnas: `id` INTEGER, `autor_id` INTEGER, `nombre` TEXT, `tipo` TEXT, `tags` TEXT, `ing` TEXT, `pasos` TEXT, `minutos` INTEGER, `creado` TEXT

### `registros`
Registro diario por usuario y fecha: peso, kcal, proteína, pasos, sueño, entrenó, energía (1–5), cintura, notas.

Columnas: `usuario_id` INTEGER, `fecha` TEXT, `peso` REAL, `kcal` REAL, `proteina` REAL, `pasos` INTEGER, `sueno` REAL, `entreno` TEXT, `energia` INTEGER, `cintura` REAL, `notas` TEXT, `etiquetas` TEXT

### `retos`
Retos (de coach o globales), con tiers y cuota opcional.

Columnas: `id` INTEGER, `titulo` TEXT, `descripcion` TEXT, `tipo` TEXT, `meta` REAL, `inicio` TEXT, `fin` TEXT, `puntos` INTEGER, `nivel` TEXT, `cuota` REAL, `premios` TEXT, `cupo` INTEGER, `validar` INTEGER, `tier_min` TEXT, `creador_id` INTEGER, `activo` INTEGER, `creado` TEXT

### `retos_inscritos`


Columnas: `reto_id` INTEGER, `usuario_id` INTEGER, `inscrito` TEXT, `pagado` INTEGER, `pago_ref` TEXT, `monto` REAL, `progreso_manual` REAL, `completado` TEXT, `validado` INTEGER, `puntos` INTEGER, `lugar` INTEGER

### `series`
Series de entrenamiento (ejercicio, peso, reps, RIR, fecha).

Columnas: `id` INTEGER, `usuario_id` INTEGER, `fecha` TEXT, `ejercicio` TEXT, `serie` INTEGER, `peso` REAL, `reps` INTEGER, `rir` REAL, `nota` TEXT

### `solicitudes_arco`
Solicitudes de derechos ARCO con folio y vencimiento en días hábiles.

Columnas: `id` INTEGER, `folio` TEXT, `usuario_id` INTEGER, `nombre` TEXT, `email` TEXT, `tipo` TEXT, `descripcion` TEXT, `estado` TEXT, `respuesta` TEXT, `creado` TEXT, `vence` TEXT, `respondido` TEXT

### `usuarios`
Cuentas (cliente, entrenador, admin). JSON en `perfil`, `programa`, `checklist`, `smae` (dieta por equivalentes). Plan pagado en `plan`/`plan_vence`.

Columnas: `id` INTEGER, `email` TEXT, `nombre` TEXT, `password` TEXT, `rol` TEXT, `coach_id` INTEGER, `codigo_coach` TEXT, `perfil` TEXT, `programa` TEXT, `checklist` TEXT, `smae` TEXT, `creado` TEXT, `es_admin` INTEGER, `plan` TEXT, `plan_vence` TEXT, `plan_nota` TEXT, `activo` INTEGER, `ultimo_acceso` TEXT, `guia_vista` TEXT

## El JSON `usuarios.perfil`
Se lee con `perfil(u)` y se guarda con `guardar(u, 'perfil', p)`. Claves base (de `db.perfil_base`):

```json
{
 "sexo": "Hombre",
 "edad": 24,
 "peso": 90.0,
 "talla": 174.0,
 "nivel": "Intermedio",
 "objetivo": "Perder grasa",
 "ritmo": 0.5,
 "actividad": "Moderado",
 "dias": 4,
 "duracion": 60,
 "comidas": 4,
 "cuello": 40.0,
 "cintura": 92.0,
 "cadera": null,
 "grasa_medida": null,
 "neat": 0.15,
 "cardio_min": 30,
 "cardio_ses": 3,
 "cardio_met": 3.5,
 "ecuacion": "",
 "parq": [
  false,
  false,
  false,
  false,
  false,
  false,
  false
 ],
 "condiciones": [],
 "preferencias": [],
 "equipo": "Gimnasio completo",
 "inicio": "2026-11-23",
 "bienestar": false
}
```

Claves que se agregan con el uso:
- `sondeo` (experiencia, dolor, lugar, equipo, gustos) y `avanzado` (marcas, años entrenando, competencia, estrés, sueño…).
- `ingreso` (ficha de ingreso del cliente invitado: teléfono, meta, motivación, horario, medicamentos, lesiones, alcohol, tabaco, alergias legibles, no le gusta, cocina, compromiso, sueño, estrés, fecha, vía).
- Alimentación: `dieta_tipo`, `alergias` (claves de `restricciones.ALERGENOS`), `intolerancias`, `alergia_otra`.
- Salud: `parq` (lista bool), `condiciones` (p. ej. `hipertension`, `diabetes`, `embarazo`), `fc_reposo`, `pas`, `pad`.
- Suplementación: `supl_ctx` (respuestas), `supl_plan` ({clave: {desde, dosis}}), `supl_consentimiento`, `supl_nota_coach`.
- Programa: `programa_nota` (explica si los días pedidos no coinciden con la plantilla).
- Idioma: `idioma`.

## El JSON `usuarios.smae` (dieta por equivalentes, formato v2)
```json
{"v": 2, "tiempos": ["Desayuno", "Colación AM", "Comida", "Pre-entreno", "Post-entreno", "Cena"],
 "dist": {"Verduras": [1, 0, 2, 0, 0, 2], "...": []}, "menu": {"Desayuno": "texto"}, "recetas": {"Comida": "id_receta"},
 "notas": "", "metas": {"kcal": 1690, "prot": 147, "grasa": 47, "carb": 170} , "autor": "Nombre", "actualizado": "AAAA-MM-DD"}
```
Si la dieta guardada es la plantilla genérica antigua (`SMAE_EJEMPLO`) o está vacía, `dieta_de(u, mac, p)` genera una propuesta automática con `dieta.automatica()` (respeta metas, tipo de dieta y alergias) y la marca `"automatica": true` hasta que alguien la guarde.
