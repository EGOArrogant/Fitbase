CREATE TABLE actividad (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER NOT NULL,
  coach_id INTEGER NOT NULL,
  tipo TEXT, texto TEXT, url TEXT, detalle TEXT,
  n INTEGER DEFAULT 1,
  creado TEXT
);

CREATE TABLE api_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hash TEXT UNIQUE NOT NULL,
  usuario_id INTEGER NOT NULL,
  dispositivo TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  ultimo_uso TEXT
);

CREATE TABLE comentarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  autor_id INTEGER NOT NULL,
  texto TEXT NOT NULL,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE consentimientos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  tipo TEXT NOT NULL, otorgado INTEGER NOT NULL, version TEXT, huella TEXT,
  ip TEXT, agente TEXT, detalle TEXT, creado TEXT
);

CREATE TABLE diario_comidas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  fecha TEXT NOT NULL,
  tiempo TEXT NOT NULL,
  alimento TEXT NOT NULL,
  porcion TEXT,
  gramos REAL,
  kcal REAL, prot REAL, carb REAL, grasa REAL
, fibra REAL, alimento_id INTEGER, fuente TEXT);

CREATE TABLE errores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ruta TEXT, metodo TEXT, usuario_id INTEGER, tipo TEXT, mensaje TEXT, traza TEXT, veces INTEGER DEFAULT 1,
  creado TEXT, ultimo TEXT, resuelto INTEGER DEFAULT 0
);

CREATE TABLE feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  tipo TEXT NOT NULL,
  area TEXT,
  calificacion INTEGER,
  texto TEXT NOT NULL,
  publico INTEGER DEFAULT 1,
  estado TEXT DEFAULT 'nuevo',
  respuesta TEXT,
  respondio_id INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  actualizado TEXT
);

CREATE TABLE feedback_votos (
  feedback_id INTEGER NOT NULL,
  usuario_id INTEGER NOT NULL,
  PRIMARY KEY (feedback_id, usuario_id)
);

CREATE TABLE fotos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  autor_id INTEGER,
  fecha TEXT NOT NULL,
  angulo TEXT NOT NULL,
  archivo TEXT NOT NULL,
  peso REAL,
  nota TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invitaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT UNIQUE NOT NULL,
  coach_id INTEGER NOT NULL,
  nombre TEXT,
  contacto TEXT,
  nota TEXT,
  max_usos INTEGER DEFAULT 1,
  usos INTEGER DEFAULT 0,
  expira TEXT,
  cliente_id INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  ultimo_uso TEXT
);

CREATE TABLE mediciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  autor_id INTEGER,
  fecha TEXT NOT NULL,
  tipo TEXT NOT NULL,
  datos TEXT NOT NULL,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notificaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  tipo TEXT, titulo TEXT NOT NULL, texto TEXT, url TEXT, actor_id INTEGER,
  leida INTEGER DEFAULT 0,
  creado TEXT
);

CREATE TABLE pedidos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  folio TEXT UNIQUE NOT NULL,
  usuario_id INTEGER NOT NULL,
  plan TEXT NOT NULL,
  periodo TEXT NOT NULL,
  monto INTEGER NOT NULL,
  moneda TEXT DEFAULT 'MXN',
  metodo TEXT NOT NULL,
  estado TEXT DEFAULT 'pendiente',
  nombre TEXT, email TEXT, telefono TEXT,
  factura TEXT,
  stripe_sesion TEXT,
  referencia TEXT,
  comprobante TEXT,
  nota_admin TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP,
  pagado_en TEXT,
  vigencia_hasta TEXT
);

CREATE TABLE productos (
  codigo TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  marca TEXT,
  kcal REAL, prot REAL, carb REAL, grasa REAL, fibra REAL, azucar REAL, sodio REAL,
  porcion_g REAL,
  porcion_desc TEXT,
  fuente TEXT,
  autor_id INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE recetas_usuario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  autor_id INTEGER NOT NULL,
  nombre TEXT NOT NULL,
  tipo TEXT NOT NULL,
  tags TEXT,
  ing TEXT NOT NULL,
  pasos TEXT,
  minutos INTEGER,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE registros (
  usuario_id INTEGER NOT NULL,
  fecha TEXT NOT NULL,
  peso REAL, kcal REAL, proteina REAL, pasos INTEGER, sueno REAL,
  entreno TEXT, energia INTEGER, cintura REAL, notas TEXT, etiquetas TEXT,
  PRIMARY KEY (usuario_id, fecha)
);

CREATE TABLE retos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  titulo TEXT NOT NULL,
  descripcion TEXT,
  tipo TEXT NOT NULL,
  meta REAL NOT NULL,
  inicio TEXT NOT NULL,
  fin TEXT NOT NULL,
  puntos INTEGER DEFAULT 100,
  nivel TEXT DEFAULT 'Todos',
  cuota REAL DEFAULT 0,
  premios TEXT,
  cupo INTEGER,
  validar INTEGER DEFAULT 0,
  tier_min TEXT,
  creador_id INTEGER,
  activo INTEGER DEFAULT 1,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE retos_inscritos (
  reto_id INTEGER NOT NULL,
  usuario_id INTEGER NOT NULL,
  inscrito TEXT DEFAULT CURRENT_TIMESTAMP,
  pagado INTEGER DEFAULT 0,
  pago_ref TEXT,
  monto REAL,
  progreso_manual REAL,
  completado TEXT,
  validado INTEGER DEFAULT 0,
  puntos INTEGER DEFAULT 0,
  lugar INTEGER,
  PRIMARY KEY (reto_id, usuario_id)
);

CREATE TABLE series (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  fecha TEXT NOT NULL,
  ejercicio TEXT NOT NULL,
  serie INTEGER,
  peso REAL,
  reps INTEGER,
  rir REAL,
  nota TEXT
);

CREATE TABLE solicitudes_arco (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  folio TEXT UNIQUE, usuario_id INTEGER, nombre TEXT, email TEXT, tipo TEXT, descripcion TEXT,
  estado TEXT DEFAULT 'recibida', respuesta TEXT, creado TEXT, vence TEXT, respondido TEXT
);

CREATE TABLE usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  nombre TEXT NOT NULL,
  password TEXT NOT NULL,
  rol TEXT NOT NULL DEFAULT 'cliente',
  coach_id INTEGER,
  codigo_coach TEXT,
  perfil TEXT,
  programa TEXT,
  checklist TEXT,
  smae TEXT,
  creado TEXT DEFAULT CURRENT_TIMESTAMP
, es_admin INTEGER DEFAULT 0, plan TEXT DEFAULT 'gratis', plan_vence TEXT, plan_nota TEXT, activo INTEGER DEFAULT 1, ultimo_acceso TEXT, guia_vista TEXT);

CREATE INDEX idx_actividad_coach ON actividad(coach_id, creado);

CREATE INDEX idx_consent_usuario ON consentimientos(usuario_id, tipo);

CREATE INDEX idx_notif_usuario ON notificaciones(usuario_id, leida);

CREATE INDEX idx_pedidos_usuario ON pedidos(usuario_id);
