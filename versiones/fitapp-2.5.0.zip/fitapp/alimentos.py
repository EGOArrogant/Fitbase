"""Base de alimentos: valores por 100 g, porciones caseras en gramos y equivalente SMAE.

Lee data/alimentos_a.json y data/alimentos_b.json (formato documentado en LEEME.md) y
completa con los ingredientes de las recetas que no estén en esos archivos.
"""
import json
import os
import unicodedata

from data.recetas import ING

BASE = os.path.dirname(os.path.abspath(__file__))


def _norm(s):
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()


# Porciones caseras de los ingredientes que solo tenían «100 g» (pesos de referencia USDA FoodData Central, medidas caseras)
PORCIONES_INGREDIENTES = {
    "Aceitunas verdes": [("5 aceitunas", 18)], "Aguacate": [("1/2 pieza mediana (pulpa)", 68), ("1 pieza mediana (pulpa)", 136), ("2 cucharadas machacado", 30)],
    "Ajo": [("1 diente", 3)], "Almendras": [("10 piezas", 12), ("1/4 de taza", 36)], "Amaranto inflado": [("1/2 taza", 12)],
    "Avena en hojuelas": [("1/2 taza", 40), ("1 cucharada", 6)], "Bistec de res magro cocido": [("1 bistec mediano", 100)],
    "Brócoli": [("1 taza picado", 90)], "Caldo de pollo casero": [("1 taza", 240)], "Caldo de verduras": [("1 taza", 240)],
    "Camarón cocido": [("10 piezas medianas", 80)], "Camote cocido": [("1 pieza mediana", 150), ("1/2 taza", 100)],
    "Carne molida de pavo 93/7 cruda": [("1 porción", 120)], "Cebolla": [("1 pieza mediana", 110), ("1/4 de taza picada", 40)],
    "Chícharos cocidos": [("1/2 taza", 80)], "Cilantro": [("1/4 de taza picado", 4)], "Ejotes": [("1 taza", 125)],
    "Elote desgranado": [("1/2 taza", 80)], "Espinaca": [("1 taza cruda", 30)], "Fresas": [("1 taza", 150), ("5 piezas medianas", 60)],
    "Frijol negro cocido": [("1/2 taza", 86)], "Frijol pinto cocido": [("1/2 taza", 85)], "Frutos rojos congelados": [("1 taza", 140)],
    "Huevo entero": [("1 pieza", 50)], "Leche de soya sin azúcar": [("1 taza (240 ml)", 240)], "Lechuga": [("1 taza picada", 47)],
    "Limón": [("1 pieza", 40), ("jugo de 1 limón", 15)], "Mango": [("1 pieza mediana (pulpa)", 160), ("1 taza picado", 165)],
    "Maíz pozolero cocido": [("1/2 taza", 80)], "Miel": [("1 cucharada", 21), ("1 cucharadita", 7)],
    "Muslo de pollo sin piel cocido": [("1 pieza", 75)], "Nopal": [("1 penca", 80), ("1 taza", 150)], "Palomitas naturales (sin aceite)": [("1 taza", 8)],
    "Pan integral": [("1 rebanada", 28)], "Papa cocida": [("1 pieza mediana", 150)], "Pechuga de pavo cocida": [("1 porción", 100)],
    "Pechuga de pollo cocida": [("1 filete mediano", 120)], "Pepitas de calabaza": [("1 cucharada", 9), ("1/4 de taza", 30)],
    "Pimiento": [("1 pieza", 120), ("1/2 taza picado", 75)], "Proteína de suero (polvo)": [("1 scoop", 30)],
    "Proteína vegetal en polvo (chícharo)": [("1 scoop", 30)], "Queso cottage": [("1/2 taza", 113)], "Salmón cocido": [("1 filete", 120)],
    "Sardina en salsa de jitomate (lata, escurrida)": [("2 piezas", 50)], "Soya texturizada (seca)": [("1/4 de taza", 24)], "Verdolagas": [("1 taza", 100)],
}


def _cargar():
    lista = []
    for f in ("alimentos_a.json", "alimentos_b.json", "alimentos_c.json"):
        p = os.path.join(BASE, "data", f)
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as fh:
                    lista.extend(json.load(fh))
            except (ValueError, OSError):
                pass
    vistos = {_norm(a["nombre"]) for a in lista}
    for nombre, (k, p_, c, g) in ING.items():
        if _norm(nombre) not in vistos:
            lista.append({"nombre": nombre, "categoria": "Ingredientes de recetas", "smae": None,
                          "por100g": {"kcal": k, "prot": p_, "carb": c, "grasa": g, "fibra": None},
                          "porciones": [{"desc": d, "g": gr} for d, gr in PORCIONES_INGREDIENTES.get(nombre, [])],
                          "eq_smae_g": None, "fuente": "USDA (referencia)"})
    for i, a in enumerate(lista):
        a["id"] = i
        a["clave"] = _norm(a["nombre"])
        a.setdefault("porciones", [])
        a["porciones"] = [x for x in a["porciones"] if x.get("g")]
        if a.get("eq_smae_g") and a.get("smae"):
            a["porciones"].append({"desc": f"1 equivalente SMAE ({a['smae']})", "g": a["eq_smae_g"]})
        a["porciones"].append({"desc": "100 g", "g": 100})
    lista.sort(key=lambda a: (a.get("categoria", ""), a["nombre"]))
    # Alimentos nuevos (alimentos_d.json) y combinaciones calculadas: se agregan AL FINAL con ids nuevos,
    # para no recorrer los ids de los alimentos que ya existían (el diario guarda alimento_id).
    extra = []
    p = os.path.join(BASE, "data", "alimentos_d.json")
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as fh:
                extra.extend(json.load(fh))
        except (ValueError, OSError):
            pass
    try:
        from data.combinaciones import generar
        extra.extend(generar(lista + extra))
    except Exception:  # noqa: BLE001 (si falla el generador, la base original sigue funcionando)
        pass
    vistos = {a["clave"] for a in lista}
    for a in extra:
        if _norm(a["nombre"]) in vistos:
            continue
        vistos.add(_norm(a["nombre"]))
        a["id"] = len(lista)
        a["clave"] = _norm(a["nombre"])
        a["porciones"] = [x for x in a.get("porciones", []) if x.get("g")] + [{"desc": "100 g", "g": 100}]
        lista.append(a)
    return lista


ALIMENTOS = _cargar()
POR_ID = {a["id"]: a for a in ALIMENTOS}
POR_NOMBRE_EXACTO = {a["nombre"]: a for a in ALIMENTOS}
CATEGORIAS = sorted({a.get("categoria", "Otros") for a in ALIMENTOS})


def macros(a, gramos):
    f = gramos / 100
    v = a["por100g"]
    return {"kcal": round((v.get("kcal") or 0) * f), "prot": round((v.get("prot") or 0) * f, 1),
            "carb": round((v.get("carb") or 0) * f, 1), "grasa": round((v.get("grasa") or 0) * f, 1)}


def buscar(q="", categoria=""):
    qn = _norm(q.strip())
    return [a for a in ALIMENTOS if (not categoria or a.get("categoria") == categoria) and (not qn or qn in a["clave"])]


def para_js():
    """Datos compactos para el buscador del diario."""
    return [{"id": a["id"], "n": a["nombre"], "c": a.get("categoria", ""), "v": a["por100g"],
             "p": [[x["desc"], x["g"]] for x in a["porciones"]]} for a in ALIMENTOS]
