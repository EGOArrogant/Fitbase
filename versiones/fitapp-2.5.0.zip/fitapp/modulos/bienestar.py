"""Bienestar y salud mental: cuestionarios validados (WHO-5, PHQ-9, GAD-7), registro diario de estrés/ánimo,
respiración guiada y relajación, con protocolo de crisis. Privacidad reforzada: el entrenador solo ve un indicador
general y únicamente si la persona lo autoriza."""
import datetime as dt
import json

from flask import abort, flash, g, jsonify, redirect, render_template, request, url_for

from data import salud_mental as sm

RESPIRACIONES = [
    {"id": "caja", "nombre": "Respiración en caja 4-4-4-4", "fases": [["Inhala", 4], ["Sostén", 4], ["Exhala", 4], ["Sostén", 4]], "min": 4,
     "para": "Calmarte antes de una competencia, una junta o al sentir tensión.", "fuente": "Ma X 2017, Front Psychol (respiración diafragmática)"},
    {"id": "coherencia", "nombre": "Coherencia cardiaca (~6 por minuto)", "fases": [["Inhala", 5], ["Exhala", 5]], "min": 5,
     "para": "Bajar el estrés y preparar el sueño.", "fuente": "Zaccaro 2018, Front Hum Neurosci; Lehrer 2014"},
    {"id": "478", "nombre": "4-7-8 (antes de dormir)", "fases": [["Inhala por la nariz", 4], ["Sostén", 7], ["Exhala por la boca", 8]], "min": 3,
     "para": "Relajarte al acostarte. Si te mareas, acorta los tiempos.", "fuente": "Técnica popular; evidencia limitada (Vierra 2022)"},
    {"id": "suspiro", "nombre": "Suspiro fisiológico", "fases": [["Inhala", 2], ["Inhala un poco más", 1], ["Exhala largo y lento", 6]], "min": 5,
     "para": "Bajar la tensión en pocos minutos.", "fuente": "Balban 2023, Cell Rep Med"},
]
RELAJACION = {
    "nombre": "Relajación muscular progresiva (Jacobson)", "min": 12, "fuente": "Toussaint 2021, Evid Based Complement Alternat Med",
    "pasos": ["Siéntate o acuéstate cómodo. Respira lento tres veces.",
              "Manos y antebrazos: aprieta los puños 5 segundos… suelta y nota la diferencia 15 segundos.",
              "Brazos: dobla los codos y tensa los bíceps 5 segundos… suelta 15 segundos.",
              "Hombros: súbelos hacia las orejas 5 segundos… déjalos caer 15 segundos.",
              "Cara: arruga la frente y aprieta los ojos 5 segundos… relaja 15 segundos.",
              "Abdomen: endurécelo como si fueras a recibir un golpe 5 segundos… suelta 15 segundos.",
              "Piernas: estira las piernas y apunta los pies hacia ti 5 segundos… suelta 15 segundos.",
              "Recorre tu cuerpo de pies a cabeza y suelta cualquier tensión que quede. Respira lento un minuto."],
}


def registrar(app, h):
    def historial(uid, limite=30):
        return [dict(x) for x in h.get_db().execute("SELECT * FROM bienestar_resultados WHERE usuario_id=? ORDER BY id DESC LIMIT ?", (uid, limite)).fetchall()]

    def ultimo_por(hist):
        out = {}
        for x in hist:
            out.setdefault(x["instrumento"], x)
        return out

    def estado_semana(uid):
        logs = h.registros(uid, dt.date.today() - dt.timedelta(days=7))
        est = [l["estres"] for l in logs if l.get("estres")]
        ani = [l["animo"] for l in logs if l.get("animo")]
        return {"estres": round(sum(est) / len(est), 1) if est else None, "animo": round(sum(ani) / len(ani), 1) if ani else None, "n": len(est) or len(ani)}

    def indicador(uid):
        """Resumen general (sin respuestas) que puede ver el entrenador si hay autorización."""
        ult = ultimo_por(historial(uid, 10))
        sem = estado_semana(uid)
        alerta = any(x["ayuda"] or x["crisis"] for x in ult.values()) or (sem["estres"] or 0) >= 4
        return {"alerta": alerta, "texto": "Semana con estrés alto o bienestar bajo: conviene preguntar cómo está." if alerta else "Sin señales de alerta esta semana.",
                "estres": sem["estres"]}

    h["indicador_bienestar"] = indicador

    @app.route("/bienestar", methods=["GET", "POST"])
    @h.login_required
    def bienestar():
        p = h.perfil(g.user)
        if request.method == "POST":
            acc = request.form.get("accion")
            if acc == "consentir":
                p["bienestar_consentimiento"] = {"fecha": dt.datetime.now().isoformat(timespec="seconds")}
                h.legalmod.registrar(h.get_db(), g.user["id"], "salud_mental", True, request)
            elif acc == "compartir":
                si = request.form.get("compartir") == "1"
                p["bienestar_compartir"] = si
                h.legalmod.registrar(h.get_db(), g.user["id"], "salud_mental_coach", si, request)
                flash("Preferencia guardada: " + ("tu entrenador verá solo un indicador general (nunca tus respuestas)." if si else "tu entrenador no verá nada de esta sección."), "ok")
            h.get_db().commit()
            h.guardar(g.user, "perfil", p)
            return redirect(url_for("bienestar"))
        hist = historial(g.user["id"])
        ult = ultimo_por(hist)
        pend = [k for k, ins in sm.INSTRUMENTOS.items() if k not in ult or (dt.datetime.now() - dt.datetime.fromisoformat(ult[k]["creado"])).days >= ins["dias"]]
        return render_template("bienestar.html", INS=sm.INSTRUMENTOS, hist=hist, ult=ult, pend=pend, sem=estado_semana(g.user["id"]),
                               recs=sm.RECOMENDACIONES, RESP=RESPIRACIONES, RELAJ=RELAJACION, CRISIS=sm.CRISIS,
                               consentido=bool(p.get("bienestar_consentimiento")), compartir=bool(p.get("bienestar_compartir")),
                               tiene_coach=bool(g.user.get("coach_id")), crisis_activa=any(x["crisis"] for x in hist[:3]))

    @app.route("/bienestar/cuestionario/<clave>", methods=["GET", "POST"])
    @h.login_required
    def bienestar_cuestionario(clave):
        ins = sm.INSTRUMENTOS.get(clave) or abort(404)
        p = h.perfil(g.user)
        if not p.get("bienestar_consentimiento"):
            flash("Antes de contestar, autoriza el uso de tus respuestas (datos sensibles).", "info")
            return redirect(url_for("bienestar") + "#consentimiento")
        if request.method == "POST":
            try:
                resp = [int(request.form.get(f"r{i}", "x")) for i in range(len(ins["items"]))]
                res = sm.calificar(clave, resp)
            except ValueError:
                flash("Contesta todas las preguntas.", "error")
                return render_template("bienestar_cuestionario.html", clave=clave, ins=ins, previas=request.form)
            con = h.get_db()
            con.execute("INSERT INTO bienestar_resultados (usuario_id, instrumento, puntaje, nivel, respuestas, ayuda, crisis, creado) VALUES (?,?,?,?,?,?,?,?)",
                        (g.user["id"], clave, res["puntaje"], res["nivel"], json.dumps(resp), int(res["ayuda"]), int(res["crisis"]),
                         dt.datetime.now().isoformat(timespec="seconds")))
            if g.user.get("coach_id") and p.get("bienestar_compartir") and (res["ayuda"] or res["crisis"]):
                h.notif.avisar(con, g.user["coach_id"], "cliente", f"{g.user['nombre']}: semana difícil",
                               "Su autoevaluación de bienestar sugiere ofrecerle apoyo. (No se comparten sus respuestas.)",
                               url_for("coach_cliente", cid=g.user["id"]), g.user["id"])
            con.commit()
            return render_template("bienestar_resultado.html", clave=clave, ins=ins, res=res, CRISIS=sm.CRISIS, recs=sm.RECOMENDACIONES)
        return render_template("bienestar_cuestionario.html", clave=clave, ins=ins, previas={})

    @app.route("/coach/cliente/<int:cid>/bienestar")
    @h.login_required
    def coach_bienestar(cid):
        c = h._cliente_de_coach(cid)
        p = h.perfil(c)
        return jsonify(ok=True, autorizado=bool(p.get("bienestar_compartir")), indicador=indicador(cid) if p.get("bienestar_compartir") else None)

    @app.route("/api/v1/bienestar")
    @h.api_auth()
    def api_bienestar():
        hist = historial(g.user["id"], 20)
        return jsonify(ok=True, instrumentos={k: {"nombre": v["nombre"], "items": v["items"], "opciones": v["opciones"]} for k, v in sm.INSTRUMENTOS.items()},
                       resultados=[{k: x[k] for k in ("instrumento", "puntaje", "nivel", "ayuda", "crisis", "creado")} for x in hist],
                       crisis=sm.CRISIS, respiraciones=RESPIRACIONES)
