"""Calentamiento por deporte (RAMP), vuelta a la calma y recuperación prioritaria al terminar una sesión.
También registra la sesión deportiva (tabla sesiones_deporte), base del módulo multideporte."""
import datetime as dt
import json

from flask import flash, g, jsonify, redirect, render_template, request, url_for

from data import deportes as dep


def _nivel(p):
    n = p.get("nivel") or "Principiante"
    return {"Principiante": "Principiante", "Intermedio": "Intermedio", "Avanzado": "Avanzado"}.get(n, "Intermedio" if "Inter" in n else "Principiante")


def registrar(app, h):
    def deporte_de(p):
        return request.values.get("deporte") if request.values.get("deporte") in dep.DEPORTES else (p.get("deporte") if p.get("deporte") in dep.DEPORTES else "musculacion")

    @app.route("/calentamiento")
    @h.login_required
    def calentamiento():
        p = h.perfil(g.user)
        d = deporte_de(p)
        minutos = 5 if request.args.get("min") == "5" else 10
        lesiones = (p.get("sondeo") or {}).get("dolor") or []
        plan = dep.calentamiento_para(d, _nivel(p), minutos, lesiones)
        return render_template("calentamiento.html", plan=plan, D=dep.DEPORTES, deporte=d, minutos=minutos, calma=dep.vuelta_calma_para(d),
                               volver=request.args.get("volver"))

    @app.route("/recuperacion", methods=["GET", "POST"])
    @h.login_required
    def recuperacion():
        p = h.perfil(g.user)
        con = h.get_db()
        if request.method == "POST":
            f = request.form
            d = f.get("deporte") if f.get("deporte") in dep.DEPORTES else "musculacion"
            num = h.calc.num
            dur, rpe = num(f.get("duracion")), num(f.get("rpe"))
            if not dur or not rpe or not (1 <= rpe <= 10) or not (1 <= dur <= 1440):
                flash("Escribe la duración (min) y qué tan dura fue (RPE de 1 a 10).", "error")
                return redirect(url_for("recuperacion", deporte=d))
            pre = h.calc.en_rango("peso", f.get("peso_pre")) or p.get("peso")
            post = h.calc.en_rango("peso", f.get("peso_post"))
            sig = num(f.get("siguiente_h"))
            datos = {"calor": f.get("calor") == "1", "contacto": f.get("contacto") == "1"}
            con.execute("INSERT INTO sesiones_deporte (usuario_id, fecha, deporte, tipo, duracion_min, rpe, distancia_km, fc_media, peso_pre, peso_post, datos, notas, creado) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (g.user["id"], f.get("fecha") or str(dt.date.today()), d, (f.get("tipo") or "")[:40] or None, dur, int(rpe), num(f.get("distancia")),
                         int(num(f.get("fc_media")) or 0) or None, pre if f.get("peso_pre") else None, post, json.dumps(datos), (f.get("notas") or "")[:500],
                         dt.datetime.now().isoformat(timespec="seconds")))
            r = con.execute("SELECT entreno FROM registros WHERE usuario_id=? AND fecha=?", (g.user["id"], f.get("fecha") or str(dt.date.today()))).fetchone()
            if not r:
                con.execute("INSERT INTO registros (usuario_id, fecha, entreno) VALUES (?,?,'Sí')", (g.user["id"], f.get("fecha") or str(dt.date.today())))
            elif r["entreno"] != "Sí":
                con.execute("UPDATE registros SET entreno='Sí' WHERE usuario_id=? AND fecha=?", (g.user["id"], f.get("fecha") or str(dt.date.today())))
            con.commit()
            p["deporte"] = d
            h.guardar(g.user, "perfil", p)
            sid = con.execute("SELECT MAX(id) FROM sesiones_deporte WHERE usuario_id=?", (g.user["id"],)).fetchone()[0]
            return redirect(url_for("recuperacion", s=sid))
        ses = None
        if request.args.get("s"):
            ses = con.execute("SELECT * FROM sesiones_deporte WHERE id=? AND usuario_id=?", (request.args.get("s"), g.user["id"])).fetchone()
        recs, desc = [], None
        if ses:
            ses = dict(ses)
            dd = json.loads(ses["datos"] or "{}")
            recs = dep.recomendaciones_recuperacion(ses["deporte"], ses["duracion_min"], ses["rpe"], _nivel(p), ses["peso_pre"] or p.get("peso"),
                                                    ses["peso_post"], None, dd.get("calor"), dd.get("contacto"))
            desc = dep.descanso_sugerido(ses["deporte"], ses["rpe"], ses["duracion_min"], dd.get("contacto"))
        ultimas = [dict(x) for x in con.execute("SELECT * FROM sesiones_deporte WHERE usuario_id=? ORDER BY fecha DESC, id DESC LIMIT 8", (g.user["id"],)).fetchall()]
        return render_template("recuperacion.html", D=dep.DEPORTES, deporte=deporte_de(p), ses=ses, recs=recs, desc=desc, ultimas=ultimas,
                               calma=dep.vuelta_calma_para(ses["deporte"]) if ses else None, dur=request.args.get("dur"), hoy=str(dt.date.today()), p=p)

    @app.route("/api/v1/recuperacion", methods=["POST"])
    @h.api_auth()
    def api_recuperacion():
        d = request.get_json(silent=True) or {}
        p = h.perfil(g.user)
        dpt = d.get("deporte") if d.get("deporte") in dep.DEPORTES else "musculacion"
        recs = dep.recomendaciones_recuperacion(dpt, h.calc.num(d.get("duracion_min")) or 30, h.calc.num(d.get("rpe")) or 6, _nivel(p),
                                                h.calc.num(d.get("peso_pre")) or p.get("peso"), h.calc.num(d.get("peso_post")), h.calc.num(d.get("siguiente_h")),
                                                bool(d.get("calor")), bool(d.get("contacto")))
        return jsonify(ok=True, recomendaciones=recs, calentamiento=dep.calentamiento_para(dpt, _nivel(p)), vuelta_calma=dep.vuelta_calma_para(dpt))
