"""Hidratación: registro por vasos, mililitros y litros, con tamaño de vaso configurable y meta personalizada.

Meta: ~35 ml por kg de peso como referencia práctica de líquidos al día; la EFSA (2010) fija la ingesta adecuada de AGUA TOTAL
(bebidas + alimentos) en 2.0 L/día para mujeres y 2.5 L/día para hombres; ~20–30 % viene de los alimentos.
En días de entrenamiento se suma lo perdido en sudor (ver Recuperación). Fuentes: EFSA NDA Panel (2010) EFSA J 8(3):1459
doi:10.2903/j.efsa.2010.1459 · Thomas, Erdman y Burke (2016) ACSM/AND/DC.
"""
import datetime as dt

from flask import flash, g, jsonify, redirect, render_template, request, url_for

BEBIDAS = [("agua", "Agua"), ("agua_sabor", "Agua de sabor sin azúcar"), ("te", "Té o café sin azúcar"), ("leche", "Leche"),
           ("bebida_deportiva", "Bebida con electrolitos"), ("otra", "Otra bebida")]


def meta_ml(p):
    base = round((p.get("peso") or 70) * 35 / 50) * 50
    efsa = 2000 if p.get("sexo") == "Mujer" else 2500
    return base, efsa


def registrar(app, h):
    def vaso(p):
        return int(p.get("vaso_ml") or 250)

    def del_dia(uid, fecha):
        return [dict(x) for x in h.get_db().execute("SELECT * FROM hidratacion WHERE usuario_id=? AND fecha=? ORDER BY id", (uid, fecha)).fetchall()]

    def resumen(uid, p, fecha=None):
        fecha = fecha or str(dt.date.today())
        filas = del_dia(uid, fecha)
        total = sum(x["ml"] for x in filas)
        meta, efsa = meta_ml(p)
        v = vaso(p)
        return {"fecha": fecha, "filas": filas, "total": total, "meta": meta, "efsa": efsa, "vaso": v, "vasos": round(total / v, 1),
                "vasos_meta": round(meta / v), "pct": min(100, round(100 * total / meta)) if meta else 0}
    h["resumen_hidratacion"] = resumen
    app.jinja_env.globals["resumen_hidratacion"] = lambda: resumen(g.user["id"], h.perfil(g.user)) if g.get("user") and g.user.get("perfil") else None

    @app.route("/hidratacion", methods=["GET", "POST"])
    @h.login_required
    def hidratacion():
        p = h.perfil(g.user)
        con = h.get_db()
        fecha = request.values.get("fecha") or str(dt.date.today())
        if request.method == "POST":
            f, acc = request.form, request.form.get("accion")
            if acc == "vaso_ml":
                p["vaso_ml"] = max(50, min(2000, int(h.calc.num(f.get("vaso_ml"), 250) or 250)))
                h.guardar(g.user, "perfil", p)
                flash(f"Tu vaso ahora mide {p['vaso_ml']} ml.", "ok")
            elif acc == "borrar":
                con.execute("DELETE FROM hidratacion WHERE id=? AND usuario_id=?", (f.get("id"), g.user["id"]))
            else:
                ml = int(h.calc.num(f.get("ml"), 0) or 0) or int((h.calc.num(f.get("vasos"), 1) or 1) * vaso(p))
                if 10 <= ml <= 3000:
                    bebida = f.get("bebida") if f.get("bebida") in dict(BEBIDAS) else "agua"
                    con.execute("INSERT INTO hidratacion (usuario_id, fecha, ml, hora, bebida) VALUES (?,?,?,?,?)",
                                (g.user["id"], fecha, ml, dt.datetime.now().strftime("%H:%M"), bebida))
                else:
                    flash("Escribe una cantidad entre 10 y 3,000 ml.", "error")
            con.commit()
            if request.headers.get("Accept", "").startswith("application/json"):
                return jsonify(ok=True, **{k: v for k, v in resumen(g.user["id"], p, fecha).items() if k != "filas"})
            return redirect(request.form.get("volver") or url_for("hidratacion", fecha=fecha))
        r = resumen(g.user["id"], p, fecha)
        hist = []
        for k in range(6, -1, -1):
            d = str(dt.date.fromisoformat(fecha) - dt.timedelta(days=k))
            hist.append((d, con.execute("SELECT COALESCE(SUM(ml),0) FROM hidratacion WHERE usuario_id=? AND fecha=?", (g.user["id"], d)).fetchone()[0]))
        graf = h.charts.barras([x[1] for x in hist], [x[0][8:10] + "/" + x[0][5:7] for x in hist], alto=160, titulo="Mililitros por día",
                               clases=["bar" if x[1] >= r["meta"] * 0.8 else "bar2" for x in hist], referencia=r["meta"]) if any(x[1] for x in hist) else ""
        return render_template("hidratacion.html", r=r, graf=graf, BEBIDAS=BEBIDAS, p=p)

    @app.route("/api/v1/hidratacion", methods=["GET", "POST"])
    @h.api_auth()
    def api_hidratacion():
        p = h.perfil(g.user)
        if request.method == "POST":
            d = request.get_json(silent=True) or {}
            ml = int(h.calc.num(d.get("ml"), 0) or 0) or int((h.calc.num(d.get("vasos"), 1) or 1) * vaso(p))
            if not 10 <= ml <= 3000:
                return h._api_err("«ml» debe estar entre 10 y 3000.")
            h.get_db().execute("INSERT INTO hidratacion (usuario_id, fecha, ml, hora, bebida) VALUES (?,?,?,?,?)",
                               (g.user["id"], d.get("fecha") or str(dt.date.today()), ml, dt.datetime.now().strftime("%H:%M"), "agua"))
            h.get_db().commit()
        r = resumen(g.user["id"], p, request.args.get("fecha"))
        return jsonify(ok=True, **r)
