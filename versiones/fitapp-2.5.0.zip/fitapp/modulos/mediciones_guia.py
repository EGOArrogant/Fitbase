"""Guía ilustrada de mediciones: silueta + marca exacta de cada medición (de dónde a dónde, dirección del pliegue)."""
import json
import math
import os

from flask import render_template

from data import mediciones_guia as mg

_SIL = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "cuerpo_svg.json"), encoding="utf-8"))


def _figura(f):
    t = f[0]
    if t == "linea":
        _, x1, y1, x2, y2 = f
        return (f'<line class="mg-cinta" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}"/>'
                f'<circle class="mg-fin" cx="{x1}" cy="{y1}" r="5"/><circle class="mg-fin" cx="{x2}" cy="{y2}" r="5"/>')
    if t == "pliegue":
        _, x, y, ang = f
        r = math.radians(ang)
        dx, dy = math.cos(r) * 22, -math.sin(r) * 22         # eje del pliegue
        px, py = -dy * 0.35, dx * 0.35                          # separación de los dedos
        return (f'<g class="mg-pliegue"><ellipse cx="{x}" cy="{y}" rx="24" ry="9" transform="rotate({-ang} {x} {y})"/>'
                f'<line x1="{x - dx + px:.1f}" y1="{y - dy + py:.1f}" x2="{x + dx + px:.1f}" y2="{y + dy + py:.1f}"/>'
                f'<line x1="{x - dx - px:.1f}" y1="{y - dy - py:.1f}" x2="{x + dx - px:.1f}" y2="{y + dy - py:.1f}"/></g>')
    if t == "calibrador":
        _, x1, y1, x2, y2 = f
        return (f'<g class="mg-calib"><line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}"/>'
                f'<line x1="{x1}" y1="{y1 - 14}" x2="{x1}" y2="{y1 + 4}"/><line x1="{x2}" y1="{y2 - 14}" x2="{x2}" y2="{y2 + 4}"/></g>')
    if t == "punto":
        _, x, y, et = f
        ancho = len(et) * 11                 # ancho aproximado del texto (font-size 20)
        izq = x + 12 + ancho <= 565 and (x > 285 or x < 230)   # a la derecha si cabe; si no, a la izquierda
        if not izq and x - 12 - ancho < 5:
            izq = True
        tx = x + 12 if izq else x - 12
        return (f'<circle class="mg-punto" cx="{x}" cy="{y}" r="6"/>'
                f'<text class="mg-et" x="{tx}" y="{y + 4}" text-anchor="{"start" if izq else "end"}">{et}</text>')
    return ""


def svg_vista(vista):
    d = _SIL["Hombre"][vista]
    vb = " ".join(str(x) for x in d["vb"])
    capas = [f'<g class="mg-capa" data-med="{m["clave"]}" hidden>' + "".join(_figura(f) for f in m["marca"]) + "</g>"
             for m in mg.MEDICIONES if m["vista"] == vista]
    lado = "Derecho del evaluado ←" if vista == "frente" else "→ Derecho del evaluado"
    return (f'<svg viewBox="{vb}" class="mg-svg" data-vista="{vista}" role="img" aria-label="Silueta, vista de {vista}">'
            f'<path class="mg-sil" d="{d["silueta"]}"/><path class="mg-lin" d="{d["lineas"]}" fill-rule="evenodd"/>' + "".join(capas) +
            f'<text class="mg-lado" x="{20 if vista == "frente" else 550}" y="925" text-anchor="{"start" if vista == "frente" else "end"}">{lado}</text></svg>')


def registrar(app, h):
    app.jinja_env.globals["MG"] = mg
    app.jinja_env.globals["mg_svg"] = svg_vista

    @app.route("/mediciones/guia")
    def mediciones_guia():
        return render_template("mediciones_guia.html")
