"""Sueño: análisis de duración, regularidad, deuda y calidad, con recomendaciones (data/sueno.py)."""
import datetime as dt

from flask import g, jsonify, render_template, request

from data import sueno as sueno_data


def datos_sueno(h, u, dias=30):
    p = h.perfil(u)
    logs = h.registros(u["id"], dt.date.today() - dt.timedelta(days=dias))
    deportista = (p.get("dias") or 0) >= 4
    a = sueno_data.analizar(logs, p.get("edad"), deportista)
    est = [l["estres"] for l in logs[-7:] if l.get("estres")]
    recs = sueno_data.recomendaciones(a, estres_alto=bool(est) and sum(est) / len(est) >= 4)
    con = [l for l in logs if l.get("sueno")]
    graf = h.charts.barras([l["sueno"] for l in con[-21:]], [f"{l['fecha'].day}/{l['fecha'].month}" for l in con[-21:]], alto=170,
                           titulo="Horas de sueño", clases=["bar" if l["sueno"] >= a["meta"][0] else "bar2" for l in con[-21:]],
                           referencia=a["meta"][0]) if con else ""
    return {"a": a, "recs": recs, "graf": graf, "logs": list(reversed(con[-14:]))}


def registrar(app, h):
    @app.route("/sueno")
    @app.route("/coach/cliente/<int:cid>/sueno")
    @h.login_required
    def sueno_view(cid=None):
        target = h._cliente_de_coach(cid) if cid else g.user
        return render_template("sueno.html", cliente=target if cid else None, **datos_sueno(h, target))

    @app.route("/api/v1/sueno")
    @h.api_auth()
    def api_sueno():
        d = datos_sueno(h, g.user, int(request.args.get("dias", 30)))
        return jsonify(ok=True, analisis=d["a"], recomendaciones=[{"prioridad": p, "titulo": t, "texto": x, "fuente": f} for p, t, x, f in d["recs"]],
                       registros=[{"fecha": str(l["fecha"]), "horas": l["sueno"], "acostarse": l.get("hora_dormir"), "levantarse": l.get("hora_despertar"),
                                   "calidad": l.get("calidad_sueno")} for l in d["logs"]])
