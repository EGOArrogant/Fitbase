"""Módulos nuevos de FitBase (3.0): cada archivo registra sus rutas con registrar(app, h).

`h` da acceso a los ayudantes de app.py (login_required, get_db, perfil, guardar, calcular, flash, etc.)
sin importar app.py (evita importaciones circulares). Así cada módulo vive en su propio archivo.
"""
import importlib
import logging

MODULOS = ["herramientas", "sueno_mod", "bienestar", "entreno_extra", "alta_cliente", "mediciones_guia", "programa_cambios", "hidratacion"]


class Ayudantes(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError as e:
            raise AttributeError(k) from e


def cargar(app, globales):
    h = Ayudantes(globales)
    cargados = []
    for nombre in MODULOS:
        try:
            m = importlib.import_module(f"modulos.{nombre}")
        except ModuleNotFoundError as e:
            if e.name == f"modulos.{nombre}":
                continue          # módulo aún no creado
            raise
        m.registrar(app, h)
        cargados.append(nombre)
    logging.getLogger(__name__).info("Módulos cargados: %s", ", ".join(cargados))
    return cargados
