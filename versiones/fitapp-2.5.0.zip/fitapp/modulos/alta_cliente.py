"""Guía de alta de cliente para profesionales con licencia: checklist de 10 pasos que se marca solo con los datos reales
del cliente, con botón «hacerlo ahora» en cada paso. Aparece al vincular un cliente y en su ficha."""
import datetime as dt

from flask import abort, flash, g, redirect, render_template, request, url_for


def pasos_alta(h, c):
    """Lista de pasos con estado (hecho/pendiente) calculado de los datos del cliente."""
    con = h.get_db()
    p = h.perfil(c)
    alta = p.get("alta") or {}
    manual = set(alta.get("hechos_manual") or [])
    cid = c["id"]
    n = lambda q: con.execute(q, (cid,)).fetchone()[0]
    smae = c.get("smae") or ""
    pasos = [
        ("datos", "Datos y consentimientos", "Que el cliente acepte términos, datos de salud y compartir su información contigo.",
         not h.legalmod.pendientes(con, cid), url_for("coach_expediente", cid=cid)),
        ("parq", "Cuestionario de salud PAR-Q+", "Revisa banderas rojas antes de entrenar. Si hay alguna, pide valoración médica.",
         bool(p.get("parq")) and len(p.get("parq") or []) > 0, url_for("coach_expediente", cid=cid) + "#salud"),
        ("sondeo", "Sondeo: deporte, nivel y metas", "Experiencia, lugar de entrenamiento, molestias y objetivo.",
         bool(p.get("sondeo")), url_for("coach_sondeo_avanzado", cid=cid)),
        ("mediciones", "Mediciones y fotos de inicio", "Medidas guiadas (y fotos con su consentimiento) para comparar después.",
         n("SELECT COUNT(*) FROM mediciones WHERE usuario_id=?") > 0, url_for("coach_mediciones", cid=cid)),
        ("pruebas", "Pruebas iniciales", "Ej.: 1RM estimado en básicos, test de 5 km o Cooper, movilidad. Registra la primera sesión.",
         n("SELECT COUNT(*) FROM series WHERE usuario_id=?") > 0 or n("SELECT COUNT(*) FROM sesiones_deporte WHERE usuario_id=?") > 0,
         url_for("coach_cliente", cid=cid)),
        ("programa", "Programa y calentamiento", "Ajusta el programa a sus días y equipo; enséñale su calentamiento.",
         bool(c.get("programa")), url_for("coach_cliente", cid=cid) + "#programa"),
        ("nutricion", "Plan nutricional", "Revisa y guarda su dieta por equivalentes (la propuesta automática ya respeta sus alergias).",
         bool(smae) and '"v": 2' in smae and '"automatica": true' not in smae, url_for("coach_dieta", cid=cid)),
        ("metas", "Metas SMART con fecha", "Específicas, medibles y con fecha: p. ej. «bajar 3 cm de cintura para el 15 de marzo».",
         bool(alta.get("metas")), url_for("alta_cliente", cid=cid) + "#metas"),
        ("herramientas", "Herramientas del cliente", "Asígnale temporizadores y explícale el registro diario y de sueño.",
         bool(p.get("temporizadores_coach")), url_for("herramientas", cid=cid)),
        ("cita", "Primera cita de seguimiento", "Agenda la revisión (sugerido: en 1–2 semanas).",
         bool(alta.get("cita")), url_for("alta_cliente", cid=cid) + "#cita"),
    ]
    out = [{"clave": k, "titulo": t, "texto": x, "hecho": ok or k in manual, "manual": k in manual and not ok, "url": u} for k, t, x, ok, u in pasos]
    return out, alta


def registrar(app, h):
    @app.route("/coach/cliente/<int:cid>/alta", methods=["GET", "POST"])
    @h.login_required
    def alta_cliente(cid):
        c = h._cliente_de_coach(cid)
        p = h.perfil(c)
        alta = dict(p.get("alta") or {})
        if request.method == "POST":
            f, acc = request.form, request.form.get("accion")
            if acc == "metas":
                metas = [m.strip()[:200] for m in f.getlist("meta") if m.strip()][:5]
                fechas = f.getlist("fecha_meta")[:len(metas)]
                alta["metas"] = [{"texto": m, "fecha": (fechas[i] if i < len(fechas) else "")[:10]} for i, m in enumerate(metas)]
                flash("Metas guardadas.", "ok")
            elif acc == "cita":
                fecha = (f.get("cita") or "")[:16]
                alta["cita"] = fecha or None
                if fecha:
                    h.notif.avisar(h.get_db(), cid, "ajuste", "Tu entrenador agendó tu revisión", fecha.replace("T", " "), url_for("dashboard"), g.user["id"])
                    h.get_db().commit()
                flash("Cita guardada y notificada al cliente." if fecha else "Cita quitada.", "ok")
            elif acc == "manual":
                hechos = set(alta.get("hechos_manual") or [])
                hechos.symmetric_difference_update({f.get("paso")})
                alta["hechos_manual"] = sorted(x for x in hechos if x)
            p["alta"] = alta
            h.guardar(c, "perfil", p)
            return redirect(url_for("alta_cliente", cid=cid))
        pasos, alta = pasos_alta(h, c)
        hechos = sum(1 for x in pasos if x["hecho"])
        return render_template("alta_cliente.html", c=c, pasos=pasos, alta=alta, pct=round(100 * hechos / len(pasos)), hechos=hechos,
                               sugerida=str(dt.date.today() + dt.timedelta(days=10)) + "T18:00")

    # el resto de la app puede pedir el % (panel del coach y ficha)
    def avance_alta(c):
        pasos, _ = pasos_alta(h, c)
        return round(100 * sum(1 for x in pasos if x["hecho"]) / len(pasos))
    h["avance_alta"] = avance_alta
    app.jinja_env.globals["avance_alta"] = avance_alta
