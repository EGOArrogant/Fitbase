"""Cronómetros y relojes: cronómetro con vueltas, cuenta regresiva, intervalos (HIIT, Tabata, EMOM, AMRAP,
For Time, rounds de boxeo, intervalos de carrera) y descanso entre series. Los presets se guardan por usuario
y el entrenador puede asignar presets a su cliente."""
import json

from flask import abort, flash, g, jsonify, redirect, render_template, request, url_for

# Presets base: (clave, nombre, tipo, config, para qué sirve)
PRESETS_BASE = [
    {"id": "tabata", "nombre": "Tabata 20/10 × 8", "tipo": "intervalos", "trabajo": 20, "descanso": 10, "rondas": 8, "prep": 10,
     "nota": "4 min de alta intensidad (Tabata 1996). Ideal para acondicionamiento."},
    {"id": "hiit-30-30", "nombre": "HIIT 30/30 × 10", "tipo": "intervalos", "trabajo": 30, "descanso": 30, "rondas": 10, "prep": 10,
     "nota": "Intervalos cortos 1:1, buenos para mejorar VO₂máx con poco tiempo."},
    {"id": "hiit-40-20", "nombre": "HIIT 40/20 × 12", "tipo": "intervalos", "trabajo": 40, "descanso": 20, "rondas": 12, "prep": 10,
     "nota": "Circuitos metabólicos y calistenia."},
    {"id": "emom-10", "nombre": "EMOM 10 min", "tipo": "emom", "trabajo": 60, "descanso": 0, "rondas": 10, "prep": 10,
     "nota": "Cada minuto haces las repeticiones indicadas y descansas lo que sobre."},
    {"id": "amrap-12", "nombre": "AMRAP 12 min", "tipo": "amrap", "trabajo": 720, "descanso": 0, "rondas": 1, "prep": 10,
     "nota": "Tantas rondas como puedas en 12 min. Anota tus rondas al final."},
    {"id": "fortime-20", "nombre": "For Time (tope 20 min)", "tipo": "fortime", "trabajo": 1200, "descanso": 0, "rondas": 1, "prep": 10,
     "nota": "Termina el trabajo lo más rápido posible con buena técnica; el reloj se detiene al tocar «Terminé»."},
    {"id": "box-3x1", "nombre": "Boxeo: rounds 3:00 / 1:00 × 6", "tipo": "boxeo", "trabajo": 180, "descanso": 60, "rondas": 6, "prep": 10, "aviso": 10,
     "nota": "Formato de round amateur/profesional; aviso a 10 s del final."},
    {"id": "box-2x1", "nombre": "Boxeo: rounds 2:00 / 1:00 × 5 (principiante)", "tipo": "boxeo", "trabajo": 120, "descanso": 60, "rondas": 5, "prep": 10, "aviso": 10,
     "nota": "Para empezar: saco, sombra o manoplas."},
    {"id": "carrera-400", "nombre": "Carrera: 6 × 2 min rápido / 2 min trote", "tipo": "intervalos", "trabajo": 120, "descanso": 120, "rondas": 6, "prep": 10,
     "nota": "Intervalos de carrera por tiempo; ajusta el ritmo a tu zona 4."},
    {"id": "caminar-correr", "nombre": "Caminar/correr 1:00 / 1:30 × 8", "tipo": "intervalos", "trabajo": 60, "descanso": 90, "rondas": 8, "prep": 10,
     "nota": "Para empezar a correr de forma progresiva."},
    {"id": "plancha", "nombre": "Plancha 3 × 45 s (descanso 30 s)", "tipo": "intervalos", "trabajo": 45, "descanso": 30, "rondas": 3, "prep": 5,
     "nota": "Core isométrico."},
    {"id": "descanso-90", "nombre": "Descanso 90 s", "tipo": "regresiva", "trabajo": 90, "descanso": 0, "rondas": 1, "prep": 0,
     "nota": "Hipertrofia: 1–2 min entre series suele bastar (Schoenfeld 2016)."},
    {"id": "descanso-180", "nombre": "Descanso 3 min", "tipo": "regresiva", "trabajo": 180, "descanso": 0, "rondas": 1, "prep": 0,
     "nota": "Fuerza máxima: 3–5 min entre series pesadas."},
]
TIPOS = {"intervalos": "Intervalos", "emom": "EMOM", "amrap": "AMRAP", "fortime": "For Time", "boxeo": "Rounds de boxeo", "regresiva": "Cuenta regresiva"}


def _limpiar(x):
    """Valida un preset que viene del navegador."""
    try:
        t = x.get("tipo") if x.get("tipo") in TIPOS else "intervalos"
        p = {"id": str(x.get("id") or "")[:40] or None, "nombre": str(x.get("nombre") or "Mi temporizador")[:60], "tipo": t,
             "trabajo": max(1, min(7200, int(x.get("trabajo") or 30))), "descanso": max(0, min(3600, int(x.get("descanso") or 0))),
             "rondas": max(1, min(99, int(x.get("rondas") or 1))), "prep": max(0, min(60, int(x.get("prep") or 0))),
             "aviso": max(0, min(60, int(x.get("aviso") or 0))), "nota": str(x.get("nota") or "")[:200]}
    except (TypeError, ValueError):
        return None
    return p


def registrar(app, h):
    def cliente(cid):
        c = h.get_db().execute("SELECT * FROM usuarios WHERE id=? AND coach_id=?", (cid, g.user["id"])).fetchone()
        if not c:
            abort(404)
        return dict(c)

    @app.route("/herramientas", methods=["GET", "POST"])
    @app.route("/coach/cliente/<int:cid>/temporizadores", methods=["GET", "POST"])
    @h.login_required
    def herramientas(cid=None):
        target = cliente(cid) if cid else g.user
        p = h.perfil(target)
        campo = "temporizadores_coach" if cid else "temporizadores"
        if request.method == "POST":
            d = request.get_json(silent=True) or {}
            lista = [x for x in (_limpiar(y) for y in (d.get("presets") or [])[:30]) if x]
            for i, x in enumerate(lista):
                x["id"] = x["id"] or f"u{i}"
            p[campo] = lista
            h.guardar(target, "perfil", p)
            if cid:
                h.notif.avisar(h.get_db(), cid, "ajuste", "Tu entrenador te asignó temporizadores", ", ".join(x["nombre"] for x in lista[:3]),
                               url_for("herramientas"), g.user["id"])
                h.get_db().commit()
            return jsonify(ok=True, n=len(lista))
        return render_template("herramientas.html", base=PRESETS_BASE, mios=p.get("temporizadores") or [],
                               del_coach=p.get("temporizadores_coach") or [], TIPOS=TIPOS, cliente=target if cid else None,
                               inicial=request.args.get("preset"))

    @app.route("/api/v1/temporizadores", methods=["GET"])
    @h.api_auth()
    def api_temporizadores():
        p = h.perfil(g.user)
        return jsonify(ok=True, base=PRESETS_BASE, mios=p.get("temporizadores") or [], del_coach=p.get("temporizadores_coach") or [])
