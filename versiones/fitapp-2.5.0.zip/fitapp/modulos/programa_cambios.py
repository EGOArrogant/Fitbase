"""Cambios seguros al programa: cambiar de plantilla, reorganizar por días disponibles y convertir gimnasio ↔ casa.

Reglas (prompt maestro §6):
- Siempre se muestra una VISTA PREVIA con qué cambia y por qué; nada se aplica sin confirmar.
- Al reorganizar por días se CONSERVAN todos los ejercicios (no se borra ninguno en silencio) y no se duplican.
- Al convertir de equipo se conserva el músculo principal y el tipo de ejercicio (compuesto/aislamiento);
  si no hay equivalente, el ejercicio se mantiene y se avisa.
- Cada cambio guarda la versión anterior (programa_versiones) y se puede deshacer.
"""
import copy
import datetime as dt
import json

from flask import abort, flash, g, redirect, render_template, request, url_for

from data.contenido import PLANTILLAS
from data.ejercicios import EJERCICIOS

PIERNA = {"Cuádriceps", "Isquiotibiales", "Glúteo", "Pantorrilla"}
EMPUJE = {"Pecho", "Hombro", "Tríceps"}
TIRON = {"Espalda", "Bíceps"}
DIAS_SEMANA = {1: [0], 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 4, 5], 6: [0, 1, 2, 3, 4, 5]}
NOMBRE_DIA = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

DESTINOS = {
    "casa": ("Casa con mancuernas", {"Mancuernas", "Peso corporal", "Banda elástica", "Kettlebell"}),
    "mancuernas": ("Solo mancuernas y peso corporal", {"Mancuernas", "Peso corporal"}),
    "bandas": ("Bandas elásticas y peso corporal", {"Banda elástica", "Peso corporal"}),
    "peso_corporal": ("Solo peso corporal", {"Peso corporal"}),
    "gimnasio": ("Gimnasio completo", None),
}
# al pasar a gimnasio se prefieren equipos que permiten cargar más y progresar en pequeños incrementos
PREFERENCIA_GYM = ["Barra", "Máquina", "Polea", "Mancuernas", "Máquina Smith"]


def _grupo(ex):
    return (EJERCICIOS.get(ex) or {}).get("grupo", "Otros")


def _cat(ex):
    gr = _grupo(ex)
    return "pierna" if gr in PIERNA else "empuje" if gr in EMPUJE else "tiron" if gr in TIRON else "core"


# ---------------------------------------------------------------- 1. reorganizar por días
def reorganizar_dias(prog, n):
    """Redistribuye TODOS los ejercicios actuales en n días, sin duplicar ni borrar."""
    n = max(1, min(6, int(n)))
    todos = [copy.deepcopy(e) for d in prog["dias"] for e in d["ejercicios"]]
    vistos, unicos = set(), []
    for e in todos:                      # si el programa ya tenía repetidos (p. ej. A/B), se conserva una sola vez cada ejercicio
        if e["ex"] in vistos:
            continue
        vistos.add(e["ex"])
        unicos.append(e)
    por_cat = {c: [e for e in unicos if _cat(e["ex"]) == c] for c in ("pierna", "empuje", "tiron", "core")}
    if n <= 3:
        nombres = [f"Cuerpo completo {chr(65 + i)}" for i in range(n)]
        dias = [[] for _ in range(n)]
        k = 0
        for c in ("pierna", "empuje", "tiron", "core"):          # reparto en «abanico»: cada día recibe de todas las categorías
            for e in por_cat[c]:
                dias[k % n].append(e)
                k += 1
    else:
        torso = por_cat["empuje"] + por_cat["tiron"]
        pierna = por_cat["pierna"]
        tipos = ["torso" if i % 2 == 0 else "pierna" for i in range(n)]
        nt, npi = tipos.count("torso"), tipos.count("pierna")
        nombres, dias = [], []
        ct = cp = 0
        for t in tipos:
            if t == "torso":
                ct += 1
                nombres.append(f"Torso {chr(64 + ct)}")
            else:
                cp += 1
                nombres.append(f"Pierna {chr(64 + cp)}")
            dias.append([])
        idx_t = [i for i, t in enumerate(tipos) if t == "torso"]
        idx_p = [i for i, t in enumerate(tipos) if t == "pierna"]
        for j, e in enumerate(sorted(torso, key=lambda e: (_cat(e["ex"]), (EJERCICIOS.get(e["ex"]) or {}).get("tipo") != "Compuesto"))):
            dias[idx_t[j % nt]].append(e)
        for j, e in enumerate(pierna):
            dias[idx_p[j % npi]].append(e)
        for j, e in enumerate(por_cat["core"]):
            dias[min(range(n), key=lambda i: len(dias[i]))].append(e)
    # compuestos primero dentro de cada día
    for d in dias:
        d.sort(key=lambda e: (EJERCICIOS.get(e["ex"]) or {}).get("tipo") != "Compuesto")
    nuevo = copy.deepcopy(prog)
    nuevo["dias"] = [{"nombre": nombres[i], "dia": DIAS_SEMANA[n][i], "ejercicios": dias[i]} for i in range(n)]
    nuevo["dias_semana"] = n
    nuevo["nombre"] = f"Mi programa · {'cuerpo completo' if n <= 3 else 'torso/pierna'} · {n} días"
    return nuevo


# ---------------------------------------------------------------- 2. convertir equipo
def _sustituto(ex, permitidos, usados, a_gym=False):
    e = EJERCICIOS.get(ex)
    if not e:
        return None
    cand = []
    for x in EJERCICIOS.values():
        if x["nombre"] == ex or x["nombre"] in usados or x["targets"][0] != e["targets"][0]:
            continue
        if permitidos is not None and x["equipo"] not in permitidos:
            continue
        if a_gym and x["equipo"] not in PREFERENCIA_GYM:
            continue
        mismo_tipo = x["tipo"] == e["tipo"]
        comunes = len(set(x["targets"]) & set(e["targets"]))
        pref = PREFERENCIA_GYM.index(x["equipo"]) if a_gym and x["equipo"] in PREFERENCIA_GYM else 0
        cand.append((not mismo_tipo, -comunes, pref, x["nombre"]))
    return min(cand)[3] if cand else None


def convertir_equipo(prog, destino):
    _nombre, permitidos = DESTINOS[destino]
    a_gym = destino == "gimnasio"
    nuevo = copy.deepcopy(prog)
    cambios, sin_equiv = [], []
    for d in nuevo["dias"]:
        usados = {e["ex"] for e in d["ejercicios"]}
        for e in d["ejercicios"]:
            info = EJERCICIOS.get(e["ex"]) or {}
            if a_gym:
                necesita = info.get("equipo") not in PREFERENCIA_GYM and info.get("tipo") == "Compuesto"
            else:
                necesita = info.get("equipo") not in permitidos
            if not necesita:
                continue
            s = _sustituto(e["ex"], permitidos, usados, a_gym)
            if s:
                cambios.append((d["nombre"], e["ex"], s))
                usados.add(s)
                e["ex"] = s
            elif not a_gym:
                sin_equiv.append((d["nombre"], e["ex"]))
    return nuevo, cambios, sin_equiv


# ---------------------------------------------------------------- 3. cambiar plantilla conservando lo personalizado
def cambiar_plantilla(prog, clave, conservar=True):
    nuevo = copy.deepcopy(PLANTILLAS[clave])
    conservados = []
    if conservar:
        mios = [e["ex"] for d in prog["dias"] for e in d["ejercicios"]]
        base = {e["ex"] for pl in PLANTILLAS.values() for d in pl["dias"] for e in d["ejercicios"]}
        propios = [x for x in mios if x not in base]            # ejercicios que la persona eligió (no venían en ninguna plantilla)
        usados = set()
        for d in nuevo["dias"]:
            for e in d["ejercicios"]:
                m = (EJERCICIOS.get(e["ex"]) or {}).get("targets", [None])[0]
                for x in propios:
                    if x not in usados and (EJERCICIOS.get(x) or {}).get("targets", [None])[0] == m and x not in {y["ex"] for y in d["ejercicios"]}:
                        conservados.append((d["nombre"], e["ex"], x))
                        e["ex"] = x
                        usados.add(x)
                        break
    return nuevo, conservados


# ---------------------------------------------------------------- comparación antes/después
def diferencias(antes, despues):
    a = {e["ex"] for d in antes["dias"] for e in d["ejercicios"]}
    b = {e["ex"] for d in despues["dias"] for e in d["ejercicios"]}
    return {"quitados": sorted(a - b), "nuevos": sorted(b - a), "conservados": len(a & b),
            "dias_antes": len(antes["dias"]), "dias_despues": len(despues["dias"])}


def registrar(app, h):
    def propuesta(prog, p):
        tipo = request.values.get("tipo")
        motivo, extra = "", {}
        if tipo == "plantilla" and request.values.get("plantilla") in PLANTILLAS:
            conservar = request.values.get("conservar", "1") == "1"
            nuevo, conservados = cambiar_plantilla(prog, request.values["plantilla"], conservar)
            motivo = f"Cambio a la plantilla «{nuevo['nombre']}»" + (" conservando tus ejercicios elegidos" if conservados else "")
            extra = {"conservados": conservados, "conservar": conservar}
        elif tipo == "dias":
            n = int(h.calc.num(request.values.get("dias"), p.get("dias") or 3) or 3)
            nuevo = reorganizar_dias(prog, n)
            motivo = f"Reorganización a {n} días por semana"
            extra = {"n": n}
        elif tipo == "equipo" and request.values.get("destino") in DESTINOS:
            nuevo, cambios, sin_equiv = convertir_equipo(prog, request.values["destino"])
            motivo = f"Conversión a «{DESTINOS[request.values['destino']][0]}»"
            extra = {"cambios": cambios, "sin_equiv": sin_equiv}
        else:
            abort(400)
        for d in nuevo["dias"]:
            d["duracion"] = h.calc.duracion_sesion(d)
            d["series_total"] = sum(e["series"] for e in d["ejercicios"])
        return tipo, nuevo, motivo, extra

    @app.route("/programa/cambio", methods=["GET", "POST"])
    @h.login_required
    def programa_cambio():
        prog, p = h.programa(g.user), h.perfil(g.user)
        tipo, nuevo, motivo, extra = propuesta(prog, p)
        if request.method == "POST" and request.form.get("confirmar") == "1":
            nuevo.pop("_", None)
            for d in nuevo["dias"]:
                d.pop("duracion", None)
                d.pop("series_total", None)
            h.guardar_programa(g.user, nuevo, motivo, g.user["id"])
            if tipo == "dias":
                p["dias"] = extra["n"]
                p.pop("programa_nota", None)
                h.guardar(g.user, "perfil", p)
            if tipo == "equipo":
                p["equipo"] = DESTINOS[request.form["destino"]][0] if request.form["destino"] != "bandas" else p.get("equipo")
                h.guardar(g.user, "perfil", p)
            flash(motivo + " aplicada. Si no te convence, usa «Deshacer último cambio».", "ok")
            return redirect(url_for("programa_view"))
        for d in prog["dias"]:
            d["duracion"] = h.calc.duracion_sesion(d)
        return render_template("programa_cambio.html", tipo=tipo, antes=prog, despues=nuevo, motivo=motivo, extra=extra,
                               dif=diferencias(prog, nuevo), DESTINOS=DESTINOS, p=p, NOMBRE_DIA=NOMBRE_DIA, PLANTILLAS=PLANTILLAS)

    @app.route("/programa/deshacer", methods=["POST"])
    @h.login_required
    def programa_deshacer():
        con = h.get_db()
        v = con.execute("SELECT * FROM programa_versiones WHERE usuario_id=? AND motivo NOT LIKE 'Deshecho:%' ORDER BY id DESC LIMIT 1",
                        (g.user["id"],)).fetchone()
        if not v:
            flash("No hay cambios anteriores para deshacer.", "info")
            return redirect(url_for("programa_view"))
        actual = con.execute("SELECT programa FROM usuarios WHERE id=?", (g.user["id"],)).fetchone()[0]
        con.execute("UPDATE usuarios SET programa=? WHERE id=?", (v["programa"], g.user["id"]))
        con.execute("DELETE FROM programa_versiones WHERE id=?", (v["id"],))
        # el programa que se deshizo queda en el historial, para no perder nada
        con.execute("INSERT INTO programa_versiones (usuario_id, programa, motivo, autor_id, creado) VALUES (?,?,?,?,?)",
                    (g.user["id"], actual, f"Deshecho: {v['motivo']}", g.user["id"], dt.datetime.now().isoformat(timespec="seconds")))
        con.commit()
        flash(f"Se deshizo: {v['motivo']}.", "ok")
        return redirect(url_for("programa_view"))

    def versiones(uid):
        return [dict(x) for x in h.get_db().execute("SELECT id, motivo, creado FROM programa_versiones WHERE usuario_id=? ORDER BY id DESC LIMIT 8", (uid,)).fetchall()]
    app.jinja_env.globals["programa_versiones"] = versiones
    app.jinja_env.globals["DESTINOS_EQUIPO"] = DESTINOS
    registrar_historial(app, h)


# ---------------------------------------------------------------- historial del sondeo (solo lectura: las versiones nunca se editan)
ETIQUETAS_SONDEO = {"sexo": "Sexo", "edad": "Edad", "peso": "Peso (kg)", "talla": "Estatura (cm)", "nivel": "Nivel", "objetivo": "Objetivo",
                    "dias": "Días por semana", "duracion": "Minutos por sesión", "comidas": "Comidas al día", "actividad": "Actividad diaria",
                    "equipo": "Lugar / equipo", "condiciones": "Condiciones de salud", "parq": "PAR-Q+", "dieta_tipo": "Tipo de dieta",
                    "alergias": "Alergias", "intolerancias": "Intolerancias", "alergia_otra": "Otras alergias", "preferencias": "Preferencias",
                    "sondeo": "Respuestas del sondeo", "ingreso": "Ficha de ingreso"}


def _legible(v):
    if isinstance(v, bool):
        return "sí" if v else "no"
    if isinstance(v, list):
        return ", ".join(_legible(x) for x in v) if v else "—"
    if isinstance(v, dict):
        return "; ".join(f"{k}: {_legible(x)}" for k, x in v.items() if x not in (None, "", [], {}))
    return str(v)


def registrar_historial(app, h):
    @app.route("/sondeo/historial")
    @app.route("/coach/cliente/<int:cid>/sondeo/historial")
    @h.login_required
    def sondeo_historial(cid=None):
        target = h._cliente_de_coach(cid) if cid else g.user
        vs = [dict(x) for x in h.get_db().execute("SELECT * FROM sondeos WHERE usuario_id=? ORDER BY tipo, version", (target["id"],)).fetchall()]
        for v in vs:
            d = json.loads(v["datos"])
            v["filas"] = [(ETIQUETAS_SONDEO.get(k, k), _legible(x)) for k, x in d.items()]
        return render_template("sondeo_historial.html", vs=vs, cliente=target if cid else None)
