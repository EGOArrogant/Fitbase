"""Guía de uso: recorrido paso a paso (web, celular y app móvil vía API) y manual de cada apartado."""

# Manual de referencia: (grupo, [(endpoint, nombre, para qué sirve, cómo usarlo, solo_para)])
# solo_para: None = todos, "entrenador", "admin"
SECCIONES = [
    ("Empieza aquí", [
        ("dashboard", "Inicio", "Tu resumen del día: calorías, proteína, peso en tendencia, entrenamiento de hoy y avisos importantes.",
         "Ábrelo cada mañana. Si algo está en rojo, toca la tarjeta para ver qué hacer.", None),
        ("habitos", "Registro diario y hábitos", "Anota tu peso, pasos, sueño, energía y si entrenaste. Con esto la app calcula tu tendencia real.",
         "Pésate en ayunas 3-7 días por semana y registra aquí. No te preocupes por subidas de un día: lo que cuenta es la tendencia.", None),
        ("asistente_view", "Coach IA", "Pregunta lo que quieras sobre tu plan, tu dieta o un ejercicio. Responde con tus datos y con evidencia.",
         "Escribe como si hablaras con tu entrenador: «¿qué ceno si me faltan 40 g de proteína?».", None),
        ("sueno_view", "Sueño", "Duración, regularidad, calidad y deuda de sueño, con recomendaciones.",
         "Anota a qué hora te acuestas y te levantas en el registro diario; la duración se calcula sola.", None),
        ("bienestar", "Bienestar y salud mental", "Autoevaluaciones de bienestar, ánimo y ansiedad (WHO-5, PHQ-9, GAD-7), respiración guiada y relajación.",
         "Contesta cada 2 semanas. Es orientación, no diagnóstico; si lo necesitas, ahí mismo está la Línea de la Vida 800 911 2000.", None),
        ("notificaciones_view", "Notificaciones", "Avisos de tu entrenador, pagos, retos y recordatorios.",
         "La campana muestra cuántas tienes sin leer. Tócala para verlas y abrir cada una.", None),
    ]),
    ("Entrenamiento", [
        ("herramientas", "Cronómetros y relojes", "Cronómetro con vueltas, descansos, HIIT, Tabata, EMOM, AMRAP, For Time y rounds de boxeo. Funciona sin internet.",
         "Elige un temporizador listo o crea el tuyo. La pantalla no se apaga y te avisa con sonido y vibración.", None),
        ("calentamiento", "Calentamiento por deporte", "Calentamiento de 5 o 10 minutos (método RAMP) adaptado a tu deporte y nivel.",
         "Hazlo antes de cada sesión: también se abre desde «Sesión de hoy».", None),
        ("recuperacion", "Terminé: recuperación", "Registra tu sesión (cualquier deporte) y recibe indicaciones de recuperación por prioridad: hidratación, comida, descanso y sueño.",
         "Pésate antes y después de sesiones largas para saber cuánto líquido reponer.", None),
        ("programa_view", "Mi programa", "Tu rutina de la semana: días, ejercicios, series, repeticiones y esfuerzo (RIR).",
         "Síguela en orden. Puedes cambiar un ejercicio por un sustituto si no tienes el equipo.", None),
        ("plan_inteligente", "Mi plan inteligente", "Plan hecho con tu sondeo: nivel, objetivo, dolores y equipo disponible.",
         "Revísalo al empezar y cada vez que cambie tu situación (lesión, gimnasio nuevo, menos tiempo).", None),
        ("entrenar", "Entrenar hoy", "Arma una sesión al momento eligiendo los músculos que quieres trabajar.",
         "Toca los músculos en el mapa, elige el tiempo que tienes y la app te propone los ejercicios.", None),
        ("sesion_view", "Sesión de hoy", "Registra cada serie: peso, repeticiones y qué tan cerca quedaste del fallo.",
         "Anota al terminar cada serie. Con esto la app sube tus cargas al ritmo correcto y detecta estancamientos.", None),
        ("cuerpo", "Mapa muscular", "Toca un músculo y descubre qué hace y qué ejercicios lo trabajan.", "Útil para aprender o buscar alternativas.", None),
        ("ejercicios", "Ejercicios", "150 ejercicios con animación 3D, técnica, errores comunes y músculos que trabajan.",
         "Filtra por músculo o equipo. Antes de un ejercicio nuevo, mira la animación y los puntos clave.", None),
    ]),
    ("Nutrición", [
        ("nutricion", "Mi plan de nutrición", "Tus calorías y macros calculados para tu objetivo, con la explicación de cada número.",
         "Úsalo como meta diaria. Si tienes Pro, se ajusta solo cada semana según tu peso real.", None),
        ("registrar", "Registrar comida", "Anota lo que comes por texto, voz, foto o código de barras.",
         "Escribe «2 huevos y un pan tostado» o toma una foto del plato. Revisa las porciones y guarda.", None),
        ("diario", "Diario de comidas", "Todo lo que comiste por día, con calorías y macros por comida.", "Edita o borra alimentos si te equivocaste.", None),
        ("puntaje_nutricional", "Puntaje nutricional", "Califica tu alimentación y te dice exactamente lo que te falta (fibra, proteína, frutas…).",
         "Míralo en la noche: te sugiere qué agregar mañana.", None),
        ("menu_semanal", "Menú semanal", "Siete días de comidas que cuadran con tus macros y la lista del súper por pasillo.",
         "Genera el menú el fin de semana y descarga la lista de compras.", None),
        ("dieta_propia", "Dieta por equivalentes", "Plan de comidas por equivalentes (sistema mexicano), flexible para cambiar alimentos.", "Intercambia alimentos del mismo grupo sin salirte del plan.", None),
        ("recetas", "Recetas", "312 recetas con macros calculados.", "Filtra por tiempo de comida o por proteína y agrégalas a tu día.", None),
        ("alimentos_view", "Tabla de alimentos", "Calorías y nutrientes de alimentos comunes en México.", "Busca un alimento para comparar opciones.", None),
    ]),
    ("Tu progreso", [
        ("progreso", "Progreso", "Gráficas de peso, cargas, calorías y adherencia en el tiempo.", "Revísalo cada semana, no cada día.", None),
        ("mediciones", "Mediciones corporales", "Perímetros, pliegues, % de grasa, masa magra, somatotipo y proporcionalidad.",
         "Mídete cada 2-4 semanas, a la misma hora y con la misma técnica.", None),
        ("fotos_progreso", "Fotos de progreso", "Fotos privadas de frente, perfil y espalda para comparar lado a lado.", "Tómalas con la misma luz y ropa cada 2-4 semanas.", None),
        ("sondeo_avanzado", "Sondeo avanzado", "Tus marcas de fuerza, experiencia y objetivos de competencia; ubica tu nivel de novato a élite.",
         "Llénalo si ya entrenas: así las recomendaciones son de tu nivel.", None),
        ("descargas", "Mis descargas (PDF)", "Tu dieta, rutina, progreso y expediente en PDF.", "Descárgalos para imprimir o compartir con tu médico.", None),
    ]),
    ("Comunidad", [
        ("retos_view", "Retos y niveles", "Retos gratis y con premios; ganas puntos y subes de nivel (tiers).",
         "Inscríbete a un reto: tu avance se cuenta solo con lo que registras.", None),
        ("feedback_view", "Tu opinión", "Cuéntanos qué mejorar o qué te gustaría que agregáramos; vota ideas de otros.", "Escribe una idea concreta y vota las que te gusten.", None),
    ]),
    ("Para entrenadores", [
        ("coach", "Modo entrenador", "Panel de todos tus clientes con alertas de inactividad, adherencia y estancamiento.",
         "Empieza por los clientes con alerta roja. Toca un cliente para ver su expediente completo.", "entrenador"),
        ("coach_actividad", "Actividad en vivo", "Lo que hacen tus clientes al momento: comidas, series, peso, fotos, retos.",
         "Déjala abierta mientras trabajas: se actualiza sola. Filtra por cliente o por tipo.", "entrenador"),
        ("coach_invitar", "Invitar clientes", "Enlace o QR para que tu cliente llene su ficha de ingreso y quede en tu panel.",
         "Crea una invitación personal y mándala por WhatsApp.", "entrenador"),
        ("coach_retos", "Organizar retos", "Crea retos para tu comunidad, con cuota y premios si quieres.", "Define meta, fechas y premios; valida a los ganadores.", "entrenador"),
        ("coach_feedback", "Feedback de clientes", "Las opiniones de tus clientes y sus calificaciones.", "Responde para que sepan que los escuchas.", "entrenador"),
    ]),
    ("Cuenta y herramientas", [
        ("calculadoras", "Calculadoras", "Calorías, macros, 1RM y más, con la explicación de cada fórmula.", "Úsalas para comprobar o aprender.", None),
        ("articulos", "Artículos", "Más de 200 artículos con evidencia de los últimos años.", "Busca un tema cuando tengas una duda.", None),
        ("planes", "Planes", "Qué incluye Gratis, Pro y Coach, y cómo pagar con tarjeta, OXXO o transferencia.", "Todo lo esencial es gratis.", None),
        ("mis_pagos", "Mis pagos", "Tu plan, pedidos y recibos.", "Renueva aquí cuando se acerque el vencimiento.", None),
        ("ajustes", "Ajustes y mis datos", "Tema claro/oscuro, tus datos, exportar o borrar tu cuenta.", "Revisa que tus datos estén al día.", None),
        ("admin_panel", "Administración", "Usuarios, roles, planes de cortesía, pagos y actualizaciones.", "Solo para el dueño de la plataforma.", "admin"),
    ]),
]


def secciones_para(u):
    rol = "admin" if u and u.get("es_admin") else (u or {}).get("rol")
    out = []
    for grupo, items in SECCIONES:
        vis = [dict(endpoint=e, nombre=n, para=p, como=c) for e, n, p, c, solo in items
               if solo is None or (solo == "entrenador" and rol in ("entrenador", "admin")) or (solo == "admin" and rol == "admin")]
        if vis:
            out.append((grupo, vis))
    return out


def pasos(u, url_for, tr=lambda s: s):
    """Recorrido. 'sel' = elemento en computadora (menú lateral); 'tab' = elemento en celular (barra inferior / superior).
    Si en celular no hay 'tab', se abre el menú y se resalta el mismo elemento del menú."""
    nav = lambda ep: f'.side a.nav[href="{url_for(ep)}"]'
    rol = "admin" if u.get("es_admin") else u.get("rol")
    p = [
        dict(titulo=f"¡Hola, {u['nombre'].split(' ')[0]}! 👋", texto="Te enseñamos en un minuto para qué sirve cada apartado. Puedes salir cuando quieras y repetir esta guía desde «Guía de uso».", pantalla="inicio"),
        dict(sel=nav("dashboard"), tab='.tabbar a[href="%s"]' % url_for("dashboard"), titulo="Inicio",
             texto="Tu resumen del día: calorías, proteína, peso en tendencia y lo que toca entrenar hoy.", pantalla="inicio"),
        dict(sel=".side .cta", tab='.tabbar a[href="%s"]' % url_for("sesion_view"), titulo="Registrar tu entrenamiento",
             texto="Al terminar cada serie anota peso y repeticiones. Así tus cargas suben al ritmo correcto.", pantalla="entrenar"),
        dict(sel=nav("registrar"), tab=".tabbar .tab-cta", titulo="Registrar comida",
             texto="Escribe, dicta, toma foto o escanea el código de barras. En segundos queda en tu diario.", pantalla="registrar"),
        dict(sel=nav("habitos"), titulo="Registro diario", texto="Peso, pasos, sueño y energía. Con 3 a 7 pesajes por semana calculamos tu tendencia real.", pantalla="habitos"),
        dict(sel=nav("programa_view"), titulo="Tu entrenamiento", texto="Tu programa, tu plan inteligente, sesiones a la medida y 150 ejercicios con animación 3D.", pantalla="programa"),
        dict(sel=nav("nutricion"), tab='.tabbar a[href="%s"]' % url_for("diario"), titulo="Tu nutrición",
             texto="Calorías y macros para tu objetivo, diario, puntaje de lo que te falta, menú semanal y 312 recetas.", pantalla="nutricion"),
        dict(sel=nav("progreso"), titulo="Tu progreso", texto="Gráficas, mediciones con % de grasa y somatotipo, y fotos privadas para comparar.", pantalla="progreso"),
        dict(sel=nav("herramientas"), titulo="Cronómetros", texto="Descansos, HIIT, Tabata y rounds de boxeo con sonido y vibración.", pantalla="herramientas"),
        dict(sel=nav("bienestar"), titulo="Bienestar", texto="Revisa cómo te sientes, respira guiado y encuentra ayuda cuando la necesites.", pantalla="bienestar"),
        dict(sel=nav("retos_view"), titulo="Retos y niveles", texto="Únete a retos, gana puntos y sube de nivel. Tu avance se cuenta solo.", pantalla="retos"),
        dict(sel=nav("asistente_view"), tab='.topbar a[href="%s"]' % url_for("asistente_view"), titulo="Coach IA",
             texto="Pregúntale lo que sea sobre tu plan. Responde con tus propios datos.", pantalla="asistente"),
        dict(sel=".side [data-notif]", tab=".topbar [data-notif]", titulo="Notificaciones",
             texto="Aquí te avisamos de comentarios de tu entrenador, pagos, retos y recordatorios.", pantalla="notificaciones"),
    ]
    if rol in ("entrenador", "admin"):
        p += [
            dict(sel=nav("coach"), titulo="Modo entrenador", texto="Todos tus clientes con alertas: quién no ha registrado, quién se estancó, quién va muy bien.", pantalla="coach"),
            dict(sel=nav("coach_actividad"), titulo="Actividad en vivo", texto="Mira al momento lo que hacen tus clientes: comidas, series, peso y fotos. Se actualiza solo.", pantalla="coach_actividad"),
            dict(sel=nav("coach"), titulo="Guía de alta de cada cliente", texto="Al unirse un cliente te llega un aviso con 10 pasos (consentimientos, PAR-Q+, mediciones, programa, dieta, metas y cita). Se marcan solos.", pantalla="coach"),
            dict(sel=nav("coach_invitar"), titulo="Invita a tus clientes", texto="Mándales un enlace o QR: llenan su ficha y aparecen en tu panel.", pantalla="coach_invitar"),
        ]
    if rol == "admin":
        p.append(dict(sel=".side .nav-admin", titulo="Administración", texto="Usuarios, planes de cortesía, pagos y actualizaciones de la plataforma.", pantalla="admin"))
    p.append(dict(sel=".side [data-guia-abrir]", titulo="¿Se te olvidó algo?",
                  texto="Abre «Guía de uso» cuando quieras: ahí está para qué sirve cada apartado y puedes repetir este recorrido.", pantalla="guia"))
    for x in p:
        x["titulo"], x["texto"] = tr(x["titulo"]), tr(x["texto"])
    return p
